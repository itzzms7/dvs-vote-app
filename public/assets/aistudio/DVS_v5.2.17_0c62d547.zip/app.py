#!/usr/bin/env python3
"""
Decentralized Voting System (DVS) — Application Entrypoint.
Starts Gunicorn serving EVoting.wsgi:application on port 3000.
"""

import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "EVoting.settings")

from EVoting.wsgi import application  # noqa: F401
from gunicorn.app.wsgiapp import run


def get_port():
    """Resolve target port, defaulting to 3000 in AI Studio dev environment."""
    for arg in sys.argv[1:]:
        if arg.isdigit():
            return int(arg)
    if "DEFAULT_APP_PORT" in os.environ:
        return int(os.environ["DEFAULT_APP_PORT"])
    port = int(os.environ.get("PORT", "3000"))
    if port == 8080 and os.path.exists("/etc/nginx/nginx.conf"):
        return 3000
    return port


def main():
    port = get_port()
    workers = os.environ.get("GUNICORN_WORKERS", "2")
    timeout = os.environ.get("GUNICORN_TIMEOUT", "120")

    sys.argv = [
        "gunicorn",
        "EVoting.wsgi:application",
        f"--bind=0.0.0.0:{port}",
        f"--workers={workers}",
        f"--timeout={timeout}",
        "--access-logfile=-",
        "--error-logfile=-",
    ]
    run()


if __name__ == "__main__":
    main()
