#!/usr/bin/env bash
set -e

cd /app/applet

# 1. Self-healing Python dependencies check
if ! python3 -c "import django, psycopg2, web3, eth_account, webauthn, cryptography, cbor2" >/dev/null 2>&1; then
    echo "[DVS] Installing Python dependencies..."
    if ! command -v pip3 >/dev/null 2>&1; then
        DEBIAN_FRONTEND=noninteractive apt-get update -qq
        DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
            -o Dpkg::Options::="--force-confdef" \
            -o Dpkg::Options::="--force-confold" \
            python3-pip python3-setuptools python3-wheel
    fi
    python3 -m pip install -r requirements.txt --break-system-packages -q
fi

if [[ "${1:-}" == "--check-only" ]]; then
    exit 0
fi

# 2. Ensure smart contract artifacts exist
if [ ! -f "artifacts/blocks/contracts/EVoting.sol/EVoting.json" ] && [ -f "EVoting.json" ]; then
    mkdir -p artifacts/blocks/contracts/EVoting.sol
    cp -f EVoting.json artifacts/blocks/contracts/EVoting.sol/EVoting.json
fi

# 3. Clean up any stale process holding port 3000 so Django runserver can bind cleanly
python3 -c "
import os, signal, time
try:
    with open('/proc/net/tcp', 'r') as f:
        lines = f.readlines()
    inodes = set()
    for line in lines[1:]:
        parts = line.strip().split()
        if len(parts) >= 10:
            local_addr, state = parts[1], parts[3]
            if local_addr.endswith(':0BB8') and state == '0A':
                inodes.add(parts[9])
    if inodes:
        my_pid = str(os.getpid())
        for pid in [p for p in os.listdir('/proc') if p.isdigit() and p != my_pid]:
            try:
                fd_dir = os.path.join('/proc', pid, 'fd')
                for fd in os.listdir(fd_dir):
                    link = os.readlink(os.path.join(fd_dir, fd))
                    for inode in inodes:
                        if f'socket:[{inode}]' in link:
                            print(f'[DVS] Freeing port 3000 from stale process PID {pid}')
                            os.kill(int(pid), signal.SIGTERM)
            except Exception:
                pass
except Exception:
    pass
" 2>/dev/null || true

# Brief pause to ensure OS socket release
sleep 0.5

# 4. Apply migrations and ensure default Super Admin account is initialized
python3 manage.py migrate --noinput
python3 manage.py init_superuser --skip-if-missing

# 5. Start Django development server directly on 0.0.0.0:3000
echo "[DVS] Starting Django development server on 0.0.0.0:3000..."
exec python3 manage.py runserver 0.0.0.0:3000 --noreload
