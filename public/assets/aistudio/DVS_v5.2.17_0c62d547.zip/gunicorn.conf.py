"""
Gunicorn configuration for DVS.
Runs database migrations and superuser bootstrap asynchronously when ready.
"""

import os
import threading


def _run_startup_init():
    import django
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "EVoting.settings")
    django.setup()

    from django.conf import settings
    from django.core.management import call_command

    try:
        call_command("migrate", interactive=False, verbosity=0)
    except Exception as exc:
        print(f"[DVS Startup] Migration notice: {exc}")

    static_root = getattr(settings, "STATIC_ROOT", None)
    if static_root and (not os.path.isdir(static_root) or not os.listdir(static_root)):
        try:
            call_command("collectstatic", interactive=False, verbosity=0)
        except Exception as exc:
            print(f"[DVS Startup] collectstatic notice: {exc}")

    try:
        call_command("init_superuser", skip_if_missing=True)
    except Exception as exc:
        print(f"[DVS Startup] Superuser bootstrap notice: {exc}")

    if os.environ.get("DVS_SKIP_STARTUP_CHAIN_SYNC", "").strip().lower() not in ("1", "true", "yes"):
        try:
            from EVotingApp.hardhat_demo import ensure_idempotent_demo_election_ready
            election_id = int(getattr(settings, "ELECTION_ID", 2026))
            ensure_idempotent_demo_election_ready(election_id=election_id)
        except Exception as exc:
            print(f"[DVS Startup] Blockchain sync notice: {exc}")


def when_ready(server):
    """Invoked in Gunicorn master process once server socket is bound and listening."""
    if os.environ.get("DVS_SKIP_STARTUP_CHAIN_SYNC", "").strip().lower() in ("1", "true", "yes"):
        return
    threading.Thread(target=_run_startup_init, daemon=True, name="dvs-init").start()
