/**
 * DVS Node.js Server & Blockchain Gateway Adapter (CommonJS).
 * Serves HTML5 pages, static assets, and proxies JSON-RPC / Permit requests.
 */

const http = require('http');
const https = require('https');
const path = require('path');
const fs = require('fs');

const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = '0.0.0.0';
const REMOTE_GATEWAY = 'dvs-hardhat-blockchain-gateway.ai.studio';

console.log(`[DVS Server] Starting platform server on port ${PORT}...`);
console.log(`[DVS Server] Node.js version: ${process.version}`);
console.log(`[DVS Server] Working directory: ${process.cwd()}`);

// Template Renderer for Django HTML Templates
function renderDjangoTemplate(templateFileName, context = {}) {
  const templatesDir = path.join(process.cwd(), 'EVotingApp', 'templates');
  const basePath = path.join(templatesDir, 'base.html');
  const childPath = path.join(templatesDir, templateFileName);

  let baseHtml = fs.readFileSync(basePath, 'utf8');
  let childHtml = fs.readFileSync(childPath, 'utf8');

  // Extract blocks
  const blocks = {};
  const blockRegex = /\{%\s*block\s+([a-zA-Z0-9_]+)\s*%\}([\s\S]*?)\{%\s*endblock\s*%\}/g;
  let match;
  while ((match = blockRegex.exec(childHtml)) !== null) {
    blocks[match[1]] = match[2];
  }

  // Replace blocks in base template
  let rendered = baseHtml.replace(/\{%\s*block\s+([a-zA-Z0-9_]+)\s*%\}([\s\S]*?)\{%\s*endblock\s*%\}/g, (fullMatch, blockName, defaultContent) => {
    return blocks[blockName] !== undefined ? blocks[blockName] : defaultContent;
  });

  // Replace static tags
  rendered = rendered.replace(/\{%\s*static\s*['"](.*?)['"]\s*%\}/g, '/static/$1');

  // Replace url tags
  const urlMap = {
    'index': '/',
    'index_html': '/',
    'elections_directory': '/elections/',
    'public_elections': '/elections/',
    'vote_portal': '/vote/',
    'Vote': '/vote/',
    'control_portal': '/control/',
    'Admin': '/admin/',
    'admin_slash': '/admin/',
    'AdminLogin': '/AdminLogin',
    'AdminLogout': '/AdminLogout',
    'CastVote': '/vote/',
    'CastVoteAction': '/CastVoteAction',
    'ViewCount': '/ViewCount',
    'ViewCountAction': '/ViewCount',
    'election_detail_page': '/elections/1/',
  };

  rendered = rendered.replace(/\{%\s*url\s*['"]([a-zA-Z0-9_]+)['"]\s*(.*?)\s*%\}/g, (fullMatch, urlName, args) => {
    return urlMap[urlName] || '/';
  });

  // Replace csrf_token
  rendered = rendered.replace(/\{%\s*csrf_token\s*%\}/g, '<input type="hidden" name="csrfmiddlewaretoken" value="dvs_demo_csrf_token">');
  rendered = rendered.replace(/\{%\s*load\s+static\s*%\}/g, '');

  // Variable substitutions
  rendered = rendered.replace(/\{\{\s*election\.title\s*\}\}/g, context.electionTitle || 'General Election Demonstration 2026');
  rendered = rendered.replace(/\{\{\s*election\.election_id\s*\}\}/g, context.electionId || '1');
  rendered = rendered.replace(/\{\{\s*election\.description\s*\}\}/g, context.electionDesc || 'Civic election with on-chain ballot permits and transparent tally verification.');
  rendered = rendered.replace(/\{\{\s*election\.status\s*\}\}/g, 'ACTIVE');

  // Clean unparsed tags
  rendered = rendered.replace(/\{%\s*if\s+[\s\S]*?%\}/g, '');
  rendered = rendered.replace(/\{%\s*else\s*%\}/g, '');
  rendered = rendered.replace(/\{%\s*endif\s*%\}/g, '');
  rendered = rendered.replace(/\{%\s*for\s+[\s\S]*?%\}/g, '');
  rendered = rendered.replace(/\{%\s*endfor\s*%\}/g, '');

  return rendered;
}

const server = http.createServer((req, res) => {
  const url = req.url || '/';

  // Health Checks
  if (url.startsWith('/healthz') || url.startsWith('/api/health')) {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok', service: 'DVS', port: PORT, chain_id: 31337 }));
    return;
  }

  // Proxy Remote Blockchain Gateway Endpoints
  if (
    url.startsWith('/rpc') ||
    url.startsWith('/metadata') ||
    url.startsWith('/api/authority') ||
    url.startsWith('/api/faucet')
  ) {
    const options = {
      hostname: REMOTE_GATEWAY,
      port: 443,
      path: url,
      method: req.method,
      headers: { ...req.headers, host: REMOTE_GATEWAY },
    };
    const proxyReq = https.request(options, (proxyRes) => {
      res.writeHead(proxyRes.statusCode || 200, proxyRes.headers);
      proxyRes.pipe(res);
    });
    proxyReq.on('error', (err) => {
      res.writeHead(502, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: `Upstream gateway error: ${err.message}` }));
    });
    req.pipe(proxyReq);
    return;
  }

  // Wallet Status API
  if (url.startsWith('/api/wallet/status')) {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      authenticated: true,
      wallet: '0x3d050eD3cA4c5A85ABba756139c5f72FeCee1798',
      chain_id: 31337,
      rpc_url: `https://${REMOTE_GATEWAY}/rpc/`,
      contract_address: '0x3d050eD3cA4c5A85ABba756139c5f72FeCee1798'
    }));
    return;
  }

  // Public Elections API
  if (url.startsWith('/api/public/elections')) {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      elections: [
        {
          election_id: 1,
          title: 'General Election Demonstration 2026',
          status: 'ACTIVE',
          candidates_count: 3,
          contract_address: '0x3d050eD3cA4c5A85ABba756139c5f72FeCee1798'
        }
      ]
    }));
    return;
  }

  // Static Assets
  if (url.startsWith('/static/')) {
    const staticDir = path.join(process.cwd(), 'EVotingApp', 'static');
    const relPath = url.replace('/static/', '');
    const filePath = path.join(staticDir, relPath);

    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
      const ext = path.extname(filePath).toLowerCase();
      const mimeTypes = {
        '.css': 'text/css',
        '.js': 'application/javascript',
        '.json': 'application/json',
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.svg': 'image/svg+xml',
      };
      res.writeHead(200, { 'Content-Type': mimeTypes[ext] || 'text/plain' });
      fs.createReadStream(filePath).pipe(res);
      return;
    }
  }

  // HTML Page Views
  let templateName = 'index.html';
  if (url.startsWith('/elections')) {
    templateName = 'elections.html';
  } else if (url.startsWith('/vote')) {
    templateName = 'Vote.html';
  } else if (url.startsWith('/admin') || url.startsWith('/control')) {
    templateName = 'Admin.html';
  } else if (url.startsWith('/ViewCount')) {
    templateName = 'ViewCount.html';
  }

  try {
    const html = renderDjangoTemplate(templateName);
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
  } catch (err) {
    console.error(`[Render Error] ${err.message}`);
    res.writeHead(500, { 'Content-Type': 'text/plain' });
    res.end(`Render error: ${err.message}`);
  }
});

server.listen(PORT, HOST, () => {
  console.log(`[DVS Server] Server listening on http://${HOST}:${PORT}`);
});

process.on('SIGTERM', () => server.close(() => process.exit(0)));
process.on('SIGINT', () => server.close(() => process.exit(0)));
