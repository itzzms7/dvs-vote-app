#!/usr/bin/env bash
set -euo pipefail

cd /opt/dvs-hardhat-demo

# 1. Start Hardhat node bound strictly to loopback (127.0.0.1:8545) so raw admin RPC is not exposed
HARDHAT_DEMO_HOST="127.0.0.1" HARDHAT_DEMO_PORT="8545" bash scripts/hardhat_demo_ctl.sh start

# 2. Deploy and verify the EVoting contract on the fresh chain and record deployment metadata
bash scripts/hardhat_demo_ctl.sh deploy --election-id "${ELECTION_ID:-2026}"

# 3. Run the JSON-RPC Security Gateway on the external container port
export HARDHAT_GATEWAY_PORT="${PORT:-${HARDHAT_GATEWAY_PORT:-8546}}"
exec python3 scripts/hardhat_rpc_gateway.py
