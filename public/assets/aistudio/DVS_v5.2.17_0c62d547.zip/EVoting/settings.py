import os
import re
import logging
from urllib.parse import urlparse, parse_qs, unquote
from django.core.exceptions import ImproperlyConfigured

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _load_local_env_file(env_path):
    """Load simple KEY=VALUE entries from .env without overriding process variables."""
    if not os.path.isfile(env_path):
        return
    try:
        with open(env_path, 'r', encoding='utf-8-sig') as env_file:
            for raw_line in env_file:
                line = raw_line.strip()
                if not line or line.startswith('#') or '=' not in line:
                    continue
                key, value = line.split('=', 1)
                key = key.strip()
                value = value.strip()
                if not key or key in os.environ:
                    continue
                if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '\"'):
                    value = value[1:-1]
                os.environ[key] = value
    except OSError as exc:
        raise ImproperlyConfigured(f"Unable to read local environment file: {exc}") from exc


_load_local_env_file(os.path.join(BASE_DIR, '.env'))

# ==============================================================================
# DEVELOPMENT FALLBACK CONSTANTS (NEVER PERMITTED IN PRODUCTION)
# ==============================================================================
DEV_DEFAULT_SECRET_KEY = '2&9!$s=m=99l-t@t@!lb+eyub=z_1^12uxi)@nwcz*cd_!)=7a'
DEV_DEFAULT_AUTHORITY_PRIVATE_KEY = '0x4c0883a69102937d6231471b5dbb6204fe5129617082792ae468d01a3f362318'
DEV_DEFAULT_AUTHORITY_ADDRESS = '0xEe1BbC1BAf695c990ecb43e6Fd43d47060c12D58'
DEV_DEFAULT_NULLIFIER_PEPPER = 'dvs-secret-nullifier-pepper-2026-do-not-expose'
DEV_DEFAULT_ONBOARDING_KEY = 'dvs-onboarding-aes256-gcm-secret-key-material-2026'
DEV_DEFAULT_PROVIDER_SALT = 'dvs-provider-reference-hmac-salt-2026'

KNOWN_DEV_PRIVATE_KEYS = {
    DEV_DEFAULT_AUTHORITY_PRIVATE_KEY.lower(),
    DEV_DEFAULT_AUTHORITY_PRIVATE_KEY[2:].lower(),
    # Standard publicly known Hardhat mnemonic private keys (#0 through #9)
    '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80',
    'ac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80',
    '0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d',
    '59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d',
    '0x5de4111afa1a4b94908f83103eb1f1706367c2e68ca870fc3fb9a804cdab365a',
    '5de4111afa1a4b94908f83103eb1f1706367c2e68ca870fc3fb9a804cdab365a',
    '0x7c852118294e51e653712a81e05800f419141751be58f605c371e15141b007a6',
    '7c852118294e51e653712a81e05800f419141751be58f605c371e15141b007a6',
    '0x47e179ec197488593b187f80a00eb0da91f1b9d0b13f8733639f19c30a34926a',
    '47e179ec197488593b187f80a00eb0da91f1b9d0b13f8733639f19c30a34926a',
    '0x8b3a350cf5c34c9194ca85829a2df0ec3153be0318b5e2d3348e872092edffba',
    '8b3a350cf5c34c9194ca85829a2df0ec3153be0318b5e2d3348e872092edffba',
    '0x92db14e403b83dfe3df233f83dfa3a0d7096f21ca9b0d6d6b8d88b2b4ec1564e',
    '92db14e403b83dfe3df233f83dfa3a0d7096f21ca9b0d6d6b8d88b2b4ec1564e',
    '0x4bbbf85ce3377467afe5d46f804f221813b2bb87f24d81f60f1fcdbf7cbf4356',
    '4bbbf85ce3377467afe5d46f804f221813b2bb87f24d81f60f1fcdbf7cbf4356',
    '0xdbda1821b80551c9d65939329250298aa3472ba22feea921c0cf5d620ea67b97',
    'dbda1821b80551c9d65939329250298aa3472ba22feea921c0cf5d620ea67b97',
    '0x2a871d0798f97d79848a013d4936a73bf4cc922c825d33c1cf7073dff6d409c6',
    '2a871d0798f97d79848a013d4936a73bf4cc922c825d33c1cf7073dff6d409c6',
}

KNOWN_PUBLIC_HARDHAT_ADDRESSES = {
    '0xf39fd6e51aad88f6f4ce6ab8827279cfffb92266',  # Hardhat #0
    '0x70997970c51812dc3a010c7d01b50e0d17dc79c8',  # Hardhat #1
    '0x3c44cdddb6a900fa2b585dd299e03d12fa4293bc',  # Hardhat #2
    '0x90f79bf6eb2c4f870365e785982e1f101e93b906',  # Hardhat #3
    '0x15d34aaf54267db7d7c367839aaf71a00a2c6a65',  # Hardhat #4
    '0x9965507d1a55bcc2695c58ba16fb37d819b0a4dc',  # Hardhat #5
    '0x976ea74026e726554db657fa54763abd0c3a0aa9',  # Hardhat #6
    '0x14dc79964da2c08b23698b3d3cc7ca32193d9955',  # Hardhat #7
    '0x23618e81e3f5cdf7f54c3d65f7fbc0abf5b21e8f',  # Hardhat #8
    '0xa0ee7a142d267c1f36714e4a8f75612f20a79720',  # Hardhat #9
}

HEX_PRIVATE_KEY_RE = re.compile(r'^(0x)?[0-9a-fA-F]{64}$')
ETH_ADDRESS_RE = re.compile(r'^0x[0-9a-fA-F]{40}$')
LOG_PRIVATE_KEY_PATTERN = re.compile(r'0x[0-9a-fA-F]{64}')


class RedactSecretsFilter(logging.Filter):
    """
    Logging filter that prevents accidental leakage of 32-byte hexadecimal private keys
    or sensitive secret material into application logs.
    """
    def filter(self, record):
        if isinstance(record.msg, str):
            record.msg = LOG_PRIVATE_KEY_PATTERN.sub('[REDACTED_PRIVATE_KEY]', record.msg)
        if record.args:
            if isinstance(record.args, dict):
                record.args = {
                    k: (LOG_PRIVATE_KEY_PATTERN.sub('[REDACTED_PRIVATE_KEY]', v) if isinstance(v, str) else v)
                    for k, v in record.args.items()
                }
            elif isinstance(record.args, tuple):
                record.args = tuple(
                    LOG_PRIVATE_KEY_PATTERN.sub('[REDACTED_PRIVATE_KEY]', a) if isinstance(a, str) else a
                    for a in record.args
                )
        return True


def _parse_bool(value, default=False):
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    s = str(value).strip().lower()
    if s in ('true', '1', 'yes', 'on'):
        return True
    if s in ('false', '0', 'no', 'off'):
        return False
    raise ImproperlyConfigured(f"Invalid boolean configuration value: '{value}'.")


def _parse_int(value, name, minimum=None):
    try:
        ival = int(str(value).strip())
    except (TypeError, ValueError):
        raise ImproperlyConfigured(f"Configuration '{name}' must be a valid integer.")
    if minimum is not None and ival < minimum:
        raise ImproperlyConfigured(f"Configuration '{name}' must be >= {minimum}.")
    return ival


def _validate_private_key_format(raw_key, key_name, is_production=False):
    """
    Validate a 32-byte hexadecimal private key without ever including the raw key
    in exception messages or logs. Returns normalized '0x'-prefixed hex string and derived address.
    """
    if not raw_key or not str(raw_key).strip():
        raise ImproperlyConfigured(f"{key_name} is required and cannot be empty.")
    clean = str(raw_key).strip()
    hex_body = clean[2:] if clean.startswith(('0x', '0X')) else clean
    if len(hex_body) == 63 and all(c in '0123456789abcdefABCDEF' for c in hex_body):
        hex_body = '0' + hex_body
    clean = '0x' + hex_body
    if 'replace-with' in clean.lower() or not HEX_PRIVATE_KEY_RE.match(clean):
        raise ImproperlyConfigured(
            f"{key_name} has an invalid format (expected a 32-byte hexadecimal private key)."
        )
    normalized = '0x' + clean[2:].lower()
    if is_production and normalized.lower() in KNOWN_DEV_PRIVATE_KEYS:
        raise ImproperlyConfigured(
            f"{key_name} cannot use a known public development/Hardhat key in production."
        )
    try:
        from eth_account import Account
        derived_address = Account.from_key(normalized).address
    except Exception:
        raise ImproperlyConfigured(f"{key_name} could not be decoded as a valid secp256k1 private key.")
    return normalized, derived_address


def parse_database_configuration(env=None, base_dir=BASE_DIR):
    """
    Parse database configuration from environment variables.
    - Preserves SQLite (`db.sqlite3`) by default for local development.
    - Supports PostgreSQL via `DATABASE_URL` or explicit `DB_ENGINE`/`DB_*` variables,
      including Cloud SQL Unix domain sockets (`/cloudsql/project:region:instance`).
    """
    if env is None:
        env = os.environ

    database_url = str(env.get('DATABASE_URL', '')).strip()
    if database_url:
        parsed = urlparse(database_url)
        scheme = (parsed.scheme or '').lower()

        if scheme in ('postgres', 'postgresql', 'pgsql'):
            db_name = unquote(parsed.path.lstrip('/'))
            db_user = unquote(parsed.username or '')
            db_password = unquote(parsed.password or '')
            db_host = unquote(parsed.hostname or '')
            db_port = str(parsed.port or '')

            query_params = parse_qs(parsed.query)
            if 'host' in query_params and query_params['host']:
                db_host = query_params['host'][0]

            if not db_name:
                raise ImproperlyConfigured("DATABASE_URL for PostgreSQL must specify a database name.")
            if not db_user:
                raise ImproperlyConfigured("DATABASE_URL for PostgreSQL must specify a database user.")

            conn_max_age = _parse_int(env.get('DB_CONN_MAX_AGE', '60'), 'DB_CONN_MAX_AGE', minimum=0)
            options = {'connect_timeout': 10}
            sslmode = (
                query_params.get('sslmode', [None])[0]
                or env.get('DB_SSLMODE', '').strip()
            )
            if sslmode:
                options['sslmode'] = sslmode

            return {
                'default': {
                    'ENGINE': 'django.db.backends.postgresql',
                    'NAME': db_name,
                    'USER': db_user,
                    'PASSWORD': db_password,
                    'HOST': db_host or 'localhost',
                    'PORT': '' if db_host.startswith('/cloudsql/') else (db_port or '5432'),
                    'CONN_MAX_AGE': conn_max_age,
                    'CONN_HEALTH_CHECKS': True,
                    'OPTIONS': options,
                }
            }

        elif scheme in ('sqlite', 'sqlite3'):
            raw_path = unquote(parsed.path or '')
            if raw_path in ('', '/', '/:memory:', ':memory:'):
                db_path = ':memory:'
            elif raw_path.startswith('//'):
                db_path = raw_path[1:]
            else:
                db_path = os.path.join(base_dir, raw_path.lstrip('/'))
            return {
                'default': {
                    'ENGINE': 'django.db.backends.sqlite3',
                    'NAME': db_path,
                    'OPTIONS': {'timeout': 20},
                }
            }
        else:
            raise ImproperlyConfigured(
                f"Unsupported DATABASE_URL scheme '{scheme}'. Supported schemes: postgresql, sqlite."
            )

    raw_engine = str(env.get('DB_ENGINE', 'sqlite3')).strip().lower()
    if raw_engine in ('postgresql', 'postgres', 'pgsql', 'django.db.backends.postgresql', 'django.db.backends.postgresql_psycopg2'):
        db_name = str(env.get('DB_NAME') or env.get('POSTGRES_DB') or '').strip()
        db_user = str(env.get('DB_USER') or env.get('POSTGRES_USER') or '').strip()
        db_password = str(env.get('DB_PASSWORD') or env.get('POSTGRES_PASSWORD') or '')
        db_host = str(env.get('DB_HOST') or env.get('POSTGRES_HOST') or 'localhost').strip()
        db_port = str(env.get('DB_PORT') or env.get('POSTGRES_PORT') or '5432').strip()
        conn_max_age = _parse_int(env.get('DB_CONN_MAX_AGE', '60'), 'DB_CONN_MAX_AGE', minimum=0)

        if not db_name:
            raise ImproperlyConfigured("PostgreSQL configuration requires DB_NAME (or POSTGRES_DB).")
        if not db_user:
            raise ImproperlyConfigured("PostgreSQL configuration requires DB_USER (or POSTGRES_USER).")

        options = {'connect_timeout': 10}
        sslmode = str(env.get('DB_SSLMODE', '')).strip()
        if sslmode:
            options['sslmode'] = sslmode

        return {
            'default': {
                'ENGINE': 'django.db.backends.postgresql',
                'NAME': db_name,
                'USER': db_user,
                'PASSWORD': db_password,
                'HOST': db_host,
                'PORT': '' if db_host.startswith('/cloudsql/') else db_port,
                'CONN_MAX_AGE': conn_max_age,
                'CONN_HEALTH_CHECKS': True,
                'OPTIONS': options,
            }
        }

    elif raw_engine in ('sqlite', 'sqlite3', 'django.db.backends.sqlite3', ''):
        sqlite_path = str(env.get('SQLITE_DB_PATH', '')).strip()
        if not sqlite_path:
            sqlite_path = os.path.join(base_dir, 'db.sqlite3')
        elif not os.path.isabs(sqlite_path) and sqlite_path != ':memory:':
            sqlite_path = os.path.join(base_dir, sqlite_path)
        return {
            'default': {
                'ENGINE': 'django.db.backends.sqlite3',
                'NAME': sqlite_path,
                'OPTIONS': {'timeout': 20},
            }
        }

    else:
        raise ImproperlyConfigured(
            f"Unsupported DB_ENGINE '{raw_engine}'. Supported engines: sqlite3, postgresql."
        )


def validate_and_load_settings(env=None, base_dir=BASE_DIR):
    """
    Validate and construct the complete Django configuration dictionary from `env`.
    Enforces strict production security checks when `DJANGO_ENV=production` or `DJANGO_DEBUG=False`,
    while keeping local development and test execution seamless.
    """
    if env is None:
        env = os.environ

    django_env = str(env.get('DJANGO_ENV', 'development')).strip().lower()
    if django_env not in ('development', 'production', 'staging', 'test'):
        raise ImproperlyConfigured(
            f"Invalid DJANGO_ENV '{django_env}'. Expected one of: development, production, staging, test."
        )

    if 'DJANGO_DEBUG' in env:
        debug = _parse_bool(env.get('DJANGO_DEBUG'))
    elif 'DEBUG' in env:
        debug = _parse_bool(env.get('DEBUG'))
    else:
        debug = django_env not in ('production', 'staging')

    if django_env == 'production' and debug:
        raise ImproperlyConfigured("DEBUG cannot be True when DJANGO_ENV is set to 'production'.")

    is_production = (django_env in ('production', 'staging')) or (not debug)

    # 1. Secret Key validation
    raw_secret_key = env.get('DJANGO_SECRET_KEY')
    if is_production:
        if not raw_secret_key or not str(raw_secret_key).strip():
            raise ImproperlyConfigured("DJANGO_SECRET_KEY must be explicitly set in production.")
        clean_secret = str(raw_secret_key).strip()
        if (
            clean_secret == DEV_DEFAULT_SECRET_KEY
            or clean_secret.startswith('django-insecure-')
            or 'replace-with' in clean_secret.lower()
            or len(clean_secret) < 32
        ):
            raise ImproperlyConfigured(
                "DJANGO_SECRET_KEY in production must be a strong secret (at least 32 characters) and not a default placeholder."
            )
        secret_key = clean_secret
    else:
        secret_key = str(raw_secret_key).strip() if (raw_secret_key and str(raw_secret_key).strip()) else DEV_DEFAULT_SECRET_KEY

    # 2. ALLOWED_HOSTS validation (with Render RENDER_EXTERNAL_HOSTNAME support)
    render_external_hostname = str(env.get('RENDER_EXTERNAL_HOSTNAME', '') or '').strip()
    raw_allowed_hosts = env.get('DJANGO_ALLOWED_HOSTS') if 'DJANGO_ALLOWED_HOSTS' in env else env.get('ALLOWED_HOSTS')
    if (not raw_allowed_hosts or not str(raw_allowed_hosts).strip()) and render_external_hostname:
        raw_allowed_hosts = render_external_hostname
    if is_production:
        if not raw_allowed_hosts or not str(raw_allowed_hosts).strip():
            raise ImproperlyConfigured(
                "DJANGO_ALLOWED_HOSTS (or ALLOWED_HOSTS / RENDER_EXTERNAL_HOSTNAME) must be explicitly configured in production."
            )
        allowed_hosts = [h.strip() for h in str(raw_allowed_hosts).split(',') if h.strip()]
        if not allowed_hosts:
            raise ImproperlyConfigured("ALLOWED_HOSTS cannot be empty in production.")
        allow_wildcard = _parse_bool(env.get('ALLOW_WILDCARD_HOSTS_IN_PRODUCTION', 'False'))
        if '*' in allowed_hosts and not allow_wildcard:
            raise ImproperlyConfigured(
                "Wildcard '*' is not permitted in ALLOWED_HOSTS in production."
            )
        if render_external_hostname and render_external_hostname not in allowed_hosts:
            allowed_hosts.append(render_external_hostname)
    else:
        if raw_allowed_hosts and str(raw_allowed_hosts).strip():
            allowed_hosts = [h.strip() for h in str(raw_allowed_hosts).split(',') if h.strip()]
            if render_external_hostname and render_external_hostname not in allowed_hosts:
                allowed_hosts.append(render_external_hostname)
        else:
            allowed_hosts = ['*']

    # 3. CSRF_TRUSTED_ORIGINS validation (with Render HTTPS origin support)
    raw_csrf_origins = (
        env.get('DJANGO_CSRF_TRUSTED_ORIGINS')
        if 'DJANGO_CSRF_TRUSTED_ORIGINS' in env
        else env.get('CSRF_TRUSTED_ORIGINS')
    )
    if raw_csrf_origins and str(raw_csrf_origins).strip():
        csrf_trusted_origins = [o.strip() for o in str(raw_csrf_origins).split(',') if o.strip()]
        if is_production and not _parse_bool(env.get('ALLOW_HTTP_CSRF_IN_PRODUCTION', 'False')):
            for origin in csrf_trusted_origins:
                if not origin.startswith('https://'):
                    raise ImproperlyConfigured(
                        f"CSRF_TRUSTED_ORIGINS entry '{origin}' must use https:// in production."
                    )
    else:
        if is_production:
            csrf_trusted_origins = ['https://*.run.app', 'https://*.onrender.com']
        else:
            csrf_trusted_origins = [
                'http://localhost:3000',
                'http://127.0.0.1:3000',
                'https://*.run.app',
                'https://*.onrender.com',
                'https://*.ai.studio',
            ]
    if render_external_hostname:
        render_csrf_origin = f"https://{render_external_hostname}"
        if render_csrf_origin not in csrf_trusted_origins:
            csrf_trusted_origins.append(render_csrf_origin)

    # 4. Database configuration
    databases = parse_database_configuration(env=env, base_dir=base_dir)

    # 5. Blockchain & Cryptographic configuration (supports DVS_BLOCKCHAIN_BASE_URL derivation)
    raw_blockchain_base = str(env.get('DVS_BLOCKCHAIN_BASE_URL', '') or '').strip().rstrip('/')
    if raw_blockchain_base:
        if not raw_blockchain_base.startswith(('http://', 'https://')):
            raise ImproperlyConfigured("DVS_BLOCKCHAIN_BASE_URL must start with http:// or https://.")
        parsed_base = urlparse(raw_blockchain_base)
        if parsed_base.username or parsed_base.password:
            raise ImproperlyConfigured("DVS_BLOCKCHAIN_BASE_URL cannot embed URL credentials.")

    raw_rpc_url = env.get('WEB3_RPC_URL')
    if (not raw_rpc_url or not str(raw_rpc_url).strip()) and raw_blockchain_base:
        raw_rpc_url = f"{raw_blockchain_base}/rpc/"

    require_https_rpc = _parse_bool(env.get('REQUIRE_HTTPS_RPC', 'True' if is_production else 'False'))
    allow_local_rpc = _parse_bool(env.get('ALLOW_LOCAL_RPC_IN_PRODUCTION', 'False'))
    if is_production:
        if not raw_rpc_url or not str(raw_rpc_url).strip():
            raise ImproperlyConfigured(
                "WEB3_RPC_URL (or DVS_BLOCKCHAIN_BASE_URL) must be explicitly configured in production."
            )
        web3_rpc_url = str(raw_rpc_url).strip()
        if not web3_rpc_url.startswith(('http://', 'https://', 'ws://', 'wss://')):
            raise ImproperlyConfigured("WEB3_RPC_URL must start with http://, https://, ws://, or wss://.")
        parsed_rpc = urlparse(web3_rpc_url)
        rpc_host = (parsed_rpc.hostname or '').lower()
        if rpc_host in ('127.0.0.1', 'localhost', '::1'):
            if not allow_local_rpc:
                raise ImproperlyConfigured(
                    "WEB3_RPC_URL cannot point to 127.0.0.1 or localhost in production."
                )
        else:
            if not web3_rpc_url.startswith(('https://', 'wss://')):
                raise ImproperlyConfigured(
                    "Remote WEB3_RPC_URL must use https:// or wss:// in production."
                )
    else:
        web3_rpc_url = str(raw_rpc_url).strip() if (raw_rpc_url and str(raw_rpc_url).strip()) else 'http://127.0.0.1:8545'
        if not web3_rpc_url.startswith(('http://', 'https://', 'ws://', 'wss://')):
            raise ImproperlyConfigured("WEB3_RPC_URL must start with http://, https://, ws://, or wss://.")
        parsed_rpc = urlparse(web3_rpc_url)
        rpc_host = (parsed_rpc.hostname or '').lower()
        if require_https_rpc and rpc_host not in ('127.0.0.1', 'localhost', '::1'):
            if not web3_rpc_url.startswith(('https://', 'wss://')):
                raise ImproperlyConfigured(
                    "Remote WEB3_RPC_URL must use https:// or wss:// when REQUIRE_HTTPS_RPC=True."
                )

    raw_metamask_rpc = str(env.get('METAMASK_RPC_URL', '') or '').strip()
    if raw_metamask_rpc:
        if not raw_metamask_rpc.startswith(('http://', 'https://', 'ws://', 'wss://')):
            raise ImproperlyConfigured("METAMASK_RPC_URL must start with http://, https://, ws://, or wss://.")
        parsed_mm = urlparse(raw_metamask_rpc)
        if parsed_mm.username or parsed_mm.password:
            raise ImproperlyConfigured("METAMASK_RPC_URL cannot embed URL credentials.")
        metamask_rpc_url = raw_metamask_rpc
    elif raw_blockchain_base:
        metamask_rpc_url = f"{raw_blockchain_base}/rpc/"
    else:
        parsed_default_mm = urlparse(web3_rpc_url)
        port_part = f":{parsed_default_mm.port}" if parsed_default_mm.port else ""
        metamask_rpc_url = f"{parsed_default_mm.scheme}://{parsed_default_mm.hostname}{port_part}{parsed_default_mm.path or ''}"

    if raw_blockchain_base:
        blockchain_base_url = raw_blockchain_base
    else:
        parsed_rpc_base = urlparse(web3_rpc_url)
        port_part = f":{parsed_rpc_base.port}" if parsed_rpc_base.port else ""
        http_scheme = 'https' if parsed_rpc_base.scheme in ('https', 'wss') else 'http'
        blockchain_base_url = f"{http_scheme}://{parsed_rpc_base.hostname}{port_part}"

    blockchain_health_url = str(env.get('BLOCKCHAIN_HEALTH_URL', '') or '').strip() or f"{blockchain_base_url}/healthz/"
    blockchain_metadata_url = str(env.get('BLOCKCHAIN_METADATA_URL', '') or '').strip() or f"{blockchain_base_url}/metadata"

    hardhat_backend_rpc_token = str(env.get('HARDHAT_BACKEND_RPC_TOKEN', '') or '').strip() or None

    web3_rpc_timeout = _parse_int(env.get('WEB3_RPC_TIMEOUT_SECONDS', '10'), 'WEB3_RPC_TIMEOUT_SECONDS', minimum=1)
    chain_id = _parse_int(env.get('CHAIN_ID', '31337'), 'CHAIN_ID', minimum=1)
    election_id = _parse_int(env.get('ELECTION_ID', '1'), 'ELECTION_ID', minimum=1)

    raw_contract_addr = str(env.get('CONTRACT_ADDRESS', '') or '').strip()
    if not raw_contract_addr:
        dep_meta_path = os.path.join(base_dir, 'deployments', 'hardhat_demo_deployment.json')
        if os.path.exists(dep_meta_path):
            try:
                import json
                with open(dep_meta_path, 'r', encoding='utf-8') as f:
                    dep_meta = json.load(f)
                cand_addr = str(dep_meta.get('contract_address', '') or '').strip()
                if ETH_ADDRESS_RE.match(cand_addr):
                    raw_contract_addr = cand_addr
            except Exception:
                pass
    if not raw_contract_addr:
        raw_contract_addr = '0x3d050eD3cA4c5A85ABba756139c5f72FeCee1798'
    if raw_contract_addr and not ETH_ADDRESS_RE.match(raw_contract_addr):
        raise ImproperlyConfigured("CONTRACT_ADDRESS must be a valid 20-byte hexadecimal Ethereum address.")
    contract_address = raw_contract_addr

    # Authority private key & address
    raw_auth_key = env.get('ELECTION_AUTHORITY_PRIVATE_KEY')
    if is_production:
        if not raw_auth_key or not str(raw_auth_key).strip():
            raise ImproperlyConfigured("ELECTION_AUTHORITY_PRIVATE_KEY must be explicitly configured in production.")
        authority_private_key, derived_auth_addr = _validate_private_key_format(
            raw_auth_key, 'ELECTION_AUTHORITY_PRIVATE_KEY', is_production=True
        )
    else:
        key_to_use = raw_auth_key if (raw_auth_key and str(raw_auth_key).strip()) else DEV_DEFAULT_AUTHORITY_PRIVATE_KEY
        authority_private_key, derived_auth_addr = _validate_private_key_format(
            key_to_use, 'ELECTION_AUTHORITY_PRIVATE_KEY', is_production=False
        )

    raw_auth_addr = str(env.get('ELECTION_AUTHORITY_ADDRESS', '')).strip()
    if raw_auth_addr and raw_auth_addr != '0x0000000000000000000000000000000000000000':
        if not ETH_ADDRESS_RE.match(raw_auth_addr):
            raise ImproperlyConfigured("ELECTION_AUTHORITY_ADDRESS must be a valid Ethereum address.")
        if raw_auth_addr.lower() != derived_auth_addr.lower():
            raise ImproperlyConfigured(
                "ELECTION_AUTHORITY_ADDRESS does not match the address derived from ELECTION_AUTHORITY_PRIVATE_KEY."
            )
        authority_address = derived_auth_addr
    else:
        authority_address = derived_auth_addr

    # Optional Blockchain Deployer Private Key (used when signing raw deployment/lifecycle transactions)
    raw_deployer_key = env.get('BLOCKCHAIN_DEPLOYER_PRIVATE_KEY')
    if raw_deployer_key and str(raw_deployer_key).strip():
        deployer_private_key, deployer_address = _validate_private_key_format(
            raw_deployer_key, 'BLOCKCHAIN_DEPLOYER_PRIVATE_KEY', is_production=is_production
        )
    else:
        deployer_private_key = None
        deployer_address = None

    # Cryptographic salts & peppers
    raw_pepper = env.get('ELECTION_NULLIFIER_PEPPER')
    if is_production:
        if (
            not raw_pepper
            or not str(raw_pepper).strip()
            or str(raw_pepper).strip() == DEV_DEFAULT_NULLIFIER_PEPPER
            or 'replace-with' in str(raw_pepper).lower()
            or len(str(raw_pepper).strip()) < 16
        ):
            raise ImproperlyConfigured(
                "ELECTION_NULLIFIER_PEPPER must be explicitly set to a strong secret in production."
            )
        nullifier_pepper = str(raw_pepper).strip()
    else:
        nullifier_pepper = str(raw_pepper).strip() if (raw_pepper and str(raw_pepper).strip()) else DEV_DEFAULT_NULLIFIER_PEPPER

    raw_onboarding_key = env.get('ONBOARDING_ENCRYPTION_KEY')
    if is_production:
        if (
            not raw_onboarding_key
            or not str(raw_onboarding_key).strip()
            or str(raw_onboarding_key).strip() == DEV_DEFAULT_ONBOARDING_KEY
            or 'replace-with' in str(raw_onboarding_key).lower()
            or len(str(raw_onboarding_key).strip()) < 16
        ):
            raise ImproperlyConfigured(
                "ONBOARDING_ENCRYPTION_KEY must be explicitly set to a strong secret in production."
            )
        onboarding_encryption_key = str(raw_onboarding_key).strip()
    else:
        onboarding_encryption_key = (
            str(raw_onboarding_key).strip()
            if (raw_onboarding_key and str(raw_onboarding_key).strip())
            else DEV_DEFAULT_ONBOARDING_KEY
        )

    raw_provider_salt = env.get('PROVIDER_REFERENCE_SALT')
    if is_production:
        if (
            not raw_provider_salt
            or not str(raw_provider_salt).strip()
            or str(raw_provider_salt).strip() == DEV_DEFAULT_PROVIDER_SALT
            or 'replace-with' in str(raw_provider_salt).lower()
            or len(str(raw_provider_salt).strip()) < 16
        ):
            raise ImproperlyConfigured(
                "PROVIDER_REFERENCE_SALT must be explicitly set to a strong secret in production."
            )
        provider_reference_salt = str(raw_provider_salt).strip()
    else:
        provider_reference_salt = (
            str(raw_provider_salt).strip()
            if (raw_provider_salt and str(raw_provider_salt).strip())
            else DEV_DEFAULT_PROVIDER_SALT
        )

    return {
        'DJANGO_ENV': django_env,
        'IS_PRODUCTION': is_production,
        'DEBUG': debug,
        'SECRET_KEY': secret_key,
        'ALLOWED_HOSTS': allowed_hosts,
        'CSRF_TRUSTED_ORIGINS': csrf_trusted_origins,
        'DATABASES': databases,
        'DVS_BLOCKCHAIN_BASE_URL': blockchain_base_url,
        'WEB3_RPC_URL': web3_rpc_url,
        'METAMASK_RPC_URL': metamask_rpc_url,
        'BLOCKCHAIN_HEALTH_URL': blockchain_health_url,
        'BLOCKCHAIN_METADATA_URL': blockchain_metadata_url,
        'HARDHAT_BACKEND_RPC_TOKEN': hardhat_backend_rpc_token,
        'REQUIRE_HTTPS_RPC': require_https_rpc,
        'ALLOW_LOCAL_RPC_IN_PRODUCTION': allow_local_rpc,
        'WEB3_RPC_TIMEOUT_SECONDS': web3_rpc_timeout,
        'CHAIN_ID': chain_id,
        'CONTRACT_ADDRESS': contract_address,
        'ELECTION_ID': election_id,
        'ELECTION_DOMAIN_NAME': str(env.get('ELECTION_DOMAIN_NAME', 'EVoting')).strip() or 'EVoting',
        'ELECTION_DOMAIN_VERSION': str(env.get('ELECTION_DOMAIN_VERSION', '1')).strip() or '1',
        'ELECTION_AUTHORITY_PRIVATE_KEY': authority_private_key,
        'ELECTION_AUTHORITY_ADDRESS': authority_address,
        'BLOCKCHAIN_DEPLOYER_PRIVATE_KEY': deployer_private_key,
        'BLOCKCHAIN_DEPLOYER_ADDRESS': deployer_address,
        'ELECTION_NULLIFIER_PEPPER': nullifier_pepper,
        'CHALLENGE_EXPIRY_SECONDS': _parse_int(env.get('CHALLENGE_EXPIRY_SECONDS', '300'), 'CHALLENGE_EXPIRY_SECONDS', minimum=30),
        'PERMIT_EXPIRY_SECONDS': _parse_int(env.get('PERMIT_EXPIRY_SECONDS', '600'), 'PERMIT_EXPIRY_SECONDS', minimum=30),
        'ONBOARDING_ENCRYPTION_KEY': onboarding_encryption_key,
        'PROVIDER_REFERENCE_SALT': provider_reference_salt,
        # Cloud Run Reverse-Proxy & Cookie Security Settings
        'SECURE_PROXY_SSL_HEADER': ('HTTP_X_FORWARDED_PROTO', 'https'),
        'USE_X_FORWARDED_HOST': True,
        'SESSION_COOKIE_SECURE': is_production,
        'CSRF_COOKIE_SECURE': is_production,
        'SESSION_COOKIE_HTTPONLY': True,
        'CSRF_COOKIE_HTTPONLY': False,
        'SESSION_COOKIE_SAMESITE': 'Lax',
        'CSRF_COOKIE_SAMESITE': 'Lax',
        'SECURE_CONTENT_TYPE_NOSNIFF': True,
        'SECURE_REFERRER_POLICY': 'strict-origin-when-cross-origin',
        'X_FRAME_OPTIONS': (
            str(env.get('DJANGO_X_FRAME_OPTIONS', 'DENY' if is_production else 'SAMEORIGIN')).strip()
            or ('DENY' if is_production else 'SAMEORIGIN')
        ),
        'SECURE_SSL_REDIRECT': _parse_bool(env.get('DJANGO_SECURE_SSL_REDIRECT', 'True')) if is_production else False,
        'SECURE_REDIRECT_EXEMPT': [r'^api/health/$', r'^healthz/$'],
        'SECURE_HSTS_SECONDS': _parse_int(
            env.get('DJANGO_SECURE_HSTS_SECONDS', '31536000' if is_production else '0'),
            'DJANGO_SECURE_HSTS_SECONDS',
            minimum=0,
        ),
        'SECURE_HSTS_INCLUDE_SUBDOMAINS': (
            _parse_bool(env.get('DJANGO_SECURE_HSTS_INCLUDE_SUBDOMAINS', 'True')) if is_production else False
        ),
        'SECURE_HSTS_PRELOAD': (
            _parse_bool(env.get('DJANGO_SECURE_HSTS_PRELOAD', 'True')) if is_production else False
        ),
    }


def auto_provision_runtime_secrets(env=os.environ, base_dir=BASE_DIR):
    """
    Ensure all required demonstration secrets, host configurations, and rotated
    blockchain keys are automatically provisioned into environment if absent,
    enabling zero-configuration publication on Google AI Studio / Cloud Run.
    """
    import secrets

    secrets_dir = os.path.join(base_dir, 'secrets')
    try:
        os.makedirs(secrets_dir, exist_ok=True)
    except Exception:
        pass

    # 1. Django Secret Key
    raw_secret = env.get('DJANGO_SECRET_KEY')
    if not raw_secret or raw_secret == DEV_DEFAULT_SECRET_KEY or 'replace-with' in str(raw_secret).lower():
        key_file = os.path.join(secrets_dir, 'django_secret_key.txt')
        cached_key = None
        if os.path.exists(key_file):
            try:
                with open(key_file, 'r', encoding='utf-8') as f:
                    cached_key = f.read().strip()
            except Exception:
                pass
        if cached_key and len(cached_key) >= 32 and cached_key != DEV_DEFAULT_SECRET_KEY:
            env['DJANGO_SECRET_KEY'] = cached_key
        else:
            fresh_secret = secrets.token_urlsafe(64)
            env['DJANGO_SECRET_KEY'] = fresh_secret
            try:
                with open(key_file, 'w', encoding='utf-8') as f:
                    f.write(fresh_secret)
                os.chmod(key_file, 0o600)
            except Exception:
                pass

    # 2. Allowed hosts & CSRF origins for Cloud Run, Render, and preview domains
    if not env.get('DJANGO_ALLOWED_HOSTS') and not env.get('ALLOWED_HOSTS'):
        env['DJANGO_ALLOWED_HOSTS'] = '.run.app,.onrender.com,.aistudio.google.com,.ai.studio,localhost,127.0.0.1,0.0.0.0'

    if not env.get('DJANGO_CSRF_TRUSTED_ORIGINS') and not env.get('CSRF_TRUSTED_ORIGINS'):
        env['DJANGO_CSRF_TRUSTED_ORIGINS'] = 'https://*.run.app,https://*.onrender.com,https://*.ai.studio,https://*.aistudio.google.com'

    # 3. Cryptographic salts and peppers
    for var_name, filename, default_val in [
        ('ELECTION_NULLIFIER_PEPPER', 'dvs_nullifier_pepper.txt', DEV_DEFAULT_NULLIFIER_PEPPER),
        ('ONBOARDING_ENCRYPTION_KEY', 'dvs_onboarding_key.txt', DEV_DEFAULT_ONBOARDING_KEY),
        ('PROVIDER_REFERENCE_SALT', 'dvs_provider_salt.txt', DEV_DEFAULT_PROVIDER_SALT),
    ]:
        val = env.get(var_name, '').strip()
        if not val or val == default_val or 'replace-with' in val.lower():
            file_path = os.path.join(secrets_dir, filename)
            cached_val = None
            if os.path.exists(file_path):
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        cached_val = f.read().strip()
                except Exception:
                    pass
            if cached_val and len(cached_val) >= 16 and cached_val != default_val:
                env[var_name] = cached_val
            else:
                fresh_val = secrets.token_urlsafe(32)
                env[var_name] = fresh_val
                try:
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(fresh_val)
                    os.chmod(file_path, 0o600)
                except Exception:
                    pass

    # 4. Rotated Blockchain Demonstration Accounts (Deployer and Election Authority)
    raw_auth_key = env.get('ELECTION_AUTHORITY_PRIVATE_KEY', '').strip()
    raw_dep_key = env.get('BLOCKCHAIN_DEPLOYER_PRIVATE_KEY', '').strip()
    if not raw_auth_key or raw_auth_key == DEV_DEFAULT_AUTHORITY_PRIVATE_KEY or 'replace-with' in raw_auth_key.lower() or not raw_dep_key or 'replace-with' in raw_dep_key.lower():
        accts_file = os.path.join(secrets_dir, 'hardhat_demo_accounts.json')
        if not os.path.exists(accts_file):
            try:
                import json
                from datetime import datetime, timezone as dt_tz
                from eth_account import Account
                def _gen_acct():
                    while True:
                        acct = Account.create()
                        raw_h = acct.key.hex()
                        if raw_h.startswith(('0x', '0X')):
                            raw_h = raw_h[2:]
                        priv = '0x' + raw_h.rjust(64, '0')
                        if priv.lower() not in KNOWN_DEV_PRIVATE_KEYS:
                            return {'address': acct.address, 'private_key': priv}
                dep_a = _gen_acct()
                auth_a = _gen_acct()
                while auth_a['address'].lower() == dep_a['address'].lower():
                    auth_a = _gen_acct()
                sec_a = _gen_acct()
                voters_a = []
                for idx in range(1, 5):
                    v_a = _gen_acct()
                    voters_a.append({
                        'role': f'DEMO_VOTER_{idx}',
                        'account_index': idx,
                        'address': v_a['address'],
                        'private_key': v_a['private_key'],
                        'label': f'Rotated Demonstration Voter Account #{idx} (Synthetic Test Account)',
                    })
                init_payload = {
                    'rotated_at': datetime.now(dt_tz.utc).isoformat(),
                    'chain_id': 31337,
                    'deployer': {'role': 'DEPLOYER', 'address': dep_a['address'], 'private_key': dep_a['private_key']},
                    'election_authority': {'role': 'ELECTION_AUTHORITY', 'address': auth_a['address'], 'private_key': auth_a['private_key']},
                    'secondary_operator': {'role': 'AUTHORITY_RESERVE_OPERATOR', 'address': sec_a['address'], 'private_key': sec_a['private_key']},
                    'demo_voters': voters_a,
                }
                with open(accts_file, 'w', encoding='utf-8') as f:
                    json.dump(init_payload, f, indent=2)
                os.chmod(accts_file, 0o600)
            except Exception as exc:
                print(f"[DVS Startup] Generating hardhat_demo_accounts.json notice: {exc}")

        if os.path.exists(accts_file):
            try:
                import json
                with open(accts_file, 'r', encoding='utf-8') as f:
                    acct_data = json.load(f)
                if not raw_auth_key or raw_auth_key == DEV_DEFAULT_AUTHORITY_PRIVATE_KEY or 'replace-with' in raw_auth_key.lower():
                    auth_k = str(acct_data['election_authority']['private_key']).strip()
                    clean_k = auth_k[2:] if auth_k.startswith(('0x', '0X')) else auth_k
                    env['ELECTION_AUTHORITY_PRIVATE_KEY'] = '0x' + clean_k.rjust(64, '0')
                    env['ELECTION_AUTHORITY_ADDRESS'] = acct_data['election_authority']['address']
                if not raw_dep_key or 'replace-with' in raw_dep_key.lower():
                    dep_k = str(acct_data['deployer']['private_key']).strip()
                    clean_k = dep_k[2:] if dep_k.startswith(('0x', '0X')) else dep_k
                    env['BLOCKCHAIN_DEPLOYER_PRIVATE_KEY'] = '0x' + clean_k.rjust(64, '0')
            except Exception as exc:
                print(f"[DVS Startup] Reading hardhat_demo_accounts.json notice: {exc}")

    # 5. Blockchain RPC URL / DVS_BLOCKCHAIN_BASE_URL
    bc_base = env.get('DVS_BLOCKCHAIN_BASE_URL', '').strip().rstrip('/')
    if not bc_base:
        url_file = os.path.join(secrets_dir, 'dvs_blockchain_base_url.txt')
        if os.path.exists(url_file):
            try:
                with open(url_file, 'r', encoding='utf-8') as f:
                    cached_bc = f.read().strip().rstrip('/')
                if cached_bc.startswith(('http://', 'https://')):
                    bc_base = cached_bc
                    env['DVS_BLOCKCHAIN_BASE_URL'] = bc_base
            except Exception:
                pass

    # If no gateway base is configured, leave it empty. Local development
    # derives its health/metadata base from WEB3_RPC_URL in validate_and_load_settings.
    # The local voting flow must not silently fall back to a remote gateway.
    if bc_base:
        if not env.get('WEB3_RPC_URL'):
            env['WEB3_RPC_URL'] = f"{bc_base}/rpc/"
        if not env.get('METAMASK_RPC_URL'):
            env['METAMASK_RPC_URL'] = f"{bc_base}/rpc/"
        if not env.get('BLOCKCHAIN_HEALTH_URL'):
            env['BLOCKCHAIN_HEALTH_URL'] = f"{bc_base}/healthz/"
        if not env.get('BLOCKCHAIN_METADATA_URL'):
            env['BLOCKCHAIN_METADATA_URL'] = f"{bc_base}/metadata"


auto_provision_runtime_secrets(os.environ, base_dir=BASE_DIR)
_CONFIG = validate_and_load_settings(os.environ, base_dir=BASE_DIR)

DJANGO_ENV = _CONFIG['DJANGO_ENV']
IS_PRODUCTION = _CONFIG['IS_PRODUCTION']
SECRET_KEY = _CONFIG['SECRET_KEY']
DEBUG = _CONFIG['DEBUG']
ALLOWED_HOSTS = _CONFIG['ALLOWED_HOSTS']
CSRF_TRUSTED_ORIGINS = list(_CONFIG['CSRF_TRUSTED_ORIGINS'])

# Allow local runserver origins only during development; production checks are unchanged.
if DEBUG:
    for _local_origin in ('http://localhost:8000', 'http://127.0.0.1:8000'):
        if _local_origin not in CSRF_TRUSTED_ORIGINS:
            CSRF_TRUSTED_ORIGINS.append(_local_origin)

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'EVotingApp',
]

MIDDLEWARE = [
    'EVoting.middleware.IframePreviewCompatibilityMiddleware',
    'django.middleware.security.SecurityMiddleware',
]

try:
    import whitenoise  # noqa: F401
    MIDDLEWARE.append('whitenoise.middleware.WhiteNoiseMiddleware')
except ImportError:
    pass

MIDDLEWARE.extend([
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
])

ROOT_URLCONF = 'EVoting.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [
            os.path.join(BASE_DIR, 'EVotingApp', 'templates'),
        ],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'EVoting.wsgi.application'

DATABASES = _CONFIG['DATABASES']

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Asia/Kolkata'
USE_I18N = True
USE_L10N = True
USE_TZ = True

# ==============================================================================
# STATIC FILES CONFIGURATION
# ==============================================================================
STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')
os.makedirs(STATIC_ROOT, exist_ok=True)
STATICFILES_DIRS = []

# Candidate symbol images uploaded through the election control portal.
# Supports Render persistent disk mount via MEDIA_ROOT or DJANGO_MEDIA_ROOT.
MEDIA_URL = '/media/'
_raw_media_root = str(os.environ.get('MEDIA_ROOT') or os.environ.get('DJANGO_MEDIA_ROOT') or '').strip()
MEDIA_ROOT = os.path.abspath(_raw_media_root) if _raw_media_root else os.path.join(BASE_DIR, 'media')
try:
    os.makedirs(MEDIA_ROOT, exist_ok=True)
except OSError:
    MEDIA_ROOT = os.path.join(BASE_DIR, 'media')
    os.makedirs(MEDIA_ROOT, exist_ok=True)

ALLOW_LOCAL_RPC_IN_PRODUCTION = _CONFIG['ALLOW_LOCAL_RPC_IN_PRODUCTION']

# Local Hardhat account used by Django for candidate setup and vote transactions.
# Keep the first account selected in Remix so it matches the contract owner.
DVS_TX_ACCOUNT_INDEX = int(os.environ.get('DVS_TX_ACCOUNT_INDEX', '0'))
DVS_CONTRACT_ADDRESS = os.environ.get('DVS_CONTRACT_ADDRESS', _CONFIG['CONTRACT_ADDRESS'])

STORAGES = {
    'default': {
        'BACKEND': 'django.core.files.storage.FileSystemStorage',
    },
    'staticfiles': {
        'BACKEND': 'django.contrib.staticfiles.storage.StaticFilesStorage',
    },
}

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# ==============================================================================
# REVERSE PROXY, HTTPS & COOKIE SECURITY SETTINGS (CLOUD RUN COMPATIBLE)
# ==============================================================================
SECURE_PROXY_SSL_HEADER = _CONFIG['SECURE_PROXY_SSL_HEADER']
USE_X_FORWARDED_HOST = _CONFIG['USE_X_FORWARDED_HOST']
SESSION_COOKIE_SECURE = _CONFIG['SESSION_COOKIE_SECURE']
CSRF_COOKIE_SECURE = _CONFIG['CSRF_COOKIE_SECURE']
SESSION_COOKIE_HTTPONLY = _CONFIG['SESSION_COOKIE_HTTPONLY']
CSRF_COOKIE_HTTPONLY = _CONFIG['CSRF_COOKIE_HTTPONLY']
SESSION_COOKIE_SAMESITE = _CONFIG['SESSION_COOKIE_SAMESITE']
CSRF_COOKIE_SAMESITE = _CONFIG['CSRF_COOKIE_SAMESITE']
SECURE_CONTENT_TYPE_NOSNIFF = _CONFIG['SECURE_CONTENT_TYPE_NOSNIFF']
SECURE_REFERRER_POLICY = _CONFIG['SECURE_REFERRER_POLICY']
X_FRAME_OPTIONS = _CONFIG['X_FRAME_OPTIONS']
SECURE_SSL_REDIRECT = _CONFIG['SECURE_SSL_REDIRECT']
SECURE_REDIRECT_EXEMPT = _CONFIG['SECURE_REDIRECT_EXEMPT']
SECURE_HSTS_SECONDS = _CONFIG['SECURE_HSTS_SECONDS']
SECURE_HSTS_INCLUDE_SUBDOMAINS = _CONFIG['SECURE_HSTS_INCLUDE_SUBDOMAINS']
SECURE_HSTS_PRELOAD = _CONFIG['SECURE_HSTS_PRELOAD']

# ==============================================================================
# BLOCKCHAIN & CRYPTOGRAPHIC CONFIGURATION
# ==============================================================================
DVS_BLOCKCHAIN_BASE_URL = _CONFIG['DVS_BLOCKCHAIN_BASE_URL']
WEB3_RPC_URL = _CONFIG['WEB3_RPC_URL']
METAMASK_RPC_URL = _CONFIG['METAMASK_RPC_URL']
BLOCKCHAIN_HEALTH_URL = _CONFIG['BLOCKCHAIN_HEALTH_URL']
BLOCKCHAIN_METADATA_URL = _CONFIG['BLOCKCHAIN_METADATA_URL']
HARDHAT_BACKEND_RPC_TOKEN = _CONFIG['HARDHAT_BACKEND_RPC_TOKEN']
REQUIRE_HTTPS_RPC = _CONFIG['REQUIRE_HTTPS_RPC']
WEB3_RPC_TIMEOUT_SECONDS = _CONFIG['WEB3_RPC_TIMEOUT_SECONDS']
CHAIN_ID = _CONFIG['CHAIN_ID']
CONTRACT_ADDRESS = _CONFIG['CONTRACT_ADDRESS']
ELECTION_ID = _CONFIG['ELECTION_ID']

ELECTION_DOMAIN_NAME = _CONFIG['ELECTION_DOMAIN_NAME']
ELECTION_DOMAIN_VERSION = _CONFIG['ELECTION_DOMAIN_VERSION']

ELECTION_AUTHORITY_PRIVATE_KEY = _CONFIG['ELECTION_AUTHORITY_PRIVATE_KEY']
ELECTION_AUTHORITY_ADDRESS = _CONFIG['ELECTION_AUTHORITY_ADDRESS']
BLOCKCHAIN_DEPLOYER_PRIVATE_KEY = _CONFIG['BLOCKCHAIN_DEPLOYER_PRIVATE_KEY']
BLOCKCHAIN_DEPLOYER_ADDRESS = _CONFIG['BLOCKCHAIN_DEPLOYER_ADDRESS']
ELECTION_NULLIFIER_PEPPER = _CONFIG['ELECTION_NULLIFIER_PEPPER']

CHALLENGE_EXPIRY_SECONDS = _CONFIG['CHALLENGE_EXPIRY_SECONDS']
PERMIT_EXPIRY_SECONDS = _CONFIG['PERMIT_EXPIRY_SECONDS']

# ==============================================================================
# MODULE 6: WEBAUTHN & EXTERNAL PROVIDER SETTINGS
# ==============================================================================
WEBAUTHN_RP_ID = os.environ.get('WEBAUTHN_RP_ID', 'localhost')
WEBAUTHN_RP_NAME = os.environ.get('WEBAUTHN_RP_NAME', 'Decentralized Voting System (DVS)')
WEBAUTHN_ALLOWED_ORIGINS = [
    origin.strip().rstrip('/')
    for origin in os.environ.get(
        'WEBAUTHN_ALLOWED_ORIGINS',
        'http://localhost:8000,http://localhost:3000'
    ).split(',')
    if origin.strip()
]
WEBAUTHN_ALLOWED_HOSTS = [
    host.strip().lower()
    for host in os.environ.get(
        'WEBAUTHN_ALLOWED_HOSTS',
        'localhost,127.0.0.1,testserver'
    ).split(',')
    if host.strip()
]
WEBAUTHN_STEP_UP_TTL_SECONDS = int(os.environ.get('WEBAUTHN_STEP_UP_TTL_SECONDS', '300'))

ONBOARDING_ENCRYPTION_KEY = _CONFIG['ONBOARDING_ENCRYPTION_KEY']
PROVIDER_REFERENCE_SALT = _CONFIG['PROVIDER_REFERENCE_SALT']
IDENTITY_PROVIDER_ENDPOINTS = {
    'genuine_national_gateway': os.environ.get(
        'GENUINE_PROVIDER_ENDPOINT',
        'https://identity-gateway.civic-authority.example.org/v1/verify'
    ),
}
IDENTITY_PROVIDER_ISSUER = os.environ.get(
    'IDENTITY_PROVIDER_ISSUER',
    'https://identity-gateway.civic-authority.example.org'
)
IDENTITY_PROVIDER_AUDIENCE = os.environ.get(
    'IDENTITY_PROVIDER_AUDIENCE',
    'dvs-electoral-platform-2026'
)
IDENTITY_PROVIDER_PUBLIC_KEYS = {}

# ==============================================================================
# PRODUCTION LOGGING CONFIGURATION (WITH SECRET REDACTION)
# ==============================================================================
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'filters': {
        'redact_secrets': {
            '()': 'EVoting.settings.RedactSecretsFilter',
        },
    },
    'formatters': {
        'standard': {
            'format': '[{asctime}] {levelname} {name}: {message}',
            'style': '{',
        },
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'filters': ['redact_secrets'],
            'formatter': 'standard',
        },
    },
    'root': {
        'handlers': ['console'],
        'level': os.environ.get('DJANGO_LOG_LEVEL', 'INFO'),
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': os.environ.get('DJANGO_LOG_LEVEL', 'INFO'),
            'propagate': False,
        },
        'EVotingApp': {
            'handlers': ['console'],
            'level': os.environ.get('DJANGO_LOG_LEVEL', 'INFO'),
            'propagate': False,
        },
    },
}
