from http.cookies import Morsel
from django.conf import settings
from django.middleware import csrf

# Register CHIPS 'Partitioned' flag on Python's Morsel cookie object
Morsel._reserved.setdefault('partitioned', 'Partitioned')
Morsel._flags.add('partitioned')


class IframePreviewCompatibilityMiddleware:
    """
    Ensures CSRF tokens, session cookies, and framing headers work seamlessly
    when the Django application is served behind the Cloud Run / Nginx proxy
    inside a cross-origin preview iframe (e.g. *.run.app embedded in AI Studio),
    while preserving standard behavior for local HTTP and automated tests.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    @staticmethod
    def _is_proxied_https_request(request):
        forwarded_host = (request.META.get('HTTP_X_FORWARDED_HOST') or '').lower().split(':')[0]
        try:
            host = (request.get_host() or '').lower().split(':')[0]
        except Exception:
            host = ''
        for candidate in (forwarded_host, host):
            if (
                candidate.endswith('.run.app')
                or candidate.endswith('.ai.studio')
                or candidate.endswith('.aistudio.google.com')
            ):
                return True
        return False

    def __call__(self, request):
        is_proxied_https = self._is_proxied_https_request(request)

        if is_proxied_https:
            # Nginx inside the container forwards to localhost:3000 over HTTP,
            # setting X-Forwarded-Proto to 'http'. Restore 'https' for external preview hosts.
            request.META['HTTP_X_FORWARDED_PROTO'] = 'https'

            # Sandboxed iframes may send Origin: null on form POST submissions.
            if request.META.get('HTTP_ORIGIN') == 'null':
                request.META['HTTP_ORIGIN'] = f"https://{request.get_host()}"

            # If the browser in a cross-origin iframe blocked the csrftoken cookie
            # (or held a stale SameSite=Lax cookie from before), recover the CSRF secret
            # from the masked csrfmiddlewaretoken submitted in the form or header.
            csrf_cookie_name = getattr(settings, 'CSRF_COOKIE_NAME', 'csrftoken')
            if (
                csrf_cookie_name not in request.COOKIES
                and request.method in ('POST', 'PUT', 'PATCH', 'DELETE')
            ):
                submitted_token = request.META.get('HTTP_X_CSRFTOKEN') or ''
                if not submitted_token and (request.content_type or '').startswith('application/x-www-form-urlencoded'):
                    submitted_token = request.POST.get('csrfmiddlewaretoken') or ''
                if len(submitted_token) == getattr(csrf, 'CSRF_TOKEN_LENGTH', 64):
                    try:
                        unmasked = csrf._unmask_cipher_token(submitted_token)
                        if len(unmasked) == getattr(csrf, 'CSRF_SECRET_LENGTH', 32):
                            request.COOKIES[csrf_cookie_name] = unmasked
                    except Exception:
                        pass

        response = self.get_response(request)

        if is_proxied_https:
            for morsel in response.cookies.values():
                morsel['samesite'] = 'None'
                morsel['secure'] = True
                morsel['partitioned'] = True

            # Allow Nginx's Content-Security-Policy frame-ancestors header to govern
            # cross-origin iframe embedding without X-Frame-Options: SAMEORIGIN conflict.
            if 'X-Frame-Options' in response.headers:
                del response.headers['X-Frame-Options']

        return response
