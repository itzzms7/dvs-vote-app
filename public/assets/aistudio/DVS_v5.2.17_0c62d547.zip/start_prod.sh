#!/usr/bin/env bash
set -euo pipefail

# ==============================================================================
# DVS Production Startup Script (Google Cloud Run Compatible)
# ==============================================================================

export DJANGO_ENV="${DJANGO_ENV:-production}"
export DJANGO_DEBUG="${DJANGO_DEBUG:-False}"
LISTEN_PORT="${PORT:-8080}"
WORKERS="${GUNICORN_WORKERS:-2}"
THREADS="${GUNICORN_THREADS:-4}"
TIMEOUT="${GUNICORN_TIMEOUT:-120}"

echo "[DVS Production] Validating Django production configuration..."
python3 manage.py check --deploy

echo "[DVS Production] Collecting static assets..."
python3 manage.py collectstatic --noinput

echo "[DVS Production] Applying database migrations..."
python3 manage.py migrate --noinput

echo "[DVS Production] Ensuring initial Superuser and RBAC groups (if configured)..."
python3 manage.py init_superuser --skip-if-missing

echo "[DVS Production] Starting Gunicorn WSGI server on 0.0.0.0:${LISTEN_PORT}..."
exec gunicorn EVoting.wsgi:application \
    --bind "0.0.0.0:${LISTEN_PORT}" \
    --workers "${WORKERS}" \
    --threads "${THREADS}" \
    --timeout "${TIMEOUT}" \
    --access-logfile - \
    --error-logfile -
