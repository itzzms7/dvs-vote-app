#!/usr/bin/env bash
set -euo pipefail

# ==============================================================================
# DVS Render Single-Service Build Script
# Installs Python & Node.js dependencies, compiles EVoting.sol via Hardhat,
# collects static assets for WhiteNoise, and runs Django system checks.
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "${PROJECT_ROOT}"

echo "[DVS Build] 1/5 Installing Python dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

echo "[DVS Build] 2/5 Installing Node.js / Hardhat dependencies..."
if [ -f "package-lock.json" ]; then
    npm ci --include=dev
else
    npm install --include=dev
fi

echo "[DVS Build] 3/5 Compiling Solidity smart contracts (EVoting.sol)..."
npx --no-install hardhat compile

if [ -f "artifacts/blocks/contracts/EVoting.sol/EVoting.json" ]; then
    cp "artifacts/blocks/contracts/EVoting.sol/EVoting.json" "EVoting.json"
    echo "[DVS Build] Synchronized compiled artifact to EVoting.json."
else
    echo "[DVS Build] ERROR: Compiled EVoting.json artifact not found after npx hardhat compile." >&2
    exit 1
fi

echo "[DVS Build] 4/5 Collecting Django static files..."
python3 manage.py collectstatic --noinput

echo "[DVS Build] 5/5 Running Django system validation checks..."
python3 manage.py check

echo "[DVS Build] Build completed successfully."
