#!/usr/bin/env bash
set -euo pipefail

# ==============================================================================
# DVS Single-Service Production Startup Orchestrator for Render
# ------------------------------------------------------------------------------
# Sequence:
#  1. Validate required environment variables.
#  2. Apply Django database migrations (`python3 manage.py migrate --noinput`).
#  3. Idempotently initialize the `Suhail` superuser (`python3 manage.py init_superuser`).
#  4. Start local Hardhat node bound exclusively to 127.0.0.1:8545.
#  5. Poll Hardhat JSON-RPC readiness with bounded retries and timeout failure.
#  6. Verify live Chain ID == 31337 (0x7a69).
#  7. Confirm compiled EVoting.sol contract artifacts exist.
#  8. Deploy EVoting.sol to local Hardhat node & record deployment metadata.
#  9. Verify deployed contract bytecode on-chain.
# 10. Synchronize Django's active contract configuration & detect stale chain-reset elections.
# 11. Start Gunicorn bound to 0.0.0.0:${PORT:-10000} and supervise both processes cleanly.
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "${PROJECT_ROOT}"

export DJANGO_ENV="${DJANGO_ENV:-production}"
export DJANGO_DEBUG="${DJANGO_DEBUG:-False}"
export WEB3_RPC_URL="${WEB3_RPC_URL:-http://127.0.0.1:8545}"
export ALLOW_LOCAL_RPC_IN_PRODUCTION="${ALLOW_LOCAL_RPC_IN_PRODUCTION:-True}"
export REQUIRE_HTTPS_RPC="${REQUIRE_HTTPS_RPC:-False}"
export CHAIN_ID="${CHAIN_ID:-31337}"
export DVS_SKIP_STARTUP_CHAIN_SYNC="1"

LISTEN_PORT="${PORT:-10000}"
HARDHAT_HOST="127.0.0.1"
HARDHAT_PORT="8545"
HARDHAT_RPC_URL="http://${HARDHAT_HOST}:${HARDHAT_PORT}"

HARDHAT_PID=""
GUNICORN_PID=""
SHUTTING_DOWN=0

cleanup_processes() {
    local exit_code=$?
    if [ "${SHUTTING_DOWN}" -eq 1 ]; then
        return
    fi
    SHUTTING_DOWN=1
    echo "[DVS Startup] Shutting down managed services..."

    if [ -n "${GUNICORN_PID}" ] && kill -0 "${GUNICORN_PID}" 2>/dev/null; then
        echo "[DVS Startup] Stopping Gunicorn (PID ${GUNICORN_PID})..."
        kill -TERM "${GUNICORN_PID}" 2>/dev/null || true
        for _ in $(seq 1 15); do
            if ! kill -0 "${GUNICORN_PID}" 2>/dev/null; then
                break
            fi
            sleep 0.2
        done
        if kill -0 "${GUNICORN_PID}" 2>/dev/null; then
            pkill -KILL -P "${GUNICORN_PID}" 2>/dev/null || true
            kill -KILL "${GUNICORN_PID}" 2>/dev/null || true
        fi
    fi

    if [ -n "${HARDHAT_PID}" ] && kill -0 "${HARDHAT_PID}" 2>/dev/null; then
        echo "[DVS Startup] Stopping Hardhat node (PID ${HARDHAT_PID})..."
        pkill -TERM -P "${HARDHAT_PID}" 2>/dev/null || true
        kill -TERM "${HARDHAT_PID}" 2>/dev/null || true
        for _ in $(seq 1 15); do
            if ! kill -0 "${HARDHAT_PID}" 2>/dev/null; then
                break
            fi
            sleep 0.2
        done
        pkill -KILL -P "${HARDHAT_PID}" 2>/dev/null || true
        if kill -0 "${HARDHAT_PID}" 2>/dev/null; then
            kill -KILL "${HARDHAT_PID}" 2>/dev/null || true
        fi
    fi

    exit "${exit_code}"
}

trap cleanup_processes SIGTERM SIGINT EXIT

echo "[DVS Startup] Step 1/11: Validating required environment variables..."
if [ -z "${DJANGO_SUPERUSER_USERNAME:-}" ]; then
    echo "[DVS Startup] ERROR: DJANGO_SUPERUSER_USERNAME is required in production startup." >&2
    exit 1
fi
if [ -z "${DJANGO_SUPERUSER_PASSWORD:-}" ]; then
    echo "[DVS Startup] ERROR: DJANGO_SUPERUSER_PASSWORD is required in production startup." >&2
    exit 1
fi
if [ "${#DJANGO_SUPERUSER_PASSWORD}" -lt 8 ]; then
    echo "[DVS Startup] ERROR: DJANGO_SUPERUSER_PASSWORD must be at least 8 characters." >&2
    exit 1
fi
if [ "${DJANGO_ENV}" = "production" ]; then
    if [ -z "${DJANGO_SECRET_KEY:-}" ] || [ "${#DJANGO_SECRET_KEY}" -lt 32 ]; then
        echo "[DVS Startup] ERROR: A strong DJANGO_SECRET_KEY (>= 32 chars) is required in production." >&2
        exit 1
    fi
    if [ -z "${DATABASE_URL:-}" ] && [ "${DB_ENGINE:-}" != "postgresql" ]; then
        echo "[DVS Startup] ERROR: DATABASE_URL (PostgreSQL) is required in production." >&2
        exit 1
    fi
fi

# Ensure persistent media directory exists if configured
if [ -n "${MEDIA_ROOT:-}" ]; then
    mkdir -p "${MEDIA_ROOT}"
fi

echo "[DVS Startup] Step 2/11: Applying Django database migrations..."
python3 manage.py migrate --noinput

echo "[DVS Startup] Step 3/11: Initializing superuser '${DJANGO_SUPERUSER_USERNAME}' idempotently..."
python3 manage.py init_superuser

echo "[DVS Startup] Step 4/11: Confirming compiled EVoting.sol contract artifacts exist..."
if [ ! -f "artifacts/blocks/contracts/EVoting.sol/EVoting.json" ] && [ ! -f "EVoting.json" ]; then
    echo "[DVS Startup] Compiled artifact missing; compiling EVoting.sol now..."
    npx --no-install hardhat compile
fi
if [ -f "artifacts/blocks/contracts/EVoting.sol/EVoting.json" ]; then
    cp "artifacts/blocks/contracts/EVoting.sol/EVoting.json" "EVoting.json"
fi
if [ ! -f "EVoting.json" ]; then
    echo "[DVS Startup] ERROR: EVoting.json contract artifact not found." >&2
    exit 1
fi

echo "[DVS Startup] Step 5/11: Starting local Hardhat node on ${HARDHAT_HOST}:${HARDHAT_PORT}..."
mkdir -p logs
node ./node_modules/.bin/hardhat node --hostname "${HARDHAT_HOST}" --port "${HARDHAT_PORT}" > logs/hardhat_node.log 2>&1 &
HARDHAT_PID=$!
echo "[DVS Startup] Hardhat node launched with PID ${HARDHAT_PID}."

echo "[DVS Startup] Step 6/11: Waiting for Hardhat JSON-RPC readiness at ${HARDHAT_RPC_URL}..."
MAX_RETRIES="${HARDHAT_STARTUP_MAX_RETRIES:-60}"
RETRY_DELAY="${HARDHAT_STARTUP_RETRY_DELAY:-0.5}"
RPC_READY=0

for attempt in $(seq 1 "${MAX_RETRIES}"); do
    if ! kill -0 "${HARDHAT_PID}" 2>/dev/null; then
        echo "[DVS Startup] ERROR: Hardhat node process (PID ${HARDHAT_PID}) exited prematurely." >&2
        tail -n 30 logs/hardhat_node.log >&2 || true
        exit 1
    fi
    if python3 -c "
import json, urllib.request, sys
req = urllib.request.Request(
    '${HARDHAT_RPC_URL}',
    data=json.dumps({'jsonrpc':'2.0','method':'eth_chainId','params':[],'id':1}).encode('utf-8'),
    headers={'Content-Type':'application/json'},
    method='POST'
)
try:
    with urllib.request.urlopen(req, timeout=2) as resp:
        body = json.loads(resp.read().decode('utf-8'))
        cid = int(body.get('result', '0x0'), 16)
        sys.exit(0 if cid == 31337 else 2)
except SystemExit:
    raise
except Exception:
    sys.exit(1)
" 2>/dev/null; then
        RPC_READY=1
        echo "[DVS Startup] Hardhat JSON-RPC is ready on attempt ${attempt}/${MAX_RETRIES} (Chain ID 31337 verified)."
        break
    fi
    sleep "${RETRY_DELAY}"
done

if [ "${RPC_READY}" -ne 1 ]; then
    echo "[DVS Startup] ERROR: Timed out waiting for Hardhat JSON-RPC at ${HARDHAT_RPC_URL}." >&2
    tail -n 30 logs/hardhat_node.log >&2 || true
    exit 1
fi

echo "[DVS Startup] Step 7/11: Deploying EVoting.sol contract to local Hardhat node..."
python3 manage.py hardhat_demo deploy --rpc-url "${HARDHAT_RPC_URL}"

echo "[DVS Startup] Step 8/11: Verifying deployed contract bytecode and state on-chain..."
python3 manage.py hardhat_demo verify --rpc-url "${HARDHAT_RPC_URL}"

echo "[DVS Startup] Step 9/11: Synchronizing deployed contract metadata with Django..."
DEPLOYED_CONTRACT_ADDRESS="$(python3 -c "
import json, os, sys
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'EVoting.settings')
import django
django.setup()
from web3 import Web3
from EVotingApp.hardhat_demo import load_demo_deployment_metadata
from EVotingApp.models import Election
from EVotingApp.services import get_web3_provider

meta = load_demo_deployment_metadata()
if not meta or not meta.get('contract_address'):
    sys.exit(1)
addr = Web3.to_checksum_address(meta['contract_address'])
w3 = get_web3_provider()
code = w3.eth.get_code(addr)
if not code or len(code) == 0:
    sys.exit(2)

# Detect any pre-existing database elections whose contract bytecode was wiped by container restart
for el in Election.objects.exclude(contract_address=''):
    try:
        el_addr = Web3.to_checksum_address(el.contract_address)
        el_code = w3.eth.get_code(el_addr)
        if not el_code or len(el_code) == 0:
            if el.deployment_status != 'CHAIN_RESET_REDEPLOY_REQUIRED':
                el.deployment_status = 'CHAIN_RESET_REDEPLOY_REQUIRED'
                el.save(update_fields=['deployment_status', 'updated_at'])
    except Exception:
        pass

print(addr)
")"

if [ -z "${DEPLOYED_CONTRACT_ADDRESS}" ]; then
    echo "[DVS Startup] ERROR: Failed to resolve verified deployed contract address." >&2
    exit 1
fi

export CONTRACT_ADDRESS="${DEPLOYED_CONTRACT_ADDRESS}"
export DVS_CONTRACT_ADDRESS="${DEPLOYED_CONTRACT_ADDRESS}"
echo "[DVS Startup] Step 10/11: Active EVoting contract synchronized at ${DEPLOYED_CONTRACT_ADDRESS}."

if [ "${DVS_STARTUP_SMOKE_TEST_ONLY:-0}" = "1" ]; then
    echo "[DVS Startup] Smoke test mode enabled; skipping Gunicorn launch."
    exit 0
fi

WORKERS="${GUNICORN_WORKERS:-2}"
THREADS="${GUNICORN_THREADS:-4}"
TIMEOUT="${GUNICORN_TIMEOUT:-120}"

echo "[DVS Startup] Step 11/11: Starting Gunicorn on 0.0.0.0:${LISTEN_PORT}..."
gunicorn EVoting.wsgi:application \
    --bind "0.0.0.0:${LISTEN_PORT}" \
    --workers "${WORKERS}" \
    --threads "${THREADS}" \
    --timeout "${TIMEOUT}" \
    --access-logfile - \
    --error-logfile - &
GUNICORN_PID=$!

# Monitor both Hardhat and Gunicorn; if either exits, shut down the other cleanly.
while true; do
    if ! kill -0 "${HARDHAT_PID}" 2>/dev/null; then
        echo "[DVS Startup] ERROR: Hardhat process (${HARDHAT_PID}) terminated unexpectedly." >&2
        exit 1
    fi
    if ! kill -0 "${GUNICORN_PID}" 2>/dev/null; then
        wait "${GUNICORN_PID}"
        exit $?
    fi
    sleep 1
done
