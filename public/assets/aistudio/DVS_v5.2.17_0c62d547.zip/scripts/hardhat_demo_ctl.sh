#!/usr/bin/env bash
# ==============================================================================
# Decentralized Voting System (DVS) — Phase 8 Hardhat Demonstration Control CLI
# Usage:
#   bash scripts/hardhat_demo_ctl.sh start      # Start Hardhat demonstration node
#   bash scripts/hardhat_demo_ctl.sh status     # Check node availability & accounts
#   bash scripts/hardhat_demo_ctl.sh deploy     # Deploy EVoting.sol & record metadata
#   bash scripts/hardhat_demo_ctl.sh metadata   # Print recorded deployment metadata
#   bash scripts/hardhat_demo_ctl.sh verify     # Verify deployed contract bytecode & state
#   bash scripts/hardhat_demo_ctl.sh reinit     # Reinitialize after node restart/reset
#   bash scripts/hardhat_demo_ctl.sh stop       # Stop Hardhat demonstration node safely
# ==============================================================================
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if python3 -c "import django" >/dev/null 2>&1; then
    PYTHON_BIN="python3"
elif [ -x "$ROOT_DIR/venv/bin/python" ]; then
    PYTHON_BIN="$ROOT_DIR/venv/bin/python"
else
    PYTHON_BIN="python3"
fi

HARDHAT_PORT="${HARDHAT_DEMO_PORT:-8545}"
HARDHAT_HOST="${HARDHAT_DEMO_HOST:-127.0.0.1}"
RPC_URL="${HARDHAT_DEMO_RPC_URL:-http://127.0.0.1:${HARDHAT_PORT}}"
PID_FILE="/tmp/dvs_hardhat_demo.pid"
LOG_FILE="/tmp/dvs_hardhat_demo.log"

check_rpc_ready() {
    curl -s -X POST -H "Content-Type: application/json" \
        --data '{"jsonrpc":"2.0","method":"eth_chainId","params":[],"id":1}' \
        "$RPC_URL" | grep -q "0x7a69"
}

cmd_start() {
    if check_rpc_ready; then
        echo "[DVS-Demo] Hardhat demonstration node is already running at $RPC_URL (Chain ID 31337)."
        return 0
    fi
    echo "[DVS-Demo] Starting Hardhat demonstration node on ${HARDHAT_HOST}:${HARDHAT_PORT}..."
    nohup npx hardhat node --hostname "$HARDHAT_HOST" --port "$HARDHAT_PORT" >"$LOG_FILE" 2>&1 &
    echo $! > "$PID_FILE"

    for i in {1..30}; do
        if check_rpc_ready; then
            echo "[DVS-Demo] Hardhat demonstration node online at $RPC_URL (Chain ID 31337)."
            return 0
        fi
        sleep 0.3
    done
    echo "[DVS-Demo] ERROR: Hardhat node failed to respond on $RPC_URL within timeout." >&2
    exit 1
}

cmd_stop() {
    if [ -f "$PID_FILE" ]; then
        TARGET_PID="$(cat "$PID_FILE")"
        if kill -0 "$TARGET_PID" 2>/dev/null; then
            echo "[DVS-Demo] Stopping Hardhat demonstration node (PID $TARGET_PID)..."
            kill "$TARGET_PID" || true
        fi
        rm -f "$PID_FILE"
    else
        echo "[DVS-Demo] No PID file found at $PID_FILE; checking for active hardhat node process..."
        pkill -f "hardhat node" 2>/dev/null || true
    fi
    echo "[DVS-Demo] Hardhat demonstration node stopped."
}

ACTION="${1:-status}"
shift || true

case "$ACTION" in
    start)
        cmd_start
        ;;
    stop)
        cmd_stop
        ;;
    status)
        "$PYTHON_BIN" manage.py hardhat_demo status --rpc-url "$RPC_URL" "$@"
        ;;
    deploy)
        if [ ! -f "artifacts/blocks/contracts/EVoting.sol/EVoting.json" ] && [ ! -f "EVoting.json" ]; then
            npx hardhat compile >/dev/null 2>&1 || true
        fi
        "$PYTHON_BIN" manage.py hardhat_demo deploy --rpc-url "$RPC_URL" "$@"
        ;;
    metadata)
        "$PYTHON_BIN" manage.py hardhat_demo metadata "$@"
        ;;
    verify)
        "$PYTHON_BIN" manage.py hardhat_demo verify --rpc-url "$RPC_URL" "$@"
        ;;
    reinit)
        cmd_start
        "$PYTHON_BIN" manage.py hardhat_demo reinit --rpc-url "$RPC_URL" "$@"
        ;;
    *)
        echo "Usage: $0 {start|status|deploy|metadata|verify|reinit|stop}" >&2
        exit 1
        ;;
esac
