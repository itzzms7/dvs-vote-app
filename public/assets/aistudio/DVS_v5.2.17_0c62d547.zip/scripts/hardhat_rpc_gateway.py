#!/usr/bin/env python3
"""
Hardhat Demonstration Environment — JSON-RPC Security Gateway & Method Filter.
Sits in front of an internal Hardhat node (127.0.0.1:8545) and enforces:
1. Strict method allowlisting for public/MetaMask callers (eth_chainId, eth_call,
   eth_sendRawTransaction, eth_getTransactionReceipt, etc.).
2. Blocking of administrative/debug/impersonation RPC methods (hardhat_*, evm_*,
   anvil_*, debug_*, personal_*, eth_sign).
3. Authentication via X-DVS-RPC-Token for privileged backend operator methods.
4. Controlled CORS headers for browser-based MetaMask interaction.
"""

import os
import sys
import json
import urllib.request
import urllib.error
from http.server import BaseHTTPRequestHandler, HTTPServer

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "EVoting.settings")

import django  # noqa: E402
django.setup()

from EVotingApp.hardhat_demo import (  # noqa: E402
    evaluate_rpc_request_security,
    load_demo_deployment_metadata,
)


UPSTREAM_RPC_URL = os.environ.get("HARDHAT_INTERNAL_RPC_URL", "http://127.0.0.1:8545")
GATEWAY_HOST = os.environ.get("HARDHAT_GATEWAY_HOST", "0.0.0.0")
GATEWAY_PORT = int(os.environ.get("HARDHAT_GATEWAY_PORT", "8546"))
BACKEND_OPERATOR_TOKEN = os.environ.get("HARDHAT_BACKEND_RPC_TOKEN", "")
RAW_ALLOWED_ORIGINS = os.environ.get("HARDHAT_ALLOWED_CORS_ORIGINS", "*")
ALLOWED_CORS_ORIGINS = [o.strip() for o in RAW_ALLOWED_ORIGINS.split(",") if o.strip()]


class HardhatRpcGatewayHandler(BaseHTTPRequestHandler):
    def log_message(self, format_str, *args):
        # Suppress verbose per-request stdout noise unless debugging
        if os.environ.get("HARDHAT_GATEWAY_VERBOSE") == "1":
            super().log_message(format_str, *args)

    def do_OPTIONS(self):
        origin = self.headers.get("Origin", "*")
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", origin)
        self.send_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
        self.send_header(
            "Access-Control-Allow-Headers",
            "Content-Type, Authorization, X-DVS-RPC-Token",
        )
        self.end_headers()

    def do_GET(self):
        if self.path in ("/healthz", "/healthz/", "/"):
            body = json.dumps({
                "status": "ok",
                "service": "hardhat-demo-rpc-gateway",
                "chain_id": 31337,
            }).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        if self.path in ("/metadata", "/metadata/"):
            base_dir = getattr(self, "metadata_base_dir", None)
            meta = load_demo_deployment_metadata(base_dir=base_dir)
            if not meta:
                err_body = json.dumps({
                    "status": "not_deployed",
                    "chain_id": 31337,
                    "error": "No active EVoting contract deployment metadata found.",
                }).encode("utf-8")
                self.send_response(404)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(err_body)))
                self.end_headers()
                self.wfile.write(err_body)
                return
            body = json.dumps(meta).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        content_len = int(self.headers.get("Content-Length", "0") or "0")
        raw_body = self.rfile.read(content_len) if content_len > 0 else b""

        try:
            payload = json.loads(raw_body.decode("utf-8"))
        except Exception:
            err_body = json.dumps({
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32700, "message": "Parse error"},
            }).encode("utf-8")
            self.send_response(400)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(err_body)))
            self.end_headers()
            self.wfile.write(err_body)
            return

        expected_token = getattr(self, "backend_token", BACKEND_OPERATOR_TOKEN) or None
        cors_origins = getattr(self, "allowed_cors_origins", ALLOWED_CORS_ORIGINS)
        upstream_url = getattr(self, "upstream_rpc_url", UPSTREAM_RPC_URL)

        sec = evaluate_rpc_request_security(
            rpc_payload=payload,
            headers=dict(self.headers),
            expected_backend_token=expected_token,
            allowed_cors_origins=cors_origins,
        )

        if not sec["allowed"]:
            err_body = json.dumps(sec["jsonrpc_error"]).encode("utf-8")
            self.send_response(sec["http_status"])
            self.send_header("Content-Type", "application/json")
            for hk, hv in sec.get("cors_headers", {}).items():
                self.send_header(hk, hv)
            self.send_header("Content-Length", str(len(err_body)))
            self.end_headers()
            self.wfile.write(err_body)
            return

        req = urllib.request.Request(
            upstream_url,
            data=raw_body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                upstream_body = resp.read()
                status_code = resp.getcode()
        except urllib.error.URLError as exc:
            err_body = json.dumps({
                "jsonrpc": "2.0",
                "id": payload.get("id") if isinstance(payload, dict) else None,
                "error": {"code": -32603, "message": f"Upstream Hardhat node unreachable: {exc.reason}"},
            }).encode("utf-8")
            self.send_response(502)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(err_body)))
            self.end_headers()
            self.wfile.write(err_body)
            return

        self.send_response(status_code)
        self.send_header("Content-Type", "application/json")
        for hk, hv in sec.get("cors_headers", {}).items():
            self.send_header(hk, hv)
        self.send_header("Content-Length", str(len(upstream_body)))
        self.end_headers()
        self.wfile.write(upstream_body)


def run_gateway_server(host=GATEWAY_HOST, port=GATEWAY_PORT):
    server = HTTPServer((host, port), HardhatRpcGatewayHandler)
    print(f"[DVS-RPC-Gateway] Listening on http://{host}:{port} -> upstream {UPSTREAM_RPC_URL}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    run_gateway_server()
