"""
Contract-level authorization test suite for EVoting.sol.
Tests EIP-712 permit signing, wallet binding, replay protection, nullifier tracking,
strict ECDSA malleability checks, and authority rotation against a live EVM node (Hardhat).
"""

import json
import time
import secrets
from web3 import Web3
from eth_account import Account
from eth_account.messages import encode_typed_data


def run_contract_test_suite():
    print("=" * 80)
    print("RUNNING EVoting.sol CONTRACT-LEVEL AUTHORIZATION & SECURITY TEST SUITE")
    print("=" * 80)

    # 1. Connect to node
    w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:8545"))
    assert w3.is_connected(), "Must be connected to Hardhat node"
    accounts = w3.eth.accounts
    deployer = accounts[0]
    alice_wallet = accounts[1]
    bob_wallet = accounts[2]
    eve_wallet = accounts[3]

    chain_id = w3.eth.chain_id

    # Generate an independent Election Authority private key (never hardcoded in contract)
    authority_account = Account.create()
    authority_address = authority_account.address
    election_id = 2026

    # Load contract artifact
    with open("artifacts/blocks/contracts/EVoting.sol/EVoting.json", "r") as f:
        artifact = json.load(f)

    abi = artifact["abi"]
    bytecode = artifact["bytecode"]

    # Deploy contract (initializes with empty candidate roster and electionOpen=False)
    ContractFactory = w3.eth.contract(abi=abi, bytecode=bytecode)
    tx_hash = ContractFactory.constructor(authority_address, election_id).transact({"from": deployer})
    tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    contract_address = tx_receipt.contractAddress
    contract = w3.eth.contract(address=contract_address, abi=abi)

    def seed_and_lock_candidates(target_contract, open_immediately=True):
        for cid, cname, csym in [(1, "Rahul Gandhi", "Congress"), (2, "Narendar Modi", "BJP"), (3, "Akhilesh Yadav", "Samajwadi")]:
            t = target_contract.functions.addCandidate(cid, cname, csym).transact({"from": deployer})
            w3.eth.wait_for_transaction_receipt(t)
        t_lock = target_contract.functions.lockCandidates().transact({"from": deployer})
        w3.eth.wait_for_transaction_receipt(t_lock)
        if open_immediately:
            t_open = target_contract.functions.setElectionOpen(True).transact({"from": deployer})
            w3.eth.wait_for_transaction_receipt(t_open)

    print(f"Contract deployed at: {contract_address}")
    print(f"Election Authority: {authority_address}")
    print(f"Chain ID: {chain_id}, Election ID: {election_id}\n")

    # Helper: Sign EIP-712 BallotPermit
    def sign_ballot_permit(signer_key, voter_wallet, candidate_id, voter_nullifier, deadline, nonce):
        typed_data = {
            "types": {
                "EIP712Domain": [
                    {"name": "name", "type": "string"},
                    {"name": "version", "type": "string"},
                    {"name": "chainId", "type": "uint256"},
                    {"name": "verifyingContract", "type": "address"},
                ],
                "BallotPermit": [
                    {"name": "voterWallet", "type": "address"},
                    {"name": "candidateId", "type": "int256"},
                    {"name": "electionId", "type": "uint256"},
                    {"name": "voterNullifier", "type": "bytes32"},
                    {"name": "deadline", "type": "uint256"},
                    {"name": "nonce", "type": "bytes32"},
                ],
            },
            "primaryType": "BallotPermit",
            "domain": {
                "name": "EVoting",
                "version": "1",
                "chainId": chain_id,
                "verifyingContract": contract_address,
            },
            "message": {
                "voterWallet": voter_wallet,
                "candidateId": candidate_id,
                "electionId": election_id,
                "voterNullifier": voter_nullifier,
                "deadline": deadline,
                "nonce": nonce,
            },
        }
        signable_message = encode_typed_data(full_message=typed_data)
        signed = Account.sign_message(signable_message, signer_key)
        return signed.v, signed.r.to_bytes(32, "big"), signed.s.to_bytes(32, "big")

    tests_passed = 0

    # -------------------------------------------------------------
    # TEST 1: Initial State & Candidate Verification
    # -------------------------------------------------------------
    assert contract.functions.totalVotes().call() == 0
    assert contract.functions.getCandidateCount().call() == 0
    assert contract.functions.getCandidateIds().call() == []
    assert contract.functions.candidatesLocked().call() is False
    assert contract.functions.electionOpen().call() is False
    seed_and_lock_candidates(contract, open_immediately=False)
    assert contract.functions.getCandidateCount().call() == 3
    assert contract.functions.getCandidateIds().call() == [1, 2, 3]
    assert contract.functions.candidatesLocked().call() is True
    assert contract.functions.getCount(1).call() == 0
    # Open election on-chain for voting tests 2..12, while keeping another contract for pre-activation window tests
    w3.eth.wait_for_transaction_receipt(contract.functions.setElectionOpen(True).transact({"from": deployer}))
    assert contract.functions.electionOpen().call() is True
    print("[PASS] Test 1: Initial empty-roster state, candidate registration, locking, and opening verified.")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 2: Valid EIP-712 Permit Vote Execution
    # -------------------------------------------------------------
    alice_nullifier = Web3.keccak(text="voter-secret-alice-1")
    alice_nonce = Web3.keccak(text="nonce-alice-1")
    alice_deadline = int(time.time()) + 1000

    v, r, s = sign_ballot_permit(
        authority_account.key, alice_wallet, 1, alice_nullifier, alice_deadline, alice_nonce
    )

    tx = contract.functions.castVoteWithPermit(
        1, alice_nullifier, alice_deadline, alice_nonce, v, r, s
    ).transact({"from": alice_wallet})
    receipt = w3.eth.wait_for_transaction_receipt(tx)
    assert receipt.status == 1
    assert contract.functions.getCount(1).call() == 1
    assert contract.functions.totalVotes().call() == 1
    assert contract.functions.hasVoted(alice_nullifier).call() is True
    assert contract.functions.isNullifierConsumed(alice_nullifier).call() is True
    print("[PASS] Test 2: Valid EIP-712 permit cast vote succeeded, count incremented.")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 3: Unauthorized Direct Call (No Valid Authority Signature)
    # -------------------------------------------------------------
    fake_authority = Account.create()
    fake_v, fake_r, fake_s = sign_ballot_permit(
        fake_authority.key, eve_wallet, 2, Web3.keccak(text="eve-nullifier"), alice_deadline, Web3.keccak(text="eve-nonce")
    )
    try:
        contract.functions.castVoteWithPermit(
            2, Web3.keccak(text="eve-nullifier"), alice_deadline, Web3.keccak(text="eve-nonce"), fake_v, fake_r, fake_s
        ).transact({"from": eve_wallet})
        assert False, "Should have reverted"
    except Exception as e:
        assert "Invalid election authority signature" in str(e) or "revert" in str(e)
    print("[PASS] Test 3: Unauthorized direct call with forged signature reverted.")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 4: Wallet Mismatch (Stolen Permit)
    # -------------------------------------------------------------
    # Permit was signed for Alice, but Bob tries to broadcast it with msg.sender = Bob
    bob_nullifier = Web3.keccak(text="bob-nullifier")
    bob_nonce = Web3.keccak(text="bob-nonce")
    v, r, s = sign_ballot_permit(
        authority_account.key, alice_wallet, 2, bob_nullifier, alice_deadline, bob_nonce
    )
    try:
        contract.functions.castVoteWithPermit(
            2, bob_nullifier, alice_deadline, bob_nonce, v, r, s
        ).transact({"from": bob_wallet})
        assert False, "Should have reverted"
    except Exception as e:
        assert "Invalid election authority signature" in str(e) or "revert" in str(e)
    print("[PASS] Test 4: Wallet mismatch (stolen permit submitted by another wallet) reverted.")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 5: Candidate Tampering
    # -------------------------------------------------------------
    # Permit signed for Candidate 2, but voter tries to submit Candidate 3
    tamper_nonce = Web3.keccak(text="tamper-nonce")
    tamper_nullifier = Web3.keccak(text="tamper-nullifier")
    v, r, s = sign_ballot_permit(
        authority_account.key, bob_wallet, 2, tamper_nullifier, alice_deadline, tamper_nonce
    )
    try:
        contract.functions.castVoteWithPermit(
            3, tamper_nullifier, alice_deadline, tamper_nonce, v, r, s
        ).transact({"from": bob_wallet})
        assert False, "Should have reverted"
    except Exception as e:
        assert "Invalid election authority signature" in str(e) or "revert" in str(e)
    print("[PASS] Test 5: Candidate tampering (altering candidate in submission) reverted.")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 6: Expired Permit Deadline
    # -------------------------------------------------------------
    expired_deadline = int(time.time()) - 100
    expired_nonce = Web3.keccak(text="expired-nonce")
    expired_nullifier = Web3.keccak(text="expired-nullifier")
    v, r, s = sign_ballot_permit(
        authority_account.key, bob_wallet, 2, expired_nullifier, expired_deadline, expired_nonce
    )
    try:
        contract.functions.castVoteWithPermit(
            2, expired_nullifier, expired_deadline, expired_nonce, v, r, s
        ).transact({"from": bob_wallet})
        assert False, "Should have reverted"
    except Exception as e:
        assert "Voting permit expired" in str(e) or "revert" in str(e)
    print("[PASS] Test 6: Expired permit deadline rejected by contract.")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 7: Duplicate Vote / Nullifier Replay
    # -------------------------------------------------------------
    # Attempt to vote again using Alice's already consumed nullifier with a new nonce
    reuse_nonce = Web3.keccak(text="new-nonce-for-alice")
    v, r, s = sign_ballot_permit(
        authority_account.key, alice_wallet, 2, alice_nullifier, alice_deadline, reuse_nonce
    )
    try:
        contract.functions.castVoteWithPermit(
            2, alice_nullifier, alice_deadline, reuse_nonce, v, r, s
        ).transact({"from": alice_wallet})
        assert False, "Should have reverted"
    except Exception as e:
        assert "Duplicate vote: nullifier already consumed" in str(e) or "revert" in str(e)
    print("[PASS] Test 7: Duplicate vote with already-consumed nullifier reverted.")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 8: Permit Nonce Replay
    # -------------------------------------------------------------
    # Attempt to submit the exact same transaction parameters and nonce
    try:
        contract.functions.castVoteWithPermit(
            1, alice_nullifier, alice_deadline, alice_nonce, v, r, s
        ).transact({"from": alice_wallet})
        assert False, "Should have reverted"
    except Exception as e:
        assert "revert" in str(e)
    print("[PASS] Test 8: Replay of consumed permit nonce reverted.")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 9: Strict ECDSA High-S (Malleability) Protection
    # -------------------------------------------------------------
    valid_nonce_2 = Web3.keccak(text="valid-nonce-2")
    valid_nullifier_2 = Web3.keccak(text="valid-nullifier-2")
    v, r, s = sign_ballot_permit(
        authority_account.key, bob_wallet, 2, valid_nullifier_2, alice_deadline, valid_nonce_2
    )

    # Compute high-S: s_high = N - s
    SECP256K1_N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
    s_int = int.from_bytes(s, "big")
    s_high_int = SECP256K1_N - s_int
    s_high_bytes = s_high_int.to_bytes(32, "big")
    v_flipped = 28 if v == 27 else 27

    try:
        contract.functions.castVoteWithPermit(
            2, valid_nullifier_2, alice_deadline, valid_nonce_2, v_flipped, r, s_high_bytes
        ).transact({"from": bob_wallet})
        assert False, "Should have reverted on high-S"
    except Exception as e:
        assert "Invalid election authority signature" in str(e) or "revert" in str(e)
    print("[PASS] Test 9: Strict ECDSA malleability check rejected malleable high-S signature.")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 10: Strict Recovery ID (v != 27 and v != 28) Protection
    # -------------------------------------------------------------
    try:
        contract.functions.castVoteWithPermit(
            2, valid_nullifier_2, alice_deadline, valid_nonce_2, 31, r, s
        ).transact({"from": bob_wallet})
        assert False, "Should have reverted on invalid v"
    except Exception as e:
        assert "Invalid election authority signature" in str(e) or "revert" in str(e)
    print("[PASS] Test 10: Invalid recovery ID (v = 31) rejected by recoverSigner.")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 11: Authority Key Rotation & Revocation
    # -------------------------------------------------------------
    new_authority = Account.create()
    tx = contract.functions.setElectionAuthority(new_authority.address).transact({"from": deployer})
    w3.eth.wait_for_transaction_receipt(tx)
    assert contract.functions.electionAuthority().call() == new_authority.address

    # Old authority signature should now revert
    rotation_nullifier = Web3.keccak(text="rotation-nullifier")
    rotation_nonce = Web3.keccak(text="rotation-nonce")
    old_v, old_r, old_s = sign_ballot_permit(
        authority_account.key, bob_wallet, 2, rotation_nullifier, alice_deadline, rotation_nonce
    )
    try:
        contract.functions.castVoteWithPermit(
            2, rotation_nullifier, alice_deadline, rotation_nonce, old_v, old_r, old_s
        ).transact({"from": bob_wallet})
        assert False, "Old authority signature should revert after rotation"
    except Exception as e:
        assert "Invalid election authority signature" in str(e) or "revert" in str(e)

    # New authority signature should succeed
    new_v, new_r, new_s = sign_ballot_permit(
        new_authority.key, bob_wallet, 2, rotation_nullifier, alice_deadline, rotation_nonce
    )
    tx = contract.functions.castVoteWithPermit(
        2, rotation_nullifier, alice_deadline, rotation_nonce, new_v, new_r, new_s
    ).transact({"from": bob_wallet})
    receipt = w3.eth.wait_for_transaction_receipt(tx)
    assert receipt.status == 1
    assert contract.functions.getCount(2).call() == 1
    print("[PASS] Test 11: Authority rotation verified (old key revoked, new key functional).")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 12: Election Close Guardrail
    # -------------------------------------------------------------
    tx = contract.functions.setElectionOpen(False).transact({"from": deployer})
    w3.eth.wait_for_transaction_receipt(tx)
    assert contract.functions.electionOpen().call() is False

    closed_nullifier = Web3.keccak(text="closed-nullifier")
    closed_nonce = Web3.keccak(text="closed-nonce")
    try:
        contract.functions.castVoteWithPermit(
            3, closed_nullifier, alice_deadline, closed_nonce, v, r, s
        ).transact({"from": eve_wallet})
        assert False, "Should revert when election is closed"
    except Exception as e:
        assert "Election is closed" in str(e) or "revert" in str(e)
    print("[PASS] Test 12: Voting rejected when election is closed.")
    tests_passed += 1
    # -------------------------------------------------------------
    # TEST 13: Early Voting Rejection (Before votingStartTime)
    # -------------------------------------------------------------
    tx_hash_early = ContractFactory.constructor(new_authority.address, 2026).transact({"from": deployer})
    rec_early = w3.eth.wait_for_transaction_receipt(tx_hash_early)
    early_contract = w3.eth.contract(address=rec_early.contractAddress, abi=abi)
    seed_and_lock_candidates(early_contract, open_immediately=False)

    current_time = int(time.time())
    future_start = current_time + 3600  # 1 hour in future
    future_end = current_time + 7200

    # Configure window while still pre-activated (votingWindowLocked == False)
    assert early_contract.functions.votingWindowLocked().call() is False
    tx = early_contract.functions.setVotingWindow(future_start, future_end).transact({"from": deployer})
    w3.eth.wait_for_transaction_receipt(tx)

    # Activate election (locks votingWindowLocked = True)
    tx = early_contract.functions.setElectionOpen(True).transact({"from": deployer})
    w3.eth.wait_for_transaction_receipt(tx)
    assert early_contract.functions.votingWindowLocked().call() is True

    # Sign permit for target contract
    def sign_for_contract(target_addr, target_el_id, signer_key, voter_wallet, candidate_id, voter_nullifier, deadline, nonce):
        typed_data = {
            "types": {
                "EIP712Domain": [
                    {"name": "name", "type": "string"},
                    {"name": "version", "type": "string"},
                    {"name": "chainId", "type": "uint256"},
                    {"name": "verifyingContract", "type": "address"},
                ],
                "BallotPermit": [
                    {"name": "voterWallet", "type": "address"},
                    {"name": "candidateId", "type": "int256"},
                    {"name": "electionId", "type": "uint256"},
                    {"name": "voterNullifier", "type": "bytes32"},
                    {"name": "deadline", "type": "uint256"},
                    {"name": "nonce", "type": "bytes32"},
                ],
            },
            "primaryType": "BallotPermit",
            "domain": {
                "name": "EVoting",
                "version": "1",
                "chainId": chain_id,
                "verifyingContract": target_addr,
            },
            "message": {
                "voterWallet": voter_wallet,
                "candidateId": candidate_id,
                "electionId": target_el_id,
                "voterNullifier": voter_nullifier,
                "deadline": deadline,
                "nonce": nonce,
            },
        }
        signable_message = encode_typed_data(full_message=typed_data)
        signed = Account.sign_message(signable_message, signer_key)
        return signed.v, signed.r.to_bytes(32, "big"), signed.s.to_bytes(32, "big")

    early_nullifier = Web3.keccak(text="early-nullifier")
    early_nonce = Web3.keccak(text="early-nonce")
    v, r, s = sign_for_contract(
        early_contract.address, 2026, new_authority.key, eve_wallet, 3, early_nullifier, future_end, early_nonce
    )
    try:
        early_contract.functions.castVoteWithPermit(
            3, early_nullifier, future_end, early_nonce, v, r, s
        ).transact({"from": eve_wallet})
        assert False, "Should revert when voting before start time"
    except Exception as e:
        assert "Voting has not started yet" in str(e) or "revert" in str(e)
    print("[PASS] Test 13: Early voting attempt before votingStartTime rejected on-chain.")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 14: Valid Voting Within Start/End Time Window
    # -------------------------------------------------------------
    tx_hash = ContractFactory.constructor(new_authority.address, 2026).transact({"from": deployer})
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    active_window_contract = w3.eth.contract(address=receipt.contractAddress, abi=abi)
    seed_and_lock_candidates(active_window_contract, open_immediately=False)

    active_start = current_time - 60  # Started 1 min ago
    active_end = current_time + 3600  # Ends in 1 hour
    tx = active_window_contract.functions.setVotingWindow(active_start, active_end).transact({"from": deployer})
    w3.eth.wait_for_transaction_receipt(tx)
    tx = active_window_contract.functions.setElectionOpen(True).transact({"from": deployer})
    w3.eth.wait_for_transaction_receipt(tx)

    valid_time_nullifier = Web3.keccak(text="valid-time-nullifier")
    valid_time_nonce = Web3.keccak(text="valid-time-nonce")
    v, r, s = sign_for_contract(
        active_window_contract.address, 2026, new_authority.key, eve_wallet, 3, valid_time_nullifier, active_end, valid_time_nonce
    )
    tx = active_window_contract.functions.castVoteWithPermit(
        3, valid_time_nullifier, active_end, valid_time_nonce, v, r, s
    ).transact({"from": eve_wallet})
    receipt = w3.eth.wait_for_transaction_receipt(tx)
    assert receipt.status == 1
    assert active_window_contract.functions.getCount(3).call() == 1
    print("[PASS] Test 14: Valid vote within votingStartTime and votingEndTime window succeeded.")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 15: Expired Voting Rejection (After votingEndTime)
    # -------------------------------------------------------------
    tx_hash = ContractFactory.constructor(new_authority.address, 2027).transact({"from": deployer})
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    expired_contract = w3.eth.contract(address=receipt.contractAddress, abi=abi)
    seed_and_lock_candidates(expired_contract, open_immediately=False)

    expired_start = current_time - 3600
    expired_end = current_time - 60  # Ended 1 min ago
    tx = expired_contract.functions.setVotingWindow(expired_start, expired_end).transact({"from": deployer})
    w3.eth.wait_for_transaction_receipt(tx)
    tx = expired_contract.functions.setElectionOpen(True).transact({"from": deployer})
    w3.eth.wait_for_transaction_receipt(tx)

    expired_nullifier = Web3.keccak(text="expired-nullifier")
    expired_nonce = Web3.keccak(text="expired-nonce")
    v, r, s = sign_for_contract(
        expired_contract.address, 2027, new_authority.key, eve_wallet, 3, expired_nullifier, current_time + 600, expired_nonce
    )
    try:
        expired_contract.functions.castVoteWithPermit(
            3, expired_nullifier, current_time + 600, expired_nonce, v, r, s
        ).transact({"from": eve_wallet})
        assert False, "Should revert when voting after end time"
    except Exception as e:
        assert "Voting deadline passed on-chain" in str(e) or "revert" in str(e)
    print("[PASS] Test 15: Vote attempt after votingEndTime rejected on-chain.")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 16: Non-Owner Unauthorized Time Window & Lock Attempts
    # -------------------------------------------------------------
    tx_hash = ContractFactory.constructor(authority_address, 2028).transact({"from": deployer})
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    window_test_contract = w3.eth.contract(address=receipt.contractAddress, abi=abi)
    seed_and_lock_candidates(window_test_contract, open_immediately=False)

    try:
        window_test_contract.functions.setVotingWindow(current_time, current_time + 3600).transact({"from": eve_wallet})
        assert False, "Non-owner should not be able to set voting window"
    except Exception as e:
        assert "Only contract owner permitted" in str(e) or "revert" in str(e)

    try:
        window_test_contract.functions.lockVotingWindow().transact({"from": eve_wallet})
        assert False, "Non-owner should not be able to lock voting window"
    except Exception as e:
        assert "Only contract owner permitted" in str(e) or "revert" in str(e)
    print("[PASS] Test 16: Non-owner unauthorized attempts to modify or lock voting window rejected.")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 17: Candidate Roster Locking Rejection
    # -------------------------------------------------------------
    assert contract.functions.candidatesLocked().call() is True
    try:
        contract.functions.addCandidate(99, "Unauthorized Candidate", "BAD").transact({"from": deployer})
        assert False, "Adding candidate when locked should revert"
    except Exception as e:
        assert "Candidate roster is locked on-chain" in str(e) or "revert" in str(e)
    print("[PASS] Test 17: Candidate modification rejected after candidate roster locked.")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 18: Voting Window Changes BEFORE Activation Succeed
    # -------------------------------------------------------------
    assert window_test_contract.functions.votingWindowLocked().call() is False
    w_start_1 = current_time + 100
    w_end_1 = current_time + 1000
    tx = window_test_contract.functions.setVotingWindow(w_start_1, w_end_1).transact({"from": deployer})
    w3.eth.wait_for_transaction_receipt(tx)
    assert window_test_contract.functions.votingStartTime().call() == w_start_1
    assert window_test_contract.functions.votingEndTime().call() == w_end_1

    # Modify window again before activation
    w_start_2 = current_time + 200
    w_end_2 = current_time + 2000
    tx = window_test_contract.functions.setVotingWindow(w_start_2, w_end_2).transact({"from": deployer})
    w3.eth.wait_for_transaction_receipt(tx)
    assert window_test_contract.functions.votingStartTime().call() == w_start_2
    assert window_test_contract.functions.votingEndTime().call() == w_end_2
    print("[PASS] Test 18: Voting window configuration and updates before activation succeeded.")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 19: Voting Window Locked & Immutable AFTER Activation
    # -------------------------------------------------------------
    tx = window_test_contract.functions.setElectionOpen(True).transact({"from": deployer})
    w3.eth.wait_for_transaction_receipt(tx)
    assert window_test_contract.functions.votingWindowLocked().call() is True

    try:
        window_test_contract.functions.setVotingWindow(w_start_2 + 50, w_end_2 + 50).transact({"from": deployer})
        assert False, "Modifying voting window after activation should revert"
    except Exception as e:
        assert "Voting window is locked and cannot be modified" in str(e) or "revert" in str(e)

    try:
        window_test_contract.functions.setVotingEndTime(w_end_2 + 500).transact({"from": deployer})
        assert False, "Modifying voting end time after activation should revert"
    except Exception as e:
        assert "Voting window is locked and cannot be modified" in str(e) or "revert" in str(e)
    print("[PASS] Test 19: Voting window locked upon activation; modifications after activation rejected.")
    tests_passed += 1

    # -------------------------------------------------------------
    # TEST 20: Voting Window Remains Locked & Immutable AFTER Closure
    # -------------------------------------------------------------
    tx = window_test_contract.functions.setElectionOpen(False).transact({"from": deployer})
    w3.eth.wait_for_transaction_receipt(tx)
    assert window_test_contract.functions.electionOpen().call() is False
    assert window_test_contract.functions.votingWindowLocked().call() is True

    try:
        window_test_contract.functions.setVotingWindow(current_time + 500, current_time + 5000).transact({"from": deployer})
        assert False, "Modifying voting window after election closure should revert"
    except Exception as e:
        assert "Voting window is locked and cannot be modified" in str(e) or "revert" in str(e)
    print("[PASS] Test 20: Voting window remains permanently locked after closure; modifications rejected.")
    tests_passed += 1

    print("=" * 80)
    print(f"ALL {tests_passed}/20 CONTRACT AUTHORIZATION & CRYPTOGRAPHIC TESTS PASSED!")
    print("=" * 80)


if __name__ == "__main__":
    run_contract_test_suite()



