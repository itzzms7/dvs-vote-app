"""
End-to-end integration test simulating the complete frontend MetaMask flow:
- Wallet challenge request & EIP-191 personal_sign authentication
- EIP-712 ballot permit acquisition with voter whitelist validation
- Client-side ABI encoding of castVoteWithPermit matching metamask.js
- Transaction submission from voter's wallet on Hardhat node
- Confirmation endpoint verification and database synchronization
- Duplicate voting and account switching rejection
"""

import os
import sys
import json
import time
import secrets
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'EVoting.settings')
django.setup()

from django.conf import settings
from django.test import Client
from web3 import Web3
from eth_account import Account
from eth_account.messages import encode_defunct

from EVotingApp.models import Voter, IssuedPermit
from EVotingApp.crypto import derive_voter_nullifier


def pad32(val):
    if isinstance(val, int):
        return hex(val)[2:].zfill(64)
    clean_hex = str(val)
    if clean_hex.startswith("0x"):
        clean_hex = clean_hex[2:]
    return clean_hex.zfill(64)


def encode_cast_vote_with_permit_js(candidate_id, nullifier, deadline, nonce, v, r, s):
    """
    Exact replica of encodeCastVoteWithPermit implemented in metamask.js
    """
    selector = "9e3b026b"
    return "0x" + selector + (
        pad32(candidate_id) +
        pad32(nullifier) +
        pad32(deadline) +
        pad32(nonce) +
        pad32(v) +
        pad32(r) +
        pad32(s)
    )


def run_stage3_frontend_e2e_tests():
    print("=" * 80)
    print("STAGE 3: FRONTEND METAMASK TO BACKEND TO EVM CONTRACT E2E VERIFICATION")
    print("=" * 80)

    w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:8545"))
    assert w3.is_connected(), "Hardhat node must be running on 127.0.0.1:8545"

    accounts = w3.eth.accounts
    deployer = accounts[0]
    voter_wallet_address = accounts[6]

    # Load contract artifact & deploy
    with open("artifacts/blocks/contracts/EVoting.sol/EVoting.json", "r") as f:
        artifact = json.load(f)

    authority_key = settings.ELECTION_AUTHORITY_PRIVATE_KEY
    authority_account = Account.from_key(authority_key)
    election_id = settings.ELECTION_ID

    from EVotingApp.models import Election
    from EVotingApp.services import initialize_legacy_election_2026_on_chain

    ContractFactory = w3.eth.contract(abi=artifact["abi"], bytecode=artifact["bytecode"])
    tx_hash = ContractFactory.constructor(authority_account.address, election_id).transact({"from": deployer})
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    contract_address = receipt.contractAddress
    deployed_contract = w3.eth.contract(address=contract_address, abi=artifact["abi"])

    legacy_el = Election.objects.get(election_id=election_id)
    original_el_contract = legacy_el.contract_address
    initialize_legacy_election_2026_on_chain(legacy_el, deployed_contract, w3, deployer)
    legacy_el.contract_address = contract_address
    legacy_el.candidates_locked_on_chain = True
    legacy_el.status = 'ACTIVE'
    legacy_el.save(update_fields=['contract_address', 'candidates_locked_on_chain', 'status'])

    # Update contract address in Django views
    import EVotingApp.views as app_views
    app_views.contract_address = contract_address
    app_views.contract = deployed_contract

    print(f"Contract deployed at: {contract_address}")
    print(f"Authority address: {authority_account.address}")
    print(f"Voter wallet: {voter_wallet_address}\n")

    client = Client()

    # Create / reset test voter
    from EVotingApp.models import VoterEligibility
    test_voter, _ = Voter.objects.get_or_create(
        aadhar_number="094490094490",
        defaults={"name": "Suhail"}
    )
    test_voter.bound_wallet = None
    test_voter.has_voted = False
    test_voter.voted_at = None
    test_voter.save()
    VoterEligibility.objects.update_or_create(
        voter=test_voter,
        election=legacy_el,
        defaults={"is_eligible": True, "has_voted": False, "voted_at": None},
    )

    # -------------------------------------------------------------
    # STEP 1: Challenge Request & EIP-191 Personal Sign
    # -------------------------------------------------------------
    challenge_res = client.get(f"/api/wallet/challenge/?address={voter_wallet_address}")
    assert challenge_res.status_code == 200, f"Challenge failed: {challenge_res.content}"
    challenge_data = challenge_res.json()
    challenge_text = challenge_data["challenge"]
    nonce = challenge_data["nonce"]

    # Sign with Hardhat node's private key for voter_wallet_address
    # Since Hardhat test accounts can sign via personal_sign or standard eth-account:
    # We will use personal_sign via web3 provider
    signed_hex = w3.eth.sign(voter_wallet_address, text=challenge_text).hex()

    verify_res = client.post(
        "/api/wallet/verify/",
        data=json.dumps({
            "address": voter_wallet_address,
            "nonce": nonce,
            "signature": signed_hex
        }),
        content_type="application/json"
    )
    assert verify_res.status_code == 200, f"Verification failed: {verify_res.content}"
    assert verify_res.json()["success"] is True

    status_res = client.get("/api/wallet/status/")
    assert status_res.json()["authenticated"] is True
    assert status_res.json()["wallet"].lower() == voter_wallet_address.lower()
    print("[PASS] Step 1: EIP-191 challenge requested, signed, and verified. Session authenticated.")

    # -------------------------------------------------------------
    # STEP 2: Request EIP-712 Ballot Permit
    # -------------------------------------------------------------
    candidate_id = 2  # Narendar Modi
    permit_res = client.post(
        "/api/ballot/permit/",
        data=json.dumps({
            "candidate_id": candidate_id,
            "aadhar": "094490094490"
        }),
        content_type="application/json"
    )
    assert permit_res.status_code == 200, f"Permit failed: {permit_res.content}"
    permit_payload = permit_res.json()["permit"]
    assert permit_payload["candidateId"] == candidate_id
    assert permit_payload["voterWallet"].lower() == voter_wallet_address.lower()
    print("[PASS] Step 2: EIP-712 Ballot Permit authorized and issued by backend.")

    # -------------------------------------------------------------
    # STEP 3: Client ABI Encoding & Transaction Broadcast
    # -------------------------------------------------------------
    call_data = encode_cast_vote_with_permit_js(
        permit_payload["candidateId"],
        permit_payload["voterNullifier"],
        permit_payload["deadline"],
        permit_payload["nonce"],
        permit_payload["v"],
        permit_payload["r"],
        permit_payload["s"]
    )

    # Submit transaction from voter's wallet on Hardhat
    tx = w3.eth.send_transaction({
        "from": voter_wallet_address,
        "to": contract_address,
        "data": call_data,
        "gas": 300000
    })
    tx_receipt = w3.eth.wait_for_transaction_receipt(tx)
    assert tx_receipt.status == 1, "Transaction failed on-chain"
    print(f"[PASS] Step 3: Transaction mined in block #{tx_receipt.blockNumber} (Tx: {tx.hex()[:18]}...).")

    # -------------------------------------------------------------
    # STEP 4: Confirm Vote on Backend & Synchronize Database
    # -------------------------------------------------------------
    confirm_res = client.post(
        "/api/ballot/confirm/",
        data=json.dumps({
            "tx_hash": tx.hex(),
            "nullifier": permit_payload["voterNullifier"]
        }),
        content_type="application/json"
    )
    assert confirm_res.status_code == 200, f"Confirmation failed: {confirm_res.content}"
    assert confirm_res.json()["success"] is True

    test_voter.refresh_from_db()
    assert test_voter.has_voted is True
    assert test_voter.voted_at is not None
    assert app_views.contract.functions.getCount(candidate_id).call() == 1
    print("[PASS] Step 4: Backend confirmed receipt, verified VoteCast event, marked voter has_voted = True.")

    # -------------------------------------------------------------
    # STEP 5: Duplicate Vote Rejection Test
    # -------------------------------------------------------------
    # Voter attempts to request a second permit for the same identity
    dup_permit_res = client.post(
        "/api/ballot/permit/",
        data=json.dumps({
            "candidate_id": 1,
            "aadhar": "094490094490"
        }),
        content_type="application/json"
    )
    assert dup_permit_res.status_code == 409, "Should reject already-voted citizen"
    print("[PASS] Step 5: Duplicate vote attempt rejected by backend.")

    # -------------------------------------------------------------
    # STEP 6: Account Switch & Disconnect Test
    # -------------------------------------------------------------
    disconnect_res = client.post("/api/wallet/disconnect/")
    assert disconnect_res.status_code == 200
    assert client.get("/api/wallet/status/").json()["authenticated"] is False
    print("[PASS] Step 6: Disconnect and account switch invalidated session.")

    # Restore original contract_address on Election 2026
    legacy_el.contract_address = original_el_contract
    legacy_el.save(update_fields=['contract_address'])
    app_views.contract_address = original_el_contract
    app_views.contract = w3.eth.contract(address=Web3.to_checksum_address(original_el_contract), abi=artifact["abi"])

    print("=" * 80)
    print("ALL STAGE 3 FRONTEND-TO-BACKEND-TO-EVM E2E FLOW TESTS PASSED!")
    print("=" * 80)


if __name__ == "__main__":
    run_stage3_frontend_e2e_tests()
