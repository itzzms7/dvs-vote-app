# DVS — Local Hardhat + Django Setup (Windows)

This build uses Django + SQLite for voter records, eligibility, candidates, election schedules, staff accounts, and confirmed ballot receipts. Each election uses a separate deployment of `blocks/contracts/EVoting.sol` on the local Hardhat chain. Candidate symbol images are stored in Django's `media/` directory. The voter UI uses Authenticate → MetaMask connection → candidate selection → vote submission; the passkey controls are not part of this voter flow.

## Requirements

- Windows 10/11
- Python 3.12 recommended
- Node.js 22 or later and npm
- MetaMask browser extension
- Remix IDE in a browser

## 1. Prepare the project

Open PowerShell in the extracted project folder. Create a virtual environment and install Python packages:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.python.txt
copy .env.example .env
```

Django reads `.env` automatically at startup. If you already have a `.env` from the previous DVS build, update it with the local values below and remove any old remote gateway URL or old contract address:

```dotenv
DJANGO_ENV=development
DJANGO_DEBUG=True
DB_ENGINE=sqlite3
DVS_BLOCKCHAIN_BASE_URL=http://127.0.0.1:8545
WEB3_RPC_URL=http://127.0.0.1:8545
METAMASK_RPC_URL=http://127.0.0.1:8545
REQUIRE_HTTPS_RPC=False
CHAIN_ID=31337
DVS_TX_ACCOUNT_INDEX=0
DVS_CONTRACT_ADDRESS=
```

Keep `.env` private. Do not paste a private key or seed phrase into the project or chat. The local Hardhat node provides unlocked development accounts.

Install the Hardhat dependencies:

```powershell
npm install
```

## 2. Start the local blockchain

Open **Terminal 1** in VS Code and run:

```powershell
npx hardhat node
```

Keep this terminal open. The local Hardhat chain uses Chain ID `31337`. Its state is reset when the node is stopped and restarted. Do not restart it during an active election. After a restart, start a fresh election and deploy a new contract; old contract addresses and on-chain vote totals are no longer present.

## 3. Deploy the voting contract in Remix

1. Open `https://remix.ethereum.org`.
2. Create a Solidity file named `EVoting.sol`.
3. Copy the complete contents of `blocks/contracts/EVoting.sol` from this project and paste them into Remix. The matching Hardhat source is also at `contracts/EVoting.sol`.
4. In the Solidity Compiler tab, select compiler version `0.8.28` and compile `EVoting.sol`.
5. In Deploy & Run Transactions, choose **Custom - External Http Provider** and enter `http://127.0.0.1:8545`.
6. Select the **first unlocked account (Account #0)** returned by `npx hardhat node`. This account must own the contract because Django uses account index `0` for candidate registration, election open/close, and vote transactions.
7. Click **Deploy**. Under Deployed Contracts, copy the new contract address.

For each new election, deploy a fresh instance of the contract and attach that instance to that election. Do not reuse a contract that already has a locked candidate roster.

## 4. Paste the contract address

In VS Code, open `.env` and paste the address after `DVS_CONTRACT_ADDRESS=` (keep the `0x` prefix). Save the file, then restart Django if it is already running.

You can also paste the address into the **Deployed Contract Address** field in the selected election's Control Portal. The address is validated against the running local chain when you click **Attach Contract**.

## 5. Migrate the SQLite database

Open **Terminal 2** in VS Code, activate the virtual environment, then run:

```powershell
.\.venv\Scripts\Activate.ps1
python manage.py migrate
python manage.py check
```

The migration adds the candidate symbol image field and a confirmed ballot receipt table. If you are upgrading an existing DVS folder, back up `db.sqlite3` and the `secrets/` directory first. Keep both in the project root; do not replace the database with a blank file or regenerate the existing nullifier pepper while an election is in progress. The ZIP supplied with this source intentionally does not contain the database or secrets.

Create an administrator only when the database does not already have one:

```powershell
python manage.py createsuperuser
```

## 6. Start the election scheduler and Django

Open **Terminal 3** and run the election scheduler. Keep it running so scheduled opening and closing transitions are processed automatically:

```powershell
.\.venv\Scripts\Activate.ps1
python manage.py run_election_scheduler --interval 5
```

Open **Terminal 4** and run Django:

```powershell
.\.venv\Scripts\Activate.ps1
python manage.py runserver 127.0.0.1:8000
```

Open the voter portal at `http://localhost:8000/Vote.html` and the administration portal at `http://localhost:8000/control/`. Use `localhost` consistently for the browser session.

## 7. Prepare an election in the Control Portal

1. Sign in with a Django staff account that has Super Admin or Election Administrator access.
2. Create a draft election and select its commencement mode.
3. Add each candidate with a unique ballot number, candidate name, party/symbol label, and a PNG/JPG/WEBP symbol image (maximum 5 MB).
4. Deploy a fresh `EVoting.sol` contract in Remix and copy its address. Paste the address in `.env` or the selected election's **Deployed Contract Address** field, then click **Attach Contract**.
5. Configure the election's opening and closing date/time and save the schedule.
6. Click **Update & Lock Roster**. Django synchronizes the candidate IDs, names, and symbol labels to the contract, then locks the candidate roster and voting window.
7. Add voters to SQLite and assign eligibility for this election using the Voter Registry panel. Voters must have an active voter record and an active eligibility assignment for this specific election.
8. For a **Scheduled Election**, the scheduler opens voting automatically when the configured start time arrives and closes it at the configured end time. Keep the scheduler terminal running. For an **Immediate Election**, use **Open Election for Voting** after the contract, roster, and time window have been locked; that action opens it immediately.

## 8. Voter flow

1. Open `http://localhost:8000/Vote.html` and choose the active election.
2. Enter the 12-digit Voter ID and click **Authenticate**. Django checks the active voter record, security flag, election status, and SQLite eligibility assignment.
3. The wallet card appears. Click **Connect Wallet** and approve the MetaMask connection. MetaMask is switched to or prompted to add **DVS Hardhat Local**, Chain ID `31337`, RPC `http://127.0.0.1:8545`.
4. Select a candidate, review the selection, and click **Submit Vote**.
5. Django rechecks eligibility and duplicate-vote status, submits `markVote(candidate_id, voter_hash)` from the configured local Hardhat account, waits for a successful transaction receipt, and stores the receipt in SQLite. The page then refreshes and displays the confirmation reference.

The browser wallet connection is handled by MetaMask in the browser. The ballot transaction in this build is sent by Django using the unlocked local Hardhat account selected by `DVS_TX_ACCOUNT_INDEX`; the connected browser account does not sign the ballot transaction. The voter ID is transformed into an election-specific HMAC/Keccak nullifier before being sent to the contract. This is a local development/test arrangement: do not deploy it as a public election service or use real voter identifiers on a public network.

## Troubleshooting

- **Hardhat offline:** check Terminal 1; keep `npx hardhat node` running.
- **Contract address has no code:** the node was restarted or the address belongs to another chain; deploy again and attach the fresh address.
- **Contract owner mismatch:** redeploy in Remix using Hardhat Account #0.
- **MetaMask wrong network:** use Chain ID `31337` and RPC `http://127.0.0.1:8545`.
- **Existing database after moving the project:** restore both `db.sqlite3` and the original `secrets/` directory before starting Django, so the voter registry and nullifier pepper remain consistent.
- **No candidates shown:** check that the election is ACTIVE, candidates are synchronized, and the roster and voting window are locked.
- **Voter rejected:** verify the voter is ACTIVE, not security-flagged, and assigned eligible status for the selected election in the Control Portal.
- **Symbol images not loading:** keep Django running in DEBUG mode and ensure `media/` exists and the candidate image is present.
