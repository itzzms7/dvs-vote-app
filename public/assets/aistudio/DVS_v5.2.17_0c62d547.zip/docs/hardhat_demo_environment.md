# Decentralized Voting System (DVS) — Phase 8: Hardhat Demonstration Environment

## 1. Objective & System Topology

This document defines the architecture, security controls, deployment procedure, and recovery runbook for the separately hosted **Hardhat Demonstration Environment** (Chain ID `31337`).

Target demonstration architecture:
- **Django Web Application:** Hosted as an independent service on Google Cloud Run.
- **Hardhat Blockchain Demonstration Service:** Hosted as an independent, stateful Ethereum JSON-RPC service (`Chain ID 31337`).
- **Backend Connectivity (Phase 9):** Django connects to the remote Hardhat RPC endpoint via `WEB3_RPC_URL` and authenticates privileged lifecycle requests using `X-DVS-RPC-Token` or raw deployer-signed transactions.
- **Browser / MetaMask Connectivity:** Voter browsers connect MetaMask to the same demonstration network (`Chain ID 31337`) via the filtered JSON-RPC Security Gateway to submit EIP-712 `castVoteWithPermit` transactions (`eth_sendRawTransaction`).

---

## 2. Remote Hosting Architecture & Rationale

### 2.1 Evaluation of Hosting Options
Because `npx hardhat node` maintains its blockchain state (blocks, contract bytecode, candidate roster, and nullifier mappings) **in memory**, any container eviction, scale-to-zero event, or process restart resets the entire chain to block `0`.

| Hosting Option | State Persistence Across Requests | Suitability for DVS Demo |
| :--- | :--- | :--- |
| **Option A (Recommended): Dedicated Google Compute Engine (GCE) VM (`e2-medium`) with Docker + systemd** | **High.** Process stays resident in memory continuously until explicitly restarted by an operator. | **Preferred.** Prevents mid-demonstration chain resets caused by serverless scale-down or instance rotation. |
| **Option B: Google Cloud Run Service (`min-instances=1`, `max-instances=1`, CPU always allocated)** | **Moderate.** Remains warm while `min-instances=1` is active, but horizontal scaling (`max-instances > 1`) or underlying revision restarts will split or wipe in-memory chain state. | **Acceptable only if pinned to `min-instances=1` and `max-instances=1`**, with automated `reinit` recovery. |
| **Option C: Serverless Scale-to-Zero Container** | **None.** Wipes deployed contracts after idle timeout. | **Rejected.** Unsuitable for stateful blockchain demonstrations. |

### 2.2 Selected Architecture
A dedicated container (`deploy/hardhat_demo/Dockerfile.hardhat`) running on a persistent **Google Compute Engine (GCE) VM** (or single-instance pinned container host) with a two-tier internal architecture:
1. **Internal Hardhat EVM Node (`127.0.0.1:8545`):** Bound strictly to loopback so unrestricted administrative RPC methods are never exposed to external interfaces.
2. **External JSON-RPC Security Gateway (`0.0.0.0:8546` behind TLS reverse proxy):** Implemented in `scripts/hardhat_rpc_gateway.py` and `EVotingApp/hardhat_demo.py`, enforcing strict RPC method whitelisting, CORS origin verification, and token checks.

---

## 3. Demonstration Network & Account Configuration

- **Network Name:** `hardhat-demo`
- **Chain ID:** `31337` (`0x7a69`)
- **Solidity Compiler:** `0.8.28` (`blocks/contracts/EVoting.sol`)
- **Currency Symbol:** `ETH` (Demonstration Test ETH only; zero real monetary value)

### Role-Separated Pre-Funded Accounts
Hardhat initializes 20 deterministic demonstration accounts funded with `10,000 ETH` each:
- **Deployer Account (Account #0):** `0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266`
  - Deploys `EVoting.sol` (`owner`) and executes administrative lifecycle transactions (`addCandidate`, `lockCandidates`, `setVotingWindow`, `setElectionOpen`).
- **Election Authority Account (Distinct from Deployer):** `0xEe1BbC1BAf695c990ecb43e6Fd43d47060c12D58` (or custom demonstration key configured via `ELECTION_AUTHORITY_PRIVATE_KEY`)
  - Signs off-chain EIP-712 `BallotPermit` authorizations verified on-chain by `EVoting.castVoteWithPermit`.
  - Enforces strict role separation (`owner != electionAuthority`).
- **Secondary Operator / Authority Reserve (Account #1):** `0x70997970C51812dc3A010C7d01b50e0d17dc79C8`
- **Synthetic Demonstration Voter Accounts (Accounts #2–#5):**
  - `DEMO_VOTER_1` (Account #2): `0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC`
  - `DEMO_VOTER_2` (Account #3): `0x90F79bf6EB2c4f870365E785982E1f101E93b906`
  - `DEMO_VOTER_3` (Account #4): `0x15d34AAf54267DB7D7c367839AAf71A00a2C6A65`
  - `DEMO_VOTER_4` (Account #5): `0x9965507D1a55bcC2695C58ba16FB37d819B0A4dc`

---

## 4. RPC Access & Security Configuration

A publicly reachable Hardhat node is **not** secure merely because it uses Chain ID `31337`. Without method filtering, any external caller could invoke `hardhat_reset` to wipe the election or `hardhat_impersonateAccount` to forge transactions.

The JSON-RPC Security Gateway (`scripts/hardhat_rpc_gateway.py` / `evaluate_rpc_request_security`) enforces:
1. **Blocked Administrative & Debug Namespaces:**
   - Rejects `hardhat_*`, `evm_*`, `anvil_*`, `debug_*`, `trace_*`, `personal_*`, `admin_*`, `miner_*`, `txpool_*`, `eth_sign`, and `eth_sendUnsignedTransaction` with HTTP `403` / JSON-RPC `-32601`.
2. **Restricted Unlocked Account Transactions:**
   - Rejects `eth_sendTransaction` and `eth_accounts` from unauthenticated callers unless the request includes a valid backend operator token (`X-DVS-RPC-Token` or `Authorization: Bearer <token>`).
3. **Permitted Public / MetaMask Methods:**
   - Allows `eth_chainId`, `net_version`, `web3_clientVersion`, `eth_blockNumber`, `eth_getBalance`, `eth_getTransactionCount`, `eth_getCode`, `eth_call`, `eth_estimateGas`, `eth_gasPrice`, `eth_maxPriorityFeePerGas`, `eth_feeHistory`, `eth_sendRawTransaction`, `eth_getTransactionReceipt`, `eth_getTransactionByHash`, `eth_getBlockByNumber`, `eth_getBlockByHash`, and `eth_getLogs`.
4. **CORS Policy for Browser MetaMask Interaction:**
   - Validates the `Origin` header against `HARDHAT_ALLOWED_CORS_ORIGINS` so MetaMask running on the Django web origin can submit signed `eth_sendRawTransaction` requests while unauthorized browser origins are rejected.

---

## 5. Repeatable Operational Workflow

All operational commands are provided via `scripts/hardhat_demo_ctl.sh` and `python3 manage.py hardhat_demo`:

```bash
# 1. Start the Hardhat demonstration node (Chain ID 31337)
bash scripts/hardhat_demo_ctl.sh start

# 2. Check node availability, Chain ID, block number, and pre-funded account balances
bash scripts/hardhat_demo_ctl.sh status

# 3. Deploy the EVoting contract, verify bytecode & initial state, and record metadata
bash scripts/hardhat_demo_ctl.sh deploy --election-id 2026

# 4. Retrieve active deployment metadata (contains zero private keys)
bash scripts/hardhat_demo_ctl.sh metadata

# 5. Verify on-chain contract bytecode, owner, authority, and EIP-712 DOMAIN_SEPARATOR
bash scripts/hardhat_demo_ctl.sh verify

# 6. Reinitialize and redeploy after a Hardhat node restart or chain reset
bash scripts/hardhat_demo_ctl.sh reinit --election-id 2026

# 7. Safely stop the demonstration node
bash scripts/hardhat_demo_ctl.sh stop
```

---

## 6. Deployment Metadata & Phase 9 Handoff Procedure

Every contract deployment writes a structured, secret-free record to:
- Active deployment record: `deployments/hardhat_demo_deployment.json`
- Historical audit log across resets: `deployments/hardhat_demo_history.json`

### How Django Will Be Updated in Phase 9 (Out of Scope for Phase 8)
When transitioning to **Phase 9 (Django-to-Blockchain Integration)**:
1. Retrieve `contract_address`, `chain_id`, `election_authority_address`, and `rpc_endpoint` from `deployments/hardhat_demo_deployment.json` (via `bash scripts/hardhat_demo_ctl.sh metadata`).
2. Configure the Cloud Run environment variables `WEB3_RPC_URL`, `CONTRACT_ADDRESS`, `CHAIN_ID=31337`, and `ELECTION_AUTHORITY_ADDRESS` to match the active demonstration deployment record.
3. Whenever the remote Hardhat node restarts, run `bash scripts/hardhat_demo_ctl.sh reinit` to deploy a fresh contract instance and synchronize the new `contract_address` with the Django Election record.
