"""
Module 6 — Pluggable Identity Provider Architecture, SSRF Guardrails,
JWS Signature Verification, and Staged Pending Voter Onboarding.
"""

import abc
import time
import json
import hmac
import socket
import hashlib
import secrets
import ipaddress
import threading
import contextlib
import contextvars
from datetime import timedelta
from dataclasses import dataclass, field
from urllib.parse import urlparse

import requests
from Crypto.Cipher import AES
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, padding, ed25519
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature

from django.conf import settings
from django.db import models, transaction, OperationalError
from django.utils import timezone

from .models import (
    Voter,
    Election,
    PendingVoterOnboarding,
    ExternalProviderVerificationRecord,
    AdminAuditLog,
)
from .services import (
    mask_aadhar,
    validate_aadhar_format,
    validate_wallet_format,
    VoterValidationError,
)


PROVIDER_TYPE_INTERNAL_LOCAL = 'INTERNAL_LOCAL'
PROVIDER_TYPE_SIMULATED_EXTERNAL = 'SIMULATED_EXTERNAL'
PROVIDER_TYPE_GENUINE_EXTERNAL = 'GENUINE_EXTERNAL'

PERMITTED_PROVIDER_ATTRIBUTES = {
    'full_name',
    'is_citizen',
    'age_qualified',
    'electoral_district_code',
    'verification_timestamp',
}

CONTROLLED_FAILURE_CODES = {
    'PROVIDER_UNAVAILABLE',
    'GATEWAY_TIMEOUT',
    'RECORD_NOT_FOUND',
    'IDENTITY_MISMATCH',
    'SCHEMA_VALIDATION_FAILED',
    'SIGNATURE_VERIFICATION_FAILED',
    'SSRF_BLOCKED',
    'CONFLICT_DETECTED',
}

# In-memory cache of consumed JWS jti tokens with expiration timestamps
_CONSUMED_JWS_JTIS = {}


class ProviderError(Exception):
    """Base exception for identity provider errors."""


class ProviderSSRFError(ProviderError):
    """Raised when an outbound provider URL or resolved IP violates SSRF protections."""


class ProviderJWSVerificationError(ProviderError):
    """Raised when a genuine external provider JWS token fails cryptographic validation."""


class OnboardingStateError(ProviderError):
    """Raised when a pending onboarding record cannot be processed or is already reviewed."""


def _b64url_decode(data: str) -> bytes:
    import base64
    rem = len(data) % 4
    if rem > 0:
        data += '=' * (4 - rem)
    return base64.urlsafe_b64decode(data.encode('ascii'))


def _b64url_encode(data: bytes) -> str:
    import base64
    return base64.urlsafe_b64encode(data).decode('ascii').rstrip('=')


def derive_provider_reference_hash(provider_id: str, identifier: str) -> str:
    """
    Compute HMAC-SHA256 reference token for an identity within a provider namespace.
    Note: Low-entropy 12-digit identifiers require strict salt secrecy and access controls.
    """
    salt = getattr(settings, 'PROVIDER_REFERENCE_SALT', 'dvs-provider-reference-hmac-salt-2026').encode('utf-8')
    msg = f"{str(provider_id).strip().lower()}:{str(identifier).strip()}".encode('utf-8')
    return '0x' + hmac.new(salt, msg, hashlib.sha256).hexdigest()


def derive_identity_blind_index(identifier: str) -> str:
    """Compute irreversible HMAC-SHA256 blind index for identity lookup."""
    salt = getattr(settings, 'PROVIDER_REFERENCE_SALT', 'dvs-provider-reference-hmac-salt-2026').encode('utf-8')
    msg = f"blind_index:{str(identifier).strip()}".encode('utf-8')
    return '0x' + hmac.new(salt, msg, hashlib.sha256).hexdigest()


def _get_aes_key() -> bytes:
    raw_key = getattr(
        settings,
        'ONBOARDING_ENCRYPTION_KEY',
        'dvs-onboarding-aes256-gcm-secret-key-material-2026'
    )
    return hashlib.sha256(raw_key.encode('utf-8')).digest()


def encrypt_onboarding_payload(raw_identifier: str) -> str:
    """
    Encrypt national identifier using AES-256-GCM for ephemeral PendingVoterOnboarding storage.
    Cleared immediately upon administrative approval or rejection.
    """
    key = _get_aes_key()
    nonce = secrets.token_bytes(12)
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    ciphertext, tag = cipher.encrypt_and_digest(str(raw_identifier).strip().encode('utf-8'))
    return json.dumps({
        'n': _b64url_encode(nonce),
        'c': _b64url_encode(ciphertext),
        't': _b64url_encode(tag),
    })


def decrypt_onboarding_payload(encrypted_json: str) -> str:
    """Decrypt ephemeral AES-256-GCM onboarding identifier in memory."""
    if not encrypted_json:
        raise OnboardingStateError("Encrypted identity payload is empty or already purged.")
    try:
        data = json.loads(encrypted_json)
        nonce = _b64url_decode(data['n'])
        ciphertext = _b64url_decode(data['c'])
        tag = _b64url_decode(data['t'])
        key = _get_aes_key()
        cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
        plaintext = cipher.decrypt_and_verify(ciphertext, tag)
        return plaintext.decode('utf-8')
    except Exception:
        raise OnboardingStateError("Failed to decrypt or authenticate onboarding identity payload.")


def sanitize_provider_attributes(attrs: dict) -> str:
    """Filter provider attributes strictly through PERMITTED_PROVIDER_ATTRIBUTES."""
    if not isinstance(attrs, dict):
        return '{}'
    cleaned = {}
    for k, v in attrs.items():
        if k in PERMITTED_PROVIDER_ATTRIBUTES:
            if isinstance(v, (bool, int, float)):
                cleaned[k] = v
            else:
                cleaned[k] = str(v)[:120]
    return json.dumps(cleaned)


def normalize_failure_code(code: str) -> str:
    """Ensure only controlled error codes are persisted in database audit records."""
    c = str(code or '').strip().upper()
    return c if c in CONTROLLED_FAILURE_CODES else 'PROVIDER_UNAVAILABLE'


def is_ip_forbidden_for_ssrf(ip_str: str) -> bool:
    """
    Check if an IPv4 or IPv6 address belongs to loopback, link-local, cloud metadata,
    RFC 1918 private, IPv6 unique-local, 6to4, Teredo, or IPv4-mapped IPv6 forbidden ranges.
    """
    if not ip_str or not isinstance(ip_str, str) or '%' in ip_str:
        return True

    try:
        ip_obj = ipaddress.ip_address(ip_str.strip())
    except ValueError:
        return True

    candidate_ips = [ip_obj]
    if isinstance(ip_obj, ipaddress.IPv6Address):
        if ip_obj.ipv4_mapped:
            candidate_ips.append(ip_obj.ipv4_mapped)
        if ip_obj.sixtofour:
            candidate_ips.append(ip_obj.sixtofour)
        if ip_obj.teredo:
            candidate_ips.extend(ip_obj.teredo)

    for candidate in candidate_ips:
        if (
            not candidate.is_global
            or candidate.is_loopback
            or candidate.is_private
            or candidate.is_link_local
            or candidate.is_multicast
            or candidate.is_unspecified
            or candidate.is_reserved
        ):
            return True

        if str(candidate) == '169.254.169.254':
            return True
        if isinstance(candidate, ipaddress.IPv4Address):
            if candidate in ipaddress.ip_network('100.64.0.0/10'):
                return True
        if isinstance(candidate, ipaddress.IPv6Address):
            if candidate in ipaddress.ip_network('fc00::/7') or candidate in ipaddress.ip_network('fe80::/10'):
                return True

    return False


def validate_outbound_provider_destination(url: str, resolver_fn=None) -> dict:
    """
    Validate a server-configured provider URL against SSRF and DNS rebinding attacks:
    - Requires HTTPS scheme.
    - Rejects cloud metadata hostnames and literal private/loopback IPs.
    - Resolves DNS and verifies every returned IP is globally routable.
    - Returns pinned IP information for socket-level connection pinning.
    """
    if not url or not isinstance(url, str):
        raise ProviderSSRFError("Invalid provider destination URL.")

    parsed = urlparse(url)
    if parsed.scheme.lower() != 'https':
        raise ProviderSSRFError("External identity providers must use HTTPS.")

    hostname = (parsed.hostname or '').strip().lower()
    if not hostname or hostname in ('localhost', 'metadata.google.internal', 'metadata', 'instance-data'):
        raise ProviderSSRFError("Blocked forbidden provider hostname.")

    # Check if hostname is already an IP literal
    try:
        ipaddress.ip_address(hostname)
        if is_ip_forbidden_for_ssrf(hostname):
            raise ProviderSSRFError("Blocked forbidden IP literal.")
        return {'hostname': hostname, 'pinned_ip': hostname, 'port': parsed.port or 443}
    except ValueError:
        pass

    # Resolve DNS and check all resolved IP addresses
    resolve = resolver_fn or socket.getaddrinfo
    try:
        addr_info = resolve(hostname, parsed.port or 443, proto=socket.IPPROTO_TCP)
    except Exception:
        raise ProviderSSRFError("DNS resolution failed for external provider hostname.")

    if not addr_info:
        raise ProviderSSRFError("No DNS records resolved for external provider hostname.")

    validated_ips = []
    for entry in addr_info:
        sockaddr = entry[4]
        resolved_ip = sockaddr[0]
        if is_ip_forbidden_for_ssrf(resolved_ip):
            raise ProviderSSRFError(
                "SSRF protection blocked resolved non-global IP address for provider hostname."
            )
        validated_ips.append(resolved_ip)

    return {
        'hostname': hostname,
        'pinned_ip': validated_ips[0],
        'port': parsed.port or 443,
    }


_ORIGINAL_SOCKET_GETADDRINFO = socket.getaddrinfo
_DNS_HOOK_LOCK = threading.Lock()
_DNS_HOOK_INSTALLED = False
_DNS_PIN_CTX = contextvars.ContextVar('dvs_dns_pin_ctx', default=None)
_DNS_PIN_TLS = threading.local()


def _threadsafe_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    """
    Thread-safe and coroutine-safe socket.getaddrinfo dispatcher.
    Inspects the calling thread/context's active DNS pin without affecting concurrent threads.
    """
    pin = _DNS_PIN_CTX.get()
    if pin is None:
        pin = getattr(_DNS_PIN_TLS, 'active_pin', None)
    if pin is None:
        return _ORIGINAL_SOCKET_GETADDRINFO(host, port, family, type, proto, flags)

    norm_host = str(host or '').strip().lower()
    if norm_host not in (pin['expected_hostname'], pin['pinned_ip'].lower()):
        raise ProviderSSRFError("Blocked unexpected outbound hostname resolution.")
    return [(pin['family'], socket.SOCK_STREAM, socket.IPPROTO_TCP, '', pin['sockaddr'])]


def _ensure_threadsafe_dns_hook_installed():
    global _DNS_HOOK_INSTALLED
    if not _DNS_HOOK_INSTALLED:
        with _DNS_HOOK_LOCK:
            if not _DNS_HOOK_INSTALLED:
                socket.getaddrinfo = _threadsafe_getaddrinfo
                _DNS_HOOK_INSTALLED = True


@contextlib.contextmanager
def pinned_dns_context(expected_hostname: str, pinned_ip: str, pinned_port: int):
    """
    Concurrency-safe DNS connection pinning context manager.
    Uses ContextVar + threading.local isolation so concurrent provider requests on different
    threads never overwrite or exchange pinned IP addresses, while preserving TLS SNI
    and X.509 certificate hostname verification.
    """
    if is_ip_forbidden_for_ssrf(pinned_ip):
        raise ProviderSSRFError("Pinned IP failed SSRF verification.")

    _ensure_threadsafe_dns_hook_installed()

    ip_obj = ipaddress.ip_address(pinned_ip)
    family = socket.AF_INET6 if isinstance(ip_obj, ipaddress.IPv6Address) else socket.AF_INET
    sockaddr = (pinned_ip, pinned_port, 0, 0) if family == socket.AF_INET6 else (pinned_ip, pinned_port)
    norm_expected = str(expected_hostname or '').strip().lower()

    pin_state = {
        'expected_hostname': norm_expected,
        'pinned_ip': pinned_ip,
        'pinned_port': pinned_port,
        'family': family,
        'sockaddr': sockaddr,
    }

    ctx_token = _DNS_PIN_CTX.set(pin_state)
    prev_tls_pin = getattr(_DNS_PIN_TLS, 'active_pin', None)
    _DNS_PIN_TLS.active_pin = pin_state
    try:
        yield
    finally:
        _DNS_PIN_CTX.reset(ctx_token)
        _DNS_PIN_TLS.active_pin = prev_tls_pin


def verify_provider_jws_token(
    jws_compact: str,
    expected_issuer: str = None,
    expected_audience: str = None,
    trusted_public_keys: dict = None,
) -> dict:
    """
    Verify a compact JWS signed response from a genuine external identity provider.
    Enforces:
    - Allowed asymmetric algorithms only: ES256, RS256, EdDSA (blocks 'none' and 'HS256').
    - Rejects untrusted header attributes: jku, x5u, jwk.
    - Resolves verification key strictly by 'kid' from server-configured trusted_public_keys.
    - Validates iss, aud, exp, iat/nbf (60s clock skew), and single-use jti replay prevention.
    """
    if not jws_compact or not isinstance(jws_compact, str) or jws_compact.count('.') != 2:
        raise ProviderJWSVerificationError("Malformed JWS compact token.")

    header_b64, payload_b64, sig_b64 = jws_compact.split('.')
    try:
        header = json.loads(_b64url_decode(header_b64).decode('utf-8'))
        payload = json.loads(_b64url_decode(payload_b64).decode('utf-8'))
        signature = _b64url_decode(sig_b64)
    except Exception:
        raise ProviderJWSVerificationError("Failed to decode JWS segments.")

    # 1. Reject untrusted remote key pointers in header
    for forbidden_hdr in ('jku', 'x5u', 'jwk', 'x5c'):
        if forbidden_hdr in header:
            raise ProviderJWSVerificationError(f"Untrusted JWS header parameter '{forbidden_hdr}' rejected.")

    # 2. Enforce strict asymmetric algorithm allowlist
    alg = header.get('alg')
    if alg not in ('ES256', 'RS256', 'EdDSA'):
        raise ProviderJWSVerificationError(f"Disallowed JWS signing algorithm '{alg}'.")

    # 3. Trusted key ID lookup
    kid = header.get('kid')
    key_store = trusted_public_keys if trusted_public_keys is not None else getattr(settings, 'IDENTITY_PROVIDER_PUBLIC_KEYS', {})
    if not kid or kid not in key_store:
        raise ProviderJWSVerificationError("Unknown or untrusted JWS key ID (kid).")

    pub_key_pem = key_store[kid]
    if isinstance(pub_key_pem, str):
        pub_key_pem = pub_key_pem.encode('utf-8')
    pub_key = serialization.load_pem_public_key(pub_key_pem)

    # 4. Verify cryptographic signature
    signing_input = f"{header_b64}.{payload_b64}".encode('ascii')
    try:
        if alg == 'ES256':
            if len(signature) == 64:
                r = int.from_bytes(signature[:32], 'big')
                s = int.from_bytes(signature[32:], 'big')
                der_sig = encode_dss_signature(r, s)
            else:
                der_sig = signature
            pub_key.verify(der_sig, signing_input, ec.ECDSA(hashes.SHA256()))
        elif alg == 'RS256':
            pub_key.verify(signature, signing_input, padding.PKCS1v15(), hashes.SHA256())
        elif alg == 'EdDSA':
            pub_key.verify(signature, signing_input)
    except Exception:
        raise ProviderJWSVerificationError("JWS cryptographic signature verification failed.")

    # 5. Validate standard claims (iss, aud, exp, iat, nbf, jti)
    now_ts = int(time.time())
    skew = 60

    iss = expected_issuer or getattr(settings, 'IDENTITY_PROVIDER_ISSUER', '')
    aud = expected_audience or getattr(settings, 'IDENTITY_PROVIDER_AUDIENCE', '')

    if payload.get('iss') != iss:
        raise ProviderJWSVerificationError("Invalid JWS issuer (iss).")
    if payload.get('aud') != aud:
        raise ProviderJWSVerificationError("Invalid JWS audience (aud).")

    exp = payload.get('exp')
    if not isinstance(exp, (int, float)) or now_ts > (exp + skew):
        raise ProviderJWSVerificationError("JWS token has expired.")

    iat = payload.get('iat')
    if isinstance(iat, (int, float)) and iat > (now_ts + skew):
        raise ProviderJWSVerificationError("JWS issued-at (iat) is in the future.")

    nbf = payload.get('nbf')
    if isinstance(nbf, (int, float)) and now_ts + skew < nbf:
        raise ProviderJWSVerificationError("JWS token is not yet valid (nbf).")

    jti = payload.get('jti')
    if not jti or not isinstance(jti, str):
        raise ProviderJWSVerificationError("Missing JWS unique identifier (jti).")

    # Cleanup expired jtis and check replay
    expired_keys = [k for k, v in _CONSUMED_JWS_JTIS.items() if v < now_ts]
    for k in expired_keys:
        _CONSUMED_JWS_JTIS.pop(k, None)

    if jti in _CONSUMED_JWS_JTIS:
        raise ProviderJWSVerificationError("Replayed JWS token (jti already consumed).")
    _CONSUMED_JWS_JTIS[jti] = int(exp) + skew

    return payload


@dataclass
class ProviderVerificationResult:
    provider_id: str
    provider_name: str
    provider_type: str
    is_simulated: bool
    is_verified: bool
    status: str  # 'VERIFIED', 'NOT_FOUND', 'REJECTED', 'UNAVAILABLE', 'ERROR'
    masked_identifier: str
    external_reference_hash: str
    electoral_attributes: dict = field(default_factory=dict)
    failure_code: str = ''
    response_latency_ms: int = 0


class BaseVoterProvider(abc.ABC):
    """Abstract interface for all voter identity & electoral roll providers."""
    provider_id: str = ''
    display_name: str = ''
    provider_type: str = ''
    is_simulated: bool = False
    description: str = ''

    @abc.abstractmethod
    def verify_voter_identity(self, identifier: str, query_params: dict = None) -> ProviderVerificationResult:
        pass

    @abc.abstractmethod
    def check_health(self) -> dict:
        pass


class LocalDatabaseProvider(BaseVoterProvider):
    """
    Internal local database electoral roll lookup.
    Classified strictly as INTERNAL_LOCAL (not external, not simulated).
    """
    provider_id = 'local_database'
    display_name = 'Local Electoral Roll Database (Internal)'
    provider_type = PROVIDER_TYPE_INTERNAL_LOCAL
    is_simulated = False
    description = 'Authoritative internal database lookup of existing registered voters.'

    def verify_voter_identity(self, identifier: str, query_params: dict = None) -> ProviderVerificationResult:
        start_ns = time.perf_counter_ns()
        clean_id = validate_aadhar_format(identifier)
        masked = mask_aadhar(clean_id)
        ref_hash = derive_provider_reference_hash(self.provider_id, clean_id)

        voter = Voter.objects.filter(aadhar_number=clean_id).first()
        latency_ms = max(1, int((time.perf_counter_ns() - start_ns) / 1_000_000))

        if not voter:
            return ProviderVerificationResult(
                provider_id=self.provider_id,
                provider_name=self.display_name,
                provider_type=self.provider_type,
                is_simulated=False,
                is_verified=False,
                status='NOT_FOUND',
                masked_identifier=masked,
                external_reference_hash=ref_hash,
                failure_code='RECORD_NOT_FOUND',
                response_latency_ms=latency_ms,
            )

        if voter.status != 'ACTIVE':
            return ProviderVerificationResult(
                provider_id=self.provider_id,
                provider_name=self.display_name,
                provider_type=self.provider_type,
                is_simulated=False,
                is_verified=False,
                status='REJECTED',
                masked_identifier=masked,
                external_reference_hash=ref_hash,
                failure_code='IDENTITY_MISMATCH',
                response_latency_ms=latency_ms,
            )

        return ProviderVerificationResult(
            provider_id=self.provider_id,
            provider_name=self.display_name,
            provider_type=self.provider_type,
            is_simulated=False,
            is_verified=True,
            status='VERIFIED',
            masked_identifier=masked,
            external_reference_hash=ref_hash,
            electoral_attributes={
                'full_name': voter.name,
                'is_citizen': True,
                'age_qualified': True,
                'electoral_district_code': 'LOCAL-ROLL',
                'verification_timestamp': timezone.now().isoformat(),
            },
            response_latency_ms=latency_ms,
        )

    def check_health(self) -> dict:
        return {
            'provider_id': self.provider_id,
            'name': self.display_name,
            'provider_type': self.provider_type,
            'is_simulated': self.is_simulated,
            'status': 'ONLINE',
        }


class SimulatedCivicRegistryProvider(BaseVoterProvider):
    """
    Simulated External Civic Identity Registry for academic & multi-laptop demonstration.
    Explicitly marked is_simulated=True and PROVIDER_TYPE_SIMULATED_EXTERNAL.
    Never represented as a genuine government or election authority service.
    """
    provider_id = 'simulated_civic_registry'
    display_name = 'Simulated Civic Identity Registry (DEMO / SYNTHETIC)'
    provider_type = PROVIDER_TYPE_SIMULATED_EXTERNAL
    is_simulated = True
    description = (
        'Simulated external identity provider for research and multi-laptop demonstration. '
        'All verified records are strictly marked synthetic.'
    )

    def verify_voter_identity(self, identifier: str, query_params: dict = None) -> ProviderVerificationResult:
        start_ns = time.perf_counter_ns()
        params = query_params or {}
        clean_id = validate_aadhar_format(identifier)
        masked = mask_aadhar(clean_id)
        ref_hash = derive_provider_reference_hash(self.provider_id, clean_id)
        scenario = str(params.get('scenario', 'VALID')).strip().upper()
        proposed_name = str(params.get('full_name') or f"Synthetic Citizen {clean_id[-4:]}").strip()[:100]
        district = str(params.get('district_code') or 'SIM-DIST-01').strip()[:10]
        latency_ms = max(2, int((time.perf_counter_ns() - start_ns) / 1_000_000))

        if scenario == 'UNAVAILABLE':
            return ProviderVerificationResult(
                provider_id=self.provider_id,
                provider_name=self.display_name,
                provider_type=self.provider_type,
                is_simulated=True,
                is_verified=False,
                status='UNAVAILABLE',
                masked_identifier=masked,
                external_reference_hash=ref_hash,
                failure_code='PROVIDER_UNAVAILABLE',
                response_latency_ms=latency_ms,
            )

        if scenario == 'TIMEOUT':
            return ProviderVerificationResult(
                provider_id=self.provider_id,
                provider_name=self.display_name,
                provider_type=self.provider_type,
                is_simulated=True,
                is_verified=False,
                status='UNAVAILABLE',
                masked_identifier=masked,
                external_reference_hash=ref_hash,
                failure_code='GATEWAY_TIMEOUT',
                response_latency_ms=5000,
            )

        if scenario == 'NOT_FOUND':
            return ProviderVerificationResult(
                provider_id=self.provider_id,
                provider_name=self.display_name,
                provider_type=self.provider_type,
                is_simulated=True,
                is_verified=False,
                status='NOT_FOUND',
                masked_identifier=masked,
                external_reference_hash=ref_hash,
                failure_code='RECORD_NOT_FOUND',
                response_latency_ms=latency_ms,
            )

        if scenario == 'REJECTED':
            return ProviderVerificationResult(
                provider_id=self.provider_id,
                provider_name=self.display_name,
                provider_type=self.provider_type,
                is_simulated=True,
                is_verified=False,
                status='REJECTED',
                masked_identifier=masked,
                external_reference_hash=ref_hash,
                failure_code='IDENTITY_MISMATCH',
                response_latency_ms=latency_ms,
            )

        return ProviderVerificationResult(
            provider_id=self.provider_id,
            provider_name=self.display_name,
            provider_type=self.provider_type,
            is_simulated=True,
            is_verified=True,
            status='VERIFIED',
            masked_identifier=masked,
            external_reference_hash=ref_hash,
            electoral_attributes={
                'full_name': proposed_name,
                'is_citizen': True,
                'age_qualified': True,
                'electoral_district_code': district,
                'verification_timestamp': timezone.now().isoformat(),
            },
            response_latency_ms=latency_ms,
        )

    def check_health(self) -> dict:
        return {
            'provider_id': self.provider_id,
            'name': self.display_name,
            'provider_type': self.provider_type,
            'is_simulated': self.is_simulated,
            'status': 'ONLINE',
        }


class GenuineExternalIdentityProvider(BaseVoterProvider):
    """
    Production integration boundary for a genuine external electoral identity authority.
    Enforces outbound SSRF validation, TLS certificate verification, 5.0s timeout,
    no redirects, and JWS signature verification.
    """
    provider_id = 'genuine_national_gateway'
    display_name = 'Authorized External Identity Gateway'
    provider_type = PROVIDER_TYPE_GENUINE_EXTERNAL
    is_simulated = False
    description = (
        'Production integration boundary for cryptographically signed JWS identity verification.'
    )

    def verify_voter_identity(self, identifier: str, query_params: dict = None) -> ProviderVerificationResult:
        start_ns = time.perf_counter_ns()
        params = query_params or {}
        clean_id = validate_aadhar_format(identifier)
        masked = mask_aadhar(clean_id)
        ref_hash = derive_provider_reference_hash(self.provider_id, clean_id)

        # If a pre-signed JWS assertion is supplied directly in query_params (e.g. for JWS boundary testing)
        signed_jws = params.get('jws_assertion')
        if signed_jws:
            try:
                claims = verify_provider_jws_token(signed_jws)
                if str(claims.get('sub_hash', '')).lower() != ref_hash.lower():
                    raise ProviderJWSVerificationError("JWS subject hash mismatch.")
                latency_ms = max(1, int((time.perf_counter_ns() - start_ns) / 1_000_000))
                return ProviderVerificationResult(
                    provider_id=self.provider_id,
                    provider_name=self.display_name,
                    provider_type=self.provider_type,
                    is_simulated=False,
                    is_verified= bool(claims.get('verified', False)),
                    status='VERIFIED' if claims.get('verified') else 'REJECTED',
                    masked_identifier=masked,
                    external_reference_hash=ref_hash,
                    electoral_attributes={
                        'full_name': str(claims.get('full_name', 'Verified Citizen'))[:100],
                        'is_citizen': bool(claims.get('is_citizen', True)),
                        'age_qualified': bool(claims.get('age_qualified', True)),
                        'electoral_district_code': str(claims.get('electoral_district_code', 'EXT-01'))[:10],
                        'verification_timestamp': timezone.now().isoformat(),
                    },
                    failure_code='' if claims.get('verified') else 'IDENTITY_MISMATCH',
                    response_latency_ms=latency_ms,
                )
            except ProviderJWSVerificationError:
                latency_ms = max(1, int((time.perf_counter_ns() - start_ns) / 1_000_000))
                return ProviderVerificationResult(
                    provider_id=self.provider_id,
                    provider_name=self.display_name,
                    provider_type=self.provider_type,
                    is_simulated=False,
                    is_verified=False,
                    status='ERROR',
                    masked_identifier=masked,
                    external_reference_hash=ref_hash,
                    failure_code='SIGNATURE_VERIFICATION_FAILED',
                    response_latency_ms=latency_ms,
                )

        # Otherwise validate configured server-side endpoint via SSRF guard
        endpoints = getattr(settings, 'IDENTITY_PROVIDER_ENDPOINTS', {})
        endpoint_url = endpoints.get(self.provider_id, '')
        try:
            dest = validate_outbound_provider_destination(endpoint_url)
        except ProviderSSRFError:
            return ProviderVerificationResult(
                provider_id=self.provider_id,
                provider_name=self.display_name,
                provider_type=self.provider_type,
                is_simulated=False,
                is_verified=False,
                status='ERROR',
                masked_identifier=masked,
                external_reference_hash=ref_hash,
                failure_code='SSRF_BLOCKED',
                response_latency_ms=1,
            )

        # In local prototype environment without live government gateway keys configured,
        # report UNAVAILABLE cleanly rather than fabricating genuine verification.
        key_store = getattr(settings, 'IDENTITY_PROVIDER_PUBLIC_KEYS', {})
        if not key_store:
            return ProviderVerificationResult(
                provider_id=self.provider_id,
                provider_name=self.display_name,
                provider_type=self.provider_type,
                is_simulated=False,
                is_verified=False,
                status='UNAVAILABLE',
                masked_identifier=masked,
                external_reference_hash=ref_hash,
                failure_code='PROVIDER_UNAVAILABLE',
                response_latency_ms=1,
            )

        try:
            with pinned_dns_context(dest['hostname'], dest['pinned_ip'], dest['port']):
                resp = requests.post(
                    endpoint_url,
                    json={'reference_hash': ref_hash},
                    timeout=(2.0, 3.0),
                    allow_redirects=False,
                    verify=True,
                )
            if 300 <= resp.status_code < 400:
                return ProviderVerificationResult(
                    provider_id=self.provider_id,
                    provider_name=self.display_name,
                    provider_type=self.provider_type,
                    is_simulated=False,
                    is_verified=False,
                    status='ERROR',
                    masked_identifier=masked,
                    external_reference_hash=ref_hash,
                    failure_code='SSRF_BLOCKED',
                    response_latency_ms=10,
                )
            if resp.status_code != 200:
                return ProviderVerificationResult(
                    provider_id=self.provider_id,
                    provider_name=self.display_name,
                    provider_type=self.provider_type,
                    is_simulated=False,
                    is_verified=False,
                    status='UNAVAILABLE',
                    masked_identifier=masked,
                    external_reference_hash=ref_hash,
                    failure_code='PROVIDER_UNAVAILABLE',
                    response_latency_ms=10,
                )
            data = resp.json()
            claims = verify_provider_jws_token(data.get('jws', ''))
            return ProviderVerificationResult(
                provider_id=self.provider_id,
                provider_name=self.display_name,
                provider_type=self.provider_type,
                is_simulated=False,
                is_verified=bool(claims.get('verified', False)),
                status='VERIFIED' if claims.get('verified') else 'REJECTED',
                masked_identifier=masked,
                external_reference_hash=ref_hash,
                electoral_attributes={
                    'full_name': str(claims.get('full_name', 'Verified Citizen'))[:100],
                    'is_citizen': True,
                    'age_qualified': True,
                    'electoral_district_code': str(claims.get('electoral_district_code', 'EXT-01'))[:10],
                    'verification_timestamp': timezone.now().isoformat(),
                },
                response_latency_ms=15,
            )
        except requests.Timeout:
            return ProviderVerificationResult(
                provider_id=self.provider_id,
                provider_name=self.display_name,
                provider_type=self.provider_type,
                is_simulated=False,
                is_verified=False,
                status='UNAVAILABLE',
                masked_identifier=masked,
                external_reference_hash=ref_hash,
                failure_code='GATEWAY_TIMEOUT',
                response_latency_ms=5000,
            )
        except ProviderJWSVerificationError:
            return ProviderVerificationResult(
                provider_id=self.provider_id,
                provider_name=self.display_name,
                provider_type=self.provider_type,
                is_simulated=False,
                is_verified=False,
                status='ERROR',
                masked_identifier=masked,
                external_reference_hash=ref_hash,
                failure_code='SIGNATURE_VERIFICATION_FAILED',
                response_latency_ms=10,
            )
        except Exception:
            return ProviderVerificationResult(
                provider_id=self.provider_id,
                provider_name=self.display_name,
                provider_type=self.provider_type,
                is_simulated=False,
                is_verified=False,
                status='UNAVAILABLE',
                masked_identifier=masked,
                external_reference_hash=ref_hash,
                failure_code='PROVIDER_UNAVAILABLE',
                response_latency_ms=10,
            )

    def check_health(self) -> dict:
        key_store = getattr(settings, 'IDENTITY_PROVIDER_PUBLIC_KEYS', {})
        return {
            'provider_id': self.provider_id,
            'name': self.display_name,
            'provider_type': self.provider_type,
            'is_simulated': self.is_simulated,
            'status': 'CONFIGURED' if key_store else 'NOT_CONFIGURED',
        }


PROVIDER_REGISTRY = {
    LocalDatabaseProvider.provider_id: LocalDatabaseProvider(),
    SimulatedCivicRegistryProvider.provider_id: SimulatedCivicRegistryProvider(),
    GenuineExternalIdentityProvider.provider_id: GenuineExternalIdentityProvider(),
}


def get_available_providers() -> list:
    """Return public discovery summary of all registered identity providers."""
    summaries = []
    for prov in PROVIDER_REGISTRY.values():
        health = prov.check_health()
        summaries.append({
            'id': prov.provider_id,
            'name': prov.display_name,
            'provider_type': prov.provider_type,
            'is_simulated': prov.is_simulated,
            'description': prov.description,
            'status': health.get('status', 'ONLINE'),
        })
    return summaries


def verify_and_stage_voter_identity(
    provider_id: str,
    identifier: str,
    query_params: dict = None,
    target_election: Election = None,
    actor_user=None,
    ip_address: str = None,
) -> dict:
    """
    Execute identity verification against a registered provider, record an immutable
    ExternalProviderVerificationRecord, and (for verified external identities) stage
    a PendingVoterOnboarding record awaiting administrative review.
    Never automatically grants election eligibility or creates active voters from external responses.
    """
    prov = PROVIDER_REGISTRY.get(str(provider_id or '').strip())
    if not prov:
        raise ProviderError(f"Unknown identity provider '{provider_id}'.")

    clean_id = validate_aadhar_format(identifier)
    params = dict(query_params or {})

    # Strictly forbid browser/client-controlled destination URLs in provider parameters
    forbidden_url_keys = {'url', 'endpoint', 'endpoint_url', 'callback_url', 'webhook_url', 'redirect_uri', 'target_url'}
    for k in list(params.keys()):
        if str(k).strip().lower() in forbidden_url_keys:
            raise ProviderSSRFError("Client-supplied provider URLs are forbidden.")

    claimed_wallet = str(params.get('claimed_wallet', '') or '').strip()
    if claimed_wallet:
        claimed_wallet = validate_wallet_format(claimed_wallet)

    # Check if claimed wallet conflicts with an existing different voter
    existing_voter = Voter.objects.filter(aadhar_number=clean_id).first()
    if claimed_wallet:
        wallet_owner = Voter.objects.filter(bound_wallet__iexact=claimed_wallet).first()
        if wallet_owner and (not existing_voter or wallet_owner.pk != existing_voter.pk):
            raise VoterValidationError(
                "Claimed wallet address is already bound to another registered voter."
            )

    result = prov.verify_voter_identity(clean_id, params)

    # Record permanent masked audit entry
    ver_record = ExternalProviderVerificationRecord.objects.create(
        voter=existing_voter,
        provider_id=result.provider_id,
        provider_name=result.provider_name,
        provider_type=result.provider_type,
        is_simulated=result.is_simulated,
        masked_identifier=result.masked_identifier,
        external_reference_hash=result.external_reference_hash,
        verification_status=result.status,
        failure_code=normalize_failure_code(result.failure_code) if result.failure_code else '',
        sanitized_attributes_json=sanitize_provider_attributes(result.electoral_attributes),
        response_latency_ms=result.response_latency_ms,
        verified_by=actor_user if (actor_user and getattr(actor_user, 'is_authenticated', False)) else None,
        ip_address=ip_address,
    )

    pending_onboarding_data = None
    if result.is_verified and result.provider_type in (
        PROVIDER_TYPE_SIMULATED_EXTERNAL,
        PROVIDER_TYPE_GENUINE_EXTERNAL,
    ):
        blind_idx = derive_identity_blind_index(clean_id)
        proposed_name = str(
            result.electoral_attributes.get('full_name') or f"Voter {clean_id[-4:]}"
        ).strip()[:100]
        is_synthetic = (result.provider_type == PROVIDER_TYPE_SIMULATED_EXTERNAL)

        with transaction.atomic():
            existing_pending = PendingVoterOnboarding.objects.filter(
                provider_id=result.provider_id,
                external_reference_hash=result.external_reference_hash,
                status='PENDING_REVIEW',
            ).first()

            if existing_pending:
                pending_obj = existing_pending
            else:
                pending_obj = PendingVoterOnboarding.objects.create(
                    provider_id=result.provider_id,
                    provider_type=result.provider_type,
                    masked_identifier=result.masked_identifier,
                    external_reference_hash=result.external_reference_hash,
                    identity_blind_index=blind_idx,
                    encrypted_identity_payload=encrypt_onboarding_payload(clean_id),
                    proposed_name=proposed_name,
                    claimed_wallet=claimed_wallet or '',
                    target_election=target_election,
                    status='PENDING_REVIEW',
                    is_synthetic=is_synthetic,
                )

            pending_onboarding_data = {
                'onboarding_id': pending_obj.pk,
                'status': pending_obj.status,
                'is_synthetic': pending_obj.is_synthetic,
                'masked_identifier': pending_obj.masked_identifier,
                'proposed_name': pending_obj.proposed_name,
                'claimed_wallet': pending_obj.claimed_wallet,
            }

    return {
        'verification_record_id': ver_record.pk,
        'provider_id': result.provider_id,
        'provider_name': result.provider_name,
        'provider_type': result.provider_type,
        'is_simulated': result.is_simulated,
        'is_verified': result.is_verified,
        'status': result.status,
        'masked_identifier': result.masked_identifier,
        'external_reference_hash': result.external_reference_hash,
        'electoral_attributes': json.loads(ver_record.sanitized_attributes_json),
        'failure_code': ver_record.failure_code,
        'pending_onboarding': pending_onboarding_data,
    }


def acquire_onboarding_lease(
    onboarding_id: int,
    reviewing_admin_user,
    lease_ttl_seconds: int = 60,
) -> str:
    """
    Atomically claim a PENDING_REVIEW (or expired PROCESSING) onboarding record
    with a unique 128-bit cryptographic processing_claim_token.
    Reclaiming an expired PROCESSING record overwrites processing_claim_token,
    immediately invalidating any previous worker's lease.
    """
    if not reviewing_admin_user or not reviewing_admin_user.is_authenticated:
        raise OnboardingStateError("Authenticated administrator required.")

    claim_token = secrets.token_hex(16)
    max_retries = 3
    for attempt in range(max_retries):
        try:
            with transaction.atomic():
                now = timezone.now()
                stale_cutoff = now - timedelta(seconds=lease_ttl_seconds)
                rows_claimed = PendingVoterOnboarding.objects.filter(
                    models.Q(status='PENDING_REVIEW') |
                    models.Q(status='PROCESSING', reviewed_at__lt=stale_cutoff),
                    pk=onboarding_id,
                ).update(
                    status='PROCESSING',
                    processing_claim_token=claim_token,
                    reviewed_by=reviewing_admin_user,
                    reviewed_at=now,
                )
                if rows_claimed != 1:
                    raise OnboardingStateError(
                        "Onboarding record is no longer pending review or is actively leased by another worker."
                    )
                return claim_token
        except OperationalError as exc:
            if 'locked' in str(exc).lower() and attempt < max_retries - 1:
                time.sleep(0.1 * (attempt + 1))
                continue
            raise

    raise OnboardingStateError("Database lock contention exceeded retry limit.")


def _release_onboarding_lease_if_held(onboarding_id: int, claim_token: str):
    """
    Revert a PROCESSING record back to PENDING_REVIEW if and only if the caller
    still holds the active processing_claim_token, allowing immediate recovery after errors.
    """
    if not claim_token:
        return
    try:
        PendingVoterOnboarding.objects.filter(
            pk=onboarding_id,
            status='PROCESSING',
            processing_claim_token=claim_token,
        ).update(
            status='PENDING_REVIEW',
            processing_claim_token='',
        )
    except Exception:
        pass


def finalize_onboarding_approval(
    onboarding_id: int,
    claim_token: str,
    reviewing_admin_user,
    ip_address: str = None,
) -> dict:
    """
    Finalize an onboarding approval using a verified processing_claim_token lease:
    - Verifies that the caller still holds the active processing_claim_token.
    - If another worker reclaimed the record, aborts and rolls back completely.
    - If decryption or validation fails while holding the lease, releases the lease back to PENDING_REVIEW.
    """
    if not reviewing_admin_user or not reviewing_admin_user.is_authenticated:
        raise OnboardingStateError("Authenticated administrator required.")
    if not claim_token:
        raise OnboardingStateError("Missing onboarding processing lease token.")

    max_retries = 3
    for attempt in range(max_retries):
        try:
            with transaction.atomic():
                pending = (
                    PendingVoterOnboarding.objects.select_for_update()
                    .filter(
                        pk=onboarding_id,
                        status='PROCESSING',
                        processing_claim_token=claim_token,
                    )
                    .first()
                )
                if not pending:
                    raise OnboardingStateError(
                        "Onboarding lease expired or was reclaimed by another worker."
                    )

                raw_identifier = decrypt_onboarding_payload(pending.encrypted_identity_payload)
                is_synthetic = (pending.provider_type == PROVIDER_TYPE_SIMULATED_EXTERNAL)

                # Conflict check if claimed_wallet belongs to someone else
                if pending.claimed_wallet:
                    wallet_owner = Voter.objects.filter(
                        bound_wallet__iexact=pending.claimed_wallet
                    ).first()
                    existing_by_id = Voter.objects.filter(aadhar_number=raw_identifier).first()
                    if wallet_owner and (not existing_by_id or wallet_owner.pk != existing_by_id.pk):
                        raise VoterValidationError(
                            "Pending record's claimed wallet conflicts with an existing bound voter wallet."
                        )

                voter, created = Voter.objects.get_or_create(
                    aadhar_number=raw_identifier,
                    defaults={
                        'name': pending.proposed_name,
                        'bound_wallet': None,  # Untrusted claim is NEVER auto-bound
                        'is_synthetic': is_synthetic,
                    },
                )

                # Conditional finalization UPDATE guarded by processing_claim_token
                rows_finalized = PendingVoterOnboarding.objects.filter(
                    pk=onboarding_id,
                    status='PROCESSING',
                    processing_claim_token=claim_token,
                ).update(
                    status='APPROVED',
                    resulting_voter=voter,
                    encrypted_identity_payload='',  # Logical erasure of ciphertext
                    processing_claim_token='',
                    reviewed_by=reviewing_admin_user,
                    reviewed_at=timezone.now(),
                )
                if rows_finalized != 1:
                    raise OnboardingStateError(
                        "Onboarding lease expired or was reclaimed by another worker; approval rolled back."
                    )

                action_verb = (
                    'ONBOARDING_APPROVED_NEW_VOTER'
                    if created
                    else 'ONBOARDING_APPROVED_EXISTING_VOTER'
                )
                AdminAuditLog.objects.create(
                    actor=reviewing_admin_user,
                    action=action_verb,
                    target_model='Voter',
                    target_id=str(voter.pk),
                    details=json.dumps({
                        'onboarding_id': pending.pk,
                        'provider_id': pending.provider_id,
                        'provider_type': pending.provider_type,
                        'is_synthetic': voter.is_synthetic,
                        'created_new': created,
                        'wallet_auto_bound': False,
                        'eligibility_auto_assigned': False,
                    }),
                    ip_address=ip_address,
                )

                return {
                    'onboarding_id': pending.pk,
                    'status': 'APPROVED',
                    'voter_id': voter.pk,
                    'voter_name': voter.name,
                    'aadhar_masked': mask_aadhar(voter.aadhar_number),
                    'bound_wallet': voter.bound_wallet,
                    'is_synthetic': voter.is_synthetic,
                    'created_new_voter': created,
                }
        except OperationalError as exc:
            if 'locked' in str(exc).lower() and attempt < max_retries - 1:
                time.sleep(0.1 * (attempt + 1))
                continue
            _release_onboarding_lease_if_held(onboarding_id, claim_token)
            raise
        except (VoterValidationError, OnboardingStateError):
            _release_onboarding_lease_if_held(onboarding_id, claim_token)
            raise

    _release_onboarding_lease_if_held(onboarding_id, claim_token)
    raise OnboardingStateError("Database lock contention exceeded retry limit.")


def approve_pending_onboarding(
    onboarding_id: int,
    reviewing_admin_user,
    ip_address: str = None,
    claim_token: str = None,
) -> dict:
    """
    Atomically claim (via unique processing_claim_token lease) and approve a pending onboarding record.
    If claim_token is already provided by the caller, verifies and finalizes that specific lease.
    """
    active_token = claim_token or acquire_onboarding_lease(onboarding_id, reviewing_admin_user)
    return finalize_onboarding_approval(
        onboarding_id=onboarding_id,
        claim_token=active_token,
        reviewing_admin_user=reviewing_admin_user,
        ip_address=ip_address,
    )


def reject_pending_onboarding(
    onboarding_id: int,
    reviewing_admin_user,
    reason: str = '',
    ip_address: str = None,
    claim_token: str = None,
) -> dict:
    """
    Atomically claim and reject a pending onboarding record using a verified processing_claim_token lease.
    """
    if not reviewing_admin_user or not reviewing_admin_user.is_authenticated:
        raise OnboardingStateError("Authenticated administrator required.")

    active_token = claim_token or acquire_onboarding_lease(onboarding_id, reviewing_admin_user)

    max_retries = 3
    for attempt in range(max_retries):
        try:
            with transaction.atomic():
                now = timezone.now()
                rows_updated = PendingVoterOnboarding.objects.filter(
                    pk=onboarding_id,
                    status='PROCESSING',
                    processing_claim_token=active_token,
                ).update(
                    status='REJECTED',
                    encrypted_identity_payload='',
                    processing_claim_token='',
                    reviewed_by=reviewing_admin_user,
                    reviewed_at=now,
                )
                if rows_updated != 1:
                    raise OnboardingStateError(
                        "Onboarding lease expired or was reclaimed by another worker."
                    )

                AdminAuditLog.objects.create(
                    actor=reviewing_admin_user,
                    action='ONBOARDING_REJECTED',
                    target_model='PendingVoterOnboarding',
                    target_id=str(onboarding_id),
                    details=json.dumps({'reason': str(reason or '')[:150]}),
                    ip_address=ip_address,
                )

            return {'onboarding_id': onboarding_id, 'status': 'REJECTED'}
        except OperationalError as exc:
            if 'locked' in str(exc).lower() and attempt < max_retries - 1:
                time.sleep(0.1 * (attempt + 1))
                continue
            _release_onboarding_lease_if_held(onboarding_id, active_token)
            raise
        except OnboardingStateError:
            _release_onboarding_lease_if_held(onboarding_id, active_token)
            raise

    _release_onboarding_lease_if_held(onboarding_id, active_token)
    raise OnboardingStateError("Database lock contention exceeded retry limit.")
