import secrets
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


def populate_user_handles(apps, schema_editor):
    """
    Generate a cryptographically random 32-byte (64-hex) userHandle for each existing voter
    that does not already have one populated. Safe and idempotent on resume.
    """
    Voter = apps.get_model('EVotingApp', 'Voter')
    missing_qs = Voter.objects.filter(
        models.Q(webauthn_user_handle__isnull=True) | models.Q(webauthn_user_handle='')
    )
    for voter in missing_qs:
        while True:
            candidate = secrets.token_bytes(32).hex()
            if not Voter.objects.filter(webauthn_user_handle=candidate).exists():
                voter.webauthn_user_handle = candidate
                voter.save(update_fields=['webauthn_user_handle'])
                break


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('EVotingApp', '0008_voter_created_at_voter_is_synthetic_voter_updated_at_and_more'),
    ]

    operations = [
        migrations.AddField(
            model_name='voter',
            name='status',
            field=models.CharField(
                choices=[('ACTIVE', 'Active'), ('DEACTIVATED', 'Deactivated'), ('ARCHIVED', 'Archived')],
                default='ACTIVE',
                max_length=20,
            ),
        ),
        migrations.AddField(
            model_name='voter',
            name='security_flagged',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='voter',
            name='security_flag_reason',
            field=models.CharField(blank=True, default='', max_length=255),
        ),
        migrations.AddField(
            model_name='voter',
            name='webauthn_user_handle',
            field=models.CharField(editable=False, max_length=64, null=True, unique=True),
        ),
        migrations.RunPython(populate_user_handles, reverse_code=migrations.RunPython.noop),
        migrations.AlterField(
            model_name='voter',
            name='webauthn_user_handle',
            field=models.CharField(editable=False, max_length=64, unique=True),
        ),
        migrations.CreateModel(
            name='WebAuthnCredential',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('credential_id', models.CharField(max_length=255, unique=True)),
                ('public_key_cose_hex', models.TextField()),
                ('sign_count', models.BigIntegerField(default=0)),
                ('registered_with_uv', models.BooleanField(default=False)),
                ('transports', models.CharField(blank=True, default='', max_length=200)),
                ('aaguid', models.CharField(blank=True, default='', max_length=36)),
                ('device_label', models.CharField(default='Personal Authenticator', max_length=100)),
                ('is_active', models.BooleanField(default=True)),
                ('clone_warning_flag', models.BooleanField(default=False)),
                ('anomaly_count', models.IntegerField(default=0)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('last_used_at', models.DateTimeField(blank=True, null=True)),
                ('revoked_at', models.DateTimeField(blank=True, null=True)),
                ('created_ip', models.GenericIPAddressField(blank=True, null=True)),
                ('voter', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='passkeys', to='EVotingApp.voter')),
            ],
            options={
                'ordering': ['-created_at'],
            },
        ),
        migrations.CreateModel(
            name='WebAuthnChallenge',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('challenge', models.CharField(max_length=128, unique=True)),
                ('challenge_type', models.CharField(choices=[('REGISTRATION', 'Registration'), ('AUTHENTICATION', 'Authentication'), ('STEP_UP', 'Step-Up Verification')], max_length=20)),
                ('session_key', models.CharField(db_index=True, max_length=64)),
                ('user_verification_req', models.CharField(default='preferred', max_length=20)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('expires_at', models.DateTimeField(db_index=True)),
                ('is_used', models.BooleanField(db_index=True, default=False)),
                ('consumed_at', models.DateTimeField(blank=True, null=True)),
                ('voter', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, related_name='webauthn_challenges', to='EVotingApp.voter')),
            ],
            options={
                'ordering': ['-created_at'],
            },
        ),
        migrations.CreateModel(
            name='PendingVoterOnboarding',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('provider_id', models.CharField(max_length=50)),
                ('provider_type', models.CharField(max_length=30)),
                ('masked_identifier', models.CharField(max_length=20)),
                ('external_reference_hash', models.CharField(db_index=True, max_length=66)),
                ('identity_blind_index', models.CharField(db_index=True, max_length=66)),
                ('encrypted_identity_payload', models.TextField(blank=True, default='')),
                ('proposed_name', models.CharField(max_length=100)),
                ('claimed_wallet', models.CharField(blank=True, default='', max_length=42)),
                ('status', models.CharField(choices=[('PENDING_REVIEW', 'Pending Administrative Review'), ('PROCESSING', 'Processing Approval'), ('APPROVED', 'Approved & Onboarded'), ('REJECTED', 'Rejected')], db_index=True, default='PENDING_REVIEW', max_length=20)),
                ('processing_claim_token', models.CharField(blank=True, default='', max_length=64)),
                ('is_synthetic', models.BooleanField(default=False)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('reviewed_at', models.DateTimeField(blank=True, null=True)),
                ('resulting_voter', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='originating_onboardings', to='EVotingApp.voter')),
                ('reviewed_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='reviewed_onboardings', to=settings.AUTH_USER_MODEL)),
                ('target_election', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='pending_onboardings', to='EVotingApp.election')),
            ],
            options={
                'ordering': ['-created_at'],
            },
        ),
        migrations.CreateModel(
            name='ExternalProviderVerificationRecord',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('provider_id', models.CharField(max_length=50)),
                ('provider_name', models.CharField(max_length=100)),
                ('provider_type', models.CharField(max_length=30)),
                ('is_simulated', models.BooleanField(default=False)),
                ('masked_identifier', models.CharField(max_length=20)),
                ('external_reference_hash', models.CharField(blank=True, default='', max_length=66)),
                ('verification_status', models.CharField(choices=[('VERIFIED', 'Verified'), ('NOT_FOUND', 'Not Found'), ('REJECTED', 'Rejected'), ('UNAVAILABLE', 'Provider Unavailable'), ('ERROR', 'System Error')], max_length=20)),
                ('failure_code', models.CharField(blank=True, default='', max_length=50)),
                ('sanitized_attributes_json', models.TextField(blank=True, default='{}')),
                ('response_latency_ms', models.IntegerField(default=0)),
                ('verified_at', models.DateTimeField(auto_now_add=True)),
                ('ip_address', models.GenericIPAddressField(blank=True, null=True)),
                ('verified_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='conducted_provider_verifications', to=settings.AUTH_USER_MODEL)),
                ('voter', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='provider_verification_records', to='EVotingApp.voter')),
            ],
            options={
                'ordering': ['-verified_at'],
            },
        ),
        migrations.AddConstraint(
            model_name='pendingvoteronboarding',
            constraint=models.UniqueConstraint(
                condition=models.Q(('status', 'PENDING_REVIEW')),
                fields=('provider_id', 'external_reference_hash'),
                name='unique_active_pending_onboarding',
            ),
        ),
    ]
