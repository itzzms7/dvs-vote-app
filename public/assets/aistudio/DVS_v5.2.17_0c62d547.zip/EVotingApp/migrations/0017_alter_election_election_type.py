from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('EVotingApp', '0016_alter_voter_aadhar_number'),
    ]

    operations = [
        migrations.AlterField(
            model_name='election',
            name='election_type',
            field=models.CharField(
                choices=[
                    ('ELECTION', 'Election'),
                    ('POLL', 'Poll'),
                    ('REFERENDUM', 'Referendum'),
                ],
                default='ELECTION',
                max_length=20,
            ),
        ),
    ]
