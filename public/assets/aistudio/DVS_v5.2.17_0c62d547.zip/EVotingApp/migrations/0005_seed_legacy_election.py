from django.db import migrations
from django.conf import settings


def seed_legacy_election_data(apps, schema_editor):
    Election = apps.get_model('EVotingApp', 'Election')
    Candidate = apps.get_model('EVotingApp', 'Candidate')
    Voter = apps.get_model('EVotingApp', 'Voter')
    VoterEligibility = apps.get_model('EVotingApp', 'VoterEligibility')
    IssuedPermit = apps.get_model('EVotingApp', 'IssuedPermit')

    legacy_contract = getattr(settings, 'CONTRACT_ADDRESS', '0x5FbDB2315678afecb367f032d93F642f64180aa3')
    legacy_authority = getattr(settings, 'ELECTION_AUTHORITY_ADDRESS', '0xEe1BbC1BAf695c990ecb43e6Fd43d47060c12D58')
    legacy_chain = getattr(settings, 'CHAIN_ID', 31337)

    election, _ = Election.objects.get_or_create(
        election_id=2026,
        defaults={
            'title': 'Legacy General Election 2026',
            'description': 'Initial legacy general election deployed on Ethereum local network',
            'election_type': 'GENERAL',
            'status': 'ACTIVE',
            'contract_address': legacy_contract,
            'chain_id': legacy_chain,
            'authority_address': legacy_authority,
            'deployment_status': 'DEPLOYED',
            'candidates_locked_on_chain': True,
        }
    )

    # Seed candidates
    default_candidates = [
        (1, 'Rahul Gandhi', 'Congress', 'Candidate for Indian National Congress'),
        (2, 'Narendar Modi', 'BJP', 'Candidate for Bharatiya Janata Party'),
        (3, 'Akhilesh Yadav', 'Samajwadi', 'Candidate for Samajwadi Party'),
    ]

    for cid, name, symbol, desc in default_candidates:
        Candidate.objects.get_or_create(
            election=election,
            candidate_id_num=cid,
            defaults={
                'name': name,
                'symbol': symbol,
                'description': desc,
                'display_order': cid,
                'is_active': True,
            }
        )

    # Inspect and preserve actual existing voters in the database
    existing_voters = Voter.objects.all()
    for voter in existing_voters:
        VoterEligibility.objects.get_or_create(
            voter=voter,
            election=election,
            defaults={
                'is_eligible': True,
                'has_voted': voter.has_voted,
                'voted_at': voter.voted_at,
            }
        )

    # Link existing issued permits to legacy election
    IssuedPermit.objects.filter(election_id=2026, election_ref__isnull=True).update(election_ref=election)


def reverse_legacy_election_data(apps, schema_editor):
    Election = apps.get_model('EVotingApp', 'Election')
    Election.objects.filter(election_id=2026).delete()


class Migration(migrations.Migration):

    dependencies = [
        ('EVotingApp', '0004_election_adminauditlog_issuedpermit_election_ref_and_more'),
    ]

    operations = [
        migrations.RunPython(seed_legacy_election_data, reverse_code=reverse_legacy_election_data),
    ]
