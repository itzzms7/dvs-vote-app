from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('EVotingApp', '0012_election_immediate_duration_hours'),
    ]

    operations = [
        migrations.AddField(
            model_name='election',
            name='auto_transition_in_progress',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='election',
            name='auto_transition_last_attempt_at',
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='election',
            name='auto_transition_last_error',
            field=models.TextField(blank=True, default=''),
        ),
        migrations.AddField(
            model_name='election',
            name='auto_transition_last_action',
            field=models.CharField(blank=True, default='', max_length=50),
        ),
    ]
