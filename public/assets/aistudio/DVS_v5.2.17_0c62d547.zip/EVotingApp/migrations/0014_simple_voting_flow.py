from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [
        ('EVotingApp', '0013_election_auto_lifecycle'),
    ]

    operations = [
        migrations.AddField(
            model_name='candidate',
            name='symbol_image',
            field=models.ImageField(blank=True, null=True, upload_to='candidate_symbols/%Y/%m/'),
        ),
        migrations.CreateModel(
            name='BallotReceipt',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('candidate_id', models.IntegerField()),
                ('voter_hash', models.CharField(max_length=66)),
                ('contract_address', models.CharField(max_length=42)),
                ('tx_hash', models.CharField(max_length=66, unique=True)),
                ('block_number', models.PositiveBigIntegerField()),
                ('receipt_reference', models.CharField(max_length=100, unique=True)),
                ('confirmed_at', models.DateTimeField()),
                ('election', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='ballot_receipts', to='EVotingApp.election')),
                ('voter', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='ballot_receipts', to='EVotingApp.voter')),
            ],
            options={'ordering': ['-confirmed_at', '-id']},
        ),
    ]
