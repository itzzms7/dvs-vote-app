import json
from datetime import timedelta
from django.test import TestCase, Client
from django.utils import timezone
from eth_account import Account
from eth_account.messages import encode_defunct

from EVotingApp.models import Voter, AuthChallenge, IssuedPermit, Election, Candidate
from EVotingApp.crypto import derive_voter_nullifier


class MetaMaskAndBallotPermitTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.wallet_account = Account.create()
        self.wallet_address = self.wallet_account.address
        self.other_wallet = Account.create()

        self.election = Election.objects.create(
            election_id=1,
            title="General Election Demonstration 2026",
            status="ACTIVE",
            deployment_status="DEPLOYED_AND_SYNCED",
            contract_address="0x3d050eD3cA4c5A85ABba756139c5f72FeCee1798",
            chain_id=31337,
            candidates_locked_on_chain=True,
            start_datetime=timezone.now() - timedelta(hours=1),
            end_datetime=timezone.now() + timedelta(hours=24),
        )

        self.candidate = Candidate.objects.create(
            election=self.election,
            candidate_id_num=1,
            name="Alice Johnson",
            symbol="AJ",
            is_active=True,
            is_synced_on_chain=True,
        )

        self.voter = Voter.objects.create(
            name="Test Citizen",
            aadhar_number="123456789012",
            has_voted=False,
        )

        from EVotingApp.models import VoterEligibility
        VoterEligibility.objects.create(
            voter=self.voter,
            election=self.election,
            is_eligible=True,
            has_voted=False,
        )

    def _authenticate_wallet(self, account=None):
        acct = account or self.wallet_account
        res = self.client.get(f"/api/wallet/challenge/?address={acct.address}")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        msg = encode_defunct(text=data["challenge"])
        signed = Account.sign_message(msg, acct.key)
        verify_res = self.client.post(
            "/api/wallet/verify/",
            data=json.dumps({
                "address": acct.address,
                "nonce": data["nonce"],
                "signature": signed.signature.hex(),
            }),
            content_type="application/json",
        )
        return verify_res, data

    def test_challenge_generation_and_valid_signature(self):
        verify_res, _ = self._authenticate_wallet()
        self.assertEqual(verify_res.status_code, 200)
        self.assertTrue(verify_res.json()["success"])

        status_res = self.client.get("/api/wallet/status/")
        self.assertTrue(status_res.json()["authenticated"])
        self.assertEqual(status_res.json()["wallet"].lower(), self.wallet_address.lower())

    def test_challenge_replay_rejected(self):
        verify_res, challenge_data = self._authenticate_wallet()
        self.assertEqual(verify_res.status_code, 200)

        msg = encode_defunct(text=challenge_data["challenge"])
        signed = Account.sign_message(msg, self.wallet_account.key)
        replay_res = self.client.post(
            "/api/wallet/verify/",
            data=json.dumps({
                "address": self.wallet_address,
                "nonce": challenge_data["nonce"],
                "signature": signed.signature.hex(),
            }),
            content_type="application/json",
        )
        self.assertEqual(replay_res.status_code, 400)

    def test_expired_challenge_rejected(self):
        res = self.client.get(f"/api/wallet/challenge/?address={self.wallet_address}")
        data = res.json()
        challenge_obj = AuthChallenge.objects.get(nonce=data["nonce"])
        challenge_obj.expires_at = timezone.now() - timedelta(seconds=10)
        challenge_obj.save()

        msg = encode_defunct(text=data["challenge"])
        signed = Account.sign_message(msg, self.wallet_account.key)
        verify_res = self.client.post(
            "/api/wallet/verify/",
            data=json.dumps({
                "address": self.wallet_address,
                "nonce": data["nonce"],
                "signature": signed.signature.hex(),
            }),
            content_type="application/json",
        )
        self.assertEqual(verify_res.status_code, 400)

    def test_permit_issuance_and_sybil_wallet_binding(self):
        self._authenticate_wallet(self.wallet_account)
        permit_res = self.client.post(
            "/api/ballot/permit/",
            data=json.dumps({"candidate_id": 1, "aadhar": "123456789012"}),
            content_type="application/json",
        )
        self.assertEqual(permit_res.status_code, 200)
        payload = permit_res.json()["permit"]
        self.assertEqual(payload["candidateId"], 1)
        self.assertEqual(payload["voterWallet"].lower(), self.wallet_address.lower())

        # Attempt to use a different wallet for the same Aadhaar number -> rejected (403)
        self._authenticate_wallet(self.other_wallet)
        sybil_res = self.client.post(
            "/api/ballot/permit/",
            data=json.dumps({"candidate_id": 1, "aadhar": "123456789012"}),
            content_type="application/json",
        )
        self.assertEqual(sybil_res.status_code, 403)

    def test_unregistered_voter_rejected(self):
        self._authenticate_wallet(self.wallet_account)
        res = self.client.post(
            "/api/ballot/permit/",
            data=json.dumps({"candidate_id": 1, "aadhar": "999999999999"}),
            content_type="application/json",
        )
        self.assertEqual(res.status_code, 403)

    def test_deterministic_hmac_nullifier_derivation(self):
        n1 = derive_voter_nullifier(2026, "123456789012")
        n2 = derive_voter_nullifier(2026, "123456789012")
        n_other_election = derive_voter_nullifier(2027, "123456789012")
        self.assertEqual(n1, n2)
        self.assertNotEqual(n1, n_other_election)
        self.assertEqual(len(n1), 66)
