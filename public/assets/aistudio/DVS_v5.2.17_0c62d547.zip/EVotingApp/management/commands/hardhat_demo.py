import json
from django.core.management.base import BaseCommand, CommandError
from EVotingApp.services import BlockchainDeploymentError
from EVotingApp.hardhat_demo import (
    verify_demo_network_and_accounts,
    deploy_demo_evoting_contract,
    verify_deployed_demo_contract,
    load_demo_deployment_metadata,
    reinitialize_after_node_restart,
    rotate_and_fund_demo_accounts,
    sync_demo_deployment_to_django,
    ensure_idempotent_demo_election_ready,
)


class Command(BaseCommand):
    help = (
        "Manage and verify the Phase 8–10 Hardhat Demonstration Environment "
        "(status, deploy, verify, metadata, reinit, rotate-accounts, sync-django, ensure-ready)."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "action",
            choices=[
                "status",
                "deploy",
                "verify",
                "metadata",
                "reinit",
                "rotate-accounts",
                "sync-django",
                "ensure-ready",
            ],
            help="Operational action to perform on the Hardhat demonstration environment.",
        )
        parser.add_argument(
            "--rpc-url",
            dest="rpc_url",
            default=None,
            help="Target Hardhat JSON-RPC URL (defaults to settings.WEB3_RPC_URL or http://127.0.0.1:8545).",
        )
        parser.add_argument(
            "--election-id",
            dest="election_id",
            type=int,
            default=2026,
            help="Election ID to initialize on the EVoting contract (default: 2026).",
        )
        parser.add_argument(
            "--address",
            dest="contract_address",
            default=None,
            help="Contract address to verify (defaults to recorded metadata contract_address).",
        )
        parser.add_argument(
            "--seed-candidates",
            dest="seed_candidates",
            action="store_true",
            help="Seed and lock the 3 demonstration candidates during deployment.",
        )
        parser.add_argument(
            "--sync-django",
            dest="sync_django",
            action="store_true",
            help="Synchronize deployed contract metadata to Django Election & ContractDeployment records.",
        )
        parser.add_argument(
            "--force-rotate",
            dest="force_rotate",
            action="store_true",
            help="Force generation of brand-new rotated demonstration accounts.",
        )
        parser.add_argument(
            "--json",
            dest="as_json",
            action="store_true",
            help="Emit output as formatted JSON.",
        )

    def handle(self, *args, **options):
        action = options["action"]
        rpc_url = options.get("rpc_url")
        election_id = options.get("election_id")
        contract_address = options.get("contract_address")
        seed_candidates = bool(options.get("seed_candidates"))
        sync_django = bool(options.get("sync_django"))
        force_rotate = bool(options.get("force_rotate"))
        as_json = bool(options.get("as_json"))

        try:
            if action == "status":
                res = verify_demo_network_and_accounts(rpc_url=rpc_url)
                if as_json:
                    self.stdout.write(json.dumps(res, indent=2))
                else:
                    self.stdout.write(self.style.SUCCESS(
                        f"[OK] Hardhat Demo Network '{res['network_name']}' online at {res['rpc_endpoint']} "
                        f"(Chain ID: {res['chain_id']}, Block: {res['block_number']})"
                    ))
                    self.stdout.write(
                        f"  Deployer          : {res['deployer']['address']} ({res['deployer']['balance_eth']} ETH)"
                    )
                    self.stdout.write(
                        f"  Election Authority: {res['election_authority']['address']} "
                        f"(Distinct from Deployer: {res['election_authority']['distinct_from_deployer']})"
                    )
                    self.stdout.write(f"  Demo Voters Funded: {len(res['demo_voters'])} accounts")

            elif action == "rotate-accounts":
                res = rotate_and_fund_demo_accounts(
                    rpc_url=rpc_url,
                    force_rotate=force_rotate,
                )
                if as_json:
                    self.stdout.write(json.dumps(res, indent=2))
                else:
                    self.stdout.write(self.style.SUCCESS(
                        "[OK] Rotated and funded Hardhat demonstration accounts (non-default keys)"
                    ))
                    self.stdout.write(f"  Deployer Address  : {res['deployer_address']}")
                    self.stdout.write(f"  Authority Address : {res['election_authority_address']}")
                    self.stdout.write(f"  Reserve Operator  : {res['secondary_operator_address']}")
                    self.stdout.write(f"  Demo Voters       : {len(res['demo_voters'])} accounts funded")

            elif action == "deploy":
                res = deploy_demo_evoting_contract(
                    election_id=election_id,
                    rpc_url=rpc_url,
                    seed_demo_candidates=seed_candidates,
                )
                if sync_django:
                    sync_res = sync_demo_deployment_to_django(
                        deployment_metadata=res,
                        election_id=election_id,
                        rpc_url=rpc_url,
                    )
                    res["django_sync"] = sync_res
                if as_json:
                    self.stdout.write(json.dumps(res, indent=2))
                else:
                    self.stdout.write(self.style.SUCCESS(
                        f"[OK] Deployed EVoting contract on {res['network_name']} (Chain ID {res['chain_id']})"
                    ))
                    self.stdout.write(f"  Deployment ID     : {res['deployment_id']}")
                    self.stdout.write(f"  Contract Address  : {res['contract_address']}")
                    self.stdout.write(f"  Deployment Tx Hash: {res['deployment_tx_hash']}")
                    self.stdout.write(f"  Deployer Address  : {res['deployer_address']}")
                    self.stdout.write(f"  Authority Address : {res['election_authority_address']}")
                    self.stdout.write(f"  Bytecode Hash     : {res['deployed_bytecode_hash']}")
                    self.stdout.write(f"  Metadata File     : {res['metadata_file']}")

            elif action == "sync-django":
                sync_res = sync_demo_deployment_to_django(
                    election_id=election_id,
                    rpc_url=rpc_url,
                )
                if as_json:
                    self.stdout.write(json.dumps(sync_res, indent=2))
                else:
                    self.stdout.write(self.style.SUCCESS(
                        f"[OK] Synchronized Election #{sync_res['election_id']} to contract {sync_res['contract_address']}"
                    ))

            elif action == "metadata":
                meta = load_demo_deployment_metadata()
                if not meta:
                    raise CommandError("No active demonstration deployment metadata found.")
                self.stdout.write(json.dumps(meta, indent=2))

            elif action == "verify":
                target_addr = contract_address
                expected_eid = None
                expected_auth = None
                if not target_addr:
                    meta = load_demo_deployment_metadata()
                    if not meta or not meta.get("contract_address"):
                        raise CommandError(
                            "No contract address specified and no recorded deployment metadata found."
                        )
                    target_addr = meta["contract_address"]
                    expected_eid = meta.get("election_id")
                    expected_auth = meta.get("election_authority_address")

                res = verify_deployed_demo_contract(
                    contract_address=target_addr,
                    expected_election_id=expected_eid,
                    expected_authority_address=expected_auth,
                    rpc_url=rpc_url,
                )
                if as_json:
                    self.stdout.write(json.dumps(res, indent=2))
                else:
                    st = res["state"]
                    self.stdout.write(self.style.SUCCESS(
                        f"[OK] Verified EVoting contract at {res['contract_address']} (Chain ID {res['chain_id']})"
                    ))
                    self.stdout.write(f"  Owner             : {st['owner']}")
                    self.stdout.write(f"  Election Authority: {st['electionAuthority']}")
                    self.stdout.write(f"  Election ID       : {st['electionId']}")
                    self.stdout.write(f"  Election Open     : {st['electionOpen']}")
                    self.stdout.write(f"  Candidates Locked : {st['candidatesLocked']}")
                    self.stdout.write(f"  Total Votes       : {st['totalVotes']}")
                    self.stdout.write(f"  DOMAIN_SEPARATOR  : {st['DOMAIN_SEPARATOR']}")

            elif action == "reinit":
                res = reinitialize_after_node_restart(
                    election_id=election_id,
                    rpc_url=rpc_url,
                    force=True,
                    seed_demo_candidates=seed_candidates,
                )
                if sync_django and res.get("deployment"):
                    sync_res = sync_demo_deployment_to_django(
                        deployment_metadata=res["deployment"],
                        election_id=election_id,
                        rpc_url=rpc_url,
                    )
                    res["django_sync"] = sync_res
                if as_json:
                    self.stdout.write(json.dumps(res, indent=2))
                else:
                    dep = res["deployment"]
                    self.stdout.write(self.style.SUCCESS(
                        f"[OK] Reinitialized Hardhat demonstration contract (Reason: {res['reason']})"
                    ))
                    if res.get("previous_contract_address"):
                        self.stdout.write(f"  Previous Contract : {res['previous_contract_address']}")
                    self.stdout.write(f"  New Contract Addr : {dep['contract_address']}")
                    self.stdout.write(f"  Deployment Tx Hash: {dep['deployment_tx_hash']}")
                    self.stdout.write(f"  Deployment ID     : {dep['deployment_id']}")

            elif action == "ensure-ready":
                res = ensure_idempotent_demo_election_ready(
                    election_id=election_id,
                    rpc_url=rpc_url,
                    seed_demo_candidates=True,
                )
                if as_json:
                    self.stdout.write(json.dumps(res, indent=2))
                else:
                    self.stdout.write(self.style.SUCCESS(
                        f"[OK] Demo Election #{election_id} readiness status: {res['status']} "
                        f"(redeployed={res['redeployed']}, contract={res.get('contract_address', 'N/A')})"
                    ))

        except BlockchainDeploymentError as bde:
            raise CommandError(str(bde))
        except CommandError:
            raise
        except Exception as exc:
            raise CommandError(f"Hardhat demonstration command failed: {str(exc)}")
