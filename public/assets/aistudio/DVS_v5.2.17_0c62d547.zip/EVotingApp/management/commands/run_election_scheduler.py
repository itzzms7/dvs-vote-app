import time
import signal
import sys
from datetime import datetime
from django.core.management.base import BaseCommand
from django.utils import timezone

from EVotingApp.simple_voting import run_election_lifecycle_scheduler


class Command(BaseCommand):
    help = (
        "Run the autonomous election lifecycle scheduler to automatically activate "
        "scheduled elections and close active elections whose voting deadline has arrived."
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.keep_running = True

    def add_arguments(self, parser):
        parser.add_argument(
            '--interval',
            type=int,
            default=10,
            help="Polling interval in seconds between lifecycle evaluation cycles (default: 10s, min: 1s)."
        )
        parser.add_argument(
            '--once',
            action='store_true',
            help="Execute a single evaluation pass and exit immediately (suitable for cron or test harnesses)."
        )

    def handle(self, *args, **options):
        interval = max(1, options['interval'])
        run_once = options['once']

        # Setup graceful signal handlers
        signal.signal(signal.SIGINT, self._handle_signal)
        signal.signal(signal.SIGTERM, self._handle_signal)

        self.stdout.write(
            self.style.SUCCESS(
                f"[DVS Scheduler] Starting election lifecycle scheduler "
                f"(interval={interval}s, once={run_once})."
            )
        )

        cycle_count = 0
        while self.keep_running:
            cycle_count += 1
            now = timezone.now()
            ts_str = now.strftime('%Y-%m-%d %H:%M:%S %Z')

            try:
                res = run_election_lifecycle_scheduler(now=now)
                act_cnt = len(res['activated'])
                close_cnt = len(res['closed'])
                skip_cnt = len(res.get('skipped', []))
                err_cnt = len(res['errors'])

                if act_cnt > 0 or close_cnt > 0 or err_cnt > 0:
                    self.stdout.write(
                        f"[{ts_str}] Cycle #{cycle_count}: "
                        f"Activated={act_cnt}, Closed={close_cnt}, Skipped={skip_cnt}, Errors={err_cnt}"
                    )
                    for a in res['activated']:
                        self.stdout.write(self.style.SUCCESS(f"  -> Activated Election #{a['election_id']}"))
                    for c in res['closed']:
                        self.stdout.write(self.style.SUCCESS(f"  -> Closed Election #{c['election_id']}"))
                    for e in res['errors']:
                        self.stdout.write(self.style.ERROR(f"  -> Error on Election #{e['election_id']} ({e['action']}): {e['error']}"))
                elif cycle_count == 1 or cycle_count % 30 == 0:
                    # Heartbeat log every 30 cycles of idle operation
                    self.stdout.write(
                        f"[{ts_str}] Cycle #{cycle_count}: Idle check complete (0 transitions due)."
                    )

            except Exception as loop_e:
                self.stdout.write(self.style.WARNING(f"[{ts_str}] Transient scheduler loop error: {str(loop_e)}"))

            if run_once:
                break

            # Sleep in 1-second increments so SIGINT/SIGTERM terminates immediately
            for _ in range(interval):
                if not self.keep_running:
                    break
                time.sleep(1)

        self.stdout.write(self.style.SUCCESS("[DVS Scheduler] Daemon stopped cleanly."))

    def _handle_signal(self, signum, frame):
        self.stdout.write(self.style.NOTICE(f"\n[DVS Scheduler] Received signal {signum}. Shutting down gracefully..."))
        self.keep_running = False
