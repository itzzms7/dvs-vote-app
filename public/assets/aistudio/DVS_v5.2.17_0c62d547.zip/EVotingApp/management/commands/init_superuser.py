import os
from django.core.management.base import BaseCommand, CommandError
from EVotingApp.services import initialize_system_superuser, ElectionLifecycleError


class Command(BaseCommand):
    help = (
        "Idempotently initialize the initial Django Superuser and assign the DVS "
        "'Super Admin' role group from DJANGO_SUPERUSER_USERNAME, DJANGO_SUPERUSER_EMAIL, "
        "and DJANGO_SUPERUSER_PASSWORD environment variables."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            '--skip-if-missing',
            action='store_true',
            help=(
                "Exit with status 0 and an informational notice if superuser environment "
                "variables are not configured (useful for automated container startup scripts)."
            ),
        )

    def handle(self, *args, **options):
        skip_if_missing = bool(options.get('skip_if_missing', False))
        strict = not skip_if_missing

        try:
            result = initialize_system_superuser(env=os.environ, strict=strict)
        except ElectionLifecycleError as e:
            raise CommandError(str(e))
        except Exception as e:
            raise CommandError(f"Superuser initialization error: {str(e)}")

        status = result.get('status')
        msg = result.get('message', '')

        if status == 'CREATED':
            self.stdout.write(self.style.SUCCESS(f"[DVS Superuser] {msg}"))
        elif status == 'ALREADY_EXISTS':
            self.stdout.write(self.style.NOTICE(f"[DVS Superuser] {msg}"))
        elif status == 'SKIPPED_MISSING_CONFIG':
            from django.conf import settings
            from django.contrib.auth.models import User
            if getattr(settings, 'IS_PRODUCTION', False):
                raise CommandError(msg)
            if not User.objects.filter(is_superuser=True).exists():
                demo_env = {
                    'DJANGO_SUPERUSER_USERNAME': 'admin',
                    'DJANGO_SUPERUSER_EMAIL': 'admin@dvs.local',
                    'DJANGO_SUPERUSER_PASSWORD': 'DvsAdmin2026!Demo',
                }
                demo_res = initialize_system_superuser(env=demo_env, strict=True)
                self.stdout.write(self.style.SUCCESS(
                    f"[DVS Superuser] Auto-provisioned demonstration Super Admin '{demo_res['username']}' "
                    f"with DVS 'Super Admin' role (login: admin / DvsAdmin2026!Demo)."
                ))
            else:
                self.stdout.write(self.style.NOTICE(
                    "[DVS Superuser] Existing superuser found in database; preserving existing credentials."
                ))
        else:
            if strict:
                raise CommandError(msg)
            self.stdout.write(self.style.WARNING(f"[DVS Superuser] {msg}"))
