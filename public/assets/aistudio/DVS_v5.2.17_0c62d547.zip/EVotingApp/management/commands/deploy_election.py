from django.core.management.base import BaseCommand, CommandError
from EVotingApp.models import Election
from EVotingApp.services import (
    deploy_election_contract,
    inspect_deployed_contract,
    BlockchainDeploymentError
)


class Command(BaseCommand):
    help = 'Deploys and verifies an EVoting smart contract for a specified election ID'

    def add_arguments(self, parser):
        parser.add_argument('election_id', type=int, help='Database Primary Key or Election ID of the election')
        parser.add_argument(
            '--force',
            action='store_true',
            help='Force deployment of a new contract instance and archive any existing contract address as legacy'
        )

    def handle(self, *args, **options):
        election_id = options['election_id']
        force = options.get('force', False)
        self.stdout.write(self.style.NOTICE(f"Initiating smart contract deployment for Election ID {election_id}..."))

        try:
            election = (
                Election.objects.filter(election_id=election_id).first()
                or Election.objects.filter(pk=election_id).first()
            )
            if not election:
                raise CommandError(f"No election found with ID {election_id}")

            contract_address = deploy_election_contract(election.pk, force_redeploy=force)
            election.refresh_from_db()
            verification = inspect_deployed_contract(contract_address)

            self.stdout.write(self.style.SUCCESS(
                f"Successfully deployed contract for '{election.title}' at address: {contract_address}"
            ))
            self.stdout.write(f"  Chain ID               : {election.chain_id}")
            self.stdout.write(f"  Deployment Tx Hash     : {election.deployment_tx_hash}")
            self.stdout.write(f"  Deployment Block Number: {election.deployment_block_number}")
            self.stdout.write(f"  Deployed Bytecode Hash : {election.deployed_bytecode_hash}")
            if election.legacy_contract_address:
                self.stdout.write(f"  Preserved Legacy Addr  : {election.legacy_contract_address}")
            self.stdout.write(f"  Interface Compatible   : {verification.get('is_compatible')}")
            self.stdout.write(f"  Verified Functions     : {verification.get('functions_verified')}")

        except BlockchainDeploymentError as bde:
            raise CommandError(f"Deployment Failed: {str(bde)}")
        except Exception as e:
            raise CommandError(f"Unexpected error during deployment: {str(e)}")
