import json
from datetime import timedelta
from unittest.mock import patch, MagicMock
from django.test import TestCase, Client
from django.utils import timezone
from django.contrib.auth.models import User, Group

from EVotingApp.models import (
    Election,
    Candidate,
    ContractDeployment,
    Voter,
    VoterEligibility,
    ElectionAdminAssignment,
    AdminAuditLog,
)
from EVotingApp.services import (
    configure_voting_window,
    activate_election,
    close_election,
    validate_immediate_duration,
    ElectionLifecycleError,
    BlockchainDeploymentError,
    get_public_election_summary,
    execute_automatic_lifecycle_transitions,
    check_election_readiness_for_activation,
    get_election_lifecycle_operational_status,
)



class Module8CommencementConfigurationTests(TestCase):
    def setUp(self):
        self.client = Client()

        # Auth Groups
        self.super_group, _ = Group.objects.get_or_create(name='Super Admin')
        self.admin_group, _ = Group.objects.get_or_create(name='Election Administrator')

        # Users
        self.superuser = User.objects.create_superuser(
            username='m8_super', password='password123', email='m8_super@dvs.local'
        )
        self.election_admin = User.objects.create_user(
            username='m8_admin', password='password123', is_staff=True
        )
        self.election_admin.groups.add(self.admin_group)

    def _login(self, user):
        self.client.force_login(user)

    # 1. Scheduled election creation with valid start and end datetimes
    def test_scheduled_election_creation_valid_dates(self):
        self._login(self.superuser)
        now = timezone.now()
        start = now + timedelta(days=1)
        end = now + timedelta(days=3)

        payload = {
            'title': '2027 Parliamentary Scheduled Election',
            'election_type': 'GENERAL',
            'commencement_mode': 'SCHEDULED',
            'start_datetime': start.isoformat(),
            'end_datetime': end.isoformat(),
            'result_publication_policy': 'HIDDEN_UNTIL_CLOSE',
            'election_id': 8001,
            'description': 'Valid scheduled election configuration.',
        }

        res = self.client.post(
            '/api/control/elections/create/',
            data=json.dumps(payload),
            content_type='application/json',
        )
        self.assertEqual(res.status_code, 201)
        data = res.json()
        self.assertTrue(data['success'])
        self.assertEqual(data['election']['commencement_mode'], 'SCHEDULED')
        self.assertEqual(data['election']['election_id'], 8001)

        el = Election.objects.get(election_id=8001)
        self.assertEqual(el.commencement_mode, 'SCHEDULED')
        self.assertIsNotNone(el.start_datetime)
        self.assertIsNotNone(el.end_datetime)
        self.assertTrue(el.end_datetime > el.start_datetime)

    # 2. Rejection of an end datetime earlier than or equal to the start datetime
    def test_rejection_of_invalid_window_end_before_or_equal_to_start(self):
        self._login(self.superuser)
        now = timezone.now()

        # End before start
        payload_invalid = {
            'title': 'Invalid Window Election',
            'election_type': 'GENERAL',
            'commencement_mode': 'SCHEDULED',
            'start_datetime': (now + timedelta(days=2)).isoformat(),
            'end_datetime': (now + timedelta(days=1)).isoformat(),
            'election_id': 8002,
        }
        res = self.client.post(
            '/api/control/elections/create/',
            data=json.dumps(payload_invalid),
            content_type='application/json',
        )
        self.assertEqual(res.status_code, 400)
        self.assertIn('later than', res.json()['error'].lower())

        # End equal to start
        payload_equal = {
            'title': 'Equal Window Election',
            'election_type': 'GENERAL',
            'commencement_mode': 'SCHEDULED',
            'start_datetime': (now + timedelta(days=2)).isoformat(),
            'end_datetime': (now + timedelta(days=2)).isoformat(),
            'election_id': 8003,
        }
        res2 = self.client.post(
            '/api/control/elections/create/',
            data=json.dumps(payload_equal),
            content_type='application/json',
        )
        self.assertEqual(res2.status_code, 400)

        # Direct service method rejection
        draft_el = Election.objects.create(
            title='Direct Service Test',
            election_id=8004,
            commencement_mode='SCHEDULED',
        )
        with self.assertRaises(ElectionLifecycleError):
            configure_voting_window(
                draft_el.pk,
                start_datetime=now + timedelta(days=2),
                end_datetime=now + timedelta(days=1),
                commencement_mode='SCHEDULED',
            )

    # 3. Scheduled elections with durations exceeding 24 hours
    def test_scheduled_elections_duration_exceeding_24_hours(self):
        self._login(self.superuser)
        now = timezone.now()
        start = now + timedelta(days=1)
        # 14 days duration (336 hours) - significantly exceeds 24h
        end = now + timedelta(days=15)

        payload = {
            'title': 'Multi-Week National Election',
            'election_type': 'GENERAL',
            'commencement_mode': 'SCHEDULED',
            'start_datetime': start.isoformat(),
            'end_datetime': end.isoformat(),
            'election_id': 8005,
        }
        res = self.client.post(
            '/api/control/elections/create/',
            data=json.dumps(payload),
            content_type='application/json',
        )
        self.assertEqual(res.status_code, 201)
        el = Election.objects.get(election_id=8005)
        duration = el.end_datetime - el.start_datetime
        self.assertGreater(duration, timedelta(hours=24))
        self.assertEqual(duration, timedelta(days=14))

    # 4. Immediate election configuration
    def test_immediate_election_configuration(self):
        self._login(self.superuser)
        now = timezone.now()

        # Passing a scheduled start time should be safely ignored/cleared in IMMEDIATE mode
        payload = {
            'title': 'Immediate By-Election 2027',
            'election_type': 'PRIMARY',
            'commencement_mode': 'IMMEDIATE',
            'start_datetime': (now + timedelta(days=5)).isoformat(),  # Should be cleared
            'end_datetime': (now + timedelta(days=6)).isoformat(),
            'election_id': 8006,
        }
        res = self.client.post(
            '/api/control/elections/create/',
            data=json.dumps(payload),
            content_type='application/json',
        )
        self.assertEqual(res.status_code, 201)
        data = res.json()
        self.assertEqual(data['election']['commencement_mode'], 'IMMEDIATE')
        self.assertIsNone(data['election']['start_datetime'])

        el = Election.objects.get(election_id=8006)
        self.assertEqual(el.commencement_mode, 'IMMEDIATE')
        self.assertIsNone(el.start_datetime)

    # 5. Correct handling of actual activation timestamps
    @patch('EVotingApp.services.inspect_deployed_contract')
    @patch('EVotingApp.services.verify_election_candidate_parity')
    @patch('EVotingApp.services.load_contract_artifact')
    @patch('EVotingApp.services.get_web3_provider')
    def test_correct_handling_of_actual_activation_timestamps(
        self, mock_get_w3, mock_load_artifact, mock_verify_parity, mock_inspect
    ):
        mock_inspect.return_value = {'has_code': True, 'is_compatible': True}
        mock_verify_parity.return_value = {'candidate_ids': [1, 2]}
        mock_load_artifact.return_value = ([], '0x', '0x')

        mock_w3 = MagicMock()
        mock_w3.is_connected.return_value = True
        mock_w3.eth.accounts = ['0x1111111111111111111111111111111111111111']
        mock_w3.eth.wait_for_transaction_receipt.return_value = MagicMock(status=1)
        mock_contract = MagicMock()
        mock_contract.functions.candidatesLocked().call.return_value = True
        mock_contract.functions.electionOpen().call.return_value = True

        window_state = {'start': 0, 'end': 0, 'locked': False}
        def fake_set_window(s, e):
            window_state['start'] = s
            window_state['end'] = e
            mock_tx = MagicMock()
            mock_tx.transact.return_value = b'tx_win'
            return mock_tx
        mock_contract.functions.setVotingWindow.side_effect = fake_set_window
        mock_contract.functions.votingStartTime().call.side_effect = lambda: window_state['start']
        mock_contract.functions.votingEndTime().call.side_effect = lambda: window_state['end']
        mock_contract.functions.votingWindowLocked().call.side_effect = lambda: window_state['locked']

        def fake_set_open(is_open):
            window_state['locked'] = True
            mock_tx = MagicMock()
            mock_tx.transact.return_value = b'tx_open'
            return mock_tx
        mock_contract.functions.setElectionOpen.side_effect = fake_set_open

        mock_w3.eth.contract.return_value = mock_contract
        mock_get_w3.return_value = mock_w3

        # Create immediate election
        el = Election.objects.create(
            title='Immediate Activation Test',
            election_id=8007,
            commencement_mode='IMMEDIATE',
            immediate_duration_hours=4,
            status='SCHEDULED',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=None,
        )
        Candidate.objects.create(
            election=el, candidate_id_num=1, name='Alice', symbol='PartyA', is_active=True, is_synced_on_chain=True
        )
        Candidate.objects.create(
            election=el, candidate_id_num=2, name='Bob', symbol='PartyB', is_active=True, is_synced_on_chain=True
        )

        before_activate = timezone.now()
        activate_election(el.pk, actor_user=self.superuser)
        after_activate = timezone.now()

        el.refresh_from_db()
        self.assertEqual(el.status, 'ACTIVE')
        self.assertIsNotNone(el.start_datetime)
        self.assertTrue(before_activate <= el.start_datetime <= after_activate)

    # 6. Invalid or missing commencement configuration
    def test_invalid_or_missing_commencement_configuration(self):
        el = Election.objects.create(
            title='Incomplete Schedule Election',
            election_id=8008,
            commencement_mode='SCHEDULED',
            status='SCHEDULED',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=None,
            end_datetime=None,
        )
        Candidate.objects.create(
            election=el, candidate_id_num=1, name='Candidate A', symbol='SymA', is_active=True, is_synced_on_chain=True
        )

        # Attempting activation without configuring start and end datetime must be rejected
        with self.assertRaises(ElectionLifecycleError) as ctx:
            activate_election(el.pk, actor_user=self.superuser)
        self.assertIn('incomplete schedule configuration', str(ctx.exception).lower())

        # Attempting configure_voting_window with invalid mode
        with self.assertRaises(ElectionLifecycleError):
            configure_voting_window(
                el.pk,
                start_datetime=timezone.now(),
                end_datetime=timezone.now() + timedelta(hours=5),
                commencement_mode='INVALID_MODE'
            )

    # 7. Prevention of configuration changes after activation
    def test_prevention_of_configuration_changes_after_activation(self):
        now = timezone.now()
        active_el = Election.objects.create(
            title='Active Election Configuration Lock',
            election_id=8009,
            commencement_mode='SCHEDULED',
            status='ACTIVE',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            voting_window_locked_on_chain=True,
            start_datetime=now - timedelta(hours=1),
            end_datetime=now + timedelta(hours=5),
        )

        # Direct service rejection
        with self.assertRaises(ElectionLifecycleError):
            configure_voting_window(
                active_el.pk,
                start_datetime=now,
                end_datetime=now + timedelta(hours=10),
            )

        # API rejection via /api/control/elections/<id>/window/
        self._login(self.superuser)
        res = self.client.post(
            f'/api/control/elections/{active_el.election_id}/window/',
            data=json.dumps({
                'start_datetime': now.isoformat(),
                'end_datetime': (now + timedelta(hours=10)).isoformat(),
            }),
            content_type='application/json',
        )
        self.assertEqual(res.status_code, 400)
        self.assertIn('after election activation', res.json()['error'])

        # API rejection via /api/control/elections/<id>/update/
        res_update = self.client.post(
            f'/api/control/elections/{active_el.election_id}/update/',
            data=json.dumps({'commencement_mode': 'IMMEDIATE'}),
            content_type='application/json',
        )
        self.assertEqual(res_update.status_code, 400)
        self.assertIn('after election activation', res_update.json()['error'])

    # 8. Compatibility with existing election lifecycle and deployment behavior
    def test_scheduled_election_premature_activation_rejection(self):
        now = timezone.now()
        # Scheduled in the future (starts tomorrow)
        future_start = now + timedelta(days=1)
        future_end = now + timedelta(days=3)

        future_el = Election.objects.create(
            title='Future Scheduled Election',
            election_id=8010,
            commencement_mode='SCHEDULED',
            status='SCHEDULED',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=future_start,
            end_datetime=future_end,
        )
        Candidate.objects.create(
            election=future_el, candidate_id_num=1, name='Futurist', symbol='FUT', is_active=True, is_synced_on_chain=True
        )

        # Premature activation MUST be rejected
        with self.assertRaises(ElectionLifecycleError) as ctx:
            activate_election(future_el.pk, actor_user=self.superuser)
        self.assertIn('before its configured commencement time', str(ctx.exception))


class Module8ImmediateDurationTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.super_group, _ = Group.objects.get_or_create(name='Super Admin')
        self.admin_group, _ = Group.objects.get_or_create(name='Election Administrator')

        self.superuser = User.objects.create_superuser(
            username='m8_super_dur', password='password123', email='m8_super_dur@dvs.local'
        )
        self.election_admin = User.objects.create_user(
            username='m8_admin_dur', password='password123', is_staff=True
        )
        self.election_admin.groups.add(self.admin_group)

    def _login(self, user):
        self.client.force_login(user)

    # 1. All valid durations 1–24
    def test_all_valid_durations_1_to_24(self):
        for h in range(1, 25):
            self.assertEqual(validate_immediate_duration(h), h)
            self.assertEqual(validate_immediate_duration(str(h)), h)
            self.assertEqual(validate_immediate_duration(float(h)), h)

        el = Election.objects.create(
            title='Duration Test Election',
            election_id=8101,
            commencement_mode='IMMEDIATE',
            status='DRAFT',
            deployment_status='NOT_DEPLOYED',
        )
        for h in [1, 6, 12, 18, 24]:
            configure_voting_window(
                el.pk,
                commencement_mode='IMMEDIATE',
                immediate_duration_hours=h,
            )
            el.refresh_from_db()
            self.assertEqual(el.immediate_duration_hours, h)

    # 2. Rejection of zero, negative, fractional, missing, boolean, and > 24 values
    def test_rejection_of_invalid_durations(self):
        invalid_values = [
            0, -1, -24, 25, 100, 1.5, 3.14, 'abc', '12.5', '0', '-5', '25', None, True, False, '', [], {}
        ]
        for val in invalid_values:
            with self.assertRaises(ElectionLifecycleError):
                validate_immediate_duration(val)

        el = Election.objects.create(
            title='Invalid Duration Election',
            election_id=8102,
            commencement_mode='IMMEDIATE',
            status='DRAFT',
            deployment_status='NOT_DEPLOYED',
        )
        with self.assertRaises(ElectionLifecycleError):
            configure_voting_window(
                el.pk,
                commencement_mode='IMMEDIATE',
                immediate_duration_hours=0,
            )
        with self.assertRaises(ElectionLifecycleError):
            configure_voting_window(
                el.pk,
                commencement_mode='IMMEDIATE',
                immediate_duration_hours=25,
            )

    # 3. Duration persistence across configuration
    def test_duration_persistence_across_configuration(self):
        self._login(self.superuser)
        res = self.client.post(
            '/api/control/elections/create/',
            data=json.dumps({
                'title': 'Immediate 8h Election',
                'election_type': 'GENERAL',
                'commencement_mode': 'IMMEDIATE',
                'immediate_duration_hours': 8,
                'election_id': 8103,
            }),
            content_type='application/json',
        )
        self.assertEqual(res.status_code, 201)
        data = res.json()
        self.assertEqual(data['election']['immediate_duration_hours'], 8)

        el = Election.objects.get(election_id=8103)
        self.assertEqual(el.immediate_duration_hours, 8)

        # Update to 16 hours via window config endpoint
        res2 = self.client.post(
            f'/api/control/elections/{el.election_id}/window/',
            data=json.dumps({
                'commencement_mode': 'IMMEDIATE',
                'immediate_duration_hours': 16,
            }),
            content_type='application/json',
        )
        self.assertEqual(res2.status_code, 200)
        self.assertEqual(res2.json()['immediate_duration_hours'], 16)
        el.refresh_from_db()
        self.assertEqual(el.immediate_duration_hours, 16)

    # 4. Immediate activation calculating start time from actual activation timestamp
    # 5. Correct calculation of end time from activation time + selected duration
    # 6. Contract receiving correct start and end timestamps
    def test_immediate_activation_calculates_actual_start_end_and_syncs_contract(self):
        el = Election.objects.create(
            title='Ready Immediate Election',
            election_id=8104,
            commencement_mode='IMMEDIATE',
            immediate_duration_hours=6,
            status='SCHEDULED',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=None,
            end_datetime=None,
        )
        Candidate.objects.create(
            election=el, candidate_id_num=1, name='Candidate A', symbol='A', is_active=True, is_synced_on_chain=True
        )

        mock_w3 = MagicMock()
        mock_w3.is_connected.return_value = True
        mock_w3.eth.accounts = ['0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266']

        mock_contract = MagicMock()
        mock_contract_state = {'open': False, 'cands_locked': True, 'win_locked': False, 'start': 0, 'end': 0}

        def mock_set_election_open(val):
            mock_contract_state['open'] = val
            mock_contract_state['win_locked'] = True
            m_tx = MagicMock()
            m_tx.transact.return_value = b'\x01' * 32
            return m_tx

        def mock_set_voting_window(s, e):
            mock_contract_state['start'] = s
            mock_contract_state['end'] = e
            m_tx = MagicMock()
            m_tx.transact.return_value = b'\x02' * 32
            return m_tx

        mock_contract.functions.candidatesLocked.return_value.call.side_effect = lambda: mock_contract_state['cands_locked']
        mock_contract.functions.votingWindowLocked.return_value.call.side_effect = lambda: mock_contract_state['win_locked']
        mock_contract.functions.electionOpen.return_value.call.side_effect = lambda: mock_contract_state['open']
        mock_contract.functions.votingStartTime.return_value.call.side_effect = lambda: mock_contract_state['start']
        mock_contract.functions.votingEndTime.return_value.call.side_effect = lambda: mock_contract_state['end']
        mock_contract.functions.candidates.return_value.call.return_value = (1, 'Candidate A', 'A', 0, True)
        mock_contract.functions.getCandidateIds.return_value.call.return_value = [1]
        mock_contract.functions.setVotingWindow.side_effect = mock_set_voting_window
        mock_contract.functions.setElectionOpen.side_effect = mock_set_election_open

        receipt_mock = MagicMock()
        receipt_mock.status = 1
        mock_w3.eth.wait_for_transaction_receipt.return_value = receipt_mock
        mock_w3.eth.contract.return_value = mock_contract

        before_activation = timezone.now()
        with patch('EVotingApp.services.get_web3_provider', return_value=mock_w3), \
             patch('EVotingApp.services.inspect_deployed_contract', return_value={'has_code': True, 'is_compatible': True}):
            activated_el = activate_election(el.pk, actor_user=self.superuser)
        after_activation = timezone.now()

        # Invariants:
        self.assertEqual(activated_el.status, 'ACTIVE')
        self.assertIsNotNone(activated_el.start_datetime)
        self.assertIsNotNone(activated_el.end_datetime)
        self.assertTrue(before_activation <= activated_el.start_datetime <= after_activation)
        # End time must equal start time + 6 hours
        expected_end = activated_el.start_datetime + timedelta(hours=6)
        self.assertEqual(activated_el.end_datetime, expected_end)

        # Smart contract received exact timestamps
        expected_start_ts = int(activated_el.start_datetime.timestamp())
        expected_end_ts = int(activated_el.end_datetime.timestamp())
        self.assertEqual(mock_contract_state['start'], expected_start_ts)
        self.assertEqual(mock_contract_state['end'], expected_end_ts)

    # 7. Activation rejected when duration is missing or invalid
    def test_activation_rejected_when_duration_is_missing_or_invalid(self):
        el = Election.objects.create(
            title='Immediate Election No Duration',
            election_id=8105,
            commencement_mode='IMMEDIATE',
            immediate_duration_hours=None,  # Missing duration
            status='SCHEDULED',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
        )
        Candidate.objects.create(
            election=el, candidate_id_num=1, name='Candidate A', symbol='A', is_active=True, is_synced_on_chain=True
        )

        with self.assertRaises(ElectionLifecycleError) as ctx:
            activate_election(el.pk, actor_user=self.superuser)
        self.assertIn('duration (1-24 hours) is required', str(ctx.exception))

    # 8. Duration and voting window immutability after activation
    def test_duration_immutability_after_activation(self):
        now = timezone.now()
        active_el = Election.objects.create(
            title='Active Immediate Election',
            election_id=8106,
            commencement_mode='IMMEDIATE',
            immediate_duration_hours=4,
            status='ACTIVE',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            voting_window_locked_on_chain=True,
            start_datetime=now,
            end_datetime=now + timedelta(hours=4),
        )

        # Service rejection
        with self.assertRaises(ElectionLifecycleError):
            configure_voting_window(
                active_el.pk,
                commencement_mode='IMMEDIATE',
                immediate_duration_hours=8,
            )

        # API rejection on /window/
        self._login(self.superuser)
        res = self.client.post(
            f'/api/control/elections/{active_el.election_id}/window/',
            data=json.dumps({
                'commencement_mode': 'IMMEDIATE',
                'immediate_duration_hours': 8,
            }),
            content_type='application/json',
        )
        self.assertEqual(res.status_code, 400)
        self.assertIn('after election activation', res.json()['error'])

        # API rejection on /update/
        res_up = self.client.post(
            f'/api/control/elections/{active_el.election_id}/update/',
            data=json.dumps({'immediate_duration_hours': 8}),
            content_type='application/json',
        )
        self.assertEqual(res_up.status_code, 400)
        self.assertIn('after election activation', res_up.json()['error'])

    # 9. Scheduled elections unaffected (including durations > 24h)
    def test_scheduled_elections_unaffected_allows_over_24h(self):
        now = timezone.now()
        start = now + timedelta(days=2)
        end = now + timedelta(days=30)  # 28 days = 672 hours (> 24 hours)

        el = Election.objects.create(
            title='Scheduled 30-Day Election',
            election_id=8107,
            commencement_mode='SCHEDULED',
            status='DRAFT',
            deployment_status='NOT_DEPLOYED',
            start_datetime=start,
            end_datetime=end,
        )
        self.assertIsNone(el.immediate_duration_hours)
        self.assertTrue((el.end_datetime - el.start_datetime).total_seconds() > 24 * 3600)

        # Configure window stays scheduled with long duration without duration validation error
        configure_voting_window(
            el.pk,
            commencement_mode='SCHEDULED',
            start_datetime=start,
            end_datetime=end,
        )
        el.refresh_from_db()
        self.assertEqual(el.commencement_mode, 'SCHEDULED')
        self.assertIsNone(el.immediate_duration_hours)

    # 10. Transaction failure and retry behavior (database not left in ACTIVE state)
    def test_activation_transaction_revert_leaves_db_unchanged(self):
        el = Election.objects.create(
            title='Failing Activation Election',
            election_id=8108,
            commencement_mode='IMMEDIATE',
            immediate_duration_hours=5,
            status='SCHEDULED',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=None,
            end_datetime=None,
        )
        Candidate.objects.create(
            election=el, candidate_id_num=1, name='Candidate A', symbol='A', is_active=True, is_synced_on_chain=True
        )

        mock_w3 = MagicMock()
        mock_w3.is_connected.return_value = True
        mock_w3.eth.accounts = ['0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266']

        mock_contract = MagicMock()
        mock_contract.functions.candidatesLocked.return_value.call.return_value = True
        mock_contract.functions.votingWindowLocked.return_value.call.return_value = False
        mock_contract.functions.candidates.return_value.call.return_value = (1, 'Candidate A', 'A', 0, True)
        mock_contract.functions.getCandidateIds.return_value.call.return_value = [1]

        # setVotingWindow succeeds
        window_tx_mock = MagicMock()
        window_tx_mock.transact.return_value = b'\x01' * 32
        mock_contract.functions.setVotingWindow.return_value = window_tx_mock

        # setElectionOpen reverts (status == 0)
        revert_receipt = MagicMock()
        revert_receipt.status = 0
        mock_w3.eth.wait_for_transaction_receipt.return_value = revert_receipt
        mock_w3.eth.contract.return_value = mock_contract

        with patch('EVotingApp.services.get_web3_provider', return_value=mock_w3), \
             patch('EVotingApp.services.inspect_deployed_contract', return_value={'has_code': True, 'is_compatible': True}):
            with self.assertRaises(BlockchainDeploymentError):
                activate_election(el.pk, actor_user=self.superuser)

        # Database record must NOT be ACTIVE
        el.refresh_from_db()
        self.assertEqual(el.status, 'SCHEDULED')
        self.assertIsNone(el.start_datetime)
        self.assertIsNone(el.end_datetime)


class Module8AutomaticLifecycleTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.super_group, _ = Group.objects.get_or_create(name='Super Admin')
        self.admin_group, _ = Group.objects.get_or_create(name='Election Administrator')

        self.superuser = User.objects.create_superuser(
            username='m8_auto_super', password='password123', email='m8_auto_super@dvs.local'
        )
        self.election_admin = User.objects.create_user(
            username='m8_auto_admin', password='password123', is_staff=True
        )
        self.election_admin.groups.add(self.admin_group)

    def _make_mock_web3(self, initial_open=False, start_ts=0, end_ts=0):
        mock_w3 = MagicMock()
        mock_w3.is_connected.return_value = True
        mock_w3.eth.accounts = ['0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266']

        mock_contract = MagicMock()
        mock_contract.functions.candidatesLocked.return_value.call.return_value = True
        mock_contract.functions.votingWindowLocked.return_value.call.return_value = True
        mock_contract.functions.electionOpen.return_value.call.return_value = initial_open
        mock_contract.functions.votingStartTime.return_value.call.return_value = start_ts
        mock_contract.functions.votingEndTime.return_value.call.return_value = end_ts
        mock_contract.functions.getCandidateIds.return_value.call.return_value = [1]
        mock_contract.functions.candidates.return_value.call.return_value = (1, 'Candidate A', 'A', 0, True)

        tx_mock = MagicMock()
        tx_mock.transact.return_value = b'\x02' * 32
        mock_contract.functions.setVotingWindow.return_value = tx_mock
        mock_contract.functions.setElectionOpen.return_value = tx_mock

        receipt_mock = MagicMock()
        receipt_mock.status = 1
        mock_w3.eth.wait_for_transaction_receipt.return_value = receipt_mock
        mock_w3.eth.contract.return_value = mock_contract

        return mock_w3, mock_contract

    # 1. Scheduled election does not activate before start time
    def test_01_scheduled_election_does_not_activate_before_start_time(self):
        now = timezone.now()
        el = Election.objects.create(
            title='Future Scheduled Election',
            election_id=8201,
            commencement_mode='SCHEDULED',
            status='SCHEDULED',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=now + timedelta(hours=2),
            end_datetime=now + timedelta(hours=10),
        )
        Candidate.objects.create(
            election=el, candidate_id_num=1, name='Candidate A', symbol='A', is_active=True, is_synced_on_chain=True
        )

        summary = execute_automatic_lifecycle_transitions(now=now, actor_user=self.superuser)
        el.refresh_from_db()

        self.assertEqual(el.status, 'SCHEDULED')
        self.assertEqual(len(summary['activated']), 0)

    # 2. Scheduled election activates when start time arrives
    def test_02_scheduled_election_activates_when_start_time_arrives(self):
        now = timezone.now()
        start = now - timedelta(minutes=5)
        end = now + timedelta(hours=4)
        el = Election.objects.create(
            title='Due Scheduled Election',
            election_id=8202,
            commencement_mode='SCHEDULED',
            status='SCHEDULED',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=start,
            end_datetime=end,
        )
        Candidate.objects.create(
            election=el, candidate_id_num=1, name='Candidate A', symbol='A', is_active=True, is_synced_on_chain=True
        )

        mock_w3, mock_contract = self._make_mock_web3(
            initial_open=False,
            start_ts=int(start.timestamp()),
            end_ts=int(end.timestamp()),
        )
        # After setElectionOpen(True) on chain, electionOpen returns True
        mock_contract.functions.electionOpen.return_value.call.side_effect = [False, True, True, True]

        with patch('EVotingApp.services.get_web3_provider', return_value=mock_w3), \
             patch('EVotingApp.services.inspect_deployed_contract', return_value={'has_code': True, 'is_compatible': True}):
            summary = execute_automatic_lifecycle_transitions(now=now, actor_user=self.superuser)

        el.refresh_from_db()
        self.assertEqual(el.status, 'ACTIVE')
        self.assertTrue(any(a['election_id'] == 8202 for a in summary['activated']))

    # 3. Scheduled election preserves configured start/end datetimes
    def test_03_scheduled_election_preserves_configured_start_and_end_datetimes(self):
        now = timezone.now()
        configured_start = now - timedelta(minutes=15)
        configured_end = now + timedelta(hours=6)
        el = Election.objects.create(
            title='Preserve Timestamps Election',
            election_id=8203,
            commencement_mode='SCHEDULED',
            status='SCHEDULED',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=configured_start,
            end_datetime=configured_end,
        )
        Candidate.objects.create(
            election=el, candidate_id_num=1, name='Candidate A', symbol='A', is_active=True, is_synced_on_chain=True
        )

        mock_w3, mock_contract = self._make_mock_web3(
            initial_open=False,
            start_ts=int(configured_start.timestamp()),
            end_ts=int(configured_end.timestamp()),
        )
        mock_contract.functions.electionOpen.return_value.call.side_effect = [False, True, True, True]

        with patch('EVotingApp.services.get_web3_provider', return_value=mock_w3), \
             patch('EVotingApp.services.inspect_deployed_contract', return_value={'has_code': True, 'is_compatible': True}):
            execute_automatic_lifecycle_transitions(now=now, actor_user=self.superuser)

        el.refresh_from_db()
        self.assertEqual(el.status, 'ACTIVE')
        # Crucial: start_datetime must be the configured_start, not now
        self.assertEqual(int(el.start_datetime.timestamp()), int(configured_start.timestamp()))
        self.assertEqual(int(el.end_datetime.timestamp()), int(configured_end.timestamp()))

    # 4. Election with incomplete readiness is not activated
    def test_04_election_with_incomplete_readiness_is_not_activated(self):
        now = timezone.now()
        el = Election.objects.create(
            title='Incomplete Readiness Election',
            election_id=8204,
            commencement_mode='SCHEDULED',
            status='SCHEDULED',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=False,  # Unlocked roster!
            start_datetime=now - timedelta(minutes=5),
            end_datetime=now + timedelta(hours=3),
        )
        Candidate.objects.create(
            election=el, candidate_id_num=1, name='Candidate A', symbol='A', is_active=True, is_synced_on_chain=False
        )

        summary = execute_automatic_lifecycle_transitions(now=now, actor_user=self.superuser)
        el.refresh_from_db()

        self.assertEqual(el.status, 'SCHEDULED')
        self.assertIn('Candidate roster is not locked on-chain', el.auto_transition_last_error)
        self.assertTrue(any(s['election_id'] == 8204 for s in summary['skipped']))
        self.assertTrue(AdminAuditLog.objects.filter(action='AUTO_ACTIVATION_SKIPPED', target_id=str(el.pk)).exists())

    # 5. Immediate election is not automatically activated
    def test_05_immediate_election_is_not_automatically_activated(self):
        now = timezone.now()
        el = Election.objects.create(
            title='Immediate Election Must Not Auto Activate',
            election_id=8205,
            commencement_mode='IMMEDIATE',
            immediate_duration_hours=6,
            status='SCHEDULED',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=None,
            end_datetime=None,
        )
        Candidate.objects.create(
            election=el, candidate_id_num=1, name='Candidate A', symbol='A', is_active=True, is_synced_on_chain=True
        )

        summary = execute_automatic_lifecycle_transitions(now=now, actor_user=self.superuser)
        el.refresh_from_db()

        self.assertEqual(el.status, 'SCHEDULED')
        self.assertFalse(any(a['election_id'] == 8205 for a in summary['activated']))

    # 6. Immediate election closes after configured duration expires
    def test_06_immediate_election_closes_after_configured_duration_expires(self):
        now = timezone.now()
        start = now - timedelta(hours=4, minutes=1)
        end = now - timedelta(minutes=1)
        el = Election.objects.create(
            title='Expired Immediate Election',
            election_id=8206,
            commencement_mode='IMMEDIATE',
            immediate_duration_hours=4,
            status='ACTIVE',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=start,
            end_datetime=end,
        )

        mock_w3, mock_contract = self._make_mock_web3(initial_open=True)

        with patch('EVotingApp.services.get_web3_provider', return_value=mock_w3), \
             patch('EVotingApp.services.inspect_deployed_contract', return_value={'has_code': True, 'is_compatible': True}):
            summary = execute_automatic_lifecycle_transitions(now=now, actor_user=self.superuser)

        el.refresh_from_db()
        self.assertEqual(el.status, 'CLOSED')
        self.assertTrue(any(c['election_id'] == 8206 for c in summary['closed']))

    # 7. Scheduled election closes after configured end time
    def test_07_scheduled_election_closes_after_configured_end_time(self):
        now = timezone.now()
        el = Election.objects.create(
            title='Expired Scheduled Election',
            election_id=8207,
            commencement_mode='SCHEDULED',
            status='ACTIVE',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=now - timedelta(days=2),
            end_datetime=now - timedelta(minutes=10),
        )

        mock_w3, mock_contract = self._make_mock_web3(initial_open=True)

        with patch('EVotingApp.services.get_web3_provider', return_value=mock_w3), \
             patch('EVotingApp.services.inspect_deployed_contract', return_value={'has_code': True, 'is_compatible': True}):
            summary = execute_automatic_lifecycle_transitions(now=now, actor_user=self.superuser)

        el.refresh_from_db()
        self.assertEqual(el.status, 'CLOSED')
        self.assertTrue(any(c['election_id'] == 8207 for c in summary['closed']))

    # 8. Election cannot be closed prematurely
    def test_08_election_cannot_be_closed_prematurely(self):
        now = timezone.now()
        el = Election.objects.create(
            title='Ongoing Active Election',
            election_id=8208,
            commencement_mode='SCHEDULED',
            status='ACTIVE',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=now - timedelta(hours=2),
            end_datetime=now + timedelta(hours=4),
        )

        summary = execute_automatic_lifecycle_transitions(now=now, actor_user=self.superuser)
        el.refresh_from_db()

        self.assertEqual(el.status, 'ACTIVE')
        self.assertFalse(any(c['election_id'] == 8208 for c in summary['closed']))

    # 9. Duplicate scheduler executions do not duplicate lifecycle transactions
    def test_09_duplicate_scheduler_executions_do_not_duplicate_transactions(self):
        now = timezone.now()
        el = Election.objects.create(
            title='Idempotency Election',
            election_id=8209,
            commencement_mode='SCHEDULED',
            status='ACTIVE',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=now - timedelta(days=1),
            end_datetime=now - timedelta(minutes=5),
        )

        mock_w3, mock_contract = self._make_mock_web3(initial_open=True)

        with patch('EVotingApp.services.get_web3_provider', return_value=mock_w3), \
             patch('EVotingApp.services.inspect_deployed_contract', return_value={'has_code': True, 'is_compatible': True}):
            summary1 = execute_automatic_lifecycle_transitions(now=now, actor_user=self.superuser)
            summary2 = execute_automatic_lifecycle_transitions(now=now, actor_user=self.superuser)

        el.refresh_from_db()
        self.assertEqual(el.status, 'CLOSED')
        self.assertEqual(len(summary1['closed']), 1)
        self.assertEqual(len(summary2['closed']), 0)
        self.assertEqual(len(summary2['activated']), 0)

    # 10. Concurrent scheduler processes cannot activate or close the same election twice
    def test_10_concurrent_scheduler_processes_respect_in_progress_lock(self):
        now = timezone.now()
        el = Election.objects.create(
            title='Locked In Progress Election',
            election_id=8210,
            commencement_mode='SCHEDULED',
            status='SCHEDULED',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=now - timedelta(minutes=5),
            end_datetime=now + timedelta(hours=3),
            auto_transition_in_progress=True,
            auto_transition_last_attempt_at=now - timedelta(seconds=15),
            auto_transition_last_action='ACTIVATION',
        )

        summary = execute_automatic_lifecycle_transitions(now=now, actor_user=self.superuser)
        el.refresh_from_db()

        self.assertEqual(el.status, 'SCHEDULED')
        self.assertTrue(any(s['election_id'] == 8210 and 'lock active' in s['reason'].lower() for s in summary['skipped']))

    # 11. RPC failures do not incorrectly change database status
    def test_11_rpc_failure_does_not_corrupt_database_status(self):
        now = timezone.now()
        el = Election.objects.create(
            title='Failing RPC Election',
            election_id=8211,
            commencement_mode='SCHEDULED',
            status='SCHEDULED',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=now - timedelta(minutes=5),
            end_datetime=now + timedelta(hours=2),
        )
        Candidate.objects.create(
            election=el, candidate_id_num=1, name='Candidate A', symbol='A', is_active=True, is_synced_on_chain=True
        )

        mock_w3, mock_contract = self._make_mock_web3(initial_open=False)

        with patch('EVotingApp.services.get_web3_provider', return_value=mock_w3), \
             patch('EVotingApp.services.inspect_deployed_contract', return_value={'has_code': True, 'is_compatible': True}), \
             patch('EVotingApp.services.activate_election', side_effect=BlockchainDeploymentError("RPC Connection Timeout")):
            summary = execute_automatic_lifecycle_transitions(now=now, actor_user=self.superuser)

        el.refresh_from_db()
        self.assertEqual(el.status, 'SCHEDULED')
        self.assertFalse(el.auto_transition_in_progress)
        self.assertIn("RPC Connection Timeout", el.auto_transition_last_error)
        self.assertTrue(AdminAuditLog.objects.filter(action='AUTO_ACTIVATION_FAILED', target_id=str(el.pk)).exists())

    # 12. Safe on-chain reconciliation for unconfirmed transactions
    def test_12_safe_onchain_reconciliation_for_unconfirmed_transactions(self):
        now = timezone.now()
        start = now - timedelta(minutes=10)
        end = now + timedelta(hours=5)
        el = Election.objects.create(
            title='Reconciliation Election',
            election_id=8212,
            commencement_mode='SCHEDULED',
            status='SCHEDULED',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=start,
            end_datetime=end,
        )
        Candidate.objects.create(
            election=el, candidate_id_num=1, name='Candidate A', symbol='A', is_active=True, is_synced_on_chain=True
        )

        # On-chain electionOpen is already True!
        mock_w3, mock_contract = self._make_mock_web3(
            initial_open=True,
            start_ts=int(start.timestamp()),
            end_ts=int(end.timestamp()),
        )

        with patch('EVotingApp.services.get_web3_provider', return_value=mock_w3), \
             patch('EVotingApp.services.inspect_deployed_contract', return_value={'has_code': True, 'is_compatible': True}):
            summary = execute_automatic_lifecycle_transitions(now=now, actor_user=self.superuser)

        el.refresh_from_db()
        self.assertEqual(el.status, 'ACTIVE')
        self.assertTrue(AdminAuditLog.objects.filter(action='AUTO_ACTIVATION_RECONCILED', target_id=str(el.pk)).exists())
        self.assertTrue(any(a['election_id'] == 8212 and a.get('reconciled') for a in summary['activated']))

    # 13. Scheduler restart recovers overdue transitions
    def test_13_scheduler_restart_recovers_overdue_transitions(self):
        now = timezone.now()
        # Election was active and deadline passed 3 hours ago while scheduler was offline
        el = Election.objects.create(
            title='Overdue Closing Election',
            election_id=8213,
            commencement_mode='SCHEDULED',
            status='ACTIVE',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=now - timedelta(days=1),
            end_datetime=now - timedelta(hours=3),
        )

        mock_w3, mock_contract = self._make_mock_web3(initial_open=True)

        with patch('EVotingApp.services.get_web3_provider', return_value=mock_w3), \
             patch('EVotingApp.services.inspect_deployed_contract', return_value={'has_code': True, 'is_compatible': True}):
            summary = execute_automatic_lifecycle_transitions(now=now, actor_user=self.superuser)

        el.refresh_from_db()
        self.assertEqual(el.status, 'CLOSED')
        self.assertTrue(any(c['election_id'] == 8213 for c in summary['closed']))

    # 14. Audit logs accurately record successful and failed transitions
    def test_14_audit_logs_record_lifecycle_events(self):
        now = timezone.now()
        el = Election.objects.create(
            title='Audit Recording Election',
            election_id=8214,
            commencement_mode='SCHEDULED',
            status='ACTIVE',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=now - timedelta(days=1),
            end_datetime=now - timedelta(minutes=1),
        )

        mock_w3, mock_contract = self._make_mock_web3(initial_open=True)

        with patch('EVotingApp.services.get_web3_provider', return_value=mock_w3), \
             patch('EVotingApp.services.inspect_deployed_contract', return_value={'has_code': True, 'is_compatible': True}):
            execute_automatic_lifecycle_transitions(now=now, actor_user=self.superuser)

        log = AdminAuditLog.objects.filter(action='AUTO_CLOSING_SUCCESS', target_id=str(el.pk)).first()
        self.assertIsNotNone(log)
        details = json.loads(log.details)
        self.assertEqual(details['election_id'], 8214)
        self.assertEqual(details['status'], 'CLOSED')

    # 15. Existing manual activation and closing workflows continue to work
    def test_15_manual_activation_and_closing_workflows_continue_to_work(self):
        now = timezone.now()
        start = now - timedelta(minutes=1)
        end = now + timedelta(hours=3)
        el = Election.objects.create(
            title='Manual Workflow Election',
            election_id=8215,
            commencement_mode='SCHEDULED',
            status='SCHEDULED',
            deployment_status='DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            candidates_locked_on_chain=True,
            start_datetime=start,
            end_datetime=end,
        )
        Candidate.objects.create(
            election=el, candidate_id_num=1, name='Candidate A', symbol='A', is_active=True, is_synced_on_chain=True
        )

        mock_w3, mock_contract = self._make_mock_web3(
            initial_open=True,
            start_ts=int(start.timestamp()),
            end_ts=int(end.timestamp()),
        )
        mock_contract.functions.electionOpen.return_value.call.side_effect = [True, True, True, True]

        with patch('EVotingApp.services.get_web3_provider', return_value=mock_w3), \
             patch('EVotingApp.services.inspect_deployed_contract', return_value={'has_code': True, 'is_compatible': True}):
            activated = activate_election(el.pk, actor_user=self.superuser)
            self.assertEqual(activated.status, 'ACTIVE')

            closed = close_election(el.pk, actor_user=self.superuser)
            self.assertEqual(closed.status, 'CLOSED')

        el.refresh_from_db()
        self.assertEqual(el.status, 'CLOSED')


class Module8Phase7DeploymentReadinessTests(TestCase):
    """
    Module 8 — Phase 7: Django Deployment Preparation Tests.
    Covers all 12 testing requirements:
    1. Production settings validation.
    2. Missing or invalid production secrets.
    3. Environment-based database selection.
    4. SQLite development compatibility.
    5. PostgreSQL configuration parsing.
    6. Static asset collection.
    7. Application startup and WSGI configuration.
    8. Health-check behavior.
    9. Blockchain configuration validation.
    10. Private-key confidentiality.
    11. Superuser initialization idempotency.
    12. Existing authentication and RBAC compatibility.
    """

    def setUp(self):
        self.client = Client()
        # Generate a fresh non-Hardhat secp256k1 private key for production configuration tests
        self.prod_priv_key = '0x' + ('9a' * 32)
        from eth_account import Account
        self.prod_auth_addr = Account.from_key(self.prod_priv_key).address
        self.valid_prod_env = {
            'DJANGO_ENV': 'production',
            'DJANGO_DEBUG': 'False',
            'DJANGO_SECRET_KEY': 'p9$kL!8vQz#2mXrT5wYnB7jC4fH6gD1sA0eR3uI8oP5lK2jM9n',
            'DJANGO_ALLOWED_HOSTS': 'dvs-app.run.app,elections.example.org',
            'DJANGO_CSRF_TRUSTED_ORIGINS': 'https://dvs-app.run.app,https://elections.example.org',
            'WEB3_RPC_URL': 'https://hardhat-rpc.example.org:8545',
            'CHAIN_ID': '31337',
            'CONTRACT_ADDRESS': '0x5FbDB2315678afecb367f032d93F642f64180aa3',
            'ELECTION_AUTHORITY_PRIVATE_KEY': self.prod_priv_key,
            'ELECTION_AUTHORITY_ADDRESS': self.prod_auth_addr,
            'ELECTION_NULLIFIER_PEPPER': 'prod-high-entropy-nullifier-pepper-9876543210',
            'ONBOARDING_ENCRYPTION_KEY': 'prod-high-entropy-onboarding-key-9876543210',
            'PROVIDER_REFERENCE_SALT': 'prod-high-entropy-provider-salt-9876543210',
        }

    # 1. Production settings validation
    def test_01_production_settings_validation(self):
        from EVoting.settings import validate_and_load_settings

        cfg = validate_and_load_settings(self.valid_prod_env)
        self.assertTrue(cfg['IS_PRODUCTION'])
        self.assertFalse(cfg['DEBUG'])
        self.assertEqual(cfg['ALLOWED_HOSTS'], ['dvs-app.run.app', 'elections.example.org'])
        self.assertEqual(cfg['CSRF_TRUSTED_ORIGINS'], ['https://dvs-app.run.app', 'https://elections.example.org'])
        self.assertTrue(cfg['SESSION_COOKIE_SECURE'])
        self.assertTrue(cfg['CSRF_COOKIE_SECURE'])
        self.assertTrue(cfg['SESSION_COOKIE_HTTPONLY'])
        self.assertEqual(cfg['SECURE_PROXY_SSL_HEADER'], ('HTTP_X_FORWARDED_PROTO', 'https'))
        self.assertTrue(cfg['USE_X_FORWARDED_HOST'])
        self.assertEqual(cfg['ELECTION_AUTHORITY_ADDRESS'], self.prod_auth_addr)

    # 2. Missing or invalid production secrets
    def test_02_missing_or_invalid_production_secrets_rejected(self):
        from django.core.exceptions import ImproperlyConfigured
        from EVoting.settings import (
            validate_and_load_settings,
            DEV_DEFAULT_SECRET_KEY,
            DEV_DEFAULT_AUTHORITY_PRIVATE_KEY,
            DEV_DEFAULT_NULLIFIER_PEPPER,
        )

        # DEBUG=True with DJANGO_ENV=production must fail
        env_debug = dict(self.valid_prod_env, DJANGO_DEBUG='True')
        with self.assertRaises(ImproperlyConfigured):
            validate_and_load_settings(env_debug)

        # Missing DJANGO_SECRET_KEY in production must fail
        env_no_secret = dict(self.valid_prod_env)
        del env_no_secret['DJANGO_SECRET_KEY']
        with self.assertRaises(ImproperlyConfigured):
            validate_and_load_settings(env_no_secret)

        # Default development secret key in production must fail
        env_dev_secret = dict(self.valid_prod_env, DJANGO_SECRET_KEY=DEV_DEFAULT_SECRET_KEY)
        with self.assertRaises(ImproperlyConfigured):
            validate_and_load_settings(env_dev_secret)

        # Missing ALLOWED_HOSTS or wildcard '*' in production must fail
        env_no_hosts = dict(self.valid_prod_env, DJANGO_ALLOWED_HOSTS='')
        with self.assertRaises(ImproperlyConfigured):
            validate_and_load_settings(env_no_hosts)

        env_wildcard_hosts = dict(self.valid_prod_env, DJANGO_ALLOWED_HOSTS='*')
        with self.assertRaises(ImproperlyConfigured):
            validate_and_load_settings(env_wildcard_hosts)

        # HTTP origin in CSRF_TRUSTED_ORIGINS in production must fail
        env_http_csrf = dict(self.valid_prod_env, DJANGO_CSRF_TRUSTED_ORIGINS='http://dvs-app.run.app')
        with self.assertRaises(ImproperlyConfigured):
            validate_and_load_settings(env_http_csrf)

        # Known Hardhat development authority private key in production must fail
        env_dev_privkey = dict(self.valid_prod_env, ELECTION_AUTHORITY_PRIVATE_KEY=DEV_DEFAULT_AUTHORITY_PRIVATE_KEY)
        with self.assertRaises(ImproperlyConfigured):
            validate_and_load_settings(env_dev_privkey)

        # Default nullifier pepper in production must fail
        env_dev_pepper = dict(self.valid_prod_env, ELECTION_NULLIFIER_PEPPER=DEV_DEFAULT_NULLIFIER_PEPPER)
        with self.assertRaises(ImproperlyConfigured):
            validate_and_load_settings(env_dev_pepper)

    # 3. Environment-based database selection
    def test_03_environment_based_database_selection(self):
        from EVoting.settings import parse_database_configuration

        sqlite_cfg = parse_database_configuration({'DB_ENGINE': 'sqlite3'})
        self.assertEqual(sqlite_cfg['default']['ENGINE'], 'django.db.backends.sqlite3')

        pg_cfg = parse_database_configuration({
            'DB_ENGINE': 'postgresql',
            'DB_NAME': 'dvs_prod',
            'DB_USER': 'dvs_user',
            'DB_PASSWORD': 'secret_db_password',
            'DB_HOST': '10.1.2.3',
            'DB_PORT': '5432',
        })
        self.assertEqual(pg_cfg['default']['ENGINE'], 'django.db.backends.postgresql')
        self.assertEqual(pg_cfg['default']['NAME'], 'dvs_prod')
        self.assertEqual(pg_cfg['default']['USER'], 'dvs_user')
        self.assertEqual(pg_cfg['default']['HOST'], '10.1.2.3')
        self.assertEqual(pg_cfg['default']['PORT'], '5432')

    # 4. SQLite development compatibility
    def test_04_sqlite_development_compatibility(self):
        from EVoting.settings import validate_and_load_settings

        dev_cfg = validate_and_load_settings({})
        self.assertFalse(dev_cfg['IS_PRODUCTION'])
        self.assertTrue(dev_cfg['DEBUG'])
        self.assertEqual(dev_cfg['DATABASES']['default']['ENGINE'], 'django.db.backends.sqlite3')
        self.assertTrue(str(dev_cfg['DATABASES']['default']['NAME']).endswith('db.sqlite3'))

    # 5. PostgreSQL configuration parsing (DATABASE_URL, Cloud SQL Unix socket, validation)
    def test_05_postgresql_configuration_parsing(self):
        from django.core.exceptions import ImproperlyConfigured
        from EVoting.settings import parse_database_configuration

        # Standard TCP DATABASE_URL
        url_cfg = parse_database_configuration({
            'DATABASE_URL': 'postgresql://dvs_admin:p%40ssword@db.internal:5433/dvs_cloud?sslmode=require'
        })
        default_db = url_cfg['default']
        self.assertEqual(default_db['ENGINE'], 'django.db.backends.postgresql')
        self.assertEqual(default_db['NAME'], 'dvs_cloud')
        self.assertEqual(default_db['USER'], 'dvs_admin')
        self.assertEqual(default_db['PASSWORD'], 'p@ssword')
        self.assertEqual(default_db['HOST'], 'db.internal')
        self.assertEqual(default_db['PORT'], '5433')
        self.assertEqual(default_db['OPTIONS'].get('sslmode'), 'require')

        # Cloud SQL Unix socket via DATABASE_URL query param
        socket_cfg = parse_database_configuration({
            'DATABASE_URL': 'postgresql://dvs_admin:secret@/dvs_cloud?host=/cloudsql/my-proj:asia-south1:dvs-pg'
        })
        self.assertEqual(socket_cfg['default']['HOST'], '/cloudsql/my-proj:asia-south1:dvs-pg')
        self.assertEqual(socket_cfg['default']['PORT'], '')

        # Missing DB_NAME or DB_USER raises ImproperlyConfigured
        with self.assertRaises(ImproperlyConfigured):
            parse_database_configuration({'DB_ENGINE': 'postgresql', 'DB_USER': 'dvs_user'})
        with self.assertRaises(ImproperlyConfigured):
            parse_database_configuration({'DB_ENGINE': 'postgresql', 'DB_NAME': 'dvs_db'})

    # 6. Static asset collection
    def test_06_static_asset_collection(self):
        import os
        from django.conf import settings
        from django.core.management import call_command

        call_command('collectstatic', interactive=False, verbosity=0)
        collected_js = os.path.join(settings.STATIC_ROOT, 'control-portal.js')
        collected_css = os.path.join(settings.STATIC_ROOT, 'default.css')
        collected_mm = os.path.join(settings.STATIC_ROOT, 'metamask.js')
        self.assertTrue(os.path.exists(collected_js))
        self.assertTrue(os.path.exists(collected_css))
        self.assertTrue(os.path.exists(collected_mm))

    # 7. Application startup and WSGI configuration
    def test_07_application_startup_and_wsgi_configuration(self):
        import os
        from django.conf import settings
        from EVoting.wsgi import application

        self.assertTrue(callable(application))
        self.assertEqual(settings.WSGI_APPLICATION, 'EVoting.wsgi.application')
        prod_script = os.path.join(settings.BASE_DIR, 'start_prod.sh')
        self.assertTrue(os.path.exists(prod_script))
        with open(prod_script, 'r') as f:
            script_content = f.read()
        self.assertIn('gunicorn EVoting.wsgi:application', script_content)
        self.assertNotIn('manage.py runserver', script_content)

    # 8. Health-check behavior (distinguishes app health from temporary RPC outage)
    def test_08_health_check_behavior(self):
        # Healthy when RPC is connected
        mock_w3_up = MagicMock()
        mock_w3_up.is_connected.return_value = True
        with patch('EVotingApp.services.get_web3_provider', return_value=mock_w3_up):
            res_up = self.client.get('/healthz/')
            self.assertEqual(res_up.status_code, 200)
            data_up = res_up.json()
            self.assertEqual(data_up['status'], 'ok')
            self.assertEqual(data_up['database']['status'], 'ok')
            self.assertEqual(data_up['blockchain']['status'], 'connected')

        # Still returns 200 OK for application health when blockchain RPC is temporarily unreachable
        mock_w3_down = MagicMock()
        mock_w3_down.is_connected.return_value = False
        with patch('EVotingApp.services.get_web3_provider', return_value=mock_w3_down):
            res_down = self.client.get('/api/health/')
            self.assertEqual(res_down.status_code, 200)
            data_down = res_down.json()
            self.assertEqual(data_down['status'], 'ok')
            self.assertEqual(data_down['database']['status'], 'ok')
            self.assertEqual(data_down['blockchain']['status'], 'unavailable')
            self.assertFalse(data_down['blockchain']['reachable'])

    # 9. Blockchain configuration validation
    def test_09_blockchain_configuration_validation(self):
        from EVotingApp.services import validate_blockchain_configuration, BlockchainDeploymentError

        valid_res = validate_blockchain_configuration(
            config_override=self.valid_prod_env,
            is_production=True,
        )
        self.assertTrue(valid_res['valid'])
        self.assertEqual(valid_res['authority_address'], self.prod_auth_addr)
        self.assertTrue(valid_res['artifact_loaded'])

        # Rejects 127.0.0.1 in production
        bad_rpc = dict(self.valid_prod_env, WEB3_RPC_URL='http://127.0.0.1:8545')
        with self.assertRaises(BlockchainDeploymentError):
            validate_blockchain_configuration(config_override=bad_rpc, is_production=True)

        # Rejects mismatched ELECTION_AUTHORITY_ADDRESS
        mismatched_addr = dict(
            self.valid_prod_env,
            ELECTION_AUTHORITY_ADDRESS='0x000000000000000000000000000000000000dead',
        )
        with self.assertRaises(BlockchainDeploymentError):
            validate_blockchain_configuration(config_override=mismatched_addr, is_production=True)

    # 10. Private-key confidentiality across health checks, logs, and errors
    def test_10_private_key_confidentiality(self):
        import logging
        from django.conf import settings
        from EVoting.settings import RedactSecretsFilter
        from EVotingApp.services import validate_blockchain_configuration, BlockchainDeploymentError

        # Health check must never contain any private key, secret key, or nullifier pepper
        res = self.client.get('/healthz/')
        raw_body = res.content.decode('utf-8')
        self.assertNotIn(settings.ELECTION_AUTHORITY_PRIVATE_KEY, raw_body)
        self.assertNotIn(settings.SECRET_KEY, raw_body)
        self.assertNotIn(settings.ELECTION_NULLIFIER_PEPPER, raw_body)

        # Validation error must never echo the invalid or valid private key material
        invalid_key = '0x' + ('ff' * 31) + 'zz'
        try:
            validate_blockchain_configuration(
                config_override={'ELECTION_AUTHORITY_PRIVATE_KEY': invalid_key},
                is_production=False,
            )
        except BlockchainDeploymentError as e:
            self.assertNotIn(invalid_key, str(e))

        # Logging filter must redact 32-byte hex private keys
        log_filter = RedactSecretsFilter()
        record = logging.LogRecord(
            name='EVotingApp',
            level=logging.ERROR,
            pathname=__file__,
            lineno=1,
            msg=f"Signing error with key {self.prod_priv_key}",
            args=(),
            exc_info=None,
        )
        log_filter.filter(record)
        self.assertNotIn(self.prod_priv_key, record.msg)
        self.assertIn('[REDACTED_PRIVATE_KEY]', record.msg)

    # 11. Superuser initialization idempotency
    def test_11_superuser_initialization_idempotency(self):
        from EVotingApp.services import initialize_system_superuser

        env_vars = {
            'DJANGO_SUPERUSER_USERNAME': 'cloud_superadmin',
            'DJANGO_SUPERUSER_EMAIL': 'cloud_superadmin@example.org',
            'DJANGO_SUPERUSER_PASSWORD': 'InitialStrongPassword!2026',
        }

        # First call creates the superuser and assigns 'Super Admin' group
        res1 = initialize_system_superuser(env=env_vars, strict=True)
        self.assertEqual(res1['status'], 'CREATED')
        self.assertTrue(res1['created'])
        self.assertNotIn('InitialStrongPassword!2026', json.dumps(res1))

        user = User.objects.get(username='cloud_superadmin')
        self.assertTrue(user.is_superuser)
        self.assertTrue(user.groups.filter(name='Super Admin').exists())
        self.assertTrue(user.check_password('InitialStrongPassword!2026'))

        # Second call with a DIFFERENT password in env must NOT overwrite existing password
        env_vars_changed = dict(env_vars, DJANGO_SUPERUSER_PASSWORD='AttemptedOverwritePassword!999')
        res2 = initialize_system_superuser(env=env_vars_changed, strict=True)
        self.assertEqual(res2['status'], 'ALREADY_EXISTS')
        self.assertFalse(res2['created'])
        self.assertFalse(res2['password_modified'])

        user.refresh_from_db()
        self.assertTrue(user.check_password('InitialStrongPassword!2026'))
        self.assertFalse(user.check_password('AttemptedOverwritePassword!999'))

        # Missing configuration with strict=False skips safely
        res_skip = initialize_system_superuser(env={}, strict=False)
        self.assertEqual(res_skip['status'], 'SKIPPED_MISSING_CONFIG')
        self.assertFalse(res_skip['created'])

    # 12. Existing authentication and RBAC compatibility
    def test_12_existing_authentication_and_rbac_compatibility(self):
        from EVotingApp.services import initialize_system_superuser
        from EVotingApp.decorators import get_user_portal_role

        env_vars = {
            'DJANGO_SUPERUSER_USERNAME': 'rbac_root_admin',
            'DJANGO_SUPERUSER_EMAIL': 'rbac_root@example.org',
            'DJANGO_SUPERUSER_PASSWORD': 'RbacRootPassword!2026',
        }
        initialize_system_superuser(env=env_vars, strict=True)
        user = User.objects.get(username='rbac_root_admin')
        self.assertEqual(get_user_portal_role(user), 'SUPER_ADMIN')

        # Verify login via AdminLogin and access to /control/ and /api/control/staff/
        login_res = self.client.post('/AdminLogin', {
            'username': 'rbac_root_admin',
            'password': 'RbacRootPassword!2026',
        })
        self.assertEqual(login_res.status_code, 200)

        staff_res = self.client.get('/api/control/staff/')
        self.assertEqual(staff_res.status_code, 200)
        staff_data = staff_res.json()
        self.assertTrue(any(s['username'] == 'rbac_root_admin' and s['portal_role'] == 'SUPER_ADMIN' for s in staff_data['staff']))


class Module8Phase8HardhatDemoEnvironmentTests(TestCase):
    """
    Module 8 — Phase 8: Hardhat Demonstration Environment Tests.
    Covers all 12 verification requirements:
    1. Hardhat node startup.
    2. Chain ID verification (31337).
    3. RPC connectivity.
    4. Demonstration account availability and balances.
    5. Contract compilation.
    6. Contract deployment.
    7. Deployed bytecode verification.
    8. Contract initial state.
    9. Deployment metadata generation (and private key exclusion).
    10. Restart and redeployment procedure.
    11. RPC access restrictions (blocking admin/debug methods & CORS validation).
    12. Existing local development compatibility.
    """

    def setUp(self):
        import tempfile
        import shutil
        self.temp_dir = tempfile.mkdtemp(prefix='dvs_phase8_test_')
        self.addCleanup(lambda: shutil.rmtree(self.temp_dir, ignore_errors=True))

    # 1. Hardhat node startup & operational control script verification
    def test_01_hardhat_node_startup_and_control_assets(self):
        import os
        from django.conf import settings

        ctl_script = os.path.join(settings.BASE_DIR, 'scripts', 'hardhat_demo_ctl.sh')
        gateway_script = os.path.join(settings.BASE_DIR, 'scripts', 'hardhat_rpc_gateway.py')
        dockerfile_path = os.path.join(settings.BASE_DIR, 'deploy', 'hardhat_demo', 'Dockerfile.hardhat')
        hardhat_cfg = os.path.join(settings.BASE_DIR, 'hardhat.config.ts')

        self.assertTrue(os.path.exists(ctl_script))
        self.assertTrue(os.path.exists(gateway_script))
        self.assertTrue(os.path.exists(dockerfile_path))
        self.assertTrue(os.path.exists(hardhat_cfg))

        with open(hardhat_cfg, 'r', encoding='utf-8') as f:
            cfg_content = f.read()
        self.assertIn('0.8.28', cfg_content)
        self.assertIn('31337', cfg_content)
        self.assertIn('hardhatDemo', cfg_content)

    # 2. Chain ID verification (31337) and rejection of wrong Chain ID
    def test_02_chain_id_verification(self):
        from EVotingApp.hardhat_demo import (
            DEMO_CHAIN_ID,
            verify_demo_network_and_accounts,
        )

        self.assertEqual(DEMO_CHAIN_ID, 31337)
        res = verify_demo_network_and_accounts()
        self.assertEqual(res['chain_id'], 31337)
        self.assertEqual(res['chain_id_hex'], '0x7a69')

        # Wrong chain ID must be rejected
        bad_w3 = MagicMock()
        bad_w3.is_connected.return_value = True
        bad_w3.eth.chain_id = 1  # Mainnet Chain ID must be rejected
        with self.assertRaises(BlockchainDeploymentError) as ctx:
            verify_demo_network_and_accounts(w3_instance=bad_w3)
        self.assertIn('31337', str(ctx.exception))

    # 3. RPC connectivity and credential-free endpoint sanitization
    def test_03_rpc_connectivity_and_sanitization(self):
        from EVotingApp.hardhat_demo import get_demo_web3, verify_demo_network_and_accounts

        w3, url = get_demo_web3('http://127.0.0.1:8545')
        self.assertTrue(w3.is_connected())

        status = verify_demo_network_and_accounts(
            rpc_url='https://demo_user:secret_pass@hardhat-demo.example.org:8545/v1/secret-token',
            w3_instance=w3,
        )
        self.assertEqual(status['rpc_endpoint'], 'https://hardhat-demo.example.org:8545')
        self.assertNotIn('secret_pass', status['rpc_endpoint'])
        self.assertNotIn('secret-token', status['rpc_endpoint'])

    # 4. Demonstration account availability, test ETH balances, and role separation
    def test_04_demonstration_account_availability_and_balances(self):
        from EVotingApp.hardhat_demo import (
            verify_demo_network_and_accounts,
            DEMO_DEPLOYER_ADDRESS,
        )

        status = verify_demo_network_and_accounts()
        self.assertEqual(status['deployer']['address'], DEMO_DEPLOYER_ADDRESS)
        self.assertTrue(status['deployer']['funded'])
        self.assertGreater(status['deployer']['balance_wei'], 10**18)

        # Election Authority must be distinct from Deployer
        self.assertTrue(status['election_authority']['distinct_from_deployer'])
        self.assertNotEqual(
            status['deployer']['address'].lower(),
            status['election_authority']['address'].lower(),
        )

        # Pre-funded synthetic voter accounts must have test ETH
        self.assertGreaterEqual(len(status['demo_voters']), 4)
        for voter_acc in status['demo_voters']:
            self.assertTrue(voter_acc['funded'])
            self.assertGreater(voter_acc['balance_wei'], 100 * 10**18)

    # 5. Contract compilation & artifact integrity
    def test_05_contract_compilation_and_artifact_integrity(self):
        from EVotingApp.services import load_contract_artifact

        abi, bytecode, deployed_bytecode = load_contract_artifact()
        self.assertIsInstance(abi, list)
        self.assertTrue(len( bytecode) > 200)
        self.assertTrue(len(deployed_bytecode) > 200)

        fn_names = {item.get('name') for item in abi if item.get('type') == 'function'}
        required_fns = {
            'castVoteWithPermit',
            'markVote',
            'addCandidate',
            'lockCandidates',
            'setVotingWindow',
            'setElectionOpen',
            'setElectionAuthority',
            'DOMAIN_SEPARATOR',
            'BALLOT_PERMIT_TYPEHASH',
        }
        self.assertTrue(required_fns.issubset(fn_names))

    # 6. Contract deployment on the demonstration chain
    def test_06_contract_deployment_captures_address_and_tx_hash(self):
        from EVotingApp.hardhat_demo import deploy_demo_evoting_contract

        dep = deploy_demo_evoting_contract(
            election_id=8801,
            base_dir=self.temp_dir,
        )
        self.assertEqual(dep['chain_id'], 31337)
        self.assertTrue(dep['contract_address'].startswith('0x'))
        self.assertEqual(len(dep['contract_address']), 42)
        self.assertTrue(dep['deployment_tx_hash'].startswith('0x'))
        self.assertEqual(len(dep['deployment_tx_hash']), 66)
        self.assertGreaterEqual(dep['deployment_block_number'], 1)
        self.assertEqual(dep['election_id'], 8801)

    # 7. Deployed bytecode verification
    def test_07_deployed_bytecode_verification(self):
        from EVotingApp.hardhat_demo import (
            deploy_demo_evoting_contract,
            verify_deployed_demo_contract,
        )

        dep = deploy_demo_evoting_contract(election_id=8802, base_dir=self.temp_dir)
        ver = verify_deployed_demo_contract(
            contract_address=dep['contract_address'],
            expected_election_id=8802,
            expected_authority_address=dep['election_authority_address'],
            expected_deployer_address=dep['deployer_address'],
        )
        self.assertTrue(ver['verified'])
        self.assertEqual(ver['deployed_bytecode_hash'], dep['deployed_bytecode_hash'])
        self.assertGreater(ver['deployed_bytecode_size'], 500)

        # Non-existent / un-deployed address must fail verification
        with self.assertRaises(BlockchainDeploymentError):
            verify_deployed_demo_contract('0x000000000000000000000000000000000000dead')

    # 8. Contract initial state & EIP-712 domain separator verification
    def test_08_contract_initial_state_and_eip712_parity(self):
        from EVotingApp.hardhat_demo import (
            deploy_demo_evoting_contract,
            compute_expected_eip712_domain_separator,
            compute_expected_ballot_permit_typehash,
        )

        dep = deploy_demo_evoting_contract(election_id=8803, base_dir=self.temp_dir)
        state = dep['contract_state']

        self.assertEqual(state['owner'], dep['deployer_address'])
        self.assertEqual(state['electionAuthority'], dep['election_authority_address'])
        self.assertEqual(state['electionId'], 8803)
        self.assertFalse(state['electionOpen'])
        self.assertFalse(state['candidatesLocked'])
        self.assertFalse(state['votingWindowLocked'])
        self.assertEqual(state['votingStartTime'], 0)
        self.assertEqual(state['votingEndTime'], 0)
        self.assertEqual(state['totalVotes'], 0)
        self.assertEqual(state['candidateCount'], 0)
        self.assertEqual(state['candidateIds'], [])

        expected_dom = compute_expected_eip712_domain_separator(31337, dep['contract_address'])
        self.assertEqual(state['DOMAIN_SEPARATOR'].lower(), expected_dom.lower())
        self.assertEqual(
            state['BALLOT_PERMIT_TYPEHASH'].lower(),
            compute_expected_ballot_permit_typehash().lower(),
        )

    # 9. Deployment metadata generation & strict private key exclusion
    def test_09_deployment_metadata_generation_and_secret_exclusion(self):
        from django.conf import settings
        from EVotingApp.hardhat_demo import (
            deploy_demo_evoting_contract,
            load_demo_deployment_metadata,
            load_demo_deployment_history,
            record_demo_deployment_metadata,
        )

        dep1 = deploy_demo_evoting_contract(election_id=8804, base_dir=self.temp_dir)
        loaded = load_demo_deployment_metadata(base_dir=self.temp_dir)
        self.assertIsNotNone(loaded)

        required_fields = {
            'deployment_id',
            'network_name',
            'chain_id',
            'rpc_endpoint',
            'contract_address',
            'deployment_tx_hash',
            'deployer_address',
            'election_authority_address',
            'deployment_timestamp',
        }
        self.assertTrue(required_fields.issubset(set(loaded.keys())))

        raw_json = json.dumps(loaded)
        self.assertNotIn(settings.ELECTION_AUTHORITY_PRIVATE_KEY, raw_json)
        self.assertNotIn('private_key', raw_json.lower())

        # Attempting to record metadata containing a private_key field must raise BlockchainDeploymentError
        bad_meta = dict(loaded, private_key='0x' + ('ab' * 32))
        with self.assertRaises(BlockchainDeploymentError):
            record_demo_deployment_metadata(bad_meta, base_dir=self.temp_dir)

        # Fresh deployment produces a distinct deployment_id and appends to history
        dep2 = deploy_demo_evoting_contract(election_id=8804, base_dir=self.temp_dir)
        self.assertNotEqual(dep1['deployment_id'], dep2['deployment_id'])
        self.assertNotEqual(dep1['contract_address'], dep2['contract_address'])
        history = load_demo_deployment_history(base_dir=self.temp_dir)
        self.assertEqual(len(history), 2)

    # 10. Restart and redeployment recovery procedure
    def test_10_restart_and_redeployment_procedure(self):
        from EVotingApp.hardhat_demo import (
            deploy_demo_evoting_contract,
            detect_chain_reset_or_missing_contract,
            reinitialize_after_node_restart,
            record_demo_deployment_metadata,
        )

        # Deploy initial contract
        dep1 = deploy_demo_evoting_contract(election_id=8805, base_dir=self.temp_dir)
        check_ok = detect_chain_reset_or_missing_contract(base_dir=self.temp_dir)
        self.assertFalse(check_ok['needs_redeployment'])
        self.assertEqual(check_ok['reason'], 'CONTRACT_ACTIVE_AND_VERIFIED')

        # Simulate node restart / chain wipe by pointing recorded metadata to an address with empty bytecode
        wiped_meta = dict(dep1, contract_address='0x000000000000000000000000000000000000beef')
        record_demo_deployment_metadata(wiped_meta, base_dir=self.temp_dir)

        check_reset = detect_chain_reset_or_missing_contract(base_dir=self.temp_dir)
        self.assertTrue(check_reset['needs_redeployment'])
        self.assertEqual(check_reset['reason'], 'CHAIN_RESET_BYTECODE_MISSING')

        # Run recovery procedure
        recovered = reinitialize_after_node_restart(
            election_id=8805,
            force=False,
            base_dir=self.temp_dir,
        )
        self.assertTrue(recovered['redeployed'])
        self.assertEqual(recovered['reason'], 'CHAIN_RESET_BYTECODE_MISSING')
        self.assertEqual(recovered['previous_contract_address'], '0x000000000000000000000000000000000000beef')
        new_addr = recovered['deployment']['contract_address']
        self.assertNotEqual(new_addr, '0x000000000000000000000000000000000000beef')

        # Subsequent check confirms recovered contract is active
        check_after = detect_chain_reset_or_missing_contract(base_dir=self.temp_dir)
        self.assertFalse(check_after['needs_redeployment'])

    # 11. RPC access restrictions & CORS policy enforcement
    def test_11_rpc_access_restrictions_and_cors_policy(self):
        from EVotingApp.hardhat_demo import evaluate_rpc_request_security

        # Allowed public MetaMask / read methods
        for allowed_method in (
            'eth_chainId',
            'eth_blockNumber',
            'eth_call',
            'eth_sendRawTransaction',
            'eth_getTransactionReceipt',
            'eth_estimateGas',
            'eth_getBalance',
        ):
            res = evaluate_rpc_request_security(
                {'jsonrpc': '2.0', 'method': allowed_method, 'params': [], 'id': 1},
                headers={'Origin': 'https://dvs-app.run.app'},
                allowed_cors_origins=['https://dvs-app.run.app'],
            )
            self.assertTrue(res['allowed'], f"Expected {allowed_method} to be allowed")
            self.assertEqual(
                res['cors_headers'].get('Access-Control-Allow-Origin'),
                'https://dvs-app.run.app',
            )

        # Blocked administrative / debug / state manipulation methods
        for blocked_method in (
            'hardhat_reset',
            'hardhat_impersonateAccount',
            'hardhat_setBalance',
            'evm_snapshot',
            'evm_revert',
            'evm_mine',
            'debug_traceTransaction',
            'personal_unlockAccount',
            'eth_sign',
            'anvil_setCode',
        ):
            res_blocked = evaluate_rpc_request_security(
                {'jsonrpc': '2.0', 'method': blocked_method, 'params': [], 'id': 99},
            )
            self.assertFalse(res_blocked['allowed'], f"Expected {blocked_method} to be blocked")
            self.assertEqual(res_blocked['http_status'], 403)
            self.assertEqual(res_blocked['jsonrpc_error']['error']['code'], -32601)

        # Privileged method eth_sendTransaction blocked without backend operator token, allowed with token
        unauth_send = evaluate_rpc_request_security(
            {'jsonrpc': '2.0', 'method': 'eth_sendTransaction', 'params': [{}], 'id': 2},
            expected_backend_token='super-secret-rpc-token',
        )
        self.assertFalse(unauth_send['allowed'])

        auth_send = evaluate_rpc_request_security(
            {'jsonrpc': '2.0', 'method': 'eth_sendTransaction', 'params': [{}], 'id': 2},
            headers={'X-DVS-RPC-Token': 'super-secret-rpc-token'},
            expected_backend_token='super-secret-rpc-token',
        )
        self.assertTrue(auth_send['allowed'])

        # Unauthorized CORS origin rejected
        bad_cors = evaluate_rpc_request_security(
            {'jsonrpc': '2.0', 'method': 'eth_chainId', 'params': [], 'id': 1},
            headers={'Origin': 'https://malicious.example.com'},
            allowed_cors_origins=['https://dvs-app.run.app'],
        )
        self.assertFalse(bad_cors['allowed'])
        self.assertEqual(bad_cors['http_status'], 403)

    # 12. Existing local development compatibility & management command CLI
    def test_12_existing_local_development_and_cli_compatibility(self):
        import io
        from django.core.management import call_command

        out_status = io.StringIO()
        call_command('hardhat_demo', 'status', '--json', stdout=out_status)
        status_data = json.loads(out_status.getvalue())
        self.assertEqual(status_data['chain_id'], 31337)
        self.assertTrue(status_data['connected'])


class Module8Phase9CloudBlockchainIntegrationTests(TestCase):
    """
    Module 8 — Phase 9: Live Cloud-to-Blockchain Connectivity and Contract Deployment Integration Tests.
    Covers all 17 verification requirements:
    1. Remote RPC configuration.
    2. HTTPS RPC validation.
    3. Backend RPC authentication header.
    4. Browser RPC requests without backend credentials.
    5. Chain ID validation.
    6. Contract bytecode validation.
    7. Election Authority key/address consistency & Demonstration Account Rotation.
    8. Deployment metadata synchronization.
    9. Chain reset detection.
    10. Stale contract rejection.
    11. MetaMask remote network compatibility.
    12. EIP-191 challenge verification.
    13. EIP-712 permit generation.
    14. Direct castVoteWithPermit transaction submission.
    15. Transaction receipt and VoteCast event verification.
    16. Scheduled and Immediate election lifecycle integration.
    17. RPC outage and recovery behavior.
    """

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        import threading
        from http.server import ThreadingHTTPServer
        from scripts.hardhat_rpc_gateway import HardhatRpcGatewayHandler
        from EVotingApp.hardhat_demo import (
            rotate_and_fund_demo_accounts,
            get_rotated_demo_private_key,
        )

        # Ensure rotated demonstration accounts exist and are funded on the local Hardhat node
        cls.rotated_summary = rotate_and_fund_demo_accounts(rpc_url='http://127.0.0.1:8545')
        cls.deployer_key = get_rotated_demo_private_key('deployer')
        cls.authority_key = get_rotated_demo_private_key('election_authority')
        cls.voter1_key = get_rotated_demo_private_key('voter', voter_index=1)
        cls.voter2_key = get_rotated_demo_private_key('voter', voter_index=2)

        # Start a live JSON-RPC Security Gateway instance on an ephemeral port in front of Hardhat (127.0.0.1:8545)
        cls.gateway_token = 'phase9-gateway-secret-token-2026'

        class TestGatewayHandler(HardhatRpcGatewayHandler):
            upstream_rpc_url = 'http://127.0.0.1:8545'
            backend_token = cls.gateway_token
            allowed_cors_origins = ['https://dvs-cloudrun.run.app', 'http://localhost:3000']

            def log_message(self, format, *args):
                pass  # Suppress HTTP access logs during test runs

        cls.gateway_server = ThreadingHTTPServer(('127.0.0.1', 0), TestGatewayHandler)
        cls.gateway_port = cls.gateway_server.server_address[1]
        cls.gateway_url = f'http://127.0.0.1:{cls.gateway_port}'
        cls.gateway_thread = threading.Thread(target=cls.gateway_server.serve_forever, daemon=True)
        cls.gateway_thread.start()

    @classmethod
    def tearDownClass(cls):
        try:
            cls.gateway_server.shutdown()
            cls.gateway_server.server_close()
        except Exception:
            pass
        super().tearDownClass()

    def setUp(self):
        import tempfile
        import shutil
        self.temp_dir = tempfile.mkdtemp(prefix='dvs_phase9_test_')
        self.addCleanup(lambda: shutil.rmtree(self.temp_dir, ignore_errors=True))
        self.client = Client()

    def _authenticate_wallet_client(self, private_key_hex, aadhar=None):
        from eth_account import Account
        from eth_account.messages import encode_defunct

        acct = Account.from_key(private_key_hex)
        ch_res = self.client.get(f'/api/wallet/challenge/?address={acct.address}')
        self.assertEqual(ch_res.status_code, 200)
        ch_data = ch_res.json()

        msg = encode_defunct(text=ch_data['challenge'])
        signed = Account.sign_message(msg, private_key=acct.key)
        payload = {
            'address': acct.address,
            'nonce': ch_data['nonce'],
            'signature': signed.signature.hex(),
        }
        if aadhar:
            payload['aadhar'] = aadhar

        ver_res = self.client.post(
            '/api/wallet/verify/',
            data=json.dumps(payload),
            content_type='application/json',
        )
        self.assertEqual(ver_res.status_code, 200)
        return acct, ch_data, ver_res.json()

    # 1. Remote RPC configuration
    def test_01_remote_rpc_configuration(self):
        from EVoting.settings import validate_and_load_settings

        env = {
            'DJANGO_ENV': 'production',
            'DJANGO_DEBUG': 'False',
            'DJANGO_SECRET_KEY': 'p9-prod-secret-key-with-more-than-32-characters-2026!',
            'DJANGO_ALLOWED_HOSTS': 'dvs-cloudrun.run.app',
            'DJANGO_CSRF_TRUSTED_ORIGINS': 'https://dvs-cloudrun.run.app',
            'WEB3_RPC_URL': 'https://hardhat-gateway.example.org',
            'METAMASK_RPC_URL': 'https://hardhat-gateway.example.org',
            'HARDHAT_BACKEND_RPC_TOKEN': 'secret-rpc-gateway-token-999',
            'WEB3_RPC_TIMEOUT_SECONDS': '15',
            'CHAIN_ID': '31337',
            'ELECTION_AUTHORITY_PRIVATE_KEY': self.authority_key,
            'BLOCKCHAIN_DEPLOYER_PRIVATE_KEY': self.deployer_key,
            'ELECTION_NULLIFIER_PEPPER': 'strong-production-nullifier-pepper-2026',
            'ONBOARDING_ENCRYPTION_KEY': 'strong-production-onboarding-key-2026',
            'PROVIDER_REFERENCE_SALT': 'strong-production-provider-salt-2026',
        }
        cfg = validate_and_load_settings(env=env)
        self.assertEqual(cfg['WEB3_RPC_URL'], 'https://hardhat-gateway.example.org')
        self.assertEqual(cfg['METAMASK_RPC_URL'], 'https://hardhat-gateway.example.org')
        self.assertEqual(cfg['HARDHAT_BACKEND_RPC_TOKEN'], 'secret-rpc-gateway-token-999')
        self.assertEqual(cfg['WEB3_RPC_TIMEOUT_SECONDS'], 15)
        self.assertEqual(cfg['CHAIN_ID'], 31337)

    # 2. HTTPS RPC validation
    def test_02_https_rpc_validation(self):
        from django.core.exceptions import ImproperlyConfigured
        from EVoting.settings import validate_and_load_settings
        from EVotingApp.services import validate_blockchain_configuration

        # Non-HTTPS remote URL must be rejected in production or when REQUIRE_HTTPS_RPC=True
        insecure_env = {
            'DJANGO_ENV': 'production',
            'DJANGO_DEBUG': 'False',
            'DJANGO_SECRET_KEY': 'p9-prod-secret-key-with-more-than-32-characters-2026!',
            'DJANGO_ALLOWED_HOSTS': 'dvs-cloudrun.run.app',
            'DJANGO_CSRF_TRUSTED_ORIGINS': 'https://dvs-cloudrun.run.app',
            'WEB3_RPC_URL': 'http://hardhat-gateway.example.org:8545',
            'ELECTION_AUTHORITY_PRIVATE_KEY': self.authority_key,
            'ELECTION_NULLIFIER_PEPPER': 'strong-production-nullifier-pepper-2026',
            'ONBOARDING_ENCRYPTION_KEY': 'strong-production-onboarding-key-2026',
            'PROVIDER_REFERENCE_SALT': 'strong-production-provider-salt-2026',
        }
        with self.assertRaises(ImproperlyConfigured) as ctx:
            validate_and_load_settings(env=insecure_env)
        self.assertIn('https://', str(ctx.exception))

        with self.assertRaises(BlockchainDeploymentError):
            validate_blockchain_configuration(
                config_override={
                    'WEB3_RPC_URL': 'http://hardhat-gateway.example.org:8545',
                    'ELECTION_AUTHORITY_PRIVATE_KEY': self.authority_key,
                },
                is_production=True,
            )

    # 3. Backend RPC authentication header & live gateway communication
    def test_03_backend_rpc_authentication_header_with_live_gateway(self):
        from django.test import override_settings
        from EVotingApp.services import get_web3_provider

        with override_settings(
            WEB3_RPC_URL=self.gateway_url,
            HARDHAT_BACKEND_RPC_TOKEN=self.gateway_token,
        ):
            w3_gw = get_web3_provider()
            self.assertTrue(w3_gw.is_connected())
            self.assertEqual(w3_gw.eth.chain_id, 31337)
            # Privileged method eth_accounts succeeds because X-DVS-RPC-Token is attached by get_web3_provider()
            accounts = w3_gw.eth.accounts
            self.assertTrue(len(accounts) > 0)

    # 4. Browser RPC requests without backend credentials
    def test_04_browser_rpc_requests_without_backend_credentials(self):
        from urllib import request as urllib_request
        from urllib.error import HTTPError
        from django.test import override_settings

        with override_settings(
            WEB3_RPC_URL=self.gateway_url,
            METAMASK_RPC_URL='https://hardhat-gateway.example.org',
            HARDHAT_BACKEND_RPC_TOKEN=self.gateway_token,
        ):
            status_res = self.client.get('/api/wallet/status/')
            self.assertEqual(status_res.status_code, 200)
            raw_text = status_res.content.decode('utf-8')
            status_json = status_res.json()

            # Public MetaMask RPC URL is provided; backend token is NEVER exposed
            self.assertEqual(status_json['rpc_url'], 'https://hardhat-gateway.example.org')
            self.assertEqual(status_json['chain_id'], 31337)
            self.assertEqual(status_json['chain_id_hex'], '0x7a69')
            self.assertNotIn(self.gateway_token, raw_text)

        # Simulated browser request (no X-DVS-RPC-Token, with Origin header) succeeds for eth_chainId
        req_ok = urllib_request.Request(
            self.gateway_url,
            data=json.dumps({'jsonrpc': '2.0', 'method': 'eth_chainId', 'params': [], 'id': 1}).encode('utf-8'),
            headers={'Content-Type': 'application/json', 'Origin': 'https://dvs-cloudrun.run.app'},
            method='POST',
        )
        with urllib_request.urlopen(req_ok, timeout=5) as resp:
            body = json.loads(resp.read().decode('utf-8'))
            self.assertEqual(body['result'], '0x7a69')
            self.assertEqual(resp.headers.get('Access-Control-Allow-Origin'), 'https://dvs-cloudrun.run.app')

        # Simulated browser request WITHOUT X-DVS-RPC-Token is blocked (403) for eth_sendTransaction and hardhat_reset
        for restricted in ('eth_sendTransaction', 'hardhat_reset'):
            req_bad = urllib_request.Request(
                self.gateway_url,
                data=json.dumps({'jsonrpc': '2.0', 'method': restricted, 'params': [], 'id': 2}).encode('utf-8'),
                headers={'Content-Type': 'application/json', 'Origin': 'https://dvs-cloudrun.run.app'},
                method='POST',
            )
            with self.assertRaises(HTTPError) as err_ctx:
                urllib_request.urlopen(req_bad, timeout=5)
            self.assertEqual(err_ctx.exception.code, 403)

    # 5. Chain ID validation
    def test_05_chain_id_validation(self):
        from EVotingApp.services import verify_live_election_contract_on_chain

        el = Election.objects.create(
            title='Chain ID Validation Election',
            election_id=8901,
            chain_id=31337,
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',
            deployment_status='DEPLOYED',
        )
        wrong_chain_w3 = MagicMock()
        wrong_chain_w3.is_connected.return_value = True
        wrong_chain_w3.eth.chain_id = 11155111  # Sepolia instead of 31337

        with self.assertRaises(BlockchainDeploymentError) as ctx:
            verify_live_election_contract_on_chain(el, w3=wrong_chain_w3)
        self.assertIn('Chain ID mismatch', str(ctx.exception))

    # 6. Contract bytecode validation
    def test_06_contract_bytecode_validation(self):
        from django.test import override_settings
        from EVotingApp.hardhat_demo import deploy_demo_evoting_contract
        from EVotingApp.services import inspect_deployed_contract

        with override_settings(
            WEB3_RPC_URL=self.gateway_url,
            HARDHAT_BACKEND_RPC_TOKEN=self.gateway_token,
            ELECTION_AUTHORITY_PRIVATE_KEY=self.authority_key,
            BLOCKCHAIN_DEPLOYER_PRIVATE_KEY=self.deployer_key,
        ):
            dep = deploy_demo_evoting_contract(election_id=8902, base_dir=self.temp_dir)
            inspection = inspect_deployed_contract(dep['contract_address'])
            self.assertTrue(inspection['has_code'])
            self.assertTrue(inspection['is_compatible'])
            self.assertEqual(inspection['deployed_bytecode_hash'], dep['deployed_bytecode_hash'])
            self.assertEqual(inspection['chain_id'], 31337)

            # Empty address has_code=False
            empty_insp = inspect_deployed_contract('0x000000000000000000000000000000000000dead')
            self.assertFalse(empty_insp['has_code'])
            self.assertFalse(empty_insp['is_compatible'])

    # 7. Election Authority key/address consistency & Demonstration Account Rotation
    def test_07_demonstration_account_rotation_and_authority_consistency(self):
        from eth_account import Account
        from EVotingApp.hardhat_demo import (
            DEMO_DEPLOYER_ADDRESS,
            DEMO_ELECTION_AUTHORITY_ADDRESS,
            DEMO_VOTER_ACCOUNTS,
            is_public_hardhat_default_account,
            assert_not_public_hardhat_default_account,
            deploy_demo_evoting_contract,
        )

        # Publicly known Hardhat Account #0 (0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266) MUST be rejected
        hardhat_default_0 = '0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266'
        hardhat_default_0_key = '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80'
        self.assertTrue(is_public_hardhat_default_account(hardhat_default_0))
        with self.assertRaises(BlockchainDeploymentError):
            assert_not_public_hardhat_default_account(hardhat_default_0, 'Deployer')

        # Attempt to deploy using Hardhat Account #0 key must be blocked
        with self.assertRaises(BlockchainDeploymentError):
            deploy_demo_evoting_contract(
                election_id=8903,
                deployer_private_key=hardhat_default_0_key,
                base_dir=self.temp_dir,
            )

        # Active rotated accounts must NOT be public Hardhat defaults and must have distinct Deployer & Authority
        self.assertFalse(is_public_hardhat_default_account(DEMO_DEPLOYER_ADDRESS))
        self.assertFalse(is_public_hardhat_default_account(DEMO_ELECTION_AUTHORITY_ADDRESS))
        self.assertNotEqual(DEMO_DEPLOYER_ADDRESS.lower(), DEMO_ELECTION_AUTHORITY_ADDRESS.lower())
        for v in DEMO_VOTER_ACCOUNTS:
            self.assertFalse(is_public_hardhat_default_account(v['address']))

        # Derived address of rotated authority key matches contract's electionAuthority()
        dep = deploy_demo_evoting_contract(
            election_id=8903,
            authority_private_key=self.authority_key,
            deployer_private_key=self.deployer_key,
            base_dir=self.temp_dir,
        )
        derived_auth = Account.from_key(self.authority_key).address
        self.assertEqual(dep['election_authority_address'], derived_auth)
        self.assertEqual(dep['contract_state']['electionAuthority'], derived_auth)
        self.assertNotEqual(dep['deployer_address'].lower(), hardhat_default_0.lower())

    # 8. Deployment metadata synchronization with Django models
    def test_08_deployment_metadata_synchronization_with_django(self):
        from django.test import override_settings
        from EVotingApp.hardhat_demo import (
            deploy_demo_evoting_contract,
            sync_demo_deployment_to_django,
        )

        with override_settings(
            WEB3_RPC_URL=self.gateway_url,
            HARDHAT_BACKEND_RPC_TOKEN=self.gateway_token,
            ELECTION_AUTHORITY_PRIVATE_KEY=self.authority_key,
            BLOCKCHAIN_DEPLOYER_PRIVATE_KEY=self.deployer_key,
        ):
            dep_meta = deploy_demo_evoting_contract(election_id=8904, base_dir=self.temp_dir)
            sync_res = sync_demo_deployment_to_django(
                deployment_metadata=dep_meta,
                election_id=8904,
                base_dir=self.temp_dir,
            )
            self.assertTrue(sync_res['synchronized'])

            el = Election.objects.get(election_id=8904)
            self.assertEqual(el.contract_address, dep_meta['contract_address'])
            self.assertEqual(el.deployment_tx_hash, dep_meta['deployment_tx_hash'])
            self.assertEqual(el.deployed_bytecode_hash, dep_meta['deployed_bytecode_hash'])
            self.assertEqual(el.authority_address, dep_meta['election_authority_address'])
            self.assertEqual(el.deployment_status, 'DEPLOYED')

            active_dep = ContractDeployment.objects.filter(election=el, is_active_deployment=True).first()
            self.assertIsNotNone(active_dep)
            self.assertEqual(active_dep.contract_address, dep_meta['contract_address'])
            self.assertFalse(active_dep.is_historical_legacy)

    # 9. Chain reset detection & 10. Stale contract rejection and recovery
    def test_09_and_10_chain_reset_detection_stale_contract_rejection_and_recovery(self):
        from django.test import override_settings
        from EVotingApp.hardhat_demo import (
            deploy_demo_evoting_contract,
            sync_demo_deployment_to_django,
            reinitialize_after_node_restart,
        )
        from EVotingApp.services import (
            add_election_candidate,
            sync_and_lock_candidates,
        )

        with override_settings(
            WEB3_RPC_URL=self.gateway_url,
            HARDHAT_BACKEND_RPC_TOKEN=self.gateway_token,
            ELECTION_AUTHORITY_PRIVATE_KEY=self.authority_key,
            BLOCKCHAIN_DEPLOYER_PRIVATE_KEY=self.deployer_key,
        ):
            # Initial deployment and sync
            dep1 = deploy_demo_evoting_contract(election_id=8905, base_dir=self.temp_dir)
            sync_demo_deployment_to_django(deployment_metadata=dep1, election_id=8905, base_dir=self.temp_dir)
            el = Election.objects.get(election_id=8905)
            add_election_candidate(el.pk, 1, 'Candidate Alpha', 'ALP', sync_on_chain=False)

            # Simulate Hardhat node restart / chain reset where contract address no longer has bytecode
            stale_addr = '0x000000000000000000000000000000000000cafe'
            el.contract_address = stale_addr
            el.save(update_fields=['contract_address'])

            # Attempting to sync and lock candidates against stale contract address must fail and mark CHAIN_RESET_REDEPLOY_REQUIRED
            with self.assertRaises(BlockchainDeploymentError) as ctx:
                sync_and_lock_candidates(el.pk, lock_on_chain=True)
            self.assertIn('Stale contract address detected', str(ctx.exception))

            el.refresh_from_db()
            self.assertEqual(el.deployment_status, 'CHAIN_RESET_REDEPLOY_REQUIRED')

            # Attempting to issue a ballot permit when election has CHAIN_RESET_REDEPLOY_REQUIRED must be rejected (409)
            el.status = 'ACTIVE'
            el.candidates_locked_on_chain = True
            el.save(update_fields=['status', 'candidates_locked_on_chain'])
            Candidate.objects.filter(election=el).update(is_synced_on_chain=True)
            voter = Voter.objects.create(name='Reset Voter', aadhar_number='890500000001', has_voted=False)
            VoterEligibility.objects.create(voter=voter, election=el, is_eligible=True)
            self._authenticate_wallet_client(self.voter1_key)

            permit_stale_res = self.client.post(
                '/api/ballot/permit/',
                data=json.dumps({'election_id': 8905, 'candidate_id': 1, 'aadhar': '890500000001'}),
                content_type='application/json',
            )
            self.assertEqual(permit_stale_res.status_code, 409)
            self.assertEqual(permit_stale_res.json().get('code'), 'CHAIN_RESET_REDEPLOY_REQUIRED')

            # Redeploy and synchronize fresh contract after chain reset
            el.status = 'SCHEDULED'
            el.save(update_fields=['status'])
            rec = reinitialize_after_node_restart(election_id=8905, force=True, base_dir=self.temp_dir)
            sync_demo_deployment_to_django(
                deployment_metadata=rec['deployment'],
                election_id=8905,
                base_dir=self.temp_dir,
            )
            el.refresh_from_db()
            self.assertEqual(el.deployment_status, 'DEPLOYED')
            self.assertEqual(el.contract_address, rec['deployment']['contract_address'])

            # Historical ContractDeployment record is preserved as historical legacy
            self.assertTrue(
                ContractDeployment.objects.filter(
                    election=el, is_historical_legacy=True, is_active_deployment=False
                ).exists()
            )
            self.assertEqual(
                ContractDeployment.objects.filter(election=el, is_active_deployment=True).count(),
                1,
            )

    # 11. MetaMask remote network compatibility, 12. EIP-191 challenge, 13. EIP-712 permit,
    # 14. Direct castVoteWithPermit transaction, 15. Receipt & VoteCast event verification
    def test_11_to_15_end_to_end_metamask_permit_direct_vote_and_receipt_verification(self):
        from django.test import override_settings
        from web3 import Web3
        from eth_account import Account
        from EVotingApp.services import (
            deploy_election_contract,
            add_election_candidate,
            sync_and_lock_candidates,
            activate_election,
            load_contract_artifact,
        )

        with override_settings(
            WEB3_RPC_URL=self.gateway_url,
            METAMASK_RPC_URL=self.gateway_url,
            HARDHAT_BACKEND_RPC_TOKEN=self.gateway_token,
            ELECTION_AUTHORITY_PRIVATE_KEY=self.authority_key,
            ELECTION_AUTHORITY_ADDRESS=Account.from_key(self.authority_key).address,
            BLOCKCHAIN_DEPLOYER_PRIVATE_KEY=self.deployer_key,
        ):
            # Create & deploy an Immediate election through Django services over the live gateway
            el = Election.objects.create(
                title='Phase 9 Live Vote Integration Election',
                election_id=8910,
                commencement_mode='IMMEDIATE',
                immediate_duration_hours=6,
                status='DRAFT',
                deployment_status='NOT_DEPLOYED',
                chain_id=31337,
            )
            contract_addr = deploy_election_contract(el.pk)
            add_election_candidate(el.pk, 1, 'Civic Reform Candidate', 'CRC', sync_on_chain=True)
            add_election_candidate(el.pk, 2, 'Digital Democracy Candidate', 'DDC', sync_on_chain=True)
            sync_and_lock_candidates(el.pk, lock_on_chain=True)
            activate_election(el.pk)

            # Register eligible voter
            voter = Voter.objects.create(
                name='Gateway Citizen One',
                aadhar_number='891011112222',
                has_voted=False,
            )
            VoterEligibility.objects.create(voter=voter, election=el, is_eligible=True)

            # 11 & 12: EIP-191 Challenge & Wallet Verification + MetaMask network status
            voter_acct, _, _ = self._authenticate_wallet_client(self.voter1_key, aadhar='891011112222')
            status_res = self.client.get('/api/wallet/status/?election_id=8910')
            self.assertEqual(status_res.status_code, 200)
            status_data = status_res.json()
            self.assertTrue(status_data['authenticated'])
            self.assertEqual(status_data['chain_id'], 31337)
            self.assertEqual(status_data['contract_address'].lower(), contract_addr.lower())
            self.assertTrue(status_data['eligibility']['is_eligible'])
            self.assertFalse(status_data['eligibility']['has_voted'])

            # 13: Request EIP-712 Ballot Permit from Django backend
            permit_res = self.client.post(
                '/api/ballot/permit/',
                data=json.dumps({
                    'election_id': 8910,
                    'candidate_id': 1,
                    'aadhar': '891011112222',
                }),
                content_type='application/json',
            )
            self.assertEqual(permit_res.status_code, 200)
            permit = permit_res.json()['permit']
            self.assertEqual(permit['voterWallet'].lower(), voter_acct.address.lower())
            self.assertEqual(permit['candidateId'], 1)
            self.assertEqual(permit['electionId'], 8910)
            self.assertEqual(permit['contractAddress'].lower(), contract_addr.lower())

            # 14: Voter submits castVoteWithPermit directly to the JSON-RPC Security Gateway
            # WITHOUT any backend token (simulating browser MetaMask wallet on Chain ID 31337)
            browser_w3 = Web3(Web3.HTTPProvider(self.gateway_url, request_kwargs={'timeout': 10}))
            self.assertTrue(browser_w3.is_connected())
            abi, _, _ = load_contract_artifact()
            browser_contract = browser_w3.eth.contract(
                address=Web3.to_checksum_address(contract_addr),
                abi=abi,
            )

            tx_call = browser_contract.functions.castVoteWithPermit(
                int(permit['candidateId']),
                Web3.to_bytes(hexstr=permit['voterNullifier']),
                int(permit['deadline']),
                Web3.to_bytes(hexstr=permit['nonce']),
                int(permit['v']),
                Web3.to_bytes(hexstr=permit['r']),
                Web3.to_bytes(hexstr=permit['s']),
            )
            nonce_val = browser_w3.eth.get_transaction_count(voter_acct.address)
            gas_est = tx_call.estimate_gas({'from': voter_acct.address})
            built_vote_tx = tx_call.build_transaction({
                'from': voter_acct.address,
                'nonce': nonce_val,
                'chainId': 31337,
                'gas': int(gas_est * 1.25),
                'gasPrice': browser_w3.eth.gas_price,
            })
            signed_vote_tx = Account.sign_transaction(built_vote_tx, private_key=self.voter1_key)
            raw_vote_tx = getattr(signed_vote_tx, 'raw_transaction', None) or getattr(signed_vote_tx, 'rawTransaction')
            vote_tx_hash = browser_w3.eth.send_raw_transaction(raw_vote_tx)
            vote_receipt = browser_w3.eth.wait_for_transaction_receipt(vote_tx_hash, timeout=30)
            self.assertEqual(vote_receipt.status, 1)

            # 15: Confirm ballot transaction receipt & VoteCast event in Django backend
            confirm_res = self.client.post(
                '/api/ballot/confirm/',
                data=json.dumps({
                    'tx_hash': vote_tx_hash.hex(),
                    'nullifier': permit['voterNullifier'],
                    'permit_nonce': permit['nonce'],
                }),
                content_type='application/json',
            )
            self.assertEqual(confirm_res.status_code, 200)
            confirm_data = confirm_res.json()
            self.assertTrue(confirm_data['success'])
            self.assertEqual(confirm_data['election_id'], 8910)
            self.assertEqual(confirm_data['contract_address'].lower(), contract_addr.lower())
            self.assertIn('DVS-8910-', confirm_data['receipt_reference'])

            # Verify on-chain vote count and duplicate/replay vote prevention
            self.assertEqual(browser_contract.functions.getCount(1).call(), 1)
            self.assertEqual(browser_contract.functions.totalVotes().call(), 1)

            # Attempting to request another permit for the same voter is rejected (409)
            dup_permit_res = self.client.post(
                '/api/ballot/permit/',
                data=json.dumps({
                    'election_id': 8910,
                    'candidate_id': 1,
                    'aadhar': '891011112222',
                }),
                content_type='application/json',
            )
            self.assertEqual(dup_permit_res.status_code, 409)

    # 16. Scheduled and Immediate election lifecycle integration over live gateway
    def test_16_scheduled_and_immediate_election_lifecycle_integration(self):
        from django.test import override_settings
        from eth_account import Account
        from EVotingApp.services import (
            deploy_election_contract,
            add_election_candidate,
            sync_and_lock_candidates,
            configure_voting_window,
            activate_election,
            close_election,
            reconcile_election_results,
            finalize_election,
        )

        superuser = User.objects.create_superuser(
            username='p9_lifecycle_super',
            email='p9_super@example.org',
            password='Password123!',
        )

        with override_settings(
            WEB3_RPC_URL=self.gateway_url,
            HARDHAT_BACKEND_RPC_TOKEN=self.gateway_token,
            ELECTION_AUTHORITY_PRIVATE_KEY=self.authority_key,
            ELECTION_AUTHORITY_ADDRESS=Account.from_key(self.authority_key).address,
            BLOCKCHAIN_DEPLOYER_PRIVATE_KEY=self.deployer_key,
        ):
            now = timezone.now()
            sched_el = Election.objects.create(
                title='Phase 9 Scheduled Election',
                election_id=8916,
                commencement_mode='SCHEDULED',
                start_datetime=now - timedelta(minutes=2),
                end_datetime=now + timedelta(hours=4),
                status='DRAFT',
                deployment_status='NOT_DEPLOYED',
                chain_id=31337,
            )
            deploy_election_contract(sched_el.pk, actor_user=superuser)
            add_election_candidate(sched_el.pk, 1, 'Scheduled Candidate 1', 'SC1', actor_user=superuser)
            add_election_candidate(sched_el.pk, 2, 'Scheduled Candidate 2', 'SC2', actor_user=superuser)
            sync_and_lock_candidates(sched_el.pk, lock_on_chain=True, actor_user=superuser)
            configure_voting_window(
                sched_el.pk,
                commencement_mode='SCHEDULED',
                start_datetime=now - timedelta(minutes=2),
                end_datetime=now + timedelta(hours=4),
                actor_user=superuser,
            )
            activate_election(sched_el.pk, actor_user=superuser)
            sched_el.refresh_from_db()
            self.assertEqual(sched_el.status, 'ACTIVE')
            self.assertTrue(sched_el.candidates_locked_on_chain)
            self.assertTrue(sched_el.voting_window_locked_on_chain)

            close_election(sched_el.pk, actor_user=superuser)
            sched_el.refresh_from_db()
            self.assertEqual(sched_el.status, 'CLOSED')

            reconcile_res = reconcile_election_results(sched_el.pk, actor_user=superuser)
            self.assertTrue(reconcile_res['results_verified'])
            finalize_election(sched_el.pk, actor_user=superuser)
            sched_el.refresh_from_db()
            self.assertEqual(sched_el.status, 'FINALIZED')

    # 17. RPC outage and recovery behavior
    def test_17_rpc_outage_and_recovery_behavior(self):
        from django.test import override_settings
        from EVotingApp.services import get_application_health_status, deploy_election_contract

        el = Election.objects.create(
            title='Outage Recovery Election',
            election_id=8917,
            commencement_mode='IMMEDIATE',
            immediate_duration_hours=4,
            status='DRAFT',
            deployment_status='NOT_DEPLOYED',
        )

        # Simulate RPC outage by pointing to an unreachable local port
        from eth_account import Account
        auth_addr = Account.from_key(self.authority_key).address
        with override_settings(
            WEB3_RPC_URL='http://127.0.0.1:59999',
            WEB3_RPC_TIMEOUT_SECONDS=1,
            ELECTION_AUTHORITY_PRIVATE_KEY=self.authority_key,
            ELECTION_AUTHORITY_ADDRESS=auth_addr,
            BLOCKCHAIN_DEPLOYER_PRIVATE_KEY=self.deployer_key,
        ):
            # Health check remains HTTP 200 for Cloud Run liveness while reporting blockchain.reachable=False
            health_outage = get_application_health_status(check_blockchain=True)
            self.assertEqual(health_outage['status'], 'ok')
            self.assertEqual(health_outage['http_status'], 200)
            self.assertFalse(health_outage['blockchain']['reachable'])
            self.assertEqual(health_outage['blockchain']['status'], 'unavailable')

            # Deployment fails cleanly with BlockchainDeploymentError without corrupting DB state
            with self.assertRaises(BlockchainDeploymentError):
                deploy_election_contract(el.pk)
            el.refresh_from_db()
            self.assertEqual(el.status, 'DRAFT')

        # Recovery: restore gateway URL and verify deployment and health check succeed
        with override_settings(
            WEB3_RPC_URL=self.gateway_url,
            HARDHAT_BACKEND_RPC_TOKEN=self.gateway_token,
            ELECTION_AUTHORITY_PRIVATE_KEY=self.authority_key,
            ELECTION_AUTHORITY_ADDRESS=auth_addr,
            BLOCKCHAIN_DEPLOYER_PRIVATE_KEY=self.deployer_key,
        ):
            health_ok = get_application_health_status(check_blockchain=True)
            self.assertEqual(health_ok['status'], 'ok')
            self.assertTrue(health_ok['blockchain']['reachable'])
            self.assertEqual(health_ok['blockchain']['status'], 'connected')

            addr = deploy_election_contract(el.pk)
            self.assertTrue(addr.startswith('0x'))
            el.refresh_from_db()
            self.assertEqual(el.deployment_status, 'DEPLOYED')

    # 18. Phase 10 Stage 1: DVS_BLOCKCHAIN_BASE_URL derivation & idempotent ensure_idempotent_demo_election_ready
    def test_18_phase10_stage1_blockchain_base_url_and_idempotent_init(self):
        from django.test import override_settings
        from EVoting.settings import validate_and_load_settings
        from EVotingApp.hardhat_demo import ensure_idempotent_demo_election_ready

        # 1. Verify DVS_BLOCKCHAIN_BASE_URL derives WEB3_RPC_URL, METAMASK_RPC_URL, /healthz, and /metadata
        cfg = validate_and_load_settings(
            env={
                'DJANGO_ENV': 'production',
                'DJANGO_DEBUG': 'False',
                'DJANGO_SECRET_KEY': 'x' * 56,
                'DJANGO_ALLOWED_HOSTS': 'dvs-app.run.app',
                'DJANGO_CSRF_TRUSTED_ORIGINS': 'https://dvs-app.run.app',
                'DVS_BLOCKCHAIN_BASE_URL': 'https://dvs-blockchain-gateway.run.app/',
                'ELECTION_AUTHORITY_PRIVATE_KEY': self.authority_key,
                'BLOCKCHAIN_DEPLOYER_PRIVATE_KEY': self.deployer_key,
                'ELECTION_NULLIFIER_PEPPER': 'pepper-secret-material-2026-prod',
                'ONBOARDING_ENCRYPTION_KEY': 'onboarding-secret-material-2026-prod',
                'PROVIDER_REFERENCE_SALT': 'provider-salt-secret-material-2026-prod',
            }
        )
        self.assertEqual(cfg['DVS_BLOCKCHAIN_BASE_URL'], 'https://dvs-blockchain-gateway.run.app')
        self.assertEqual(cfg['WEB3_RPC_URL'], 'https://dvs-blockchain-gateway.run.app/rpc')
        self.assertEqual(cfg['METAMASK_RPC_URL'], 'https://dvs-blockchain-gateway.run.app/rpc')
        self.assertEqual(cfg['BLOCKCHAIN_HEALTH_URL'], 'https://dvs-blockchain-gateway.run.app/healthz')
        self.assertEqual(cfg['BLOCKCHAIN_METADATA_URL'], 'https://dvs-blockchain-gateway.run.app/metadata')

        # 2. Verify ensure_idempotent_demo_election_ready deploys once, and subsequent calls do NOT redeploy
        with override_settings(
            WEB3_RPC_URL=self.gateway_url,
            HARDHAT_BACKEND_RPC_TOKEN=self.gateway_token,
            ELECTION_AUTHORITY_PRIVATE_KEY=self.authority_key,
            BLOCKCHAIN_DEPLOYER_PRIVATE_KEY=self.deployer_key,
        ):
            init1 = ensure_idempotent_demo_election_ready(
                election_id=8918,
                rpc_url=self.gateway_url,
                base_dir=self.temp_dir,
            )
            self.assertEqual(init1['status'], 'deployed_and_synchronized')
            self.assertTrue(init1['redeployed'])
            first_addr = init1['contract_address']

            # Calling ensure_idempotent_demo_election_ready again on ordinary startup MUST NOT redeploy
            init2 = ensure_idempotent_demo_election_ready(
                election_id=8918,
                rpc_url=self.gateway_url,
                base_dir=self.temp_dir,
            )
            self.assertEqual(init2['status'], 'already_deployed_and_verified')
            self.assertFalse(init2['redeployed'])
            self.assertEqual(init2['contract_address'], first_addr)

    # 19. Phase 10 Stage 2: Super Admin Blockchain URL sync and MetaMask configuration verification
    def test_19_phase10_stage2_blockchain_sync_api(self):
        from EVotingApp.services import initialize_system_superuser

        # Provision super admin
        admin_res = initialize_system_superuser(
            env={
                'DJANGO_SUPERUSER_USERNAME': 'stage2_superadmin',
                'DJANGO_SUPERUSER_EMAIL': 'stage2_admin@example.org',
                'DJANGO_SUPERUSER_PASSWORD': 'SuperAdminPass!2026',
            },
            strict=True,
        )
        self.client.login(username='stage2_superadmin', password='SuperAdminPass!2026')

        # GET status
        res_get = self.client.get('/api/control/blockchain/sync/')
        self.assertEqual(res_get.status_code, 200)
        data_get = res_get.json()
        self.assertEqual(data_get['chain_id'], 31337)
        self.assertIn('configured_base_url', data_get)
        self.assertIn('blockchain_health', data_get)

        # Invalid URL format rejected
        res_bad = self.client.post(
            '/api/control/blockchain/sync/',
            data=json.dumps({'blockchain_base_url': 'ftp://invalid-scheme.org'}),
            content_type='application/json',
        )
        self.assertEqual(res_bad.status_code, 400)

        # Embedded credentials rejected
        res_creds = self.client.post(
            '/api/control/blockchain/sync/',
            data=json.dumps({'blockchain_base_url': 'https://user:pass@invalid-scheme.org'}),
            content_type='application/json',
        )
        self.assertEqual(res_creds.status_code, 400)




