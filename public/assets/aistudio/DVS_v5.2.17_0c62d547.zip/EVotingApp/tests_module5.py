import json
import io
from datetime import timedelta
from unittest.mock import patch
from django.test import TestCase, Client
from django.contrib.auth.models import User, Group
from django.utils import timezone
from eth_account import Account

from EVotingApp.models import (
    Voter,
    Election,
    Candidate,
    VoterEligibility,
    ElectionAdminAssignment,
    AdminAuditLog,
)
from EVotingApp.services import (
    register_voter,
    update_voter_record,
    bind_or_update_voter_wallet,
    assign_voter_eligibility,
    revoke_voter_eligibility,
    import_synthetic_voters_from_csv,
    get_election_voters_summary,
    validate_aadhar_format,
    validate_wallet_format,
    mask_aadhar,
    deploy_election_contract,
    sync_and_lock_candidates,
    activate_election,
    VoterValidationError,
    VoterEligibilityError,
    get_web3_provider,
)


class Module5VoterRegistrationAndEligibilityTests(TestCase):
    def setUp(self):
        self.client = Client()

        # Groups
        self.super_group, _ = Group.objects.get_or_create(name='Super Admin')
        self.admin_group, _ = Group.objects.get_or_create(name='Election Administrator')
        self.auditor_group, _ = Group.objects.get_or_create(name='Auditor')

        # Users
        self.superuser = User.objects.create_superuser(
            username='voter_super', password='password123', email='super@dvs.local'
        )
        self.election_admin = User.objects.create_user(
            username='voter_admin', password='password123', is_staff=True
        )
        self.election_admin.groups.add(self.admin_group)

        self.auditor = User.objects.create_user(
            username='voter_auditor', password='password123', is_staff=True
        )
        self.auditor.groups.add(self.auditor_group)

        self.unassigned_admin = User.objects.create_user(
            username='unassigned_voter_admin', password='password123', is_staff=True
        )
        self.unassigned_admin.groups.add(self.admin_group)

        # Primary test election
        self.election_a = Election.objects.create(
            title='2026 District Parliamentary Election',
            description='Parliamentary general election',
            election_type='GENERAL',
            election_id=5010,
            status='DRAFT',
            deployment_status='NOT_DEPLOYED',
            start_datetime=timezone.now() - timedelta(minutes=5),
            end_datetime=timezone.now() + timedelta(days=2),
        )
        Candidate.objects.create(election=self.election_a, candidate_id_num=1, name='Aarav Mehta', symbol='Sun')
        Candidate.objects.create(election=self.election_a, candidate_id_num=2, name='Diya Sengupta', symbol='Lotus')

        ElectionAdminAssignment.objects.create(
            election=self.election_a, user=self.election_admin, role='ELECTION_ADMIN'
        )
        ElectionAdminAssignment.objects.create(
            election=self.election_a, user=self.auditor, role='AUDITOR'
        )

        # Secondary test election
        self.election_b = Election.objects.create(
            title='2026 State Legislative Assembly Election',
            description='State assembly election',
            election_type='GENERAL',
            election_id=5020,
            status='DRAFT',
            deployment_status='NOT_DEPLOYED',
            start_datetime=timezone.now() - timedelta(minutes=5),
            end_datetime=timezone.now() + timedelta(days=2),
        )
        Candidate.objects.create(election=self.election_b, candidate_id_num=1, name='Karan Roy', symbol='Lion')

        ElectionAdminAssignment.objects.create(
            election=self.election_b, user=self.election_admin, role='ELECTION_ADMIN'
        )

    def test_voter_registration_validation_and_duplicate_prevention(self):
        """
        Verify voter registration validation rules:
        - Accepts valid 12-digit Aadhaar number and valid name.
        - Rejects non-12-digit Aadhaar, non-digit Aadhaar, and repeating identical digits.
        - Rejects duplicate Aadhaar numbers (preserves original record).
        - Correctly sets is_synthetic flag.
        - Masks Aadhaar in AdminAuditLog.
        """
        # 1. Valid registration
        voter = register_voter(
            name='Ananya Iyer',
            aadhar_number='551122334455',
            bound_wallet='0x70997970C51812dc3A010C7d01b50e0d17dc79C8',
            is_synthetic=True,
            actor_user=self.election_admin,
        )
        self.assertEqual(voter.name, 'Ananya Iyer')
        self.assertEqual(voter.aadhar_number, '551122334455')
        self.assertTrue(voter.is_synthetic)
        self.assertEqual(voter.bound_wallet, '0x70997970C51812dc3A010C7d01b50e0d17dc79C8')

        # 2. Reject duplicate Aadhaar
        with self.assertRaises(VoterValidationError):
            register_voter(
                name='Different Name',
                aadhar_number='551122334455',
                actor_user=self.election_admin,
            )

        # 3. Reject invalid Aadhaar formats
        with self.assertRaises(VoterValidationError):
            register_voter('Bad Length Short', '12345678901', actor_user=self.election_admin)
        with self.assertRaises(VoterValidationError):
            register_voter('Bad Length Long', '1234567890123', actor_user=self.election_admin)
        with self.assertRaises(VoterValidationError):
            register_voter('Non Digits', '12345678901A', actor_user=self.election_admin)
        with self.assertRaises(VoterValidationError):
            register_voter('Repeating Digits', '000000000000', actor_user=self.election_admin)
        with self.assertRaises(VoterValidationError):
            register_voter('Repeating Digits 9', '999999999999', actor_user=self.election_admin)
        with self.assertRaises(VoterValidationError):
            register_voter('', '551122334466', actor_user=self.election_admin)

        # 4. Verify audit log has masked Aadhaar (never exposes raw 12 digits)
        log = AdminAuditLog.objects.filter(target_model='Voter', target_id=str(voter.pk)).first()
        self.assertIsNotNone(log)
        self.assertEqual(log.action, 'VOTER_REGISTERED')
        self.assertIn('XXXXXXXX4455', log.details)
        self.assertNotIn('551122334455', log.details)

    def test_multiple_elections_per_voter_and_independent_voting_status(self):
        """
        Verify election-specific eligibility and status independence:
        - A voter can be assigned to multiple distinct elections via VoterEligibility.
        - Voting in Election A marks VoterEligibility(voter, Election A).has_voted = True,
          while VoterEligibility(voter, Election B).has_voted remains False.
        - The voter remains eligible and able to obtain permits for Election B.
        - Proves Voter.has_voted is NOT the authoritative status for new elections.
        """
        voter = register_voter(
            name='Rohan Verma',
            aadhar_number='661122334455',
            bound_wallet='0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC',
            actor_user=self.election_admin,
        )

        el_a = assign_voter_eligibility(self.election_a.pk, voter.pk, is_eligible=True, actor_user=self.election_admin)
        el_b = assign_voter_eligibility(self.election_b.pk, voter.pk, is_eligible=True, actor_user=self.election_admin)

        self.assertTrue(el_a.is_eligible)
        self.assertFalse(el_a.has_voted)
        self.assertTrue(el_b.is_eligible)
        self.assertFalse(el_b.has_voted)

        # Simulate voter casting confirmed vote in Election A
        el_a.has_voted = True
        el_a.voted_at = timezone.now()
        el_a.save()

        # Check independence: VoterEligibility for Election B is untouched
        el_b.refresh_from_db()
        self.assertFalse(el_b.has_voted)
        self.assertIsNone(el_b.voted_at)

        # Voter.has_voted on root model remains False (not used as authoritative status for new elections)
        voter.refresh_from_db()
        self.assertFalse(voter.has_voted)

    def test_duplicate_eligibility_prevention_and_uniqueness(self):
        """
        Verify that multiple eligibility assignments for the same voter-election pair
        are handled idempotently and unique_together prevents duplicate rows.
        """
        voter = register_voter(
            name='Neha Kapoor',
            aadhar_number='771122334455',
            actor_user=self.election_admin,
        )

        assign_voter_eligibility(self.election_a.pk, voter.pk, is_eligible=True, actor_user=self.election_admin)
        count_before = VoterEligibility.objects.filter(voter=voter, election=self.election_a).count()
        self.assertEqual(count_before, 1)

        # Re-assigning updates the existing record without creating a second record
        assign_voter_eligibility(self.election_a.pk, voter.pk, is_eligible=True, actor_user=self.election_admin)
        count_after = VoterEligibility.objects.filter(voter=voter, election=self.election_a).count()
        self.assertEqual(count_after, 1)

    def test_wallet_binding_duplicate_rejection_and_unauthorized_reassignment(self):
        """
        Verify 1-to-1 wallet-to-voter binding security:
        - Prevents binding a wallet that is already bound to another registered voter.
        - Prevents unauthorized wallet changes once a voter has cast confirmed ballots.
        - Allows authorized wallet reassignment with force=True and logs audit event.
        """
        wallet_1 = '0x90F79bf6EB2c4f870365E785982E1f101E93b906'
        wallet_2 = '0x15d34AAf54267DB7D7c367839AAf71A00a2C6A65'

        v1 = register_voter('Citizen One', '881122334455', bound_wallet=wallet_1, actor_user=self.election_admin)
        v2 = register_voter('Citizen Two', '881122334466', actor_user=self.election_admin)

        # 1. Attempting to bind wallet_1 to v2 fails (already bound to v1)
        with self.assertRaises(VoterValidationError):
            bind_or_update_voter_wallet(v2.pk, wallet_1, actor_user=self.election_admin)

        # 2. Mark v1 as having voted in Election A
        el_a = assign_voter_eligibility(self.election_a.pk, v1.pk, is_eligible=True, actor_user=self.election_admin)
        el_a.has_voted = True
        el_a.save()

        # 3. Attempting to reassign v1's wallet without force=True fails
        with self.assertRaises(VoterValidationError):
            bind_or_update_voter_wallet(v1.pk, wallet_2, force=False, actor_user=self.election_admin)

        # 4. Reassigning with force=True succeeds and logs VOTER_WALLET_REASSIGNED
        bind_or_update_voter_wallet(v1.pk, wallet_2, force=True, actor_user=self.election_admin)
        v1.refresh_from_db()
        self.assertEqual(v1.bound_wallet, wallet_2)

        log = AdminAuditLog.objects.filter(target_model='Voter', target_id=str(v1.pk), action='VOTER_WALLET_REASSIGNED').first()
        self.assertIsNotNone(log)

    def test_csv_synthetic_voter_import_validation_and_preview(self):
        """
        Verify synthetic voter CSV import validation and dry-run preview:
        - Processes valid new records, valid existing records, invalid records,
          duplicate records within file, and conflicting wallet records.
        - dry_run=True returns comprehensive preview metrics without modifying database.
        """
        # Pre-seed existing voters
        existing_voter = register_voter(
            name='Existing Citizen',
            aadhar_number='991122334455',
            bound_wallet='0x23618e81E3f5cdF7f54C3d65f7FBc0aBf5B21E8f',
            actor_user=self.election_admin,
        )
        conflict_voter = register_voter(
            name='Conflict Citizen',
            aadhar_number='881122334455',
            bound_wallet='0x90F79bf6EB2c4f870365E785982E1f101E93b906',
            actor_user=self.election_admin,
        )

        csv_data = (
            "name,aadhar_number,wallet_address\n"
            "Synthetic Alpha,112233445566,0xa0Ee7A142d267C1f36714E4a8F75612F20a79720\n"  # Valid new
            "Synthetic Beta,112233445577,\n"                                              # Valid new (no wallet)
            "Existing Citizen,991122334455,0x23618e81E3f5cdF7f54C3d65f7FBc0aBf5B21E8f\n"  # Valid existing (matching wallet)
            "Conflict Citizen,881122334455,0x70997970C51812dc3A010C7d01b50e0d17dc79C8\n"  # Conflict (existing voter with different wallet)
            "Dup Alpha,112233445566,0x14dC79964da2C08b23698B3D3cc7Ca32193d9955\n"         # Duplicate in file (Aadhaar repeated)
            "Malformed Aadhaar,12345,0x14dC79964da2C08b23698B3D3cc7Ca32193d9955\n"          # Invalid (short Aadhaar)
            ",223344556677,0x14dC79964da2C08b23698B3D3cc7Ca32193d9955\n"                  # Invalid (empty name)
        )

        initial_voter_count = Voter.objects.count()

        preview = import_synthetic_voters_from_csv(
            csv_content_or_file=csv_data,
            default_election_id=self.election_a.pk,
            assign_eligibility=True,
            dry_run=True,
            actor_user=self.election_admin,
        )

        self.assertTrue(preview['dry_run'])
        self.assertEqual(preview['valid_new_count'], 2)
        self.assertEqual(preview['valid_existing_count'], 1)
        self.assertEqual(preview['duplicate_in_file_count'], 1)
        self.assertEqual(preview['conflict_count'], 1)
        self.assertEqual(preview['invalid_count'], 2)

        # In dry run, zero new voter records were written to DB
        self.assertEqual(Voter.objects.count(), initial_voter_count)

    def test_csv_synthetic_voter_import_commit_and_transaction_rollback(self):
        """
        Verify synthetic voter CSV import execution (dry_run=False):
        - Successfully commits valid records with is_synthetic=True.
        - Assigns VoterEligibility for target election.
        - Verifies transaction rollback: simulated failure ensures zero partial corrupted records.
        """
        csv_data = (
            "name,aadhar_number,wallet_address\n"
            "Batch Voter 1,331122334455,0x9965507D1a55bcC2695C58ba16FB37d819B0A4df\n"
            "Batch Voter 2,331122334466,0x976EA74026E726554dB657fA54763abd0C3a0aa9\n"
        )

        commit_result = import_synthetic_voters_from_csv(
            csv_content_or_file=csv_data,
            default_election_id=self.election_a.pk,
            assign_eligibility=True,
            dry_run=False,
            actor_user=self.election_admin,
        )

        self.assertTrue(commit_result.get('committed'))
        self.assertEqual(commit_result['valid_new_count'], 2)
        self.assertEqual(commit_result['eligibilities_assigned'], 2)

        v1 = Voter.objects.get(aadhar_number='331122334455')
        self.assertTrue(v1.is_synthetic)
        self.assertTrue(VoterEligibility.objects.filter(voter=v1, election=self.election_a, is_eligible=True).exists())

        # Test Transaction Rollback: if an unexpected exception occurs during commit, atomic rollback leaves no orphans
        voters_before_fail = Voter.objects.count()
        bad_csv = (
            "name,aadhar_number,wallet_address\n"
            "Rollback Voter,441122334455,\n"
        )
        with patch('EVotingApp.models.VoterEligibility.objects.get_or_create', side_effect=RuntimeError("Simulated DB Disk Failure")):
            with self.assertRaises(RuntimeError):
                import_synthetic_voters_from_csv(
                    csv_content_or_file=bad_csv,
                    default_election_id=self.election_a.pk,
                    assign_eligibility=True,
                    dry_run=False,
                    actor_user=self.election_admin,
                )

        # Zero orphaned voter records created
        self.assertEqual(Voter.objects.count(), voters_before_fail)
        self.assertFalse(Voter.objects.filter(aadhar_number='441122334455').exists())

    def test_eligibility_enforcement_before_permit_issuance(self):
        """
        Verify that /api/ballot/permit/ strictly checks VoterEligibility:
        - Unregistered voter -> rejected with 403.
        - Registered voter not assigned to the election -> rejected with 403.
        - Registered voter whose eligibility is revoked (is_eligible=False) -> rejected with 403.
        - Registered voter who already cast a ballot in this election -> rejected with 409.
        """
        w3 = get_web3_provider()
        if not w3.is_connected():
            self.skipTest("Hardhat node not running")

        # Deploy, sync and activate election_a
        deploy_election_contract(self.election_a.pk, actor_user=self.election_admin)
        sync_and_lock_candidates(self.election_a.pk, lock_on_chain=True, actor_user=self.election_admin)
        activate_election(self.election_a.pk, actor_user=self.election_admin)

        wallet_address = '0x70997970C51812dc3A010C7d01b50e0d17dc79C8'
        session = self.client.session
        session['authenticated_wallet'] = wallet_address
        session.save()

        # 1. Unregistered voter
        res_unreg = self.client.post(
            '/api/ballot/permit/',
            data=json.dumps({
                'election_id': self.election_a.election_id,
                'candidate_id': 1,
                'aadhar': '999999999999',
            }),
            content_type='application/json',
        )
        self.assertEqual(res_unreg.status_code, 403)

        # 2. Registered voter NOT assigned to election_a
        voter = register_voter('Unassigned Voter', '121212121212', bound_wallet=wallet_address, actor_user=self.election_admin)
        res_not_assigned = self.client.post(
            '/api/ballot/permit/',
            data=json.dumps({
                'election_id': self.election_a.election_id,
                'candidate_id': 1,
                'aadhar': '121212121212',
            }),
            content_type='application/json',
        )
        self.assertEqual(res_not_assigned.status_code, 403)

        # 3. Voter assigned with is_eligible=False
        el = assign_voter_eligibility(self.election_a.pk, voter.pk, is_eligible=False, actor_user=self.election_admin)
        res_ineligible = self.client.post(
            '/api/ballot/permit/',
            data=json.dumps({
                'election_id': self.election_a.election_id,
                'candidate_id': 1,
                'aadhar': '121212121212',
            }),
            content_type='application/json',
        )
        self.assertEqual(res_ineligible.status_code, 403)

        # 4. Voter granted eligibility -> permit succeeds (200)
        assign_voter_eligibility(self.election_a.pk, voter.pk, is_eligible=True, actor_user=self.election_admin)
        res_ok = self.client.post(
            '/api/ballot/permit/',
            data=json.dumps({
                'election_id': self.election_a.election_id,
                'candidate_id': 1,
                'aadhar': '121212121212',
            }),
            content_type='application/json',
        )
        self.assertEqual(res_ok.status_code, 200)

        # 5. Voter already voted in this election -> permit rejected with 409
        el.refresh_from_db()
        el.has_voted = True
        el.save()
        res_voted = self.client.post(
            '/api/ballot/permit/',
            data=json.dumps({
                'election_id': self.election_a.election_id,
                'candidate_id': 1,
                'aadhar': '121212121212',
            }),
            content_type='application/json',
        )
        self.assertEqual(res_voted.status_code, 409)

    def test_eligibility_lifecycle_guards_and_revocation_restrictions(self):
        """
        Verify lifecycle and revocation guards on voter eligibility:
        - Cannot assign or modify eligibility on CLOSED or FINALIZED elections.
        - Cannot revoke eligibility for a voter who has already cast a confirmed ballot.
        """
        voter = register_voter('Guarded Voter', '232323232323', actor_user=self.election_admin)
        el = assign_voter_eligibility(self.election_a.pk, voter.pk, is_eligible=True, actor_user=self.election_admin)

        # Mark voter has_voted in this election
        el.has_voted = True
        el.save()

        # Revocation must be rejected with VoterEligibilityError
        with self.assertRaises(VoterEligibilityError):
            revoke_voter_eligibility(self.election_a.pk, voter.pk, actor_user=self.election_admin)

        # When election is CLOSED or FINALIZED, eligibility operations are rejected
        self.election_a.status = 'CLOSED'
        self.election_a.save()

        with self.assertRaises(VoterEligibilityError):
            assign_voter_eligibility(self.election_a.pk, voter.pk, is_eligible=True, actor_user=self.election_admin)

    def test_rbac_and_audit_logging_for_voter_and_eligibility_management(self):
        """
        Verify election-level RBAC and audit logging for voter management APIs:
        - Auditor can view GET /voters/ but is rejected with 403 on all mutations.
        - Election Admin can add voters and import CSV for assigned election, but is blocked (403) from other elections.
        - Super Admin can manage all elections.
        - AdminAuditLog entries created with masked Aadhaar numbers.
        """
        # 1. Auditor read-only test
        self.client.login(username='voter_auditor', password='password123')
        get_res = self.client.get(f'/api/control/elections/{self.election_a.election_id}/voters/')
        self.assertEqual(get_res.status_code, 200)

        # Auditor write attempt -> 403
        add_res = self.client.post(
            f'/api/control/elections/{self.election_a.election_id}/voters/add/',
            data=json.dumps({'name': 'Auditor Rogue', 'aadhar': '998877665544'}),
            content_type='application/json',
        )
        self.assertEqual(add_res.status_code, 403)

        # 2. Unassigned Admin attempt on election_a -> 403
        self.client.login(username='unassigned_voter_admin', password='password123')
        unassigned_res = self.client.post(
            f'/api/control/elections/{self.election_a.election_id}/voters/add/',
            data=json.dumps({'name': 'Unassigned Rogue', 'aadhar': '998877665544'}),
            content_type='application/json',
        )
        self.assertEqual(unassigned_res.status_code, 403)

        # 3. Assigned Election Admin attempt on election_a -> 201
        self.client.login(username='voter_admin', password='password123')
        valid_add = self.client.post(
            f'/api/control/elections/{self.election_a.election_id}/voters/add/',
            data=json.dumps({'name': 'Authorized Voter', 'aadhar': '998877665544'}),
            content_type='application/json',
        )
        self.assertEqual(valid_add.status_code, 201, valid_add.content)
        created_voter_id = valid_add.json()['voter']['id']
        self.assertEqual(valid_add.json()['voter']['aadhar_masked'], 'XXXXXXXX5544')

        # 4. Eligibility update via API
        elig_update = self.client.post(
            f'/api/control/elections/{self.election_a.election_id}/voters/{created_voter_id}/eligibility/',
            data=json.dumps({'is_eligible': False}),
            content_type='application/json',
        )
        self.assertEqual(elig_update.status_code, 200)
        self.assertFalse(elig_update.json()['is_eligible'])

        # 5. CSV Import via API (dry_run=True)
        csv_preview = self.client.post(
            f'/api/control/elections/{self.election_a.election_id}/voters/import-csv/',
            data=json.dumps({
                'csv_content': "name,aadhar_number\nAPI Synthetic 1,778899001122\nAPI Synthetic 2,778899001133\n",
                'dry_run': True,
            }),
            content_type='application/json',
        )
        self.assertEqual(csv_preview.status_code, 200)
        self.assertEqual(csv_preview.json()['valid_new_count'], 2)

        # 6. Audit log check
        voter_logs = AdminAuditLog.objects.filter(target_model='Voter', target_id=str(created_voter_id))
        self.assertTrue(voter_logs.exists())
        self.assertIn('XXXXXXXX5544', voter_logs.first().details)
        self.assertNotIn('998877665544', voter_logs.first().details)
