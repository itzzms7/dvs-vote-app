"""
Module 6 Automated Verification Suite (21 Tests):
- WebAuthn / Passkey Registration, Step-Up, and Atomic Challenge Consumption
- Discoverable Credential Identity Resolution & Opaque userHandle Cross-Check
- 4-Case Authenticator Counter Matrix (Zero-Counter, Initial, Reset, Regression)
- Credential Revocation, Last-Credential Guard, and Super Admin vs Election Admin Boundaries
- Pluggable Identity Providers (Internal Local, Simulated External, Genuine External)
- Complete SSRF & DNS Rebinding Protections + JWS Cryptographic Signature Verification
- Staged Pending Onboarding, Conditional Uniqueness, and Atomic Approval without Wallet Auto-Binding
- Strict Separation between Passkey Authentication, Wallet Ownership (EIP-191), and Ballot Permits (EIP-712)
"""

import time
import json
import cbor2
import socket
import hashlib
import secrets
import threading
from datetime import timedelta

from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature

from django.test import TestCase, Client
from django.conf import settings
from django.utils import timezone
from django.db import IntegrityError
from django.db.models.deletion import ProtectedError
from django.contrib.auth.models import User, Group
from eth_account import Account
from eth_account.messages import encode_defunct
from webauthn.helpers import bytes_to_base64url, base64url_to_bytes

from .models import (
    Voter,
    Election,
    Candidate,
    VoterEligibility,
    ElectionAdminAssignment,
    AdminAuditLog,
    WebAuthnCredential,
    WebAuthnChallenge,
    PendingVoterOnboarding,
    ExternalProviderVerificationRecord,
)
from .webauthn_service import (
    consume_webauthn_challenge,
    WebAuthnChallengeError,
    archive_voter_account,
)
from .providers import (
    PROVIDER_TYPE_INTERNAL_LOCAL,
    PROVIDER_TYPE_SIMULATED_EXTERNAL,
    PROVIDER_TYPE_GENUINE_EXTERNAL,
    is_ip_forbidden_for_ssrf,
    validate_outbound_provider_destination,
    pinned_dns_context,
    verify_provider_jws_token,
    derive_provider_reference_hash,
    acquire_onboarding_lease,
    finalize_onboarding_approval,
    approve_pending_onboarding,
    reject_pending_onboarding,
    OnboardingStateError,
    ProviderSSRFError,
    ProviderJWSVerificationError,
    _b64url_encode,
)
from .services import (
    deploy_election_contract,
    configure_voting_window,
    add_election_candidate,
    sync_and_lock_candidates,
    activate_election,
    assign_voter_eligibility,
)


def build_mock_webauthn_keypair():
    """Generate a real ECDSA P-256 keypair and its CBOR-encoded COSE Key."""
    priv = ec.generate_private_key(ec.SECP256R1())
    pub_nums = priv.public_key().public_numbers()
    x_bytes = pub_nums.x.to_bytes(32, 'big')
    y_bytes = pub_nums.y.to_bytes(32, 'big')
    cose_key_bytes = cbor2.dumps({
        1: 2,    # kty: EC2
        3: -7,   # alg: ES256
        -1: 1,   # crv: P-256
        -2: x_bytes,
        -3: y_bytes,
    })
    return priv, cose_key_bytes


def build_registration_credential_payload(
    challenge_b64url: str,
    cose_key_bytes: bytes,
    cred_id_bytes: bytes = None,
    rp_id: str = 'localhost',
    origin: str = 'http://localhost:3000',
    up: bool = True,
    uv: bool = True,
    sign_count: int = 0,
) -> tuple:
    """Build a valid W3C WebAuthn RegistrationCredential JSON dictionary."""
    cred_id = cred_id_bytes or secrets.token_bytes(16)
    aaguid = bytes(16)
    rp_id_hash = hashlib.sha256(rp_id.encode('utf-8')).digest()
    flags = (1 << 6)  # AT (attested credential data present)
    if up:
        flags |= (1 << 0)
    if uv:
        flags |= (1 << 2)

    attested_data = aaguid + len(cred_id).to_bytes(2, 'big') + cred_id + cose_key_bytes
    auth_data = rp_id_hash + bytes([flags]) + int(sign_count).to_bytes(4, 'big') + attested_data
    att_obj = cbor2.dumps({'fmt': 'none', 'attStmt': {}, 'authData': auth_data})

    client_data = json.dumps({
        'type': 'webauthn.create',
        'challenge': challenge_b64url,
        'origin': origin,
        'crossOrigin': False,
    }).encode('utf-8')

    cred_id_b64 = bytes_to_base64url(cred_id)
    payload = {
        'id': cred_id_b64,
        'rawId': cred_id_b64,
        'type': 'public-key',
        'response': {
            'attestationObject': bytes_to_base64url(att_obj),
            'clientDataJSON': bytes_to_base64url(client_data),
            'transports': ['internal'],
        },
    }
    return cred_id_b64, payload


def build_authentication_credential_payload(
    challenge_b64url: str,
    cred_id_b64: str,
    priv_key,
    rp_id: str = 'localhost',
    origin: str = 'http://localhost:3000',
    up: bool = True,
    uv: bool = True,
    sign_count: int = 0,
    user_handle_hex: str = None,
    tamper_signature: bool = False,
) -> dict:
    """Build a cryptographically signed W3C WebAuthn AuthenticationCredential JSON dictionary."""
    rp_id_hash = hashlib.sha256(rp_id.encode('utf-8')).digest()
    flags = 0
    if up:
        flags |= (1 << 0)
    if uv:
        flags |= (1 << 2)

    auth_data = rp_id_hash + bytes([flags]) + int(sign_count).to_bytes(4, 'big')
    client_data = json.dumps({
        'type': 'webauthn.get',
        'challenge': challenge_b64url,
        'origin': origin,
        'crossOrigin': False,
    }).encode('utf-8')

    sig_base = auth_data + hashlib.sha256(client_data).digest()
    sig = priv_key.sign(sig_base, ec.ECDSA(hashes.SHA256()))
    if tamper_signature:
        sig = sig[:-1] + bytes([sig[-1] ^ 0xFF])

    response_dict = {
        'authenticatorData': bytes_to_base64url(auth_data),
        'clientDataJSON': bytes_to_base64url(client_data),
        'signature': bytes_to_base64url(sig),
    }
    if user_handle_hex is not None:
        response_dict['userHandle'] = bytes_to_base64url(bytes.fromhex(user_handle_hex))

    return {
        'id': cred_id_b64,
        'rawId': cred_id_b64,
        'type': 'public-key',
        'response': response_dict,
    }


class Module6WebAuthnAndProvidersTests(TestCase):
    """Comprehensive 21-test suite for Module 6: Passkeys (WebAuthn) & External Identity Providers."""

    def setUp(self):
        self.super_group, _ = Group.objects.get_or_create(name='Super Admin')
        self.admin_group, _ = Group.objects.get_or_create(name='Election Administrator')
        self.auditor_group, _ = Group.objects.get_or_create(name='Auditor')

        self.super_admin = User.objects.create_superuser(
            username='mod6_super', password='password123', email='super@dvs.local'
        )
        self.super_admin.groups.add(self.super_group)

        self.election_admin = User.objects.create_user(
            username='mod6_eladmin', password='password123'
        )
        self.election_admin.groups.add(self.admin_group)

        self.unassigned_admin = User.objects.create_user(
            username='mod6_unassigned', password='password123'
        )
        self.unassigned_admin.groups.add(self.admin_group)

        self.auditor = User.objects.create_user(
            username='mod6_auditor', password='password123'
        )
        self.auditor.groups.add(self.auditor_group)

        self.election = Election.objects.create(
            title='Module 6 General Election',
            election_id=6001,
            status='DRAFT',
            created_by=self.super_admin,
        )
        ElectionAdminAssignment.objects.create(
            election=self.election, user=self.election_admin, role='ELECTION_ADMIN'
        )
        ElectionAdminAssignment.objects.create(
            election=self.election, user=self.auditor, role='AUDITOR'
        )

        # Create a test voter with a known Ethereum private key & wallet
        self.voter_eth_acct = Account.create('MOD6_VOTER_SEED_1')
        self.voter = Voter.objects.create(
            name='Aarav Sharma',
            aadhar_number='451245124512',
            bound_wallet=self.voter_eth_acct.address,
            is_synthetic=True,
        )

        self.other_eth_acct = Account.create('MOD6_VOTER_SEED_2')
        self.other_voter = Voter.objects.create(
            name='Diya Verma',
            aadhar_number='781278127812',
            bound_wallet=self.other_eth_acct.address,
            is_synthetic=True,
        )

    def _authenticate_voter_wallet(self, client: Client, eth_acct) -> dict:
        """Complete EIP-191 wallet challenge verification to establish an authenticated voter session."""
        chal_res = client.get('/api/wallet/challenge/', {'address': eth_acct.address}, HTTP_HOST='localhost:3000')
        self.assertEqual(chal_res.status_code, 200)
        chal_data = chal_res.json()
        signed = Account.sign_message(encode_defunct(text=chal_data['challenge']), eth_acct.key)
        ver_res = client.post(
            '/api/wallet/verify/',
            data=json.dumps({
                'address': eth_acct.address,
                'nonce': chal_data['nonce'],
                'signature': signed.signature.hex(),
            }),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(ver_res.status_code, 200)
        return ver_res.json()

    # =========================================================================
    # GROUP 1: WEBAUTHN CHALLENGE, REGISTRATION & CONCURRENCY (6 TESTS)
    # =========================================================================

    def test_01_webauthn_registration_options_requires_authenticated_voter(self):
        """Unauthenticated requests to /api/auth/passkey/register/options/ are rejected with 401."""
        c = Client()
        res = c.post('/api/auth/passkey/register/options/', HTTP_HOST='localhost:3000')
        self.assertEqual(res.status_code, 401)

    def test_02_registration_challenge_atomic_conditional_consumption(self):
        """Verify conditional atomic challenge consumption prevents replay and cross-session reuse."""
        c = Client()
        self._authenticate_voter_wallet(c, self.voter_eth_acct)
        opt_res = c.post('/api/auth/passkey/register/options/', HTTP_HOST='localhost:3000')
        self.assertEqual(opt_res.status_code, 200)
        challenge_b64 = opt_res.json()['challenge']
        session_key = c.session.session_key

        # Cross-session attempt must fail
        with self.assertRaises(WebAuthnChallengeError):
            consume_webauthn_challenge(
                challenge_b64url=challenge_b64,
                expected_type='REGISTRATION',
                session_key='wrong-session-key-12345',
                expected_voter_id=self.voter.pk,
            )

        # First valid consumption succeeds
        consumed = consume_webauthn_challenge(
            challenge_b64url=challenge_b64,
            expected_type='REGISTRATION',
            session_key=session_key,
            expected_voter_id=self.voter.pk,
        )
        self.assertTrue(consumed.is_used)
        self.assertIsNotNone(consumed.consumed_at)

        # Immediate replay of consumed challenge must fail
        with self.assertRaises(WebAuthnChallengeError):
            consume_webauthn_challenge(
                challenge_b64url=challenge_b64,
                expected_type='REGISTRATION',
                session_key=session_key,
                expected_voter_id=self.voter.pk,
            )

    def test_03_unauthorized_passkey_registration_blocked(self):
        """Reject any attempt to register a passkey against another voter's ID."""
        c = Client()
        self._authenticate_voter_wallet(c, self.voter_eth_acct)
        opt_res = c.post('/api/auth/passkey/register/options/', HTTP_HOST='localhost:3000')
        self.assertEqual(opt_res.status_code, 200)
        challenge_b64 = opt_res.json()['challenge']

        _, cose_key = build_mock_webauthn_keypair()
        _, reg_payload = build_registration_credential_payload(challenge_b64, cose_key)

        # Attempt to pass other_voter.pk in request body
        ver_res = c.post(
            '/api/auth/passkey/register/verify/',
            data=json.dumps({
                'voter_id': self.other_voter.pk,
                'credential': reg_payload,
            }),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(ver_res.status_code, 403)
        self.assertEqual(WebAuthnCredential.objects.filter(voter=self.other_voter).count(), 0)

    def test_04_subsequent_passkey_registration_requires_stepup(self):
        """Enrolling a second passkey requires fresh step-up authentication within 5 minutes."""
        c = Client()
        self._authenticate_voter_wallet(c, self.voter_eth_acct)

        # Enroll first passkey
        opt1 = c.post('/api/auth/passkey/register/options/', HTTP_HOST='localhost:3000').json()
        _, cose1 = build_mock_webauthn_keypair()
        _, reg1 = build_registration_credential_payload(opt1['challenge'], cose1)
        res1 = c.post(
            '/api/auth/passkey/register/verify/',
            data=json.dumps({'credential': reg1, 'device_label': 'Primary Key'}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(res1.status_code, 200)

        # Expire step_up_authenticated_at in session
        session = c.session
        session['step_up_authenticated_at'] = int(time.time()) - 900
        session.save()

        # Attempt to request options for a second passkey without fresh step-up -> 403 STEP_UP_REQUIRED
        opt2_res = c.post('/api/auth/passkey/register/options/', HTTP_HOST='localhost:3000')
        self.assertEqual(opt2_res.status_code, 403)
        self.assertEqual(opt2_res.json().get('code'), 'STEP_UP_REQUIRED')

        # Re-authenticate wallet (fresh step-up) -> second passkey enrollment succeeds
        self._authenticate_voter_wallet(c, self.voter_eth_acct)
        opt2_ok = c.post('/api/auth/passkey/register/options/', HTTP_HOST='localhost:3000')
        self.assertEqual(opt2_ok.status_code, 200)

    def test_05_successful_passkey_registration_and_opaque_user_handle(self):
        """Verify opaque userHandle is 32-byte random hex (never voter.id or Aadhaar) and COSE key is saved."""
        self.assertEqual(len(self.voter.webauthn_user_handle), 64)
        self.assertNotIn(str(self.voter.aadhar_number), self.voter.webauthn_user_handle)

        c = Client()
        self._authenticate_voter_wallet(c, self.voter_eth_acct)
        opt_res = c.post('/api/auth/passkey/register/options/', HTTP_HOST='localhost:3000')
        self.assertEqual(opt_res.status_code, 200)
        opt_data = opt_res.json()

        # Verify user.id in options decodes to voter.webauthn_user_handle
        returned_user_id_hex = base64url_to_bytes(opt_data['user']['id']).hex()
        self.assertEqual(returned_user_id_hex, self.voter.webauthn_user_handle)

        _, cose_key = build_mock_webauthn_keypair()
        _, reg_payload = build_registration_credential_payload(opt_data['challenge'], cose_key)
        ver_res = c.post(
            '/api/auth/passkey/register/verify/',
            data=json.dumps({'credential': reg_payload, 'device_label': 'MacBook Touch ID'}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(ver_res.status_code, 200)
        cred = WebAuthnCredential.objects.get(voter=self.voter)
        self.assertEqual(cred.device_label, 'MacBook Touch ID')
        self.assertEqual(cred.public_key_cose_hex, cose_key.hex())
        self.assertTrue(cred.registered_with_uv)

    def test_06_malicious_origin_and_host_header_rejected(self):
        """Reject WebAuthn requests with poisoned Host headers or untrusted phishing origins."""
        c = Client()
        self._authenticate_voter_wallet(c, self.voter_eth_acct)

        # Poisoned Host header rejected
        bad_host_res = c.post('/api/auth/passkey/register/options/', HTTP_HOST='evil-phishing.org')
        self.assertEqual(bad_host_res.status_code, 400)

        # Valid options, but attestation signed on phishing origin rejected
        opt_res = c.post('/api/auth/passkey/register/options/', HTTP_HOST='localhost:3000').json()
        _, cose_key = build_mock_webauthn_keypair()
        _, phishing_payload = build_registration_credential_payload(
            opt_res['challenge'],
            cose_key,
            origin='https://evil-phishing.org',
        )
        ver_res = c.post(
            '/api/auth/passkey/register/verify/',
            data=json.dumps({'credential': phishing_payload}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(ver_res.status_code, 400)
        self.assertEqual(WebAuthnCredential.objects.count(), 0)

    # =========================================================================
    # GROUP 2: WEBAUTHN ASSERTION, COUNTER SEMANTICS & REVOCATION (6 TESTS)
    # =========================================================================

    def _enroll_voter_passkey(self, voter_acct, sign_count=0, uv=True):
        c = Client()
        self._authenticate_voter_wallet(c, voter_acct)
        opt = c.post('/api/auth/passkey/register/options/', HTTP_HOST='localhost:3000').json()
        priv, cose_key = build_mock_webauthn_keypair()
        cred_id_b64, reg_payload = build_registration_credential_payload(
            opt['challenge'], cose_key, sign_count=sign_count, uv=uv
        )
        res = c.post(
            '/api/auth/passkey/register/verify/',
            data=json.dumps({'credential': reg_payload, 'device_label': 'Test Key'}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(res.status_code, 200)
        return priv, cred_id_b64

    def test_07_successful_passkey_authentication_and_userhandle_crosscheck(self):
        """
        Verify discoverable credential authentication:
        - Resolves Voter from credential.voter (never from userHandle alone).
        - Rejects mismatched userHandle.
        - Cycles session key on success.
        """
        priv, cred_id_b64 = self._enroll_voter_passkey(self.voter_eth_acct, sign_count=1)

        # 1. Mismatched userHandle (pointing to other_voter) must be rejected with 401
        auth_client = Client()
        opt1 = auth_client.post('/api/auth/passkey/authenticate/options/', HTTP_HOST='localhost:3000').json()
        bad_handle_payload = build_authentication_credential_payload(
            challenge_b64url=opt1['challenge'],
            cred_id_b64=cred_id_b64,
            priv_key=priv,
            sign_count=2,
            user_handle_hex=self.other_voter.webauthn_user_handle,
        )
        bad_res = auth_client.post(
            '/api/auth/passkey/authenticate/verify/',
            data=json.dumps({'credential': bad_handle_payload}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(bad_res.status_code, 401)
        self.assertTrue(
            AdminAuditLog.objects.filter(action='AUTHENTICATOR_USERHANDLE_MISMATCH').exists()
        )

        # 2. Valid userHandle matching voter.webauthn_user_handle succeeds and cycles session
        opt2 = auth_client.post('/api/auth/passkey/authenticate/options/', HTTP_HOST='localhost:3000').json()
        pre_auth_session_key = auth_client.session.session_key
        good_payload = build_authentication_credential_payload(
            challenge_b64url=opt2['challenge'],
            cred_id_b64=cred_id_b64,
            priv_key=priv,
            sign_count=2,
            user_handle_hex=self.voter.webauthn_user_handle,
        )
        good_res = auth_client.post(
            '/api/auth/passkey/authenticate/verify/',
            data=json.dumps({'credential': good_payload}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(good_res.status_code, 200)
        self.assertEqual(good_res.json()['voter_id'], self.voter.pk)
        self.assertNotEqual(auth_client.session.session_key, pre_auth_session_key)

    def test_08_zero_counter_platform_authenticator_and_zero_reset_cases(self):
        """
        Verify Counter Evaluation Cases A, B, and C:
        - Case A: stored=0, incoming=0 -> Accepted (zero-counter platform authenticator).
        - Case B: stored=0, incoming=5 -> Accepted, stored updated to 5.
        - Case C: stored=5, incoming=0 -> Accepted, stored kept at 5, informational notice logged, NOT flagged as clone.
        """
        priv, cred_id_b64 = self._enroll_voter_passkey(self.voter_eth_acct, sign_count=0)
        c = Client()

        # Case A: 0 -> 0
        opt_a = c.post('/api/auth/passkey/authenticate/options/', HTTP_HOST='localhost:3000').json()
        pay_a = build_authentication_credential_payload(opt_a['challenge'], cred_id_b64, priv, sign_count=0)
        res_a = c.post(
            '/api/auth/passkey/authenticate/verify/',
            data=json.dumps({'credential': pay_a}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(res_a.status_code, 200)
        cred = WebAuthnCredential.objects.get(credential_id=cred_id_b64)
        self.assertEqual(cred.sign_count, 0)
        self.assertFalse(cred.clone_warning_flag)

        # Case B: 0 -> 5
        opt_b = c.post('/api/auth/passkey/authenticate/options/', HTTP_HOST='localhost:3000').json()
        pay_b = build_authentication_credential_payload(opt_b['challenge'], cred_id_b64, priv, sign_count=5)
        res_b = c.post(
            '/api/auth/passkey/authenticate/verify/',
            data=json.dumps({'credential': pay_b}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(res_b.status_code, 200)
        cred.refresh_from_db()
        self.assertEqual(cred.sign_count, 5)

        # Case C: 5 -> 0 (Zero reset / platform proxy)
        opt_c = c.post('/api/auth/passkey/authenticate/options/', HTTP_HOST='localhost:3000').json()
        pay_c = build_authentication_credential_payload(opt_c['challenge'], cred_id_b64, priv, sign_count=0)
        res_c = c.post(
            '/api/auth/passkey/authenticate/verify/',
            data=json.dumps({'credential': pay_c}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(res_c.status_code, 200)
        cred.refresh_from_db()
        self.assertEqual(cred.sign_count, 5)
        self.assertFalse(cred.clone_warning_flag)
        self.assertTrue(AdminAuditLog.objects.filter(action='PASSKEY_COUNTER_ZERO_NOTICE').exists())

    def test_09_counter_regression_flags_anomaly_and_rejects(self):
        """
        Verify Counter Evaluation Case D2:
        When stored_count > 0 and incoming_count > 0 and incoming_count <= stored_count:
        - Assertion is rejected with 401.
        - Credential is immediately suspended (is_active=False, revoked_at set, clone_warning_flag=True).
        - AUTHENTICATOR_COUNTER_ANOMALY is audited with credential_suspended=True.
        - Subsequent attempts with the compromised credential (even with higher counter) are rejected.
        - Voter can recover via EIP-191 wallet verification and enroll a new passkey without reactivating the compromised credential.
        """
        priv, cred_id_b64 = self._enroll_voter_passkey(self.voter_eth_acct, sign_count=10)
        c = Client()

        # Regression: stored=10, incoming=7
        opt = c.post('/api/auth/passkey/authenticate/options/', HTTP_HOST='localhost:3000').json()
        pay = build_authentication_credential_payload(opt['challenge'], cred_id_b64, priv, sign_count=7)
        res = c.post(
            '/api/auth/passkey/authenticate/verify/',
            data=json.dumps({'credential': pay}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(res.status_code, 401)
        cred = WebAuthnCredential.objects.get(credential_id=cred_id_b64)
        self.assertFalse(cred.is_active)
        self.assertIsNotNone(cred.revoked_at)
        self.assertTrue(cred.clone_warning_flag)
        self.assertEqual(cred.anomaly_count, 1)
        anomaly_log = AdminAuditLog.objects.filter(action='AUTHENTICATOR_COUNTER_ANOMALY').first()
        self.assertIsNotNone(anomaly_log)
        self.assertTrue(json.loads(anomaly_log.details)['credential_suspended'])

        # Attempt to use compromised credential again with a higher counter (15) -> still rejected (401)
        opt2 = c.post('/api/auth/passkey/authenticate/options/', HTTP_HOST='localhost:3000').json()
        pay2 = build_authentication_credential_payload(opt2['challenge'], cred_id_b64, priv, sign_count=15)
        res2 = c.post(
            '/api/auth/passkey/authenticate/verify/',
            data=json.dumps({'credential': pay2}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(res2.status_code, 401)

        # Recovery via Aadhaar + MetaMask EIP-191 wallet verification succeeds and allows enrolling a new passkey
        _, new_cred_id_b64 = self._enroll_voter_passkey(self.voter_eth_acct, sign_count=1)
        cred.refresh_from_db()
        self.assertFalse(cred.is_active)
        self.assertTrue(WebAuthnCredential.objects.get(credential_id=new_cred_id_b64).is_active)

    def test_10_user_verification_flag_enforced_when_required(self):
        """
        When require_uv=True or step_up=True is requested, UV is checked strictly from the
        current ceremony's authenticator flags (registered_with_uv=True cannot bypass UV=0).
        """
        priv, cred_id_b64 = self._enroll_voter_passkey(self.voter_eth_acct, sign_count=1, uv=True)
        c = Client()
        # Request step_up=True even without explicit require_uv=True -> must force UV=required
        opt = c.post(
            '/api/auth/passkey/authenticate/options/',
            data=json.dumps({'step_up': True}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        ).json()
        self.assertEqual(opt.get('userVerification'), 'required')

        # Assertion with UV=False must fail even though cred.registered_with_uv is True
        pay_no_uv = build_authentication_credential_payload(
            opt['challenge'], cred_id_b64, priv, sign_count=2, uv=False
        )
        res = c.post(
            '/api/auth/passkey/authenticate/verify/',
            data=json.dumps({'credential': pay_no_uv, 'step_up': True}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(res.status_code, 401)

    def test_11_revoked_passkey_authentication_rejected(self):
        """An inactive/revoked credential cannot be used to authenticate."""
        priv, cred_id_b64 = self._enroll_voter_passkey(self.voter_eth_acct, sign_count=1)
        cred = WebAuthnCredential.objects.get(credential_id=cred_id_b64)
        cred.is_active = False
        cred.save(update_fields=['is_active'])

        c = Client()
        opt = c.post('/api/auth/passkey/authenticate/options/', HTTP_HOST='localhost:3000').json()
        pay = build_authentication_credential_payload(opt['challenge'], cred_id_b64, priv, sign_count=2)
        res = c.post(
            '/api/auth/passkey/authenticate/verify/',
            data=json.dumps({'credential': pay}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(res.status_code, 401)

    def test_12_last_credential_revocation_protection_and_recovery(self):
        """
        Revoking a voter's sole active passkey requires confirm_disable_passkey=True
        and transitions cleanly to WALLET_ONLY mode while preserving EIP-191 wallet recovery.
        """
        self._enroll_voter_passkey(self.voter_eth_acct, sign_count=1)
        cred = WebAuthnCredential.objects.get(voter=self.voter)

        c = Client()
        self._authenticate_voter_wallet(c, self.voter_eth_acct)

        # Without confirm_disable_passkey=True -> rejected with 400
        res_block = c.post(
            f'/api/auth/passkey/{cred.pk}/revoke/',
            data=json.dumps({'confirm_disable_passkey': False}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(res_block.status_code, 400)
        cred.refresh_from_db()
        self.assertTrue(cred.is_active)

        # With confirm_disable_passkey=True -> revoked, auth_mode == WALLET_ONLY
        res_ok = c.post(
            f'/api/auth/passkey/{cred.pk}/revoke/',
            data=json.dumps({'confirm_disable_passkey': True}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(res_ok.status_code, 200)
        self.assertEqual(res_ok.json()['auth_mode'], 'WALLET_ONLY')
        cred.refresh_from_db()
        self.assertFalse(cred.is_active)

    # =========================================================================
    # GROUP 3: EXTERNAL PROVIDERS, SSRF, JWS & STAGED ONBOARDING (6 TESTS)
    # =========================================================================

    def test_13_provider_discovery_and_classification(self):
        """Verify provider discovery distinguishes INTERNAL_LOCAL, SIMULATED_EXTERNAL, and GENUINE_EXTERNAL."""
        c = Client()
        res = c.get('/api/identity/providers/')
        self.assertEqual(res.status_code, 200)
        by_id = {p['id']: p for p in res.json()['providers']}

        self.assertEqual(by_id['local_database']['provider_type'], PROVIDER_TYPE_INTERNAL_LOCAL)
        self.assertFalse(by_id['local_database']['is_simulated'])

        self.assertEqual(by_id['simulated_civic_registry']['provider_type'], PROVIDER_TYPE_SIMULATED_EXTERNAL)
        self.assertTrue(by_id['simulated_civic_registry']['is_simulated'])

        self.assertEqual(by_id['genuine_national_gateway']['provider_type'], PROVIDER_TYPE_GENUINE_EXTERNAL)
        self.assertFalse(by_id['genuine_national_gateway']['is_simulated'])

    def test_14_provider_ssrf_and_dns_rebind_rejection(self):
        """
        Verify SSRF protections block:
        - HTTP non-TLS URLs
        - IPv4 loopback (127.0.0.1) & IPv6 loopback (::1)
        - Cloud metadata (169.254.169.254, metadata.google.internal) & link-local (169.254.0.10, fe80::1, fe80::1%eth0)
        - IPv4-mapped IPv6 (::ffff:127.0.0.1), 6to4 (2002:7f00:0001::1), and Teredo
        - RFC 1918 private networks (10.x, 192.168.x) and IPv6 unique-local (fd00::1)
        - DNS rebinding to private IPs & socket connection pinning via pinned_dns_context
        - Browser-controlled URL parameters in /api/control/elections/<id>/identity/verify/
        """
        forbidden_urls = [
            'http://identity-gateway.example.org/verify',
            'https://127.0.0.1/verify',
            'https://[::1]/verify',
            'https://[::ffff:127.0.0.1]/verify',
            'https://169.254.169.254/latest/meta-data/',
            'https://169.254.0.10/internal',
            'https://metadata.google.internal/computeMetadata/v1/',
            'https://10.0.0.1/internal',
            'https://192.168.1.1/admin',
            'https://[fd00::1]/internal',
            'https://[2002:7f00:0001::1]/rebind6to4',
        ]
        for bad_url in forbidden_urls:
            with self.assertRaises(ProviderSSRFError):
                validate_outbound_provider_destination(bad_url)

        self.assertTrue(is_ip_forbidden_for_ssrf('fe80::1%eth0'))
        self.assertTrue(is_ip_forbidden_for_ssrf('2001:0000:4136:e378:8000:63bf:f8f7:f6fe'))

        # Simulated DNS rebinding resolver returning 127.0.0.1 for external hostname
        def rebinding_resolver(host, port, proto=0):
            return [(2, 1, 6, '', ('127.0.0.1', port))]

        with self.assertRaises(ProviderSSRFError):
            validate_outbound_provider_destination(
                'https://external-provider.example.org/verify',
                resolver_fn=rebinding_resolver,
            )

        # Verify pinned_dns_context forces socket.getaddrinfo to return the pinned global IP
        # and blocks resolution of any unexpected redirect hostname
        import socket
        with pinned_dns_context('external-provider.example.org', '93.184.216.34', 443):
            res_info = socket.getaddrinfo('external-provider.example.org', 443)
            self.assertEqual(res_info[0][4][0], '93.184.216.34')
            with self.assertRaises(ProviderSSRFError):
                socket.getaddrinfo('evil-redirect.internal', 443)

        # Verify browser-supplied URL parameter is rejected with 400 SSRF_BLOCKED
        c = Client()
        c.force_login(self.election_admin)
        url_inject_res = c.post(
            f'/api/control/elections/{self.election.election_id}/identity/verify/',
            data=json.dumps({
                'provider_id': 'simulated_civic_registry',
                'identifier': '612361236123',
                'parameters': {'endpoint_url': 'https://169.254.169.254/latest/meta-data/'},
            }),
            content_type='application/json',
        )
        self.assertEqual(url_inject_res.status_code, 400)
        self.assertEqual(url_inject_res.json().get('code'), 'SSRF_BLOCKED')

    def test_15_provider_response_creates_pending_onboarding_without_eligibility(self):
        """
        Verify that a positive external provider verification stages a PendingVoterOnboarding
        record (with conditional uniqueness) and NEVER creates a Voter or VoterEligibility automatically.
        """
        c = Client()
        c.force_login(self.election_admin)

        new_aadhar = '612361236123'
        res1 = c.post(
            f'/api/control/elections/{self.election.election_id}/identity/verify/',
            data=json.dumps({
                'provider_id': 'simulated_civic_registry',
                'identifier': new_aadhar,
                'parameters': {
                    'scenario': 'VALID',
                    'full_name': 'Meera Nair',
                    'claimed_wallet': '0x70997970C51812dc3A010C7d01b50e0d17dc79C8',
                },
            }),
            content_type='application/json',
        )
        self.assertEqual(res1.status_code, 200)
        data1 = res1.json()
        self.assertTrue(data1['is_verified'])
        self.assertIsNotNone(data1['pending_onboarding'])
        onboarding_id = data1['pending_onboarding']['onboarding_id']

        # Voter does NOT exist yet and has ZERO eligibility
        self.assertFalse(Voter.objects.filter(aadhar_number=new_aadhar).exists())
        self.assertEqual(VoterEligibility.objects.filter(election=self.election).count(), 0)

        # Plaintext Aadhaar is NOT stored in PendingVoterOnboarding
        pending_obj = PendingVoterOnboarding.objects.get(pk=onboarding_id)
        self.assertEqual(pending_obj.masked_identifier, 'XXXXXXXX6123')
        self.assertNotIn(new_aadhar, pending_obj.encrypted_identity_payload)

        # Duplicate active pending request returns the same pending onboarding idempotently
        res2 = c.post(
            f'/api/control/elections/{self.election.election_id}/identity/verify/',
            data=json.dumps({
                'provider_id': 'simulated_civic_registry',
                'identifier': new_aadhar,
                'parameters': {'scenario': 'VALID', 'full_name': 'Meera Nair'},
            }),
            content_type='application/json',
        )
        self.assertEqual(res2.status_code, 200)
        self.assertEqual(res2.json()['pending_onboarding']['onboarding_id'], onboarding_id)

    def test_16_administrative_approval_creates_voter_without_autobinding_wallet(self):
        """
        Verify atomic administrative approval:
        - Transitions PendingVoterOnboarding to APPROVED and clears encrypted_identity_payload.
        - Creates Voter record with bound_wallet=None (untrusted provider wallet claim is NEVER auto-bound).
        - Does NOT automatically grant election eligibility.
        - Subsequent duplicate approval attempt is rejected with 409.
        """
        c = Client()
        c.force_login(self.election_admin)
        new_aadhar = '654365436543'
        untrusted_wallet = '0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC'

        ver_res = c.post(
            f'/api/control/elections/{self.election.election_id}/identity/verify/',
            data=json.dumps({
                'provider_id': 'simulated_civic_registry',
                'identifier': new_aadhar,
                'parameters': {
                    'scenario': 'VALID',
                    'full_name': 'Rohan Joshi',
                    'claimed_wallet': untrusted_wallet,
                },
            }),
            content_type='application/json',
        ).json()
        onboarding_id = ver_res['pending_onboarding']['onboarding_id']

        # Approve pending onboarding (after first testing AES-GCM tamper rollback & stale PROCESSING recovery)
        pending_pre = PendingVoterOnboarding.objects.get(pk=onboarding_id)
        valid_cipher_json = pending_pre.encrypted_identity_payload

        # 1. Tamper with AES-256-GCM authentication tag -> approval fails (409) and rolls back status to PENDING_REVIEW
        tampered_dict = json.loads(valid_cipher_json)
        tampered_dict['t'] = _b64url_encode(b'\x00' * 16)
        PendingVoterOnboarding.objects.filter(pk=onboarding_id).update(
            encrypted_identity_payload=json.dumps(tampered_dict)
        )
        tamper_res = c.post(
            f'/api/control/elections/{self.election.election_id}/onboarding/{onboarding_id}/review/',
            data=json.dumps({'decision': 'APPROVE'}),
            content_type='application/json',
        )
        self.assertEqual(tamper_res.status_code, 409)
        pending_pre.refresh_from_db()
        self.assertEqual(pending_pre.status, 'PENDING_REVIEW')
        self.assertFalse(Voter.objects.filter(aadhar_number=new_aadhar).exists())

        # 2. Restore valid ciphertext and simulate a stale PROCESSING state (>60s old) -> recovery succeeds
        PendingVoterOnboarding.objects.filter(pk=onboarding_id).update(
            encrypted_identity_payload=valid_cipher_json,
            status='PROCESSING',
            reviewed_at=timezone.now() - timedelta(seconds=120),
        )

        app_res = c.post(
            f'/api/control/elections/{self.election.election_id}/onboarding/{onboarding_id}/review/',
            data=json.dumps({'decision': 'APPROVE'}),
            content_type='application/json',
        )
        self.assertEqual(app_res.status_code, 200)
        app_data = app_res.json()
        self.assertEqual(app_data['status'], 'APPROVED')
        self.assertIsNone(app_data['bound_wallet'])
        self.assertTrue(app_data['is_synthetic'])

        # Verify encrypted payload was logically cleared
        pending_obj = PendingVoterOnboarding.objects.get(pk=onboarding_id)
        self.assertEqual(pending_obj.encrypted_identity_payload, '')

        # Verify Voter created with bound_wallet=None and zero eligibilities
        voter = Voter.objects.get(aadhar_number=new_aadhar)
        self.assertIsNone(voter.bound_wallet)
        self.assertEqual(VoterEligibility.objects.filter(voter=voter).count(), 0)

        # Second approval attempt on already-approved record fails with 409
        dup_res = c.post(
            f'/api/control/elections/{self.election.election_id}/onboarding/{onboarding_id}/review/',
            data=json.dumps({'decision': 'APPROVE'}),
            content_type='application/json',
        )
        self.assertEqual(dup_res.status_code, 409)

    def test_17_synthetic_vs_genuine_record_classification_and_jws_verification(self):
        """
        Verify JWS signature validation, replay protection, untrusted header rejection,
        and genuine (is_synthetic=False) vs simulated (is_synthetic=True) voter classification.
        """
        priv = ec.generate_private_key(ec.SECP256R1())
        pub_pem = priv.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        ).decode('utf-8')

        kid = 'authority-key-2026-v1'
        trusted_keys = {kid: pub_pem}
        genuine_aadhar = '891289128912'
        ref_hash = derive_provider_reference_hash('genuine_national_gateway', genuine_aadhar)
        now_ts = int(time.time())

        header = {'alg': 'ES256', 'kid': kid, 'typ': 'JWT'}
        payload = {
            'iss': settings.IDENTITY_PROVIDER_ISSUER,
            'aud': settings.IDENTITY_PROVIDER_AUDIENCE,
            'sub_hash': ref_hash,
            'verified': True,
            'full_name': 'Kavita Iyer',
            'is_citizen': True,
            'age_qualified': True,
            'electoral_district_code': 'IND-KA-01',
            'iat': now_ts,
            'exp': now_ts + 300,
            'jti': 'jws-nonce-' + secrets.token_hex(8),
        }

        h_b64 = _b64url_encode(json.dumps(header).encode('utf-8'))
        p_b64 = _b64url_encode(json.dumps(payload).encode('utf-8'))
        der_sig = priv.sign(f"{h_b64}.{p_b64}".encode('ascii'), ec.ECDSA(hashes.SHA256()))
        r, s = decode_dss_signature(der_sig)
        raw_sig = r.to_bytes(32, 'big') + s.to_bytes(32, 'big')
        jws_token = f"{h_b64}.{p_b64}.{_b64url_encode(raw_sig)}"

        # 1. Untrusted header 'jku' must be rejected
        bad_hdr = _b64url_encode(json.dumps({'alg': 'ES256', 'kid': kid, 'jku': 'https://evil.com/jwks.json'}).encode('utf-8'))
        with self.assertRaises(ProviderJWSVerificationError):
            verify_provider_jws_token(f"{bad_hdr}.{p_b64}.{_b64url_encode(raw_sig)}", trusted_public_keys=trusted_keys)

        # 2. Valid JWS through GenuineExternalIdentityProvider stages onboarding with is_synthetic=False
        with self.settings(IDENTITY_PROVIDER_PUBLIC_KEYS=trusted_keys):
            c = Client()
            c.force_login(self.election_admin)
            ver_res = c.post(
                f'/api/control/elections/{self.election.election_id}/identity/verify/',
                data=json.dumps({
                    'provider_id': 'genuine_national_gateway',
                    'identifier': genuine_aadhar,
                    'parameters': {'jws_assertion': jws_token},
                }),
                content_type='application/json',
            )
            self.assertEqual(ver_res.status_code, 200)
            vdata = ver_res.json()
            self.assertTrue(vdata['is_verified'])
            self.assertFalse(vdata['is_simulated'])
            self.assertFalse(vdata['pending_onboarding']['is_synthetic'])

            # Approve genuine onboarding -> Voter has is_synthetic=False
            onb_id = vdata['pending_onboarding']['onboarding_id']
            app_res = c.post(
                f'/api/control/elections/{self.election.election_id}/onboarding/{onb_id}/review/',
                data=json.dumps({'decision': 'APPROVE'}),
                content_type='application/json',
            )
            self.assertEqual(app_res.status_code, 200)
            genuine_voter = Voter.objects.get(aadhar_number=genuine_aadhar)
            self.assertFalse(genuine_voter.is_synthetic)

            # 3. Replaying the same JWS token (same jti) must fail verification
            replay_res = c.post(
                f'/api/control/elections/{self.election.election_id}/identity/verify/',
                data=json.dumps({
                    'provider_id': 'genuine_national_gateway',
                    'identifier': genuine_aadhar,
                    'parameters': {'jws_assertion': jws_token},
                }),
                content_type='application/json',
            ).json()
            self.assertFalse(replay_res['is_verified'])
            self.assertEqual(replay_res['failure_code'], 'SIGNATURE_VERIFICATION_FAILED')

    def test_18_auditor_and_election_admin_permission_boundaries(self):
        """
        Verify strict RBAC boundaries:
        - Auditor can GET masked verification records (200) but receives 403 on provider verify, onboarding review, and security flag.
        - Unassigned Election Admin receives 403 on another election's endpoints.
        - Election Admin can flag suspected compromised voter security (suspending election eligibility),
          but CANNOT invoke Super Admin account-wide passkey suspension (403).
        - Super Admin CAN invoke account-wide passkey suspension (200).
        """
        self._enroll_voter_passkey(self.voter_eth_acct, sign_count=1)
        assign_voter_eligibility(
            election_db_id=self.election.pk,
            voter_id=self.voter.pk,
            actor_user=self.election_admin,
        )

        # 1. Auditor checks
        aud_client = Client()
        aud_client.force_login(self.auditor)
        get_rec = aud_client.get(f'/api/control/elections/{self.election.election_id}/identity/records/')
        self.assertEqual(get_rec.status_code, 200)

        post_ver = aud_client.post(
            f'/api/control/elections/{self.election.election_id}/identity/verify/',
            data=json.dumps({'provider_id': 'local_database', 'identifier': self.voter.aadhar_number}),
            content_type='application/json',
        )
        self.assertEqual(post_ver.status_code, 403)

        # 2. Unassigned admin blocked (403)
        un_client = Client()
        un_client.force_login(self.unassigned_admin)
        un_res = un_client.get(f'/api/control/elections/{self.election.election_id}/identity/records/')
        self.assertEqual(un_res.status_code, 403)

        # 3. Election Admin cannot call Super Admin account-wide passkey suspension (403)
        adm_client = Client()
        adm_client.force_login(self.election_admin)
        susp_denied = adm_client.post(
            f'/api/control/voters/{self.voter.pk}/suspend-passkeys/',
            data=json.dumps({'reason': 'Attempt by election admin'}),
            content_type='application/json',
        )
        self.assertEqual(susp_denied.status_code, 403)

        # Election Admin CAN flag voter security for their assigned election
        flag_ok = adm_client.post(
            f'/api/control/elections/{self.election.election_id}/voters/{self.voter.pk}/flag-security/',
            data=json.dumps({'reason': 'Suspected compromised device at polling station', 'suspend_election_eligibility': True}),
            content_type='application/json',
        )
        self.assertEqual(flag_ok.status_code, 200)
        self.assertTrue(flag_ok.json()['election_eligibility_suspended'])
        self.assertTrue(WebAuthnCredential.objects.filter(voter=self.voter, is_active=True).exists())

        # 4. Super Admin CAN suspend account-wide passkeys
        sup_client = Client()
        sup_client.force_login(self.super_admin)
        susp_ok = sup_client.post(
            f'/api/control/voters/{self.voter.pk}/suspend-passkeys/',
            data=json.dumps({'reason': 'Confirmed security escalation'}),
            content_type='application/json',
        )
        self.assertEqual(susp_ok.status_code, 200)
        self.assertFalse(WebAuthnCredential.objects.filter(voter=self.voter, is_active=True).exists())

    # =========================================================================
    # GROUP 4: VOTING & BLOCKCHAIN SEPARATION REGRESSIONS (3 TESTS)
    # =========================================================================

    def test_19_passkey_alone_cannot_bypass_metamask_permit(self):
        """
        Critical Architectural Constraint:
        A voter authenticated ONLY via Passkey (without an active EIP-191 MetaMask wallet session)
        must be rejected (401) when requesting an EIP-712 ballot permit.
        """
        priv, cred_id_b64 = self._enroll_voter_passkey(self.voter_eth_acct, sign_count=1)

        # Fresh client: authenticate ONLY via Passkey
        passkey_only_client = Client()
        opt = passkey_only_client.post('/api/auth/passkey/authenticate/options/', HTTP_HOST='localhost:3000').json()
        pay = build_authentication_credential_payload(opt['challenge'], cred_id_b64, priv, sign_count=2)
        auth_res = passkey_only_client.post(
            '/api/auth/passkey/authenticate/verify/',
            data=json.dumps({'credential': pay}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(auth_res.status_code, 200)
        self.assertFalse(auth_res.json()['wallet_session_active'])

        # Attempt to request ballot permit without MetaMask wallet authentication -> 401
        permit_res = passkey_only_client.post(
            '/api/ballot/permit/',
            data=json.dumps({
                'aadhar': self.voter.aadhar_number,
                'candidate_id': 1,
                'election_id': self.election.election_id,
            }),
            content_type='application/json',
        )
        self.assertEqual(permit_res.status_code, 401)

    def test_20_voter_deletion_protection_preserves_credentials_and_audits(self):
        """
        Verify that Voter deletion is blocked by models.PROTECT when WebAuthnCredential exists,
        and that archive_voter_account cleanly retires the voter while preserving credential history.
        """
        self._enroll_voter_passkey(self.voter_eth_acct, sign_count=1)

        with self.assertRaises(ProtectedError):
            self.voter.delete()

        res = archive_voter_account(
            voter_id=self.voter.pk,
            actor_user=self.super_admin,
            reason='Statutory post-election archival',
        )
        self.assertEqual(res['status'], 'ARCHIVED')
        self.voter.refresh_from_db()
        self.assertEqual(self.voter.status, 'ARCHIVED')
        # Historical credential row is preserved in DB with is_active=False
        self.assertEqual(WebAuthnCredential.objects.filter(voter=self.voter).count(), 1)
        self.assertFalse(WebAuthnCredential.objects.get(voter=self.voter).is_active)

    def test_21_existing_eip712_and_evm_workflow_intact(self):
        """
        End-to-end regression test proving that a voter who authenticates with Passkey AND
        MetaMask EIP-191 wallet challenge can obtain an EIP-712 ballot permit for an ACTIVE
        election after explicit VoterEligibility assignment.
        """
        # 1. Deploy, configure window, add & lock candidate, and activate election
        deploy_election_contract(self.election.pk, actor_user=self.election_admin)
        now = timezone.now()
        configure_voting_window(
            election_db_id=self.election.pk,
            start_datetime=now - timedelta(minutes=5),
            end_datetime=now + timedelta(hours=2),
            actor_user=self.election_admin,
        )
        add_election_candidate(
            election_db_id=self.election.pk,
            candidate_id_num=101,
            name='Dr. Vikram Sarabhai',
            symbol='Rocket',
            actor_user=self.election_admin,
        )
        sync_and_lock_candidates(self.election.pk, actor_user=self.election_admin)
        activate_election(self.election.pk, actor_user=self.election_admin)

        # 2. Assign VoterEligibility
        assign_voter_eligibility(
            election_db_id=self.election.pk,
            voter_id=self.voter.pk,
            actor_user=self.election_admin,
        )

        # 3. Enroll passkey, authenticate with passkey, and verify MetaMask wallet
        priv, cred_id_b64 = self._enroll_voter_passkey(self.voter_eth_acct, sign_count=1)
        c = Client()
        opt = c.post('/api/auth/passkey/authenticate/options/', HTTP_HOST='localhost:3000').json()
        pay = build_authentication_credential_payload(opt['challenge'], cred_id_b64, priv, sign_count=2)
        c.post(
            '/api/auth/passkey/authenticate/verify/',
            data=json.dumps({'credential': pay}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self._authenticate_voter_wallet(c, self.voter_eth_acct)

        # 4. Request EIP-712 ballot permit -> 200 OK
        permit_res = c.post(
            '/api/ballot/permit/',
            data=json.dumps({
                'aadhar': self.voter.aadhar_number,
                'candidate_id': 101,
                'election_id': self.election.election_id,
            }),
            content_type='application/json',
        )
        self.assertEqual(permit_res.status_code, 200)
        p_data = permit_res.json()['permit']
        self.assertEqual(p_data['candidateId'], 101)
        self.assertEqual(p_data['voterWallet'].lower(), self.voter.bound_wallet.lower())

    # =========================================================================
    # GROUP 5: FINAL CONCURRENCY VERIFICATION (2 TESTS)
    # =========================================================================

    def test_22_onboarding_processing_lease_reclamation_race(self):
        """
        Task 1 Concurrency Verification:
        Proves that when Worker 1's PROCESSING lease expires (>60s) and Worker 2 reclaims
        the onboarding record with a new claim token:
        1. While Worker 1's lease is active (<60s), Worker 2 cannot reclaim it.
        2. Once Worker 1's lease expires (>60s), Worker 2 reclaims it and obtains a distinct
           claim token, overwriting and invalidating Worker 1's claim token.
        3. Worker 1 (expired worker) is blocked from finalizing approval or rejection with its
           stale claim token, both while Worker 2 holds PROCESSING and after Worker 2 finalizes.
        4. Worker 2 (current claim holder) cleanly finalizes approval exactly once.
        """
        c = Client()
        c.force_login(self.election_admin)
        lease_aadhar = '741274127412'

        ver_res = c.post(
            f'/api/control/elections/{self.election.election_id}/identity/verify/',
            data=json.dumps({
                'provider_id': 'simulated_civic_registry',
                'identifier': lease_aadhar,
                'parameters': {
                    'scenario': 'VALID',
                    'full_name': 'Siddharth Rao',
                },
            }),
            content_type='application/json',
        ).json()
        onboarding_id = ver_res['pending_onboarding']['onboarding_id']

        # Step 1: Worker 1 acquires the processing lease
        worker1_token = acquire_onboarding_lease(
            onboarding_id=onboarding_id,
            reviewing_admin_user=self.election_admin,
        )
        self.assertTrue(len(worker1_token) == 32)
        pending_obj = PendingVoterOnboarding.objects.get(pk=onboarding_id)
        self.assertEqual(pending_obj.status, 'PROCESSING')
        self.assertEqual(pending_obj.processing_claim_token, worker1_token)

        # Step 2: While Worker 1's lease is active (<60s), Worker 2 cannot reclaim it
        with self.assertRaises(OnboardingStateError):
            acquire_onboarding_lease(
                onboarding_id=onboarding_id,
                reviewing_admin_user=self.super_admin,
            )

        # Step 3: Simulate Worker 1 stalling past the 60-second lease window
        PendingVoterOnboarding.objects.filter(pk=onboarding_id).update(
            reviewed_at=timezone.now() - timedelta(seconds=65)
        )

        # Worker 2 now reclaims the stale PROCESSING record and gets a new claim token
        worker2_token = acquire_onboarding_lease(
            onboarding_id=onboarding_id,
            reviewing_admin_user=self.super_admin,
        )
        self.assertNotEqual(worker1_token, worker2_token)
        pending_obj.refresh_from_db()
        self.assertEqual(pending_obj.status, 'PROCESSING')
        self.assertEqual(pending_obj.processing_claim_token, worker2_token)

        # Step 4: Worker 1 wakes up and attempts to finalize approval or rejection using its
        # invalidated claim token -> MUST fail with OnboardingStateError without mutating state
        with self.assertRaises(OnboardingStateError):
            finalize_onboarding_approval(
                onboarding_id=onboarding_id,
                claim_token=worker1_token,
                reviewing_admin_user=self.election_admin,
            )
        with self.assertRaises(OnboardingStateError):
            approve_pending_onboarding(
                onboarding_id=onboarding_id,
                reviewing_admin_user=self.election_admin,
                claim_token=worker1_token,
            )
        with self.assertRaises(OnboardingStateError):
            reject_pending_onboarding(
                onboarding_id=onboarding_id,
                reviewing_admin_user=self.election_admin,
                reason='Stale worker rejection attempt',
                claim_token=worker1_token,
            )

        # Record is still held by Worker 2 in PROCESSING state, and Voter is not created yet
        pending_obj.refresh_from_db()
        self.assertEqual(pending_obj.status, 'PROCESSING')
        self.assertEqual(pending_obj.processing_claim_token, worker2_token)
        self.assertFalse(Voter.objects.filter(aadhar_number=lease_aadhar).exists())

        # Step 5: Worker 2 finalizes approval using its valid worker2_token
        result = finalize_onboarding_approval(
            onboarding_id=onboarding_id,
            claim_token=worker2_token,
            reviewing_admin_user=self.super_admin,
        )
        self.assertEqual(result['status'], 'APPROVED')
        self.assertTrue(Voter.objects.filter(aadhar_number=lease_aadhar).exists())

        pending_obj.refresh_from_db()
        self.assertEqual(pending_obj.status, 'APPROVED')
        self.assertEqual(pending_obj.processing_claim_token, '')
        self.assertEqual(pending_obj.encrypted_identity_payload, '')

        # Step 6: Late retry by Worker 1 after Worker 2 finalized is also rejected
        with self.assertRaises(OnboardingStateError):
            finalize_onboarding_approval(
                onboarding_id=onboarding_id,
                claim_token=worker1_token,
                reviewing_admin_user=self.election_admin,
            )

    def test_23_concurrent_dns_pinning_thread_isolation(self):
        """
        Task 2 Concurrency Verification:
        Proves that simultaneous multi-threaded executions of pinned_dns_context() are
        strictly isolated per thread/context:
        - Thread A pins host-a.example.org -> 93.184.216.34
        - Thread B pins host-b.example.org -> 93.184.216.35
        - Synchronized at a barrier while both contexts are active simultaneously:
          * Thread A resolves host-a.example.org to 93.184.216.34 and rejects host-b.example.org.
          * Thread B resolves host-b.example.org to 93.184.216.35 and rejects host-a.example.org.
          * Even if two concurrent threads pin the same hostname to different validated IPs,
            each thread receives only its own pinned IP.
        """
        barrier = threading.Barrier(2, timeout=5.0)
        results = {}
        errors = []

        def worker_a():
            try:
                with pinned_dns_context('host-a.example.org', '93.184.216.34', 443):
                    barrier.wait()
                    info = socket.getaddrinfo('host-a.example.org', 443)
                    results['a_own_ip'] = info[0][4][0]
                    try:
                        socket.getaddrinfo('host-b.example.org', 443)
                        results['a_cross_blocked'] = False
                    except ProviderSSRFError:
                        results['a_cross_blocked'] = True
                    barrier.wait()
            except Exception as exc:
                errors.append(f"worker_a: {exc!r}")

        def worker_b():
            try:
                with pinned_dns_context('host-b.example.org', '93.184.216.35', 443):
                    barrier.wait()
                    info = socket.getaddrinfo('host-b.example.org', 443)
                    results['b_own_ip'] = info[0][4][0]
                    try:
                        socket.getaddrinfo('host-a.example.org', 443)
                        results['b_cross_blocked'] = False
                    except ProviderSSRFError:
                        results['b_cross_blocked'] = True
                    barrier.wait()
            except Exception as exc:
                errors.append(f"worker_b: {exc!r}")

        t1 = threading.Thread(target=worker_a)
        t2 = threading.Thread(target=worker_b)
        t1.start()
        t2.start()
        t1.join(timeout=10.0)
        t2.join(timeout=10.0)

        self.assertEqual(errors, [])
        self.assertEqual(results.get('a_own_ip'), '93.184.216.34')
        self.assertEqual(results.get('b_own_ip'), '93.184.216.35')
        self.assertTrue(results.get('a_cross_blocked'))
        self.assertTrue(results.get('b_cross_blocked'))

        # Also verify same-hostname concurrent pinning with distinct validated IPs never cross-contaminates
        barrier_same = threading.Barrier(2, timeout=5.0)
        same_host_ips = {}

        def same_host_worker(key, ip):
            with pinned_dns_context('shared-gateway.example.org', ip, 443):
                barrier_same.wait()
                res = socket.getaddrinfo('shared-gateway.example.org', 443)
                same_host_ips[key] = res[0][4][0]
                barrier_same.wait()

        ts1 = threading.Thread(target=same_host_worker, args=('w1', '93.184.216.40'))
        ts2 = threading.Thread(target=same_host_worker, args=('w2', '93.184.216.41'))
        ts1.start()
        ts2.start()
        ts1.join(timeout=10.0)
        ts2.join(timeout=10.0)

        self.assertEqual(same_host_ips.get('w1'), '93.184.216.40')
        self.assertEqual(same_host_ips.get('w2'), '93.184.216.41')

