/**
 * Module 6 & Module 7 Phase 5 — Browser WebAuthn (Passkey) Bridge.
 * Preserves passkey authentication and programmatic registration/revocation API helpers.
 */
window.DVSWebAuthn = (function () {
    'use strict';

    function getCsrfToken() {
        var match = document.cookie.match(/(?:^|;\s*)csrftoken=([^;]*)/);
        if (match) return decodeURIComponent(match[1]);
        var input = document.querySelector('input[name="csrfmiddlewaretoken"]');
        return input ? input.value : '';
    }

    function base64urlToBuffer(b64url) {
        var padding = '='.repeat((4 - (b64url.length % 4)) % 4);
        var base64 = (b64url + padding).replace(/-/g, '+').replace(/_/g, '/');
        var raw = window.atob(base64);
        var bytes = new Uint8Array(raw.length);
        for (var i = 0; i < raw.length; i++) {
            bytes[i] = raw.charCodeAt(i);
        }
        return bytes.buffer;
    }

    function bufferToBase64url(buffer) {
        var bytes = new Uint8Array(buffer);
        var binary = '';
        for (var i = 0; i < bytes.byteLength; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return window.btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    }

    function showFeedback(elId, message, type) {
        var el = document.getElementById(elId || 'passkey-feedback');
        if (!el) return;
        if (!message) {
            el.textContent = '';
            el.className = 'feedback-panel';
            return;
        }
        el.textContent = message;
        el.className = 'feedback-panel is-visible feedback-' + (type || 'info');
    }

    function isWebAuthnSupported() {
        return Boolean(
            window.PublicKeyCredential &&
            navigator.credentials &&
            typeof navigator.credentials.create === 'function' &&
            typeof navigator.credentials.get === 'function'
        );
    }

    function updatePasskeyBadge(text, statusClass) {
        var badge = document.getElementById('passkey-status-badge');
        if (!badge) return;
        badge.textContent = text;
        badge.className = 'status-badge ' + statusClass;
    }

    async function enrollPasskey(customLabel) {
        if (!isWebAuthnSupported()) {
            showFeedback('passkey-feedback', 'Passkeys are not supported on this device.', 'warning');
            return false;
        }

        var deviceLabel = customLabel || 'Personal Device Passkey';

        try {
            var optResp = await fetch('/api/auth/passkey/register/options/', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                body: JSON.stringify({})
            });
            var options = await optResp.json();
            if (!optResp.ok) {
                showFeedback('passkey-feedback', options.error || 'Could not start passkey registration.', 'error');
                return false;
            }

            options.challenge = base64urlToBuffer(options.challenge);
            options.user.id = base64urlToBuffer(options.user.id);
            if (Array.isArray(options.excludeCredentials)) {
                options.excludeCredentials = options.excludeCredentials.map(function (item) {
                    return Object.assign({}, item, { id: base64urlToBuffer(item.id) });
                });
            }

            var credential = await navigator.credentials.create({ publicKey: options });
            var transports = [];
            if (credential.response && typeof credential.response.getTransports === 'function') {
                transports = credential.response.getTransports();
            }

            var payload = {
                device_label: deviceLabel,
                credential: {
                    id: credential.id,
                    rawId: bufferToBase64url(credential.rawId),
                    type: credential.type,
                    response: {
                        attestationObject: bufferToBase64url(credential.response.attestationObject),
                        clientDataJSON: bufferToBase64url(credential.response.clientDataJSON),
                        transports: transports
                    }
                }
            };

            var verifyResp = await fetch('/api/auth/passkey/register/verify/', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                body: JSON.stringify(payload)
            });
            var result = await verifyResp.json();
            if (!verifyResp.ok) {
                showFeedback('passkey-feedback', result.error || 'Passkey registration failed.', 'error');
                return false;
            }

            updatePasskeyBadge('Verified', 'status-authenticated');
            showFeedback('passkey-feedback', 'Passkey registered.', 'success');
            return true;
        } catch (err) {
            showFeedback('passkey-feedback', 'Passkey registration cancelled.', 'warning');
            return false;
        }
    }

    async function authenticatePasskey(aadharHint, isStepUp) {
        if (!isWebAuthnSupported()) {
            showFeedback('passkey-feedback', 'Passkeys are not supported on this device. Enter your 12-digit Voter ID.', 'warning');
            return false;
        }

        showFeedback('passkey-feedback', 'Complete the passkey prompt on your device...', 'info');

        try {
            var optResp = await fetch('/api/auth/passkey/authenticate/options/', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                body: JSON.stringify({
                    aadhar: aadharHint || '',
                    step_up: Boolean(isStepUp)
                })
            });
            var options = await optResp.json();
            if (!optResp.ok) {
                showFeedback('passkey-feedback', options.error || 'Could not start passkey sign-in.', 'error');
                return false;
            }

            options.challenge = base64urlToBuffer(options.challenge);
            if (Array.isArray(options.allowCredentials)) {
                options.allowCredentials = options.allowCredentials.map(function (item) {
                    return Object.assign({}, item, { id: base64urlToBuffer(item.id) });
                });
            }

            var assertion = await navigator.credentials.get({ publicKey: options });
            var userHandleB64 = '';
            if (assertion.response && assertion.response.userHandle) {
                userHandleB64 = bufferToBase64url(assertion.response.userHandle);
            }

            var payload = {
                credential: {
                    id: assertion.id,
                    rawId: bufferToBase64url(assertion.rawId),
                    type: assertion.type,
                    response: {
                        authenticatorData: bufferToBase64url(assertion.response.authenticatorData),
                        clientDataJSON: bufferToBase64url(assertion.response.clientDataJSON),
                        signature: bufferToBase64url(assertion.response.signature),
                        userHandle: userHandleB64
                    }
                }
            };

            var verifyResp = await fetch('/api/auth/passkey/authenticate/verify/', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                body: JSON.stringify(payload)
            });
            var result = await verifyResp.json();
            if (!verifyResp.ok) {
                showFeedback('passkey-feedback', result.error || 'Passkey sign-in failed.', 'error');
                return false;
            }

            updatePasskeyBadge('Verified', 'status-authenticated');
            showFeedback('passkey-feedback', 'Identity verified.', 'success');

            if (window.DVSWallet && typeof window.DVSWallet.syncServerStatus === 'function') {
                await window.DVSWallet.syncServerStatus();
            }
            return true;
        } catch (err) {
            showFeedback('passkey-feedback', 'Passkey sign-in cancelled.', 'warning');
            return false;
        }
    }

    async function revokePasskey(credentialId, confirmDisableLast) {
        try {
            var resp = await fetch('/api/auth/passkey/' + encodeURIComponent(credentialId) + '/revoke/', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                body: JSON.stringify({ confirm_disable_passkey: Boolean(confirmDisableLast) })
            });
            return resp.ok;
        } catch (err) {
            return false;
        }
    }

    async function loadPasskeyList() {
        try {
            var resp = await fetch('/api/auth/passkey/list/', {
                method: 'GET',
                credentials: 'same-origin'
            });
            if (!resp.ok) return [];
            var data = await resp.json();
            return Array.isArray(data.passkeys) ? data.passkeys : [];
        } catch (err) {
            return [];
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        var authBtn = document.getElementById('btn-passkey-auth');
        if (authBtn) {
            authBtn.addEventListener('click', function () {
                var aadharInput = document.getElementById('input-aadhar');
                var hint = aadharInput ? aadharInput.value.trim() : '';
                authenticatePasskey(hint, false);
            });
        }
    });

    return {
        enrollPasskey: enrollPasskey,
        authenticatePasskey: authenticatePasskey,
        revokePasskey: revokePasskey,
        loadPasskeyList: loadPasskeyList,
        isWebAuthnSupported: isWebAuthnSupported
    };
})();
