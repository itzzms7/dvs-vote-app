(function () {
    'use strict';

    var EXPECTED_CHAIN_ID = '0x7a69';
    var EXPECTED_CHAIN_DECIMAL = 31337;
    var connectedAddress = '';
    var walletConnected = false;
    var voterAuthenticated = false;
    var submitting = false;

    function el(id) { return document.getElementById(id); }
    function csrfToken() {
        var input = document.querySelector('input[name="csrfmiddlewaretoken"]');
        if (input && input.value) return input.value;
        var match = document.cookie.match(/(?:^|;\s*)csrftoken=([^;]+)/);
        return match ? decodeURIComponent(match[1]) : '';
    }
    function showMessage(id, message, type) {
        var node = el(id);
        if (!node) return;
        node.textContent = message || '';
        node.className = 'feedback-panel' + (message ? ' is-visible' : '') + (type ? ' feedback-' + type : '');
    }
    function setBadge(id, label, connected) {
        var node = el(id);
        if (!node) return;
        node.textContent = label;
        node.className = 'status-badge ' + (connected ? 'status-authenticated' : 'status-disconnected');
    }
    function currentElectionId() {
        var root = el('voter-portal-root');
        return root ? parseInt(root.dataset.electionId || '0', 10) : 0;
    }
    function revealBallot() {
        var ballot = el('step-candidate-section');
        if (ballot) ballot.classList.remove('is-hidden');
        var connectNotice = el('metamask-notice');
        if (connectNotice) connectNotice.textContent = 'Wallet connected. You may now select a candidate.';
    }
    function openWalletModal(name) {
        var modal = el('modal-wallet-connect');
        var label = el('wallet-connect-voter-name');
        if (label) label.textContent = 'Eligibility confirmed for ' + name + '.';
        if (modal) {
            modal.classList.add('is-open');
            modal.setAttribute('aria-hidden', 'false');
        }
    }
    function closeWalletModal() {
        var modal = el('modal-wallet-connect');
        if (modal) {
            modal.classList.remove('is-open');
            modal.setAttribute('aria-hidden', 'true');
        }
    }
    function openReviewModal() {
        var modal = el('modal-ballot-review');
        var candidateId = el('input-candidate-id');
        var selected = document.querySelector('[data-candidate-card].is-selected');
        if (!selected || !candidateId || !candidateId.value) {
            showMessage('vote-feedback', 'Select a candidate before continuing.', 'error');
            return;
        }
        var name = selected.getAttribute('data-candidate-name') || 'Selected candidate';
        var symbol = selected.getAttribute('data-candidate-party') || '';
        if (el('review-modal-candidate-name')) el('review-modal-candidate-name').textContent = name;
        if (el('review-modal-candidate-party')) el('review-modal-candidate-party').textContent = symbol;
        if (el('review-modal-candidate-id')) el('review-modal-candidate-id').textContent = '#' + candidateId.value;
        if (modal) modal.classList.add('is-open');
    }
    function closeReviewModal() {
        var modal = el('modal-ballot-review');
        if (modal) modal.classList.remove('is-open');
    }
    async function ensureNetwork() {
        if (!window.ethereum) throw new Error('MetaMask is not available in this browser.');
        var chainId = await window.ethereum.request({ method: 'eth_chainId' });
        if (chainId.toLowerCase() === EXPECTED_CHAIN_ID) return;
        try {
            await window.ethereum.request({
                method: 'wallet_switchEthereumChain',
                params: [{ chainId: EXPECTED_CHAIN_ID }]
            });
        } catch (error) {
            if (error && error.code === 4902) {
                await window.ethereum.request({
                    method: 'wallet_addEthereumChain',
                    params: [{
                        chainId: EXPECTED_CHAIN_ID,
                        chainName: 'DVS Hardhat Local',
                        nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
                        rpcUrls: ['http://127.0.0.1:8545']
                    }]
                });
            } else {
                throw error;
            }
        }
        var confirmedChainId = await window.ethereum.request({ method: 'eth_chainId' });
        if (confirmedChainId.toLowerCase() !== EXPECTED_CHAIN_ID) {
            throw new Error('Switch MetaMask to DVS Hardhat Local (Chain ID 31337).');
        }
    }
    async function connectWallet() {
        if (!window.ethereum) throw new Error('Install or enable MetaMask to connect your wallet.');
        var accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        if (!accounts || !accounts.length) throw new Error('No wallet account was selected.');
        await ensureNetwork();
        connectedAddress = accounts[0];
        walletConnected = true;
        setBadge('wallet-status-badge', 'Connected', true);
        if (el('wallet-address-display')) el('wallet-address-display').textContent = connectedAddress;
        if (el('wallet-network-badge')) el('wallet-network-badge').textContent = 'DVS Hardhat · ' + EXPECTED_CHAIN_DECIMAL;
        showMessage('metamask-notice', 'Wallet connected.', 'success');
        closeWalletModal();
        revealBallot();
    }
    async function authenticateVoter() {
        var idInput = el('input-aadhar');
        var voterId = idInput ? idInput.value.trim() : '';
        if (!/^\d{12}$/.test(voterId)) {
            showMessage('voter-auth-feedback', 'Enter a valid 12-digit Voter ID.', 'error');
            if (idInput) idInput.focus();
            return;
        }
        var button = el('btn-voter-authenticate');
        if (button) { button.disabled = true; button.textContent = 'Checking…'; }
        try {
            var response = await fetch('/api/voter/authenticate/', {
                method: 'POST', credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken() },
                body: JSON.stringify({ voter_id: voterId, election_id: currentElectionId() })
            });
            var data = await response.json();
            if (!response.ok) throw new Error(data.error || 'Authentication failed.');
            voterAuthenticated = true;
            setBadge('voter-auth-status', 'Authenticated', true);
            if (el('voter-session-summary')) {
                el('voter-session-summary').textContent = 'Signed in as ' + data.voter_name + ' (' + data.voter_id_masked + ').';
            }
            showMessage('voter-auth-feedback', data.has_voted ? 'Your ballot is already recorded.' : 'Eligibility confirmed.', 'success');
            if (data.has_voted) { window.setTimeout(function () { window.location.reload(); }, 500); return; }
            openWalletModal(data.voter_name);
        } catch (error) {
            showMessage('voter-auth-feedback', error.message || 'Could not authenticate voter.', 'error');
        } finally {
            if (button) { button.disabled = false; button.textContent = 'Authenticate'; }
        }
    }
    async function submitVote() {
        if (submitting) return;
        if (!voterAuthenticated) {
            showMessage('vote-feedback', 'Authenticate before submitting your ballot.', 'error');
            return;
        }
        if (!walletConnected) {
            openWalletModal('your voter account');
            return;
        }
        var candidateInput = el('input-candidate-id');
        var candidateId = candidateInput ? parseInt(candidateInput.value, 10) : 0;
        if (!candidateId) {
            showMessage('vote-feedback', 'Select a candidate before submitting.', 'error');
            return;
        }
        submitting = true;
        var button = el('btn-confirm-submit-vote');
        var reviewButton = el('btn-review-ballot');
        if (button) { button.disabled = true; button.textContent = 'Submitting…'; }
        if (reviewButton) reviewButton.disabled = true;
        closeReviewModal();
        var progressPanel = el('ballot-tx-progress-panel');
        if (progressPanel) progressPanel.classList.add('is-visible');
        if (el('ballot-tx-stage-title')) el('ballot-tx-stage-title').textContent = 'Submitting your ballot. Please do not close this page.';
        try {
            var response = await fetch('/api/voter/cast/', {
                method: 'POST', credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken() },
                body: JSON.stringify({ election_id: currentElectionId(), candidate_id: candidateId })
            });
            var data = await response.json();
            if (!response.ok) throw new Error(data.error || 'Vote submission failed.');
            showMessage('vote-feedback', 'Vote recorded. Transaction confirmed in block ' + data.block_number + '.', 'success');
            if (el('ballot-tx-stage-title')) el('ballot-tx-stage-title').textContent = 'Vote confirmed';
            window.setTimeout(function () { window.location.reload(); }, 900);
        } catch (error) {
            showMessage('vote-feedback', error.message || 'Vote submission failed.', 'error');
            if (button) { button.disabled = false; button.textContent = 'Submit Vote'; }
            if (reviewButton) reviewButton.disabled = false;
        } finally {
            submitting = false;
        }
    }
    function bindCandidateSelection() {
        var cards = document.querySelectorAll('[data-candidate-card]');
        cards.forEach(function (card) {
            function selectCard() {
                cards.forEach(function (item) {
                    item.classList.remove('is-selected');
                    item.setAttribute('aria-checked', 'false');
                    var badge = item.querySelector('[data-candidate-badge]');
                    if (badge) { badge.textContent = 'Select'; badge.className = 'status-badge status-disconnected'; }
                });
                card.classList.add('is-selected');
                card.setAttribute('aria-checked', 'true');
                var badge = card.querySelector('[data-candidate-badge]');
                if (badge) { badge.textContent = 'Selected on Ballot'; badge.className = 'status-badge status-authenticated'; }
                var id = card.getAttribute('data-candidate-id');
                if (el('input-candidate-id')) el('input-candidate-id').value = id;
                if (el('selected-candidate-indicator')) el('selected-candidate-indicator').textContent = '#' + id + ' ' + card.getAttribute('data-candidate-name');
                if (el('ballot-selection-summary')) el('ballot-selection-summary').textContent = 'Selected: #' + id + ' ' + card.getAttribute('data-candidate-name') + ' (' + card.getAttribute('data-candidate-party') + ')';
                showMessage('vote-feedback', '', 'info');
            }
            card.addEventListener('click', selectCard);
            card.addEventListener('keydown', function (event) {
                if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); selectCard(); }
            });
        });
    }
    function bind() {
        var root = el('voter-portal-root');
        if (!root) return;
        var authenticateButton = el('btn-voter-authenticate');
        if (authenticateButton) authenticateButton.addEventListener('click', authenticateVoter);
        var connectButton = el('btn-modal-connect-wallet');
        if (connectButton) connectButton.addEventListener('click', async function () {
            connectButton.disabled = true;
            try { await connectWallet(); }
            catch (error) { showMessage('wallet-connect-feedback', error.message || 'Wallet connection failed.', 'error'); }
            finally { connectButton.disabled = false; }
        });
        var cancelWallet = el('btn-cancel-wallet-connect');
        if (cancelWallet) cancelWallet.addEventListener('click', closeWalletModal);
        var reviewButton = el('btn-review-ballot');
        if (reviewButton) reviewButton.addEventListener('click', openReviewModal);
        var cancelReview = el('btn-cancel-ballot-review');
        if (cancelReview) cancelReview.addEventListener('click', closeReviewModal);
        var confirmButton = el('btn-confirm-submit-vote');
        if (confirmButton) confirmButton.addEventListener('click', submitVote);
        bindCandidateSelection();

        if (root.dataset.sessionAuthenticated === 'true' && window.ethereum) {
            window.ethereum.request({ method: 'eth_accounts' }).then(async function (accounts) {
                if (!accounts || !accounts.length) return;
                await ensureNetwork();
                connectedAddress = accounts[0]; walletConnected = true; voterAuthenticated = true;
                setBadge('voter-auth-status', 'Authenticated', true);
                setBadge('wallet-status-badge', 'Connected', true);
                if (el('wallet-address-display')) el('wallet-address-display').textContent = connectedAddress;
                if (el('wallet-network-badge')) el('wallet-network-badge').textContent = 'DVS Hardhat · ' + EXPECTED_CHAIN_DECIMAL;
                revealBallot();
            }).catch(function () {});
        }
        if (window.ethereum && window.ethereum.on) {
            window.ethereum.on('accountsChanged', function (accounts) {
                if (!accounts || !accounts.length) {
                    connectedAddress = ''; walletConnected = false;
                    setBadge('wallet-status-badge', 'Not Connected', false);
                    if (el('wallet-address-display')) el('wallet-address-display').textContent = 'No wallet connected';
                    var ballot = el('step-candidate-section'); if (ballot) ballot.classList.add('is-hidden');
                } else {
                    connectedAddress = accounts[0]; walletConnected = true;
                    setBadge('wallet-status-badge', 'Connected', true);
                    if (el('wallet-address-display')) el('wallet-address-display').textContent = connectedAddress;
                    if (voterAuthenticated) revealBallot();
                }
            });
            window.ethereum.on('chainChanged', function () { window.location.reload(); });
        }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind); else bind();
})();
