/**
 * DVS — Shared UI Shell & Accessibility Controller (Module 7 Phase 2)
 * Handles:
 * - Mobile navigation menu toggle and Escape key dismissal
 * - Accessible inline form validation (replacing legacy window.alert)
 * - Reusable toast notification and modal dialog helpers
 */
(function () {
    'use strict';

    function showToast(message, type) {
        var region = document.getElementById('global-toast-region');
        if (!region) return;
        var item = document.createElement('div');
        item.className = 'toast-item feedback-' + (type || 'info');
        item.textContent = message;
        region.appendChild(item);
        window.setTimeout(function () {
            if (item.parentNode) {
                item.parentNode.removeChild(item);
            }
        }, 4500);
    }

    function openModal(modalId) {
        var backdrop = document.getElementById(modalId);
        if (!backdrop) return;
        backdrop.classList.add('is-open');
        backdrop.setAttribute('aria-hidden', 'false');
        var firstFocusable = backdrop.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
        if (firstFocusable) firstFocusable.focus();
    }

    function closeModal(modalId) {
        var backdrop = document.getElementById(modalId);
        if (!backdrop) return;
        backdrop.classList.remove('is-open');
        backdrop.setAttribute('aria-hidden', 'true');
    }

    function setFieldError(inputEl, errorEl, message) {
        if (inputEl) {
            if (message) {
                inputEl.classList.add('inp-invalid');
                inputEl.setAttribute('aria-invalid', 'true');
            } else {
                inputEl.classList.remove('inp-invalid');
                inputEl.removeAttribute('aria-invalid');
            }
        }
        if (errorEl) {
            errorEl.textContent = message || '';
            if (message) {
                errorEl.classList.add('is-visible');
            } else {
                errorEl.classList.remove('is-visible');
            }
        }
    }

    function initMobileNav() {
        var toggleBtn = document.getElementById('btn-mobile-nav-toggle');
        var navMenu = document.getElementById('primary-navigation');
        if (!toggleBtn || !navMenu) return;

        toggleBtn.addEventListener('click', function () {
            var isOpen = navMenu.classList.toggle('is-open');
            toggleBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
            toggleBtn.textContent = isOpen ? 'Close' : 'Menu';
        });

        document.addEventListener('keydown', function (ev) {
            if (ev.key === 'Escape' && navMenu.classList.contains('is-open')) {
                navMenu.classList.remove('is-open');
                toggleBtn.setAttribute('aria-expanded', 'false');
                toggleBtn.textContent = 'Menu';
                toggleBtn.focus();
            }
        });
    }

    function initAccessibleForms() {
        var adminForm = document.querySelector('form[data-validate="admin-login"]');
        if (adminForm) {
            adminForm.addEventListener('submit', function (ev) {
                var userInp = adminForm.querySelector('input[name="username"]');
                var passInp = adminForm.querySelector('input[name="password"]');
                var userErr = document.getElementById('error-admin-username');
                var passErr = document.getElementById('error-admin-password');
                var valid = true;

                setFieldError(userInp, userErr, '');
                setFieldError(passInp, passErr, '');

                if (!userInp || !userInp.value.trim()) {
                    setFieldError(userInp, userErr, 'Please enter your administrator username.');
                    if (userInp) userInp.focus();
                    valid = false;
                }
                if (!passInp || !passInp.value.trim()) {
                    setFieldError(passInp, passErr, 'Please enter your password.');
                    if (valid && passInp) passInp.focus();
                    valid = false;
                }
                if (!valid) {
                    ev.preventDefault();
                }
            });
        }

        var countForm = document.querySelector('form[data-validate="view-count"]');
        if (countForm) {
            countForm.addEventListener('submit', function (ev) {
                var candInp = countForm.querySelector('input[name="t1"]');
                var candErr = document.getElementById('error-candidate-id');
                setFieldError(candInp, candErr, '');

                if (!candInp || !candInp.value.trim()) {
                    setFieldError(candInp, candErr, 'Please enter a valid candidate ID.');
                    if (candInp) candInp.focus();
                    ev.preventDefault();
                }
            });
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        initMobileNav();
        initAccessibleForms();
    });

    window.DVSUI = {
        showToast: showToast,
        openModal: openModal,
        closeModal: closeModal,
        setFieldError: setFieldError
    };
})();
