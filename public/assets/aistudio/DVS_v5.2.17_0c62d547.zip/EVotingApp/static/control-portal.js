/**
 * DVS Standalone Administration Portal Controller (Module 7 Phase 4)
 * Role-adaptive operational client for Super Admin, Election Administrator,
 * Election Worker, and Auditor workspaces at /control/.
 */
(function () {
    'use strict';

    function getCsrfToken() {
        var input = document.querySelector('input[name="csrfmiddlewaretoken"]');
        if (input && input.value) {
            return input.value;
        }
        var match = document.cookie.match(/(?:^|;\s*)csrftoken=([^;]+)/);
        return match ? decodeURIComponent(match[1]) : '';
    }

    function escapeHtml(value) {
        return String(value === null || value === undefined ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function showBanner(message, type) {
        var banner = document.getElementById('admin-feedback-banner');
        if (banner) {
            banner.className = 'feedback-panel feedback-' + (type || 'info') + ' is-visible';
            banner.textContent = message;
        }
        if (window.DVSUI && typeof window.DVSUI.showToast === 'function') {
            window.DVSUI.showToast(message, type || 'info');
        }
    }

    function apiRequest(url, method, payload) {
        var opts = {
            method: method || 'GET',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRFToken': getCsrfToken()
            },
            credentials: 'same-origin'
        };
        if (payload !== undefined && payload !== null) {
            opts.headers['Content-Type'] = 'application/json';
            opts.body = JSON.stringify(payload);
        }
        return fetch(url, opts).then(function (res) {
            return res.json().catch(function () {
                return { error: 'Unexpected server response.' };
            }).then(function (data) {
                if (!res.ok) {
                    var errMsg = data.error || ('Operation failed (HTTP ' + res.status + ').');
                    var err = new Error(errMsg);
                    err.status = res.status;
                    err.data = data;
                    throw err;
                }
                return data;
            });
        });
    }


    function apiRequestFormData(url, formData) {
        return fetch(url, {
            method: 'POST', credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest', 'X-CSRFToken': getCsrfToken() },
            body: formData
        }).then(function (res) {
            return res.json().catch(function () { return { error: 'Unexpected server response.' }; })
                .then(function (data) {
                    if (!res.ok) throw new Error(data.error || ('Operation failed (HTTP ' + res.status + ').'));
                    return data;
                });
        });
    }

    function initControlPortal() {
        var root = document.getElementById('control-portal-root');
        if (!root) {
            return;
        }

        var electionId = root.getAttribute('data-election-id');
        var canWriteElection = root.getAttribute('data-can-write-election') === 'true';
        var canManagePlatform = root.getAttribute('data-can-manage-platform') === 'true';

        // 1. Sidebar Tab Navigation
        var navButtons = root.querySelectorAll('.admin-nav-btn[data-panel-target]');
        var panels = root.querySelectorAll('.admin-panel');

        navButtons.forEach(function (btn) {
            btn.addEventListener('click', function () {
                var targetId = btn.getAttribute('data-panel-target');
                navButtons.forEach(function (other) {
                    var active = other === btn;
                    other.classList.toggle('is-active', active);
                    other.setAttribute('aria-selected', active ? 'true' : 'false');
                });
                panels.forEach(function (panel) {
                    panel.classList.toggle('is-active', panel.id === targetId);
                });

                if (targetId === 'panel-candidates') {
                    loadCandidates();
                } else if (targetId === 'panel-voters') {
                    loadVoters();
                } else if (targetId === 'panel-identity') {
                    loadIdentityQueue();
                } else if (targetId === 'panel-audit') {
                    loadAuditLogs();
                }
            });
        });

        // 2. Super Admin: Create Draft Election
        var createElectionForm = document.getElementById('form-create-election');
        if (createElectionForm) {
            var createModeSelect = document.getElementById('input-create-election-mode');
            var createDatesGroup = document.getElementById('group-create-schedule-dates');
            var createDurationGroup = document.getElementById('group-create-immediate-duration');
            var createImmediateNotice = document.getElementById('notice-create-immediate');

            function syncCreateModeUI() {
                var isImmediate = createModeSelect && createModeSelect.value === 'IMMEDIATE';
                if (createDatesGroup) {
                    if (isImmediate) {
                        createDatesGroup.classList.add('is-hidden');
                    } else {
                        createDatesGroup.classList.remove('is-hidden');
                    }
                }
                if (createDurationGroup) {
                    if (isImmediate) {
                        createDurationGroup.classList.remove('is-hidden');
                    } else {
                        createDurationGroup.classList.add('is-hidden');
                    }
                }
                if (createImmediateNotice) {
                    if (isImmediate) {
                        createImmediateNotice.classList.remove('is-hidden');
                        createImmediateNotice.classList.add('is-visible');
                    } else {
                        createImmediateNotice.classList.add('is-hidden');
                        createImmediateNotice.classList.remove('is-visible');
                    }
                }
            }
            if (createModeSelect) {
                createModeSelect.addEventListener('change', syncCreateModeUI);
                syncCreateModeUI();
            }

            createElectionForm.addEventListener('submit', function (e) {
                e.preventDefault();
                var titleInput = document.getElementById('input-create-election-title');
                var typeInput = document.getElementById('input-create-election-type');
                var modeInput = document.getElementById('input-create-election-mode');
                var durationInput = document.getElementById('input-create-election-duration');
                var policyInput = document.getElementById('input-create-election-policy');
                var startInput = document.getElementById('input-create-election-start');
                var endInput = document.getElementById('input-create-election-end');
                var idInput = document.getElementById('input-create-election-id');
                var descInput = document.getElementById('input-create-election-desc');

                var title = titleInput ? titleInput.value.trim() : '';
                if (!title) {
                    showBanner('Please enter an election title.', 'error');
                    return;
                }

                var mode = modeInput ? modeInput.value : 'SCHEDULED';
                var startIso = null;
                var endIso = null;
                var durationHours = null;

                if (mode === 'SCHEDULED') {
                    var sVal = startInput && startInput.value ? startInput.value : null;
                    var eVal = endInput && endInput.value ? endInput.value : null;
                    if (sVal && eVal && new Date(eVal) <= new Date(sVal)) {
                        showBanner('Voting close time must be later than voting open time.', 'error');
                        return;
                    }
                    startIso = sVal ? new Date(sVal).toISOString() : null;
                    endIso = eVal ? new Date(eVal).toISOString() : null;
                } else {
                    if (!durationInput || !durationInput.value) {
                        showBanner('Immediate elections require selecting a voting duration (1–24 hours).', 'error');
                        return;
                    }
                    durationHours = parseInt(durationInput.value, 10);
                }

                apiRequest('/api/control/elections/create/', 'POST', {
                    title: title,
                    election_type: typeInput ? typeInput.value : 'GENERAL',
                    commencement_mode: mode,
                    immediate_duration_hours: durationHours,
                    result_publication_policy: policyInput ? policyInput.value : 'HIDDEN_UNTIL_CLOSE',
                    start_datetime: startIso,
                    end_datetime: endIso,
                    election_id: idInput && idInput.value ? idInput.value : null,
                    description: descInput ? descInput.value.trim() : ''
                }).then(function (res) {
                    showBanner(
                        'Draft Election #' + res.election.election_id + ' (' + res.election.title + ') created. Switching workspace...',
                        'success'
                    );
                    window.location.href = '/control/?election_id=' + encodeURIComponent(res.election.election_id);
                }).catch(function (err) {
                    showBanner(err.message, 'error');
                });
            });
        }

        // 3. Attach the Remix-deployed contract to this election.
        var prepareBtn = document.getElementById('btn-prepare-election');
        if (prepareBtn && electionId) {
            prepareBtn.addEventListener('click', function () {
                var addressInput = document.getElementById('input-contract-address');
                var address = addressInput ? addressInput.value.trim() : '';
                if (!/^0x[a-fA-F0-9]{40}$/.test(address)) {
                    showBanner('Paste the deployed 20-byte contract address from Remix.', 'error');
                    return;
                }
                prepareBtn.disabled = true;
                showBanner('Checking the contract on local Hardhat...', 'info');
                apiRequest('/api/control/elections/' + electionId + '/deploy/', 'POST', { contract_address: address })
                    .then(function (res) {
                        var badge = document.getElementById('badge-prep-state');
                        if (badge) badge.textContent = 'Contract Attached';
                        var overviewPrep = document.getElementById('overview-prep-status');
                        if (overviewPrep) overviewPrep.textContent = 'Contract Attached';
                        showBanner('Contract attached at ' + res.contract_address + '. Candidates synchronized: ' + res.candidates_synced + '.', 'success');
                        prepareBtn.disabled = false;
                    }).catch(function (err) {
                        showBanner(err.message, 'error');
                        prepareBtn.disabled = false;
                    });
            });
        }

        // 4. Edit Election Metadata
        var updateElectionForm = document.getElementById('form-update-election');
        if (updateElectionForm && electionId) {
            updateElectionForm.addEventListener('submit', function (e) {
                e.preventDefault();
                var titleEl = document.getElementById('input-edit-election-title');
                var typeEl = document.getElementById('input-edit-election-type');
                var modeEl = document.getElementById('input-edit-election-mode');
                var polEl = document.getElementById('input-edit-election-policy');
                var descEl = document.getElementById('input-edit-election-desc');

                var payload = {
                    title: titleEl ? titleEl.value.trim() : '',
                    election_type: typeEl ? typeEl.value : 'GENERAL',
                    result_publication_policy: polEl ? polEl.value : 'HIDDEN_UNTIL_CLOSE',
                    description: descEl ? descEl.value.trim() : ''
                };
                if (modeEl && !modeEl.disabled) {
                    payload.commencement_mode = modeEl.value;
                }

                apiRequest('/api/control/elections/' + electionId + '/update/', 'POST', payload).then(function (res) {
                    showBanner('Election details updated for ' + res.election.title + '.', 'success');
                }).catch(function (err) {
                    showBanner(err.message, 'error');
                });
            });
        }

        // 5. Candidate Roster Management
        function loadCandidates() {
            var tbody = document.getElementById('tbody-admin-candidates');
            if (!tbody || !electionId) {
                return;
            }
            apiRequest('/api/control/elections/' + electionId + '/candidates/', 'GET')
                .then(function (data) {
                    var list = data.candidates || [];
                    var statEl = document.getElementById('overview-stat-candidates');
                    if (statEl) {
                        statEl.textContent = String(data.active_count || list.length);
                    }
                    if (list.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="6" class="text-muted">No candidates registered for this election yet.</td></tr>';
                        return;
                    }
                    var rowsHtml = list.map(function (c) {
                        var statusText = c.is_active
                            ? (c.is_synced_on_chain ? 'Active (Synchronized)' : 'Active (Pending Lock)')
                            : 'Inactive';
                        var actionCell = '';
                        if (canWriteElection) {
                            if (c.is_active && !data.candidates_locked_on_chain) {
                                actionCell = '<td><button type="button" class="btn btn-secondary btn-deactivate-cand" data-cand-id="' + c.candidate_id + '">Remove</button></td>';
                            } else {
                                actionCell = '<td class="text-muted">Locked</td>';
                            }
                        }
                        return (
                            '<tr>' +
                            '<td class="mono">#' + escapeHtml(c.candidate_id) + '</td>' +
                            '<td><strong>' + escapeHtml(c.name) + '</strong></td>' +
                            '<td>' + (c.symbol_image_url ? '<img src="' + escapeHtml(c.symbol_image_url) + '" alt="" class="admin-candidate-symbol-thumb">' : '') + escapeHtml(c.symbol) + '</td>' +
                            '<td>' + escapeHtml(c.description || '—') + '</td>' +
                            '<td><strong class="badge badge-active">' + escapeHtml(statusText) + '</strong></td>' +
                            actionCell +
                            '</tr>'
                        );
                    }).join('');
                    tbody.innerHTML = rowsHtml;

                    tbody.querySelectorAll('.btn-deactivate-cand').forEach(function (btn) {
                        btn.addEventListener('click', function () {
                            var cid = btn.getAttribute('data-cand-id');
                            apiRequest('/api/control/elections/' + electionId + '/candidates/' + cid + '/deactivate/', 'POST', {})
                                .then(function () {
                                    showBanner('Candidate #' + cid + ' removed from active ballot.', 'info');
                                    loadCandidates();
                                })
                                .catch(function (err) {
                                    showBanner(err.message, 'error');
                                });
                        });
                    });
                })
                .catch(function (err) {
                    tbody.innerHTML = '<tr><td colspan="6" class="text-muted">' + escapeHtml(err.message) + '</td></tr>';
                });
        }

        var addCandidateForm = document.getElementById('form-add-candidate');
        if (addCandidateForm && electionId) {
            var symbolImageInput = document.getElementById('input-cand-symbol-image');
            if (symbolImageInput) {
                symbolImageInput.addEventListener('change', function () {
                    var file = symbolImageInput.files && symbolImageInput.files[0];
                    var preview = document.getElementById('candidate-symbol-preview');
                    var wrap = document.getElementById('candidate-symbol-preview-wrap');
                    if (!file || !preview || !wrap) { if (wrap) wrap.classList.add('is-hidden'); return; }
                    if (file.size > 5 * 1024 * 1024) { showBanner('Candidate symbol image must be 5 MB or smaller.', 'error'); symbolImageInput.value = ''; wrap.classList.add('is-hidden'); return; }
                    preview.src = URL.createObjectURL(file);
                    wrap.classList.remove('is-hidden');
                });
            }
            addCandidateForm.addEventListener('submit', function (e) {
                e.preventDefault();
                var cid = document.getElementById('input-cand-id').value;
                var name = document.getElementById('input-cand-name').value.trim();
                var sym = document.getElementById('input-cand-symbol').value.trim();
                var desc = document.getElementById('input-cand-desc').value.trim();
                var image = symbolImageInput && symbolImageInput.files ? symbolImageInput.files[0] : null;
                if (!cid || !name || !sym || !image) {
                    showBanner('Ballot number, candidate name, symbol, and symbol image are required.', 'error');
                    return;
                }
                var formData = new FormData();
                formData.append('candidate_id', cid);
                formData.append('name', name);
                formData.append('symbol', sym);
                formData.append('description', desc);
                formData.append('symbol_image', image);
                apiRequestFormData('/api/control/elections/' + electionId + '/candidates/', formData)
                    .then(function () {
                        showBanner('Candidate ' + name + ' added to the election roster.', 'success');
                        addCandidateForm.reset();
                        var wrap = document.getElementById('candidate-symbol-preview-wrap');
                        if (wrap) wrap.classList.add('is-hidden');
                        loadCandidates();
                    }).catch(function (err) { showBanner(err.message, 'error'); });
            });
        }


        var lockCandidatesBtn = document.getElementById('btn-lock-candidates');
        if (lockCandidatesBtn && electionId) {
            lockCandidatesBtn.addEventListener('click', function () {
                lockCandidatesBtn.disabled = true;
                apiRequest('/api/control/elections/' + electionId + '/candidates/lock/', 'POST', {
                    lock: true
                }).then(function () {
                    var badge = document.getElementById('badge-candidate-lock-state');
                    if (badge) {
                        badge.textContent = 'Roster Locked';
                    }
                    showBanner('Candidate roster verified and locked.', 'success');
                    loadCandidates();
                }).catch(function (err) {
                    showBanner(err.message, 'error');
                    lockCandidatesBtn.disabled = false;
                });
            });
        }

        // 6. Voter Registry & Simplified Single-Step Registration
        var cachedVoters = [];

        function renderVotersTable(filterQuery) {
            var tbody = document.getElementById('tbody-admin-voters');
            if (!tbody) {
                return;
            }
            var q = (filterQuery || '').trim().toLowerCase();
            var filtered = cachedVoters.filter(function (v) {
                if (!q) {
                    return true;
                }
                var haystack = (
                    (v.name || '') + ' ' +
                    (v.aadhar_masked || '') + ' ' +
                    (v.bound_wallet || '') + ' ' +
                    (v.is_eligible ? 'eligible' : 'revoked') + ' ' +
                    (v.has_voted ? 'voted' : 'not voted')
                ).toLowerCase();
                return haystack.indexOf(q) !== -1;
            });

            if (filtered.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="text-muted">No voter records match the current view.</td></tr>';
                return;
            }

            tbody.innerHTML = filtered.map(function (v) {
                var eligBadge = v.is_eligible
                    ? '<strong class="badge badge-active">Eligible</strong>'
                    : '<strong class="badge badge-closed">Revoked</strong>';
                var voteBadge = v.has_voted
                    ? '<strong class="badge badge-finalized">Ballot Cast</strong>'
                    : '<strong class="badge badge-draft">Not Voted</strong>';
                var walletCell = v.bound_wallet
                    ? '<code class="mono">' + escapeHtml(v.bound_wallet.slice(0, 10) + '...' + v.bound_wallet.slice(-6)) + '</code>'
                    : '<small class="text-muted">Not Bound</small>';
                var actionsCell = '';
                if (canWriteElection) {
                    if (!v.has_voted) {
                        var nextElig = v.is_eligible ? 'false' : 'true';
                        var btnLabel = v.is_eligible ? 'Suspend Eligibility' : 'Restore Eligibility';
                        actionsCell = (
                            '<td><button type="button" class="btn btn-secondary btn-toggle-eligibility" ' +
                            'data-voter-id="' + v.voter_id + '" data-next-eligible="' + nextElig + '">' +
                            btnLabel + '</button></td>'
                        );
                    } else {
                        actionsCell = '<td class="text-muted">Vote Confirmed</td>';
                    }
                }
                return (
                    '<tr>' +
                    '<td><strong>' + escapeHtml(v.name) + '</strong></td>' +
                    '<td class="mono">' + escapeHtml(v.aadhar_masked) + '</td>' +
                    '<td>' + eligBadge + '</td>' +
                    '<td>' + voteBadge + '</td>' +
                    '<td>' + walletCell + '</td>' +
                    actionsCell +
                    '</tr>'
                );
            }).join('');

            tbody.querySelectorAll('.btn-toggle-eligibility').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    var vid = btn.getAttribute('data-voter-id');
                    var makeEligible = btn.getAttribute('data-next-eligible') === 'true';
                    apiRequest('/api/control/elections/' + electionId + '/voters/' + vid + '/eligibility/', 'POST', {
                        is_eligible: makeEligible
                    }).then(function () {
                        showBanner(
                            makeEligible ? 'Voter eligibility restored for this election.' : 'Voter eligibility suspended for this election.',
                            'info'
                        );
                        loadVoters();
                    }).catch(function (err) {
                        showBanner(err.message, 'error');
                    });
                });
            });
        }

        function loadVoters() {
            var tbody = document.getElementById('tbody-admin-voters');
            if (!tbody || !electionId) {
                return;
            }
            apiRequest('/api/control/elections/' + electionId + '/voters/', 'GET')
                .then(function (data) {
                    cachedVoters = data.voters || [];
                    var regEl = document.getElementById('overview-stat-registered');
                    var eligEl = document.getElementById('overview-stat-eligible');
                    var votedEl = document.getElementById('overview-stat-votes');
                    if (regEl) regEl.textContent = String(data.total_voters || 0);
                    if (eligEl) eligEl.textContent = String(data.eligible_voters || 0);
                    if (votedEl) votedEl.textContent = String(data.confirmed_voted || 0);

                    var lookupInput = document.getElementById('input-voter-lookup');
                    renderVotersTable(lookupInput ? lookupInput.value : '');
                })
                .catch(function (err) {
                    tbody.innerHTML = '<tr><td colspan="6" class="text-muted">' + escapeHtml(err.message) + '</td></tr>';
                });
        }

        var voterLookupInput = document.getElementById('input-voter-lookup');
        if (voterLookupInput) {
            voterLookupInput.addEventListener('input', function () {
                renderVotersTable(voterLookupInput.value);
            });
        }

        var refreshVotersBtn = document.getElementById('btn-refresh-voters');
        if (refreshVotersBtn) {
            refreshVotersBtn.addEventListener('click', loadVoters);
        }

        var registerVoterForm = document.getElementById('form-register-voter');
        if (registerVoterForm && electionId) {
            registerVoterForm.addEventListener('submit', function (e) {
                e.preventDefault();
                var nameVal = document.getElementById('input-voter-name').value.trim();
                var aadharVal = document.getElementById('input-voter-aadhar').value.trim();
                var walletVal = document.getElementById('input-voter-wallet').value.trim();
                var isSyntheticVal = document.getElementById('select-voter-record-type').value === 'true';

                if (!aadharVal) {
                    showBanner('Please enter a 12-digit Aadhaar / Citizen ID.', 'error');
                    return;
                }

                apiRequest('/api/control/elections/' + electionId + '/voters/add/', 'POST', {
                    name: nameVal,
                    aadhar_number: aadharVal,
                    bound_wallet: walletVal || null,
                    is_synthetic: isSyntheticVal
                }).then(function (res) {
                    var outcome = res.registration_outcome;
                    var msg = 'Voter ' + res.voter.name + ' (' + res.voter.aadhar_masked + ') registered and enrolled in Election #' + electionId + '.';
                    if (outcome === 'EXISTING_VOTER_ADDED_TO_ELECTION') {
                        msg = 'Existing voter ' + res.voter.name + ' (' + res.voter.aadhar_masked + ') enrolled in Election #' + electionId + '.';
                    } else if (outcome === 'ALREADY_ELIGIBLE_IN_ELECTION') {
                        msg = 'Voter ' + res.voter.name + ' (' + res.voter.aadhar_masked + ') is already enrolled and eligible in Election #' + electionId + '.';
                    }
                    showBanner(msg, 'success');
                    registerVoterForm.reset();
                    loadVoters();
                }).catch(function (err) {
                    showBanner(err.message, 'error');
                });
            });
        }

        // 7. Bulk Synthetic Voter CSV Import (Dry Run + Commit)
        var csvDryRunBtn = document.getElementById('btn-csv-dry-run');
        var csvCommitBtn = document.getElementById('btn-csv-commit');
        var csvTextarea = document.getElementById('input-csv-voters');
        var csvPreviewPanel = document.getElementById('csv-preview-panel');

        function runCsvImport(isDryRun) {
            if (!csvTextarea || !electionId) {
                return;
            }
            var csvContent = csvTextarea.value.trim();
            if (!csvContent) {
                showBanner('Please paste CSV voter rows before running import.', 'error');
                return;
            }
            apiRequest('/api/control/elections/' + electionId + '/voters/import-csv/', 'POST', {
                csv_content: csvContent,
                dry_run: isDryRun
            }).then(function (res) {
                if (csvPreviewPanel) {
                    csvPreviewPanel.className = 'feedback-panel feedback-info is-visible';
                    csvPreviewPanel.textContent =
                        (isDryRun ? 'Dry-Run Preview: ' : 'Import Committed: ') +
                        res.valid_new_count + ' new valid, ' +
                        res.valid_existing_count + ' existing valid, ' +
                        res.duplicate_in_file_count + ' duplicates in file, ' +
                        res.conflict_count + ' conflicts, ' +
                        res.invalid_count + ' invalid rows.';
                }
                if (isDryRun) {
                    if (csvCommitBtn) {
                        csvCommitBtn.disabled = (res.valid_new_count + res.valid_existing_count) === 0;
                    }
                    showBanner('CSV validation preview complete.', 'info');
                } else {
                    if (csvCommitBtn) {
                        csvCommitBtn.disabled = true;
                    }
                    showBanner(
                        'Imported and enrolled ' + (res.eligibilities_assigned || 0) + ' voter(s) into Election #' + electionId + '.',
                        'success'
                    );
                    loadVoters();
                }
            }).catch(function (err) {
                showBanner(err.message, 'error');
            });
        }

        if (csvDryRunBtn) {
            csvDryRunBtn.addEventListener('click', function () {
                runCsvImport(true);
            });
        }
        if (csvCommitBtn) {
            csvCommitBtn.addEventListener('click', function () {
                runCsvImport(false);
            });
        }

        // 8. Identity Verification & Pending Onboarding Queue
        function loadIdentityQueue() {
            var tbody = document.getElementById('tbody-pending-onboarding');
            if (!tbody || !electionId) {
                return;
            }
            apiRequest('/api/control/elections/' + electionId + '/identity/records/', 'GET')
                .then(function (data) {
                    var list = data.pending_onboardings || [];
                    if (list.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="6" class="text-muted">No pending onboarding records in queue.</td></tr>';
                        return;
                    }
                    tbody.innerHTML = list.map(function (p) {
                        var actionHtml = '';
                        if (canWriteElection) {
                            if (p.status === 'PENDING_REVIEW') {
                                actionHtml = (
                                    '<td><div class="action-row">' +
                                    '<button type="button" class="btn btn-primary btn-onboarding-decision" data-id="' + p.id + '" data-decision="APPROVE">Approve</button>' +
                                    '<button type="button" class="btn btn-secondary btn-onboarding-decision" data-id="' + p.id + '" data-decision="REJECT">Reject</button>' +
                                    '</div></td>'
                                );
                            } else {
                                actionHtml = '<td class="text-muted">Reviewed</td>';
                            }
                        }
                        return (
                            '<tr>' +
                            '<td class="mono">#' + escapeHtml(p.id) + '</td>' +
                            '<td>' + escapeHtml(p.provider_id) + '</td>' +
                            '<td><strong>' + escapeHtml(p.proposed_name) + '</strong></td>' +
                            '<td class="mono">' + escapeHtml(p.masked_identifier) + '</td>' +
                            '<td><strong class="badge badge-scheduled">' + escapeHtml(p.status) + '</strong></td>' +
                            actionHtml +
                            '</tr>'
                        );
                    }).join('');

                    tbody.querySelectorAll('.btn-onboarding-decision').forEach(function (btn) {
                        btn.addEventListener('click', function () {
                            var oid = btn.getAttribute('data-id');
                            var decision = btn.getAttribute('data-decision');
                            apiRequest('/api/control/elections/' + electionId + '/onboarding/' + oid + '/review/', 'POST', {
                                decision: decision,
                                reason: decision === 'REJECT' ? 'Rejected during administrative review.' : ''
                            }).then(function (res) {
                                showBanner('Onboarding record #' + oid + ' ' + res.status.toLowerCase() + '.', 'success');
                                loadIdentityQueue();
                            }).catch(function (err) {
                                showBanner(err.message, 'error');
                            });
                        });
                    });
                })
                .catch(function (err) {
                    tbody.innerHTML = '<tr><td colspan="6" class="text-muted">' + escapeHtml(err.message) + '</td></tr>';
                });
        }

        var identityForm = document.getElementById('form-identity-verify');
        if (identityForm && electionId) {
            identityForm.addEventListener('submit', function (e) {
                e.preventDefault();
                var providerId = document.getElementById('select-identity-provider').value;
                var aadharVal = document.getElementById('input-identity-aadhar').value.trim();
                var nameVal = document.getElementById('input-identity-name').value.trim();
                var scenarioVal = document.getElementById('select-identity-scenario').value;

                if (!aadharVal) {
                    showBanner('Please enter a 12-digit Citizen Identifier to verify.', 'error');
                    return;
                }

                var params = {};
                if (nameVal) {
                    params.full_name = nameVal;
                }
                if (scenarioVal) {
                    params.scenario = scenarioVal;
                }

                apiRequest('/api/control/elections/' + electionId + '/identity/verify/', 'POST', {
                    provider_id: providerId,
                    identifier: aadharVal,
                    parameters: params
                }).then(function (res) {
                    if (res.status === 'VERIFIED') {
                        var stagedMsg = (res.pending_onboarding && res.pending_onboarding.onboarding_id)
                            ? ' Staged in Pending Onboarding Queue (#' + res.pending_onboarding.onboarding_id + ').'
                            : ' Verified in local electoral roll.';
                        showBanner('Identity verified (' + res.masked_identifier + ').' + stagedMsg, 'success');
                    } else {
                        showBanner('Verification result: ' + res.status + ' (' + (res.failure_code || 'No match') + ').', 'warning');
                    }
                    loadIdentityQueue();
                }).catch(function (err) {
                    showBanner(err.message, 'error');
                });
            });
        }

        var refreshIdentityBtn = document.getElementById('btn-refresh-identity');
        if (refreshIdentityBtn) {
            refreshIdentityBtn.addEventListener('click', loadIdentityQueue);
        }

        // 9. Voting Schedule & Lifecycle Transitions
        var windowForm = document.getElementById('form-configure-window');
        if (windowForm && electionId) {
            var windowModeSelect = document.getElementById('select-window-mode');
            var windowDatesGroup = document.getElementById('group-window-schedule-dates');
            var windowDurationGroup = document.getElementById('group-window-duration');
            var windowImmediateNotice = document.getElementById('notice-window-immediate');
            var commencementBadge = document.getElementById('badge-commencement-mode');

            function syncWindowModeUI() {
                var isImmediate = windowModeSelect && windowModeSelect.value === 'IMMEDIATE';
                if (windowDatesGroup) {
                    if (isImmediate) {
                        windowDatesGroup.classList.add('is-hidden');
                    } else {
                        windowDatesGroup.classList.remove('is-hidden');
                    }
                }
                if (windowDurationGroup) {
                    if (isImmediate) {
                        windowDurationGroup.classList.remove('is-hidden');
                    } else {
                        windowDurationGroup.classList.add('is-hidden');
                    }
                }
                if (windowImmediateNotice) {
                    if (isImmediate) {
                        windowImmediateNotice.classList.remove('is-hidden');
                        windowImmediateNotice.classList.add('is-visible');
                    } else {
                        windowImmediateNotice.classList.add('is-hidden');
                        windowImmediateNotice.classList.remove('is-visible');
                    }
                }
            }
            if (windowModeSelect) {
                windowModeSelect.addEventListener('change', syncWindowModeUI);
                syncWindowModeUI();
            }

            windowForm.addEventListener('submit', function (e) {
                e.preventDefault();
                var mode = windowModeSelect ? windowModeSelect.value : 'SCHEDULED';
                var startVal = document.getElementById('input-window-start').value;
                var endVal = document.getElementById('input-window-end').value;
                var durationSelect = document.getElementById('select-window-duration');

                var startIso = null;
                var endIso = null;
                var durationHours = null;

                if (mode === 'SCHEDULED') {
                    if (!startVal || !endVal) {
                        showBanner('Scheduled elections require both start and end date/time.', 'error');
                        return;
                    }
                    if (new Date(endVal) <= new Date(startVal)) {
                        showBanner('Voting close time must be later than voting open time.', 'error');
                        return;
                    }
                    startIso = new Date(startVal).toISOString();
                    endIso = new Date(endVal).toISOString();
                } else {
                    if (!durationSelect || !durationSelect.value) {
                        showBanner('Please select a voting duration (1–24 hours) for this immediate election.', 'error');
                        return;
                    }
                    durationHours = parseInt(durationSelect.value, 10);
                }

                apiRequest('/api/control/elections/' + electionId + '/window/', 'POST', {
                    commencement_mode: mode,
                    immediate_duration_hours: durationHours,
                    start_datetime: startIso,
                    end_datetime: endIso
                }).then(function (res) {
                    if (commencementBadge) {
                        commencementBadge.textContent = res.commencement_mode === 'IMMEDIATE'
                            ? 'Immediate Election'
                            : 'Scheduled Election';
                    }
                    var schedDetail = document.getElementById('overview-schedule-detail');
                    if (schedDetail && res.commencement_mode === 'IMMEDIATE' && res.immediate_duration_hours) {
                        schedDetail.textContent = 'Immediate (' + res.immediate_duration_hours + ' hours duration · Commences upon activation)';
                    }
                    showBanner('Commencement and voting schedule saved for Election #' + electionId + '.', 'success');
                }).catch(function (err) {
                    showBanner(err.message, 'error');
                });
            });
        }

        function bindLifecycleButton(btnId, endpointSuffix, payload, successMessage) {
            var btn = document.getElementById(btnId);
            if (!btn || !electionId) {
                return;
            }
            btn.addEventListener('click', function () {
                btn.disabled = true;
                apiRequest('/api/control/elections/' + electionId + '/' + endpointSuffix + '/', 'POST', payload || {})
                    .then(function (res) {
                        showBanner(res.message || successMessage, 'success');
                        if (res.reconciliation) {
                            var repBox = document.getElementById('reconciliation-report-box');
                            if (repBox) {
                                var r = res.reconciliation;
                                repBox.innerHTML =
                                    '<h3>Result Verification Complete</h3>' +
                                    '<p>Status: <strong>' + (r.verified ? 'Verified & Matched' : 'Discrepancy Detected') + '</strong> | ' +
                                    'Confirmed Ballots: <strong>' + escapeHtml(r.onchain_total_votes) + '</strong> | ' +
                                    'Voting Authorizations: <strong>' + escapeHtml(r.db_confirmed_permits) + '</strong></p>';
                            }
                        }
                        btn.disabled = false;
                    })
                    .catch(function (err) {
                        showBanner(err.message, 'error');
                        btn.disabled = false;
                    });
            });
        }

        bindLifecycleButton('btn-lifecycle-activate', 'activate', {}, 'Election opened for active voting.');
        bindLifecycleButton('btn-lifecycle-close', 'close', {}, 'Voting window closed.');
        bindLifecycleButton('btn-lifecycle-reconcile', 'reconcile', {}, 'Election results verified.');
        bindLifecycleButton('btn-lifecycle-publish', 'publish', { publish: true }, 'Election results authorized for public display.');
        bindLifecycleButton('btn-lifecycle-finalize', 'finalize', {}, 'Election permanently finalized.');

        var runSchedulerBtn = document.getElementById('btn-run-scheduler-check');
        if (runSchedulerBtn) {
            runSchedulerBtn.addEventListener('click', function () {
                runSchedulerBtn.disabled = true;
                showBanner('Running automated election scheduler check...', 'info');
                apiRequest('/api/control/lifecycle/scheduler/', 'POST', {})
                    .then(function (res) {
                        var rep = res.report || {};
                        var activated = (rep.activated || []).length;
                        var closed = (rep.closed || []).length;
                        var failed = (rep.failed || []).length;
                        var skipped = (rep.skipped || []).length;
                        var msg = 'Scheduler check complete: ' + activated + ' activated, ' + closed + ' closed, ' + skipped + ' skipped, ' + failed + ' failed.';
                        showBanner(msg, failed > 0 ? 'warning' : 'success');
                        setTimeout(function () {
                            window.location.reload();
                        }, 1200);
                    })
                    .catch(function (err) {
                        showBanner(err.message, 'error');
                        runSchedulerBtn.disabled = false;
                    });
            });
        }

        // 10. Super Admin Staff & Role Management
        var staffForm = document.getElementById('form-manage-staff');
        if (staffForm && canManagePlatform) {
            staffForm.addEventListener('submit', function (e) {
                e.preventDefault();
                var uVal = document.getElementById('input-staff-username').value.trim();
                var pVal = document.getElementById('input-staff-password').value;
                var rVal = document.getElementById('select-staff-role').value;
                var elVal = document.getElementById('select-staff-election').value;

                if (!uVal) {
                    showBanner('Staff username is required.', 'error');
                    return;
                }

                apiRequest('/api/control/staff/', 'POST', {
                    operation: 'CREATE_OR_UPDATE_STAFF',
                    username: uVal,
                    password: pVal,
                    role: rVal,
                    election_id: elVal || null
                }).then(function (res) {
                    showBanner(
                        'Staff account ' + res.staff.username + ' saved as ' + res.staff.portal_role_label + '.',
                        'success'
                    );
                    staffForm.reset();
                    refreshStaffTable();
                }).catch(function (err) {
                    showBanner(err.message, 'error');
                });
            });
        }

        function bindRemoveAssignmentButtons() {
            document.querySelectorAll('.btn-remove-assignment').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    var aid = btn.getAttribute('data-assignment-id');
                    apiRequest('/api/control/staff/', 'POST', {
                        operation: 'REMOVE_ELECTION_ROLE',
                        assignment_id: parseInt(aid, 10)
                    }).then(function () {
                        showBanner('Staff assignment removed.', 'info');
                        refreshStaffTable();
                    }).catch(function (err) {
                        showBanner(err.message, 'error');
                    });
                });
            });
        }

        function refreshStaffTable() {
            var tbody = document.getElementById('tbody-staff-assignments');
            if (!tbody || !canManagePlatform) {
                return;
            }
            apiRequest('/api/control/staff/', 'GET').then(function (data) {
                var list = data.assignments || [];
                if (list.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="4" class="text-muted">No election-specific staff assignments recorded yet.</td></tr>';
                    return;
                }
                tbody.innerHTML = list.map(function (a) {
                    return (
                        '<tr>' +
                        '<td>#' + escapeHtml(a.election_id) + ' — ' + escapeHtml(a.election_title) + '</td>' +
                        '<td><strong>' + escapeHtml(a.username) + '</strong></td>' +
                        '<td><strong class="badge badge-active">' + escapeHtml(a.role_label) + '</strong></td>' +
                        '<td><button type="button" class="btn btn-secondary btn-remove-assignment" data-assignment-id="' + a.id + '">Remove</button></td>' +
                        '</tr>'
                    );
                }).join('');
                bindRemoveAssignmentButtons();
            });
        }

        bindRemoveAssignmentButtons();

        // 11. Audit Logs & Verification Inspection
        function loadAuditLogs() {
            var tbody = document.getElementById('tbody-audit-logs');
            if (!tbody || !electionId) {
                return;
            }
            apiRequest('/api/control/elections/' + electionId + '/audit/', 'GET')
                .then(function (data) {
                    var logs = data.audit_logs || [];
                    if (logs.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="4" class="text-muted">No administrative audit entries recorded for this election yet.</td></tr>';
                        return;
                    }
                    tbody.innerHTML = logs.map(function (log) {
                        return (
                            '<tr>' +
                            '<td class="mono">' + escapeHtml(log.timestamp) + '</td>' +
                            '<td><strong>' + escapeHtml(log.actor__username || 'System') + '</strong></td>' +
                            '<td><code class="mono">' + escapeHtml(log.action) + '</code></td>' +
                            '<td>' + escapeHtml(log.details) + '</td>' +
                            '</tr>'
                        );
                    }).join('');
                })
                .catch(function (err) {
                    tbody.innerHTML = '<tr><td colspan="4" class="text-muted">' + escapeHtml(err.message) + '</td></tr>';
                });
        }

        var refreshAuditBtn = document.getElementById('btn-refresh-audit');
        if (refreshAuditBtn) {
            refreshAuditBtn.addEventListener('click', loadAuditLogs);
        }

        // Blockchain Gateway Runtime Sync Form
        var blockchainSyncForm = document.getElementById('form-blockchain-sync');
        if (blockchainSyncForm) {
            blockchainSyncForm.addEventListener('submit', function (ev) {
                ev.preventDefault();
                var inputUrl = document.getElementById('input-blockchain-url');
                var submitBtn = document.getElementById('btn-blockchain-sync');
                var targetUrl = (inputUrl ? inputUrl.value : '').trim();
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.textContent = 'Validating & Syncing...';
                }
                apiRequest('/api/control/blockchain/sync/', 'POST', { blockchain_base_url: targetUrl })
                    .then(function (res) {
                        showBanner('Blockchain gateway synchronized successfully on Chain ID ' + res.chain_id + '.', 'success');
                        var displayBase = document.getElementById('display-blockchain-base-url');
                        var displayRpc = document.getElementById('display-metamask-rpc-url');
                        var displayContract = document.getElementById('display-active-contract-addr');
                        var statusBadge = document.getElementById('blockchain-status-badge');
                        if (displayBase && res.configured_base_url) {
                            displayBase.textContent = res.configured_base_url;
                        }
                        if (displayRpc && res.metamask_rpc_url) {
                            displayRpc.textContent = res.metamask_rpc_url;
                        }
                        if (displayContract && res.sync_result && res.sync_result.contract_address) {
                            displayContract.textContent = res.sync_result.contract_address;
                        }
                        if (statusBadge) {
                            statusBadge.className = 'badge badge-active';
                            statusBadge.textContent = 'Connected & Synced';
                        }
                    })
                    .catch(function (err) {
                        showBanner('Blockchain synchronization failed: ' + err.message, 'error');
                    })
                    .finally(function () {
                        if (submitBtn) {
                            submitBtn.disabled = false;
                            submitBtn.textContent = 'Connect & Sync Blockchain';
                        }
                    });
            });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initControlPortal);
    } else {
        initControlPortal();
    }
})();
