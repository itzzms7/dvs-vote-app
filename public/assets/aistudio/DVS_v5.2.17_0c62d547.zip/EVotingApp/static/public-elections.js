/**
 * DVS Public Elections Dashboard Interactive Controller
 * Switches between Active and Completed election views without navigating away from the page.
 */
(function () {
    'use strict';

    function initElectionsCategorySwitch() {
        var switchButtons = document.querySelectorAll('[data-category-switch]');
        var categoryPanels = document.querySelectorAll('[data-category-panel]');

        if (switchButtons.length === 0 || categoryPanels.length === 0) {
            return;
        }

        function setCategory(selectedCategory) {
            var target = (selectedCategory || 'ACTIVE').toUpperCase();

            switchButtons.forEach(function (btn) {
                var btnCat = (btn.getAttribute('data-category-switch') || '').toUpperCase();
                var isSelected = btnCat === target;
                btn.classList.toggle('is-active', isSelected);
                btn.setAttribute('aria-selected', isSelected ? 'true' : 'false');
            });

            categoryPanels.forEach(function (panel) {
                var panelCat = (panel.getAttribute('data-category-panel') || '').toUpperCase();
                var isVisible = panelCat === target;
                panel.classList.toggle('is-hidden', !isVisible);
            });
        }

        switchButtons.forEach(function (btn) {
            btn.addEventListener('click', function (event) {
                event.preventDefault();
                var targetCategory = btn.getAttribute('data-category-switch') || 'ACTIVE';
                setCategory(targetCategory);
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initElectionsCategorySwitch);
    } else {
        initElectionsCategorySwitch();
    }
})();

