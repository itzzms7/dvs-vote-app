/**
 * Decentralized E-Voting System (DVS) - Voter Wallet & Ballot Submission Module
 */

const DVSWallet = (function () {
    'use strict';

    let currentAddress = null;
    let currentChainId = null;
    let isAuthenticated = false;
    let expectedChainIdDec = 31337;
    let activeSubmissionInFlight = false;

    function pad32(val) {
        if (typeof val === 'number' || typeof val === 'bigint') {
            return val.toString(16).padStart(64, '0');
        }
        const cleanHex = String(val).replace(/^0x/, '');
        return cleanHex.padStart(64, '0');
    }

    function encodeCastVoteWithPermit(candidateId, nullifier, deadline, nonce, v, r, s) {
        const selector = '9e3b026b';
        return '0x' + selector +
            pad32(candidateId) +
            pad32(nullifier) +
            pad32(deadline) +
            pad32(nonce) +
            pad32(v) +
            pad32(r) +
            pad32(s);
    }

    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        if (!cookieValue) {
            const input = document.querySelector('input[name="csrfmiddlewaretoken"]');
            if (input) cookieValue = input.value;
        }
        return cookieValue;
    }

    function formatAddress(addr) {
        if (!addr || addr.length < 10) return addr;
        return addr.substring(0, 6) + '...' + addr.substring(addr.length - 4);
    }

    function getCurrentElectionId() {
        const root = document.getElementById('voter-portal-root');
        if (root && root.dataset.electionId) {
            const parsed = parseInt(root.dataset.electionId, 10);
            if (!isNaN(parsed) && parsed > 0) return parsed;
        }
        const input = document.getElementById('input-election-id');
        if (input && input.value) {
            const parsed = parseInt(input.value, 10);
            if (!isNaN(parsed) && parsed > 0) return parsed;
        }
        return null;
    }

    function showNotice(message, type) {
        const noticeEl = document.getElementById('metamask-notice');
        if (!noticeEl) return;
        if (!message) {
            noticeEl.textContent = '';
            noticeEl.className = 'feedback-panel';
            return;
        }
        noticeEl.textContent = message;
        noticeEl.className = 'feedback-panel is-visible feedback-' + (type || 'info');
    }

    function showVoteFeedback(message, type) {
        const feedbackEl = document.getElementById('vote-feedback');
        if (!feedbackEl) return;
        if (!message) {
            feedbackEl.textContent = '';
            feedbackEl.className = 'feedback-panel';
            return;
        }
        feedbackEl.textContent = message;
        feedbackEl.className = 'feedback-panel is-visible feedback-' + (type || 'info');
    }

    function updateProgressStage(message, tone) {
        const panel = document.getElementById('ballot-tx-progress-panel');
        const titleEl = document.getElementById('ballot-tx-stage-title');
        if (!panel) return;
        if (!message) {
            panel.className = 'feedback-panel';
            return;
        }
        if (titleEl) titleEl.textContent = message;
        panel.className = 'feedback-panel is-visible feedback-' + (tone || 'info');
    }

    function updateUI() {
        const connectBtn = document.getElementById('btn-connect-wallet');
        const disconnectBtn = document.getElementById('btn-disconnect-wallet');
        const walletAddressEl = document.getElementById('wallet-address-display');
        const walletStatusEl = document.getElementById('wallet-status-badge');
        const networkBadgeEl = document.getElementById('wallet-network-badge');

        if (!connectBtn) return;

        const chainDec = currentChainId ? parseInt(currentChainId, 16) : null;
        const wrongNetwork = Boolean(chainDec && expectedChainIdDec && chainDec !== expectedChainIdDec);

        if (isAuthenticated && currentAddress) {
            connectBtn.classList.add('is-hidden');
            connectBtn.classList.remove('is-inline-block');
            if (disconnectBtn) {
                disconnectBtn.classList.remove('is-hidden');
                disconnectBtn.classList.add('is-inline-block');
            }
            if (walletAddressEl) {
                walletAddressEl.textContent = formatAddress(currentAddress);
                walletAddressEl.setAttribute('title', currentAddress);
            }
            if (walletStatusEl) {
                if (wrongNetwork) {
                    walletStatusEl.textContent = 'Wrong Network';
                    walletStatusEl.className = 'status-badge status-pending';
                } else {
                    walletStatusEl.textContent = 'Connected';
                    walletStatusEl.className = 'status-badge status-authenticated';
                }
            }
            if (networkBadgeEl && chainDec) {
                networkBadgeEl.textContent = wrongNetwork ? 'Network Mismatch' : 'Ready';
                networkBadgeEl.classList.add('is-visible');
            }
        } else if (currentAddress) {
            connectBtn.textContent = 'Verify Wallet';
            connectBtn.classList.remove('is-hidden');
            connectBtn.classList.add('is-inline-block');
            if (disconnectBtn) {
                disconnectBtn.classList.add('is-hidden');
                disconnectBtn.classList.remove('is-inline-block');
            }
            if (walletAddressEl) walletAddressEl.textContent = formatAddress(currentAddress);
            if (walletStatusEl) {
                walletStatusEl.textContent = 'Unverified';
                walletStatusEl.className = 'status-badge status-pending';
            }
            if (networkBadgeEl) {
                networkBadgeEl.textContent = '';
                networkBadgeEl.classList.remove('is-visible');
            }
        } else {
            connectBtn.textContent = 'Connect Wallet';
            connectBtn.classList.remove('is-hidden');
            connectBtn.classList.add('is-inline-block');
            if (disconnectBtn) {
                disconnectBtn.classList.add('is-hidden');
                disconnectBtn.classList.remove('is-inline-block');
            }
            if (walletAddressEl) walletAddressEl.textContent = 'No wallet connected';
            if (walletStatusEl) {
                walletStatusEl.textContent = 'Disconnected';
                walletStatusEl.className = 'status-badge status-disconnected';
            }
            if (networkBadgeEl) {
                networkBadgeEl.textContent = '';
                networkBadgeEl.classList.remove('is-visible');
            }
        }
    }

    async function ensureExpectedNetwork() {
        if (typeof window.ethereum === 'undefined') return false;
        const hexChainId = '0x' + Number(expectedChainIdDec).toString(16);
        const activeChain = await window.ethereum.request({ method: 'eth_chainId' });
        currentChainId = activeChain;
        if (parseInt(activeChain, 16) === Number(expectedChainIdDec)) {
            return true;
        }
        try {
            await window.ethereum.request({
                method: 'wallet_switchEthereumChain',
                params: [{ chainId: hexChainId }]
            });
            currentChainId = await window.ethereum.request({ method: 'eth_chainId' });
            return parseInt(currentChainId, 16) === Number(expectedChainIdDec);
        } catch (err) {
            showNotice('Please switch your wallet to the active election network.', 'warning');
            return false;
        }
    }

    async function syncServerStatus() {
        try {
            const electionId = getCurrentElectionId();
            const query = electionId ? '?election_id=' + encodeURIComponent(electionId) : '';
            const res = await fetch('/api/wallet/status/' + query, { credentials: 'same-origin' });
            if (!res.ok) return null;
            const data = await res.json();
            if (data.chain_id) {
                expectedChainIdDec = Number(data.chain_id);
            }
            if (data.authenticated && data.wallet) {
                currentAddress = data.wallet;
                isAuthenticated = true;
            } else {
                isAuthenticated = false;
            }
            if (data.voter_name) {
                const nameInput = document.getElementById('input-voter-name');
                if (nameInput && !nameInput.value) {
                    nameInput.value = data.voter_name;
                }
                const summaryEl = document.getElementById('voter-session-summary');
                if (summaryEl && data.aadhar_masked) {
                    summaryEl.textContent = 'Signed in as ' + data.voter_name + ' (' + data.aadhar_masked + '). Enter your 12-digit Voter ID to submit your vote.';
                }
            }
            if (data.verified_receipt) {
                renderVerifiedReceipt(data.verified_receipt);
            }
            updateUI();
            return data;
        } catch (err) {
            return null;
        }
    }

    async function connectAndAuthenticate() {
        if (typeof window.ethereum === 'undefined') {
            showNotice('Wallet extension not detected. Please open this page in a wallet-enabled browser.', 'error');
            return false;
        }

        try {
            showNotice('Select your account in your wallet...', 'info');
            const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
            if (!accounts || accounts.length === 0) {
                showNotice('No wallet account selected.', 'error');
                return false;
            }

            currentAddress = accounts[0];
            currentChainId = await window.ethereum.request({ method: 'eth_chainId' });

            const existingStatus = await syncServerStatus();
            if (
                existingStatus &&
                existingStatus.authenticated &&
                existingStatus.wallet &&
                existingStatus.wallet.toLowerCase() === currentAddress.toLowerCase()
            ) {
                await ensureExpectedNetwork();
                updateUI();
                showNotice('Wallet connected and verified.', 'success');
                return true;
            }

            await ensureExpectedNetwork();
            updateUI();

            const challengeRes = await fetch(
                '/api/wallet/challenge/?address=' + encodeURIComponent(currentAddress),
                { credentials: 'same-origin' }
            );
            const challengeData = await challengeRes.json();

            if (!challengeRes.ok) {
                showNotice(challengeData.error || 'Could not start wallet verification.', 'error');
                return false;
            }

            showNotice('Approve the verification request in your wallet...', 'info');
            const signature = await window.ethereum.request({
                method: 'personal_sign',
                params: [challengeData.challenge, currentAddress]
            });

            const aadharInput = document.getElementById('input-aadhar');
            const rawAadhar = aadharInput ? aadharInput.value.trim() : '';

            const verifyRes = await fetch('/api/wallet/verify/', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken')
                },
                body: JSON.stringify({
                    address: currentAddress,
                    nonce: challengeData.nonce,
                    signature: signature,
                    aadhar: rawAadhar
                })
            });

            const verifyData = await verifyRes.json();
            if (!verifyRes.ok) {
                isAuthenticated = false;
                updateUI();
                showNotice(verifyData.error || 'Wallet verification failed.', 'error');
                return false;
            }

            isAuthenticated = true;
            currentAddress = verifyData.wallet;
            await syncServerStatus();
            updateUI();
            showNotice('Wallet connected and verified.', 'success');
            return true;
        } catch (err) {
            if (err && err.code === 4001) {
                showNotice('Verification request cancelled.', 'warning');
            } else {
                showNotice(err.message || 'Wallet connection failed.', 'error');
            }
            return false;
        }
    }

    async function disconnectWallet() {
        try {
            await fetch('/api/wallet/disconnect/', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-CSRFToken': getCookie('csrftoken')
                }
            });
        } catch (err) {
            // Ignore network error on disconnect
        }
        currentAddress = null;
        isAuthenticated = false;
        updateUI();
        showNotice('Wallet disconnected.', 'info');
    }

    function selectCandidateCard(candidateId) {
        const cards = document.querySelectorAll('[data-candidate-card]');
        const hiddenInput = document.getElementById('input-candidate-id');
        const indicatorEl = document.getElementById('selected-candidate-indicator');
        const summaryEl = document.getElementById('ballot-selection-summary');

        let chosenName = '';
        let chosenParty = '';

        cards.forEach(function (card) {
            const cid = card.getAttribute('data-candidate-id');
            const isMatch = String(cid) === String(candidateId);
            card.classList.toggle('is-selected', isMatch);
            card.setAttribute('aria-checked', isMatch ? 'true' : 'false');

            const badge = card.querySelector('[data-candidate-badge]');
            if (badge) {
                badge.textContent = isMatch ? 'Selected on Ballot' : 'Select';
                badge.className = 'status-badge ' + (isMatch ? 'status-authenticated' : 'status-disconnected');
            }

            const candName = card.getAttribute('data-candidate-name') || 'Candidate';
            if (isMatch) {
                chosenName = candName;
                chosenParty = card.getAttribute('data-candidate-party') || '';
            }
        });

        if (hiddenInput) {
            hiddenInput.value = String(candidateId);
        }

        if (indicatorEl && chosenName) {
            indicatorEl.textContent = '#' + candidateId + ' ' + chosenName;
            indicatorEl.className = 'status-badge status-active';
        }

        if (summaryEl && chosenName) {
            summaryEl.textContent = 'Selected: #' + candidateId + ' ' + chosenName + (chosenParty ? ' (' + chosenParty + ')' : '');
        }

        updateUI();
    }

    function openBallotReviewModal() {
        showVoteFeedback('', 'info');
        const candInput = document.getElementById('input-candidate-id');
        const aadharInput = document.getElementById('input-aadhar');

        if (!candInput || !candInput.value) {
            showVoteFeedback('Please select a candidate.', 'error');
            return;
        }

        const aadhar = aadharInput ? aadharInput.value.trim() : '';
        if (!aadhar || !/^\d{12}$/.test(aadhar)) {
            showVoteFeedback('Please enter your 12-digit Voter ID.', 'error');
            if (aadharInput) aadharInput.focus();
            return;
        }

        const selectedCard = document.querySelector('[data-candidate-card][data-candidate-id="' + candInput.value + '"]');
        const candidateName = selectedCard ? selectedCard.getAttribute('data-candidate-name') : ('Candidate #' + candInput.value);
        const candidateParty = selectedCard ? selectedCard.getAttribute('data-candidate-party') : '';

        const nameEl = document.getElementById('review-modal-candidate-name');
        const partyEl = document.getElementById('review-modal-candidate-party');
        const idEl = document.getElementById('review-modal-candidate-id');

        if (nameEl) nameEl.textContent = candidateName;
        if (partyEl) partyEl.textContent = candidateParty;
        if (idEl) idEl.textContent = '#' + candInput.value;

        const modal = document.getElementById('modal-ballot-review');
        if (modal) {
            modal.classList.add('is-open');
        }
    }

    function closeBallotReviewModal() {
        const modal = document.getElementById('modal-ballot-review');
        if (modal) {
            modal.classList.remove('is-open');
        }
    }

    function renderVerifiedReceipt(receiptData) {
        const panel = document.getElementById('ballot-receipt-panel');
        if (!panel || !receiptData) return;

        const refCodeEl = document.getElementById('receipt-reference-code');
        const tsEl = document.getElementById('receipt-timestamp-display');
        const titleEl = document.getElementById('receipt-election-title');

        if (refCodeEl && receiptData.receipt_reference) {
            refCodeEl.textContent = receiptData.receipt_reference;
        }
        if (tsEl && receiptData.confirmed_at) {
            tsEl.textContent = receiptData.confirmed_at;
        }
        if (titleEl && receiptData.election_title) {
            titleEl.textContent = receiptData.election_title;
        }

        panel.classList.remove('is-hidden');

        const root = document.getElementById('voter-portal-root');
        if (root) {
            root.dataset.hasVoted = 'true';
        }

        const eligBadge = document.getElementById('voter-eligibility-badge');
        if (eligBadge) {
            eligBadge.textContent = '';
            const strong = document.createElement('strong');
            strong.className = 'status-badge status-authenticated';
            strong.textContent = 'Ballot Recorded';
            eligBadge.appendChild(strong);
        }

        const reviewBtn = document.getElementById('btn-review-ballot');
        if (reviewBtn) {
            reviewBtn.disabled = true;
            reviewBtn.textContent = 'Vote Recorded';
        }
    }

    async function waitForReceipt(txHash, maxAttempts) {
        const limit = maxAttempts || 35;
        for (let i = 0; i < limit; i++) {
            const receipt = await window.ethereum.request({
                method: 'eth_getTransactionReceipt',
                params: [txHash]
            });
            if (receipt) return receipt;
            await new Promise(function (resolve) { setTimeout(resolve, 1000); });
        }
        throw new Error('Confirmation timed out.');
    }

    async function executeConfirmedVoteSubmission() {
        if (activeSubmissionInFlight) return;

        closeBallotReviewModal();

        const candInput = document.getElementById('input-candidate-id');
        const aadharInput = document.getElementById('input-aadhar');
        const confirmBtn = document.getElementById('btn-confirm-submit-vote');
        const reviewBtn = document.getElementById('btn-review-ballot');

        const candidateId = candInput ? parseInt(candInput.value, 10) : NaN;
        const aadhar = aadharInput ? aadharInput.value.trim() : '';
        const electionId = getCurrentElectionId();

        if (!candidateId || isNaN(candidateId)) {
            showVoteFeedback('Please select a candidate.', 'error');
            return;
        }
        if (!aadhar || !/^\d{12}$/.test(aadhar)) {
            showVoteFeedback('Please enter a valid 12-digit Voter ID.', 'error');
            return;
        }

        if (!isAuthenticated || !currentAddress) {
            const connected = await connectAndAuthenticate();
            if (!connected) return;
        }

        const networkOk = await ensureExpectedNetwork();
        if (!networkOk) return;

        activeSubmissionInFlight = true;
        if (confirmBtn) confirmBtn.disabled = true;
        if (reviewBtn) reviewBtn.disabled = true;

        try {
            updateProgressStage('Preparing your ballot.', 'info');
            showVoteFeedback('', 'info');

            const permitPayload = {
                candidate_id: candidateId,
                aadhar: aadhar
            };
            if (electionId) {
                permitPayload.election_id = electionId;
            }

            const permitRes = await fetch('/api/ballot/permit/', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken')
                },
                body: JSON.stringify(permitPayload)
            });

            const permitData = await permitRes.json();
            if (!permitRes.ok) {
                updateProgressStage('', 'info');
                showVoteFeedback(permitData.error || 'Ballot authorization declined.', 'error');
                activeSubmissionInFlight = false;
                if (confirmBtn) confirmBtn.disabled = false;
                if (reviewBtn) reviewBtn.disabled = false;
                return;
            }

            const p = permitData.permit;
            const txData = encodeCastVoteWithPermit(
                p.candidateId,
                p.voterNullifier,
                p.deadline,
                p.nonce,
                p.v,
                p.r,
                p.s
            );

            updateProgressStage('Waiting for voting authorization.', 'info');

            const txHash = await window.ethereum.request({
                method: 'eth_sendTransaction',
                params: [{
                    from: currentAddress,
                    to: permitData.contract_address,
                    data: txData
                }]
            });

            updateProgressStage('Confirming your vote.', 'info');

            const receipt = await waitForReceipt(txHash, 35);
            if (receipt.status !== '0x1') {
                updateProgressStage('', 'info');
                showVoteFeedback('Your vote could not be recorded.', 'error');
                activeSubmissionInFlight = false;
                if (confirmBtn) confirmBtn.disabled = false;
                if (reviewBtn) reviewBtn.disabled = false;
                return;
            }

            const confirmRes = await fetch('/api/ballot/confirm/', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken')
                },
                body: JSON.stringify({
                    tx_hash: txHash,
                    nullifier: p.voterNullifier,
                    permit_nonce: p.nonce
                })
            });

            const confirmData = await confirmRes.json();
            if (!confirmRes.ok) {
                updateProgressStage('', 'info');
                showVoteFeedback(confirmData.error || 'Vote confirmation failed.', 'warning');
                activeSubmissionInFlight = false;
                if (confirmBtn) confirmBtn.disabled = false;
                if (reviewBtn) reviewBtn.disabled = false;
                return;
            }

            updateProgressStage('Vote successfully recorded.', 'success');
            showVoteFeedback('', 'info');

            renderVerifiedReceipt({
                receipt_reference: confirmData.receipt_reference,
                tx_hash: confirmData.tx_hash,
                block_number: confirmData.block_number,
                contract_address: permitData.contract_address,
                confirmed_at: confirmData.confirmed_at,
                election_title: confirmData.election_title
            });

            const receiptPanel = document.getElementById('ballot-receipt-panel');
            if (receiptPanel && typeof receiptPanel.scrollIntoView === 'function') {
                receiptPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        } catch (err) {
            updateProgressStage('', 'info');
            if (err && err.code === 4001) {
                showVoteFeedback('Voting authorization was cancelled. Your vote was not submitted.', 'warning');
            } else {
                showVoteFeedback(err.message || 'Vote submission failed.', 'error');
            }
            if (confirmBtn) confirmBtn.disabled = false;
            if (reviewBtn) reviewBtn.disabled = false;
        } finally {
            activeSubmissionInFlight = false;
        }
    }

    function bindCandidateCards() {
        const cards = document.querySelectorAll('[data-candidate-card]');
        cards.forEach(function (card) {
            const cid = card.getAttribute('data-candidate-id');
            card.addEventListener('click', function () {
                selectCandidateCard(cid);
            });
            card.addEventListener('keydown', function (ev) {
                if (ev.key === 'Enter' || ev.key === ' ') {
                    ev.preventDefault();
                    selectCandidateCard(cid);
                }
            });
        });
    }

    function init() {
        const connectBtn = document.getElementById('btn-connect-wallet');
        const disconnectBtn = document.getElementById('btn-disconnect-wallet');
        const voteForm = document.getElementById('vote-form');
        const reviewBtn = document.getElementById('btn-review-ballot');
        const cancelReviewBtn = document.getElementById('btn-cancel-ballot-review');
        const confirmVoteBtn = document.getElementById('btn-confirm-submit-vote');

        if (connectBtn) {
            connectBtn.addEventListener('click', connectAndAuthenticate);
        }
        if (disconnectBtn) {
            disconnectBtn.addEventListener('click', disconnectWallet);
        }

        bindCandidateCards();

        if (reviewBtn) {
            reviewBtn.addEventListener('click', openBallotReviewModal);
        }
        if (cancelReviewBtn) {
            cancelReviewBtn.addEventListener('click', closeBallotReviewModal);
        }
        if (confirmVoteBtn) {
            confirmVoteBtn.addEventListener('click', executeConfirmedVoteSubmission);
        }

        if (voteForm) {
            voteForm.addEventListener('submit', function (ev) {
                ev.preventDefault();
                openBallotReviewModal();
            });
        }

        if (typeof window.ethereum !== 'undefined') {
            window.ethereum.request({ method: 'eth_chainId' })
                .then(function (chainId) {
                    currentChainId = chainId;
                    return syncServerStatus();
                })
                .catch(function () {
                    syncServerStatus();
                });

            window.ethereum.on('accountsChanged', async function (accounts) {
                if (!accounts || accounts.length === 0) {
                    await disconnectWallet();
                } else if (currentAddress && accounts[0].toLowerCase() !== currentAddress.toLowerCase()) {
                    await disconnectWallet();
                    currentAddress = accounts[0];
                    updateUI();
                    showNotice('Active wallet account changed. Please verify your wallet.', 'warning');
                }
            });

            window.ethereum.on('chainChanged', function (chainId) {
                currentChainId = chainId;
                updateUI();
            });
        } else {
            syncServerStatus();
            showNotice('Wallet extension not detected.', 'warning');
        }
    }

    document.addEventListener('DOMContentLoaded', init);

    return {
        connectAndAuthenticate: connectAndAuthenticate,
        disconnectWallet: disconnectWallet,
        syncServerStatus: syncServerStatus,
        selectCandidateCard: selectCandidateCard,
        isWalletAuthenticated: function () { return isAuthenticated; },
        getCurrentAddress: function () { return currentAddress; }
    };
})();
