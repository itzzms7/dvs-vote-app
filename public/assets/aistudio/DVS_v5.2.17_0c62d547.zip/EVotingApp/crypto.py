"""
Cryptographic service functions for E-Voting:
- HMAC-SHA256 nullifier derivation with server secret pepper
- EIP-712 BallotPermit typed-data signing
- EIP-191 personal_sign challenge verification
- Strict ECDSA validation
"""

import hmac
import hashlib
from django.conf import settings
from web3 import Web3
from eth_account import Account
from eth_account.messages import encode_defunct, encode_typed_data

SECP256K1_N_DIV_2 = 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0


def derive_voter_nullifier(election_id: int, aadhar_number: str) -> str:
    """
    Derives an opaque, election-specific voter nullifier.
    Encoding: UTF-8 of '{election_id}:{aadhar_number}'
    HMAC: HMAC-SHA256 with server-side ELECTION_NULLIFIER_PEPPER
    Final Digest: Keccak-256 over HMAC digest -> 32-byte hex string.
    """
    pepper_bytes = settings.ELECTION_NULLIFIER_PEPPER.encode('utf-8')
    msg_bytes = f"{int(election_id)}:{str(aadhar_number).strip()}".encode('utf-8')
    hmac_digest = hmac.new(pepper_bytes, msg_bytes, hashlib.sha256).digest()
    nullifier_bytes = Web3.keccak(hmac_digest)
    return '0x' + nullifier_bytes.hex()


def verify_eip191_signature(message_text: str, signature_hex: str, expected_address: str) -> bool:
    """
    Verifies an EIP-191 personal_sign message against the expected address.
    Strictly enforces signature length, canonical recovery ID, and low-S.
    """
    try:
        expected = Web3.to_checksum_address(expected_address)
        signable = encode_defunct(text=message_text)
        recovered = Account.recover_message(signable, signature=signature_hex)
        return recovered.lower() == expected.lower()
    except Exception as e:
        print(f"EIP-191 verification failed: {e}")
        return False


def sign_eip712_ballot_permit(
    voter_wallet: str,
    candidate_id: int,
    election_id: int,
    voter_nullifier: str,
    deadline: int,
    nonce: str,
    chain_id: int,
    contract_address: str,
    authority_private_key: str
) -> dict:
    """
    Constructs and signs an EIP-712 BallotPermit payload.
    Matches EVoting.sol types, ordering, and domain separator exactly.
    """
    checksum_wallet = Web3.to_checksum_address(voter_wallet)
    checksum_contract = Web3.to_checksum_address(contract_address)

    # Ensure bytes32 formatting
    if not voter_nullifier.startswith('0x'):
        voter_nullifier = '0x' + voter_nullifier
    if not nonce.startswith('0x'):
        nonce = '0x' + nonce

    typed_data = {
        "types": {
            "EIP712Domain": [
                {"name": "name", "type": "string"},
                {"name": "version", "type": "string"},
                {"name": "chainId", "type": "uint256"},
                {"name": "verifyingContract", "type": "address"},
            ],
            "BallotPermit": [
                {"name": "voterWallet", "type": "address"},
                {"name": "candidateId", "type": "int256"},
                {"name": "electionId", "type": "uint256"},
                {"name": "voterNullifier", "type": "bytes32"},
                {"name": "deadline", "type": "uint256"},
                {"name": "nonce", "type": "bytes32"},
            ],
        },
        "primaryType": "BallotPermit",
        "domain": {
            "name": settings.ELECTION_DOMAIN_NAME,
            "version": settings.ELECTION_DOMAIN_VERSION,
            "chainId": int(chain_id),
            "verifyingContract": checksum_contract,
        },
        "message": {
            "voterWallet": checksum_wallet,
            "candidateId": int(candidate_id),
            "electionId": int(election_id),
            "voterNullifier": voter_nullifier,
            "deadline": int(deadline),
            "nonce": nonce,
        },
    }

    signable_message = encode_typed_data(full_message=typed_data)
    signed = Account.sign_message(signable_message, authority_private_key)

    # Validate strict low-s
    s_int = signed.s
    if s_int > SECP256K1_N_DIV_2:
        raise ValueError("Generated signature has non-canonical high-S value.")

    v = signed.v
    r_hex = '0x' + signed.r.to_bytes(32, 'big').hex()
    s_hex = '0x' + signed.s.to_bytes(32, 'big').hex()

    return {
        "candidateId": int(candidate_id),
        "voterNullifier": voter_nullifier,
        "deadline": int(deadline),
        "nonce": nonce,
        "v": v,
        "r": r_hex,
        "s": s_hex,
        "voterWallet": checksum_wallet,
        "electionId": int(election_id),
        "contractAddress": checksum_contract,
        "chainId": int(chain_id),
    }
