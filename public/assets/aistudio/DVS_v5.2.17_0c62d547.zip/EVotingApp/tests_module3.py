import json
import time
import secrets
from datetime import timedelta
from django.test import TestCase, Client
from django.contrib.auth.models import User, Group
from django.utils import timezone
from web3 import Web3
from eth_account import Account

from EVotingApp.models import (
    Voter,
    Election,
    ContractDeployment,
    Candidate,
    VoterEligibility,
    ElectionAdminAssignment,
    IssuedPermit,
)
from EVotingApp.crypto import derive_voter_nullifier, sign_eip712_ballot_permit
from EVotingApp.services import (
    get_web3_provider,
    load_contract_artifact,
    inspect_deployed_contract,
    deploy_election_contract,
    add_election_candidate,
    update_election_candidate,
    deactivate_election_candidate,
    sync_and_lock_candidates,
    configure_voting_window,
    activate_election,
    close_election,
    reconcile_election_results,
    verify_historical_deployment_results,
    authorize_result_publication,
    finalize_election,
    get_public_election_summary,
    ElectionLifecycleError,
)


class Module3CorrectionsAndLifecycleTests(TestCase):
    def setUp(self):
        self.client = Client()

        # Groups
        self.super_group, _ = Group.objects.get_or_create(name='Super Admin')
        self.admin_group, _ = Group.objects.get_or_create(name='Election Administrator')
        self.auditor_group, _ = Group.objects.get_or_create(name='Auditor')

        # Users
        self.superuser = User.objects.create_superuser(
            username='super_ctrl', password='password123', email='super@dvs.local'
        )
        self.election_admin = User.objects.create_user(
            username='el_admin', password='password123', is_staff=True
        )
        self.election_admin.groups.add(self.admin_group)

        self.auditor = User.objects.create_user(
            username='el_auditor', password='password123', is_staff=True
        )
        self.auditor.groups.add(self.auditor_group)

        self.unassigned_admin = User.objects.create_user(
            username='other_admin', password='password123', is_staff=True
        )
        self.unassigned_admin.groups.add(self.admin_group)

        # Create a test election in DRAFT state
        self.election = Election.objects.create(
            title='2026 University Council Election',
            description='General Student Council Election',
            election_type='GENERAL',
            election_id=3050,
            status='DRAFT',
            deployment_status='NOT_DEPLOYED',
            contract_address='0x5FbDB2315678afecb367f032d93F642f64180aa3',  # Initial legacy placeholder
            start_datetime=timezone.now() - timedelta(minutes=5),
            end_datetime=timezone.now() + timedelta(days=2),
        )
        Candidate.objects.create(election=self.election, candidate_id_num=1, name='Rahul Gandhi', symbol='Congress')
        Candidate.objects.create(election=self.election, candidate_id_num=2, name='Narendar Modi', symbol='BJP')
        Candidate.objects.create(election=self.election, candidate_id_num=3, name='Akhilesh Yadav', symbol='Samajwadi')

        # Assign election_admin and auditor to self.election
        ElectionAdminAssignment.objects.create(
            election=self.election, user=self.election_admin, role='ELECTION_ADMIN'
        )
        ElectionAdminAssignment.objects.create(
            election=self.election, user=self.auditor, role='AUDITOR'
        )

        # Seed a test voter & historical permit on the old contract
        self.voter = Voter.objects.create(
            aadhar_number='445566778899',
            name='Confidential Citizen Name',
            bound_wallet='0x1111111111111111111111111111111111111111',
            has_voted=True,
        )
        VoterEligibility.objects.create(
            voter=self.voter,
            election=self.election,
            is_eligible=True,
            has_voted=True,
        )
        self.historical_permit = IssuedPermit.objects.create(
            permit_nonce='0x' + ('aa' * 32),
            voter=self.voter,
            election_ref=self.election,
            candidate_id=1,
            election_id=3050,
            voter_nullifier='0x' + ('bb' * 32),
            deadline=9999999999,
            is_consumed_on_chain=True,
            is_historical_legacy=False,
        )

    def test_route_namespaces_public_vote_and_control(self):
        """Verify '/', '/public/elections/', '/vote/', and '/control/' routes resolve without conflicting with '/admin/'."""
        res_home = self.client.get('/')
        self.assertEqual(res_home.status_code, 200)

        res_public = self.client.get('/public/elections/')
        self.assertEqual(res_public.status_code, 200)
        self.assertIn('elections', res_public.json())

        res_vote = self.client.get('/vote/')
        self.assertEqual(res_vote.status_code, 200)

        res_control = self.client.get('/control/')
        self.assertEqual(res_control.status_code, 200)

    def test_public_endpoint_exposes_zero_voter_pii_and_hides_active_results(self):
        """
        Verify that public election endpoints:
        - Hide candidate-wise results during ACTIVE voting by default.
        - Never expose voter names, Aadhaar numbers, bound wallets, or individual ballots.
        """
        self.election.status = 'ACTIVE'
        self.election.save()

        res = self.client.get(f'/api/public/elections/{self.election.election_id}/')
        self.assertEqual(res.status_code, 200)
        payload = res.json()
        raw_json = res.content.decode('utf-8')

        self.assertFalse(payload['results']['visible'])
        self.assertEqual(payload['results']['classification'], 'HIDDEN')
        self.assertEqual(payload['results']['candidates'], [])

        self.assertNotIn('445566778899', raw_json)
        self.assertNotIn('Confidential Citizen Name', raw_json)
        self.assertNotIn('0x1111111111111111111111111111111111111111', raw_json)
        self.assertNotIn('bb' * 32, raw_json)

    def test_provisional_verified_and_official_result_states(self):
        """
        Verify result publication & verification progression:
        1. CLOSED + unpublished -> HIDDEN
        2. CLOSED + published (unverified) -> PROVISIONAL
        3. CLOSED + published + reconciled -> VERIFIED
        4. FINALIZED + reconciled -> OFFICIAL
        """
        self.election.status = 'CLOSED'
        self.election.results_published = False
        self.election.results_verified = False
        self.election.save()

        summary_1 = get_public_election_summary(self.election)
        self.assertFalse(summary_1['results']['visible'])
        self.assertEqual(summary_1['results']['classification'], 'HIDDEN')

        authorize_result_publication(self.election.pk, publish=True, actor_user=self.election_admin)
        self.election.refresh_from_db()
        summary_2 = get_public_election_summary(self.election)
        self.assertTrue(summary_2['results']['visible'])
        self.assertEqual(summary_2['results']['classification'], 'PROVISIONAL')
        self.assertEqual(len(summary_2['results']['candidates']), 3)

        self.election.results_verified = True
        self.election.reconciled_at = timezone.now()
        self.election.save()
        summary_3 = get_public_election_summary(self.election)
        self.assertTrue(summary_3['results']['visible'])
        self.assertEqual(summary_3['results']['classification'], 'VERIFIED')

        self.election.status = 'FINALIZED'
        self.election.finalized_at = timezone.now()
        self.election.save()
        summary_4 = get_public_election_summary(self.election)
        self.assertTrue(summary_4['results']['visible'])
        self.assertEqual(summary_4['results']['classification'], 'OFFICIAL')

    def test_auditor_permissions_strictly_read_only_on_backend_and_api(self):
        """
        Verify that an Auditor can perform GET requests on assigned election audit endpoints
        but is rejected with 403 Forbidden on all write endpoints and POST requests.
        """
        self.client.login(username='el_auditor', password='password123')

        audit_get = self.client.get(f'/api/control/elections/{self.election.election_id}/audit/')
        self.assertEqual(audit_get.status_code, 200)

        audit_post = self.client.post(f'/api/control/elections/{self.election.election_id}/audit/')
        self.assertEqual(audit_post.status_code, 403)

        write_endpoints = [
            f'/api/control/elections/{self.election.election_id}/deploy/',
            f'/api/control/elections/{self.election.election_id}/window/',
            f'/api/control/elections/{self.election.election_id}/activate/',
            f'/api/control/elections/{self.election.election_id}/close/',
            f'/api/control/elections/{self.election.election_id}/reconcile/',
            f'/api/control/elections/{self.election.election_id}/publish/',
            f'/api/control/elections/{self.election.election_id}/finalize/',
            f'/api/control/elections/{self.election.election_id}/candidates/',
            f'/api/control/elections/{self.election.election_id}/candidates/1/update/',
            f'/api/control/elections/{self.election.election_id}/candidates/1/deactivate/',
            f'/api/control/elections/{self.election.election_id}/candidates/lock/',
        ]
        for url in write_endpoints:
            res = self.client.post(url, data=json.dumps({}), content_type='application/json')
            self.assertEqual(res.status_code, 403, f"Auditor must be blocked on {url}")

    def test_unassigned_election_admin_blocked_from_other_election(self):
        """Verify an Election Administrator not assigned to an election is rejected with 403."""
        self.client.login(username='other_admin', password='password123')
        res = self.client.get(f'/api/control/elections/{self.election.election_id}/audit/')
        self.assertEqual(res.status_code, 403)

    def test_voting_window_immutability_in_backend_service(self):
        """
        Verify configure_voting_window:
        - Allows changes before activation (DRAFT / SCHEDULED).
        - Rejects changes after activation (ACTIVE) or closure (CLOSED).
        """
        now = timezone.now()
        start_1 = now + timedelta(hours=1)
        end_1 = now + timedelta(hours=5)

        configure_voting_window(self.election.pk, start_1, end_1, actor_user=self.election_admin)
        self.election.refresh_from_db()
        self.assertEqual(self.election.start_datetime, start_1)

        start_2 = now + timedelta(hours=2)
        end_2 = now + timedelta(hours=6)
        configure_voting_window(self.election.pk, start_2, end_2, actor_user=self.election_admin)
        self.election.refresh_from_db()
        self.assertEqual(self.election.start_datetime, start_2)

        self.election.status = 'ACTIVE'
        self.election.voting_window_locked_on_chain = True
        self.election.save()

        with self.assertRaises(ElectionLifecycleError):
            configure_voting_window(self.election.pk, start_1, end_1, actor_user=self.election_admin)

        self.election.status = 'CLOSED'
        self.election.save()

        with self.assertRaises(ElectionLifecycleError):
            configure_voting_window(self.election.pk, start_1, end_1, actor_user=self.election_admin)

    def test_full_lifecycle_deploy_schedule_activate_close_reconcile_finalize(self):
        """
        End-to-end Module 3 & 4 lifecycle test against local Hardhat node:
        DRAFT -> CONTRACT DEPLOYED -> SCHEDULED -> CANDIDATE SYNCHRONIZATION ->
        CANDIDATE LOCK -> window update -> ACTIVE (locks window) -> CLOSED -> RECONCILED -> FINALIZED (OFFICIAL).
        Also verifies legacy contract address preservation and historical permit separation.
        """
        w3 = get_web3_provider()
        if not w3.is_connected():
            self.skipTest("Hardhat node not running")

        # 1. Deploy replacement contract (transitions DRAFT -> SCHEDULED, roster remains UNLOCKED and empty on-chain)
        new_addr = deploy_election_contract(self.election.pk, actor_user=self.election_admin, force_redeploy=True)
        self.election.refresh_from_db()
        self.historical_permit.refresh_from_db()

        self.assertEqual(self.election.status, 'SCHEDULED')
        self.assertEqual(self.election.deployment_status, 'DEPLOYED')
        self.assertEqual(self.election.contract_address, new_addr)
        self.assertEqual(self.election.legacy_contract_address, '0x5FbDB2315678afecb367f032d93F642f64180aa3')
        self.assertTrue(self.election.deployment_tx_hash.startswith('0x'))
        self.assertIsNotNone(self.election.deployment_block_number)
        self.assertTrue(self.election.deployed_bytecode_hash.startswith('0x'))
        self.assertFalse(self.election.candidates_locked_on_chain)
        self.assertFalse(self.election.voting_window_locked_on_chain)

        # Verify historical permit was preserved separately and tagged as legacy
        self.assertTrue(self.historical_permit.is_historical_legacy)
        self.assertEqual(self.historical_permit.contract_address, '0x5FbDB2315678afecb367f032d93F642f64180aa3')

        inspection = inspect_deployed_contract(new_addr)
        self.assertTrue(inspection['has_code'])
        self.assertTrue(inspection['is_compatible'])
        self.assertEqual(inspection['state']['getCandidateIds'], [])
        self.assertFalse(inspection['state']['candidatesLocked'])
        self.assertFalse(inspection['state']['votingWindowLocked'])

        # Activation before candidate synchronization and locking must be rejected
        with self.assertRaises(ElectionLifecycleError):
            activate_election(self.election.pk, actor_user=self.election_admin)

        # 2. Candidate Synchronization in SCHEDULED state (lock_on_chain=False)
        sync_and_lock_candidates(self.election.pk, lock_on_chain=False, actor_user=self.election_admin)
        self.election.refresh_from_db()
        self.assertFalse(self.election.candidates_locked_on_chain)

        # Activation while candidates are synced but roster is still unlocked must be rejected
        with self.assertRaises(ElectionLifecycleError):
            activate_election(self.election.pk, actor_user=self.election_admin)

        # 3. Candidate Lock in SCHEDULED state (lock_on_chain=True)
        sync_and_lock_candidates(self.election.pk, lock_on_chain=True, actor_user=self.election_admin)
        self.election.refresh_from_db()
        self.assertTrue(self.election.candidates_locked_on_chain)

        # 4. Configure and update voting window while in SCHEDULED (pre-activation)
        now = timezone.now()
        configure_voting_window(
            self.election.pk,
            now - timedelta(minutes=5),
            now + timedelta(hours=2),
            actor_user=self.election_admin
        )

        # 5. Activate election (SCHEDULED -> ACTIVE)
        activate_election(self.election.pk, actor_user=self.election_admin)
        self.election.refresh_from_db()
        self.assertEqual(self.election.status, 'ACTIVE')
        self.assertTrue(self.election.voting_window_locked_on_chain)

        inspection_active = inspect_deployed_contract(new_addr)
        self.assertTrue(inspection_active['state']['electionOpen'])
        self.assertTrue(inspection_active['state']['candidatesLocked'])
        self.assertTrue(inspection_active['state']['votingWindowLocked'])
        self.assertEqual(inspection_active['state']['getCandidateIds'], [1, 2, 3])

        # 6. Close election (ACTIVE -> CLOSED)
        close_election(self.election.pk, actor_user=self.election_admin)
        self.election.refresh_from_db()
        self.assertEqual(self.election.status, 'CLOSED')

        # 7. Reconcile election results (active contract votes = 0, historical legacy = 1)
        recon = reconcile_election_results(self.election.pk, actor_user=self.election_admin)
        self.assertTrue(recon['results_verified'])
        self.assertEqual(recon['onchain_total_votes'], 0)
        self.assertEqual(recon['db_confirmed_votes'], 0)
        self.assertEqual(recon['historical_legacy_permits_count'], 1)

        # 8. Finalize election (CLOSED -> FINALIZED -> OFFICIAL)
        finalize_election(self.election.pk, actor_user=self.election_admin)
        self.election.refresh_from_db()
        self.assertEqual(self.election.status, 'FINALIZED')
        self.assertIsNotNone(self.election.finalized_at)

        summary = get_public_election_summary(self.election)
        self.assertTrue(summary['results']['visible'])
        self.assertEqual(summary['results']['classification'], 'OFFICIAL')
        self.assertEqual(
            summary['blockchain_audit']['historical_legacy_archive']['historical_permit_records_count'],
            1
        )

    def test_multiple_contract_deployments_preserved_without_overwriting_history(self):
        """
        Verification Pass Item 1:
        Verify that repeated redeployments (Deployment 1 -> Deployment 2 -> Deployment 3)
        create distinct ContractDeployment records and NEVER overwrite historical
        chain_id, contract_address, deployment_tx_hash, deployment_block_number, or deployed_bytecode_hash.
        """
        w3 = get_web3_provider()
        if not w3.is_connected():
            self.skipTest("Hardhat node not running")

        # Clear initial placeholder address so we test 3 real sequential deployments
        self.election.contract_address = ''
        self.election.save()

        addr_1 = deploy_election_contract(self.election.pk, actor_user=self.election_admin, force_redeploy=True)
        dep_1 = ContractDeployment.objects.get(election=self.election, contract_address=addr_1)
        tx_1 = dep_1.deployment_tx_hash
        block_1 = dep_1.deployment_block_number
        hash_1 = dep_1.deployed_bytecode_hash

        addr_2 = deploy_election_contract(self.election.pk, actor_user=self.election_admin, force_redeploy=True)
        dep_2 = ContractDeployment.objects.get(election=self.election, contract_address=addr_2)
        tx_2 = dep_2.deployment_tx_hash
        block_2 = dep_2.deployment_block_number
        hash_2 = dep_2.deployed_bytecode_hash

        addr_3 = deploy_election_contract(self.election.pk, actor_user=self.election_admin, force_redeploy=True)
        dep_3 = ContractDeployment.objects.get(election=self.election, contract_address=addr_3)

        self.assertEqual(ContractDeployment.objects.filter(election=self.election).count(), 3)
        self.assertEqual(len({addr_1, addr_2, addr_3}), 3)

        # Verify dep_1 and dep_2 were never overwritten and retain exact metadata
        dep_1.refresh_from_db()
        dep_2.refresh_from_db()
        dep_3.refresh_from_db()

        self.assertFalse(dep_1.is_active_deployment)
        self.assertTrue(dep_1.is_historical_legacy)
        self.assertIsNotNone(dep_1.superseded_at)
        self.assertEqual(dep_1.deployment_tx_hash, tx_1)
        self.assertEqual(dep_1.deployment_block_number, block_1)
        self.assertEqual(dep_1.deployed_bytecode_hash, hash_1)
        self.assertEqual(dep_1.chain_id, 31337)

        self.assertFalse(dep_2.is_active_deployment)
        self.assertTrue(dep_2.is_historical_legacy)
        self.assertIsNotNone(dep_2.superseded_at)
        self.assertEqual(dep_2.deployment_tx_hash, tx_2)
        self.assertEqual(dep_2.deployment_block_number, block_2)
        self.assertEqual(dep_2.deployed_bytecode_hash, hash_2)

        self.assertTrue(dep_3.is_active_deployment)
        self.assertFalse(dep_3.is_historical_legacy)
        self.assertIsNone(dep_3.superseded_at)

    def test_historical_permits_vs_cast_votes_and_replacement_isolation(self):
        """
        Verification Pass Item 2:
        - Distinguish issued historical permits (unconsumed) from cast historical votes (receipt + VoteCast verified).
        - Verify historical results using actual transaction receipts and VoteCast events.
        - Ensure old unconsumed permits cannot be used or confirmed through the replacement contract workflow.
        - Keep historical contract results separate from the current contract's results.
        """
        w3 = get_web3_provider()
        if not w3.is_connected():
            self.skipTest("Hardhat node not running")

        from django.conf import settings
        abi, _, _ = load_contract_artifact()
        authority_key = settings.ELECTION_AUTHORITY_PRIVATE_KEY
        authority_addr = Account.from_key(authority_key).address
        voter_wallet_1 = w3.eth.accounts[7]
        voter_wallet_2 = w3.eth.accounts[8]

        # Clear initial placeholder permits
        IssuedPermit.objects.filter(election_ref=self.election).delete()
        self.election.contract_address = ''
        self.election.authority_address = authority_addr
        self.election.save()

        # Deploy Contract V1, sync/lock candidates, and cast 1 real on-chain vote + issue 1 unconsumed permit
        addr_v1 = deploy_election_contract(self.election.pk, actor_user=self.election_admin, force_redeploy=True)
        sync_and_lock_candidates(self.election.pk, lock_on_chain=True, actor_user=self.election_admin)
        contract_v1 = w3.eth.contract(address=Web3.to_checksum_address(addr_v1), abi=abi)
        # Open V1 on-chain for voting
        w3.eth.wait_for_transaction_receipt(
            contract_v1.functions.setElectionOpen(True).transact({'from': w3.eth.accounts[0]})
        )

        # Permit 1 (cast on V1)
        nullifier_1 = derive_voter_nullifier(self.election.election_id, '111122223333')
        nonce_1 = '0x' + secrets.token_hex(32)
        deadline_1 = int(time.time()) + 1200
        signed_p1 = sign_eip712_ballot_permit(
            voter_wallet=voter_wallet_1,
            candidate_id=2,
            election_id=self.election.election_id,
            voter_nullifier=nullifier_1,
            deadline=deadline_1,
            nonce=nonce_1,
            chain_id=w3.eth.chain_id,
            contract_address=addr_v1,
            authority_private_key=authority_key,
        )
        tx_v1 = contract_v1.functions.castVoteWithPermit(
            2,
            Web3.to_bytes(hexstr=nullifier_1),
            deadline_1,
            Web3.to_bytes(hexstr=nonce_1),
            signed_p1['v'],
            Web3.to_bytes(hexstr=signed_p1['r']),
            Web3.to_bytes(hexstr=signed_p1['s']),
        ).transact({'from': voter_wallet_1})
        rec_v1 = w3.eth.wait_for_transaction_receipt(tx_v1)

        voter_1 = Voter.objects.create(aadhar_number='111122223333', name='Voter One', bound_wallet=voter_wallet_1)
        IssuedPermit.objects.create(
            permit_nonce=nonce_1,
            voter=voter_1,
            election_ref=self.election,
            candidate_id=2,
            election_id=self.election.election_id,
            voter_nullifier=nullifier_1,
            deadline=deadline_1,
            contract_address=addr_v1,
            tx_hash='0x' + tx_v1.hex() if not tx_v1.hex().startswith('0x') else tx_v1.hex(),
            block_number=rec_v1.blockNumber,
            is_consumed_on_chain=True,
            is_historical_legacy=False,
        )

        # Permit 2 (issued on V1, but NEVER submitted/consumed on-chain)
        voter_2 = Voter.objects.create(aadhar_number='222233334444', name='Voter Two', bound_wallet=voter_wallet_2)
        nullifier_2 = derive_voter_nullifier(self.election.election_id, '222233334444')
        nonce_2 = '0x' + secrets.token_hex(32)
        signed_p2 = sign_eip712_ballot_permit(
            voter_wallet=voter_wallet_2,
            candidate_id=1,
            election_id=self.election.election_id,
            voter_nullifier=nullifier_2,
            deadline=deadline_1,
            nonce=nonce_2,
            chain_id=w3.eth.chain_id,
            contract_address=addr_v1,
            authority_private_key=authority_key,
        )
        unconsumed_v1_permit = IssuedPermit.objects.create(
            permit_nonce=nonce_2,
            voter=voter_2,
            election_ref=self.election,
            candidate_id=1,
            election_id=self.election.election_id,
            voter_nullifier=nullifier_2,
            deadline=deadline_1,
            contract_address=addr_v1,
            is_consumed_on_chain=False,
            is_historical_legacy=False,
        )

        # Now deploy Replacement Contract V2 (while election is still SCHEDULED), sync/lock candidates, and activate
        addr_v2 = deploy_election_contract(self.election.pk, actor_user=self.election_admin, force_redeploy=True)
        sync_and_lock_candidates(self.election.pk, lock_on_chain=True, actor_user=self.election_admin)
        activate_election(self.election.pk, actor_user=self.election_admin)
        contract_v2 = w3.eth.contract(address=Web3.to_checksum_address(addr_v2), abi=abi)

        # 1. Verify old unconsumed permit signed for V1 is rejected on-chain by V2 (DOMAIN_SEPARATOR mismatch)
        with self.assertRaises(Exception):
            contract_v2.functions.castVoteWithPermit(
                1,
                Web3.to_bytes(hexstr=nullifier_2),
                deadline_1,
                Web3.to_bytes(hexstr=nonce_2),
                signed_p2['v'],
                Web3.to_bytes(hexstr=signed_p2['r']),
                Web3.to_bytes(hexstr=signed_p2['s']),
            ).transact({'from': voter_wallet_2})

        # 2. Verify backend /api/ballot/confirm/ rejects old historical permit or V1 tx_hash
        confirm_res = self.client.post(
            '/api/ballot/confirm/',
            data=json.dumps({
                'tx_hash': '0x' + tx_v1.hex() if not tx_v1.hex().startswith('0x') else tx_v1.hex(),
                'nullifier': nullifier_2,
                'permit_nonce': unconsumed_v1_permit.permit_nonce,
            }),
            content_type='application/json',
        )
        self.assertEqual(confirm_res.status_code, 400)
        self.assertIn('Historical permit', confirm_res.json()['error'])

        # 3. Verify historical deployment audit distinguishes 2 issued permits: 1 unconsumed vs 1 receipt-verified cast vote
        hist_report = verify_historical_deployment_results(self.election)
        self.assertEqual(hist_report['historical_permits_issued'], 2)
        self.assertEqual(hist_report['historical_unconsumed_permits'], 1)
        self.assertEqual(hist_report['historical_claimed_consumed_permits'], 1)
        self.assertEqual(hist_report['historical_verified_cast_votes'], 1)

        # 4. Verify active V2 contract reconciliation has 0 active votes and keeps V1 votes strictly separate
        recon_v2 = reconcile_election_results(self.election.pk, actor_user=self.election_admin)
        self.assertTrue(recon_v2['results_verified'])
        self.assertEqual(recon_v2['onchain_total_votes'], 0)
        self.assertEqual(recon_v2['db_confirmed_votes'], 0)
        self.assertEqual(recon_v2['historical_archive']['historical_verified_cast_votes'], 1)

    def test_reconciliation_integrity_rejects_db_only_or_tampered_records(self):
        """
        Verification Pass Item 3:
        Verify that reconcile_election_results:
        - Checks real transaction receipts and VoteCast events.
        - Rejects fabricated DB consumed permits that lack an on-chain receipt/VoteCast event.
        - Rejects candidate mismatches between DB permit and on-chain VoteCast event.
        - Never sets results_verified=True from database totals alone.
        """
        w3 = get_web3_provider()
        if not w3.is_connected():
            self.skipTest("Hardhat node not running")

        from django.conf import settings
        abi, _, _ = load_contract_artifact()
        authority_key = settings.ELECTION_AUTHORITY_PRIVATE_KEY
        authority_addr = Account.from_key(authority_key).address
        voter_wallet = w3.eth.accounts[5]

        IssuedPermit.objects.filter(election_ref=self.election).delete()
        self.election.contract_address = ''
        self.election.authority_address = authority_addr
        self.election.save()

        addr = deploy_election_contract(self.election.pk, actor_user=self.election_admin, force_redeploy=True)
        sync_and_lock_candidates(self.election.pk, lock_on_chain=True, actor_user=self.election_admin)
        activate_election(self.election.pk, actor_user=self.election_admin)
        contract = w3.eth.contract(address=Web3.to_checksum_address(addr), abi=abi)

        # Cast 1 genuine vote on-chain for Candidate 1
        nullifier_real = derive_voter_nullifier(self.election.election_id, '555566667777')
        nonce_real = '0x' + secrets.token_hex(32)
        deadline = int(time.time()) + 1200
        signed = sign_eip712_ballot_permit(
            voter_wallet=voter_wallet,
            candidate_id=1,
            election_id=self.election.election_id,
            voter_nullifier=nullifier_real,
            deadline=deadline,
            nonce=nonce_real,
            chain_id=w3.eth.chain_id,
            contract_address=addr,
            authority_private_key=authority_key,
        )
        tx = contract.functions.castVoteWithPermit(
            1,
            Web3.to_bytes(hexstr=nullifier_real),
            deadline,
            Web3.to_bytes(hexstr=nonce_real),
            signed['v'],
            Web3.to_bytes(hexstr=signed['r']),
            Web3.to_bytes(hexstr=signed['s']),
        ).transact({'from': voter_wallet})
        rec = w3.eth.wait_for_transaction_receipt(tx)
        tx_hex = '0x' + tx.hex() if not tx.hex().startswith('0x') else tx.hex()

        v_real = Voter.objects.create(aadhar_number='555566667777', name='Real Voter', bound_wallet=voter_wallet)
        permit_real = IssuedPermit.objects.create(
            permit_nonce=nonce_real,
            voter=v_real,
            election_ref=self.election,
            candidate_id=1,
            election_id=self.election.election_id,
            voter_nullifier=nullifier_real,
            deadline=deadline,
            contract_address=addr,
            tx_hash=tx_hex,
            block_number=rec.blockNumber,
            is_consumed_on_chain=True,
            is_historical_legacy=False,
        )

        # Case A: Tamper with DB candidate_id (set candidate_id=2 in DB while on-chain VoteCast is for candidate 1)
        permit_real.candidate_id = 2
        permit_real.save()
        recon_tampered = reconcile_election_results(self.election.pk, actor_user=self.election_admin)
        self.assertFalse(recon_tampered['results_verified'])
        self.assertGreater(len(recon_tampered['discrepancies']), 0)

        # Restore genuine candidate_id=1 -> reconciliation must now succeed
        permit_real.candidate_id = 1
        permit_real.save()
        recon_valid = reconcile_election_results(self.election.pk, actor_user=self.election_admin)
        self.assertTrue(recon_valid['results_verified'])
        self.assertEqual(recon_valid['db_confirmed_votes'], 1)
        self.assertEqual(recon_valid['onchain_total_votes'], 1)

        # Case B: Insert a duplicate/fabricated DB permit with same tx_hash
        permit_dup = IssuedPermit.objects.create(
            permit_nonce='0x' + secrets.token_hex(32),
            voter=v_real,
            election_ref=self.election,
            candidate_id=1,
            election_id=self.election.election_id,
            voter_nullifier='0x' + ('99' * 32),
            deadline=deadline,
            contract_address=addr,
            tx_hash=tx_hex,  # Duplicate tx_hash!
            block_number=rec.blockNumber,
            is_consumed_on_chain=True,
            is_historical_legacy=False,
        )
        recon_dup = reconcile_election_results(self.election.pk, actor_user=self.election_admin)
        self.assertFalse(recon_dup['results_verified'])
        self.assertTrue(any('Duplicate transaction hash' in d for d in recon_dup['discrepancies']))
        permit_dup.delete()

    def test_lifecycle_negative_restrictions_enforced_server_side(self):
        """
        Verification Pass Item 4:
        Verify server-side rejection of:
        1. Activation without deployment.
        2. Repeated activation and invalid status transitions.
        3. Reopening a closed or finalized election.
        4. Candidate changes after roster locking.
        5. Voting-window changes after activation.
        6. Finalization before successful reconciliation.
        """
        # 1. Reject activation without deployment (DRAFT / NOT_DEPLOYED)
        with self.assertRaises(ElectionLifecycleError):
            activate_election(self.election.pk, actor_user=self.election_admin)

        self.election.status = 'SCHEDULED'
        self.election.deployment_status = 'NOT_DEPLOYED'
        self.election.save()
        with self.assertRaises(ElectionLifecycleError):
            activate_election(self.election.pk, actor_user=self.election_admin)

        # 2. Reject invalid transitions from SCHEDULED (cannot close or finalize directly)
        with self.assertRaises(ElectionLifecycleError):
            close_election(self.election.pk, actor_user=self.election_admin)
        with self.assertRaises(ElectionLifecycleError):
            finalize_election(self.election.pk, actor_user=self.election_admin)

        # 3. Reject repeated activation when already ACTIVE, and reject finalize from ACTIVE
        self.election.status = 'ACTIVE'
        self.election.deployment_status = 'DEPLOYED'
        self.election.candidates_locked_on_chain = True
        self.election.voting_window_locked_on_chain = True
        self.election.save()

        with self.assertRaises(ElectionLifecycleError):
            activate_election(self.election.pk, actor_user=self.election_admin)
        with self.assertRaises(ElectionLifecycleError):
            finalize_election(self.election.pk, actor_user=self.election_admin)

        # 4. Reject candidate changes after roster locking
        with self.assertRaises(ElectionLifecycleError):
            add_election_candidate(
                self.election.pk, 4, 'New Candidate', 'Star', actor_user=self.election_admin
            )
        with self.assertRaises(ElectionLifecycleError):
            update_election_candidate(
                self.election.pk, 1, name='Changed Name', actor_user=self.election_admin
            )
        with self.assertRaises(ElectionLifecycleError):
            deactivate_election_candidate(
                self.election.pk, 1, actor_user=self.election_admin
            )

        # 5. Reject voting-window changes after activation
        now = timezone.now()
        with self.assertRaises(ElectionLifecycleError):
            configure_voting_window(
                self.election.pk, now, now + timedelta(hours=2), actor_user=self.election_admin
            )

        # 6. Reject reopening a CLOSED election & reject finalization before reconciliation
        self.election.status = 'CLOSED'
        self.election.results_verified = False
        self.election.save()

        with self.assertRaises(ElectionLifecycleError):
            activate_election(self.election.pk, actor_user=self.election_admin)
        with self.assertRaises(ElectionLifecycleError):
            finalize_election(self.election.pk, actor_user=self.election_admin)

        # 7. Reject reopening or re-closing a FINALIZED election
        self.election.status = 'FINALIZED'
        self.election.save()

        with self.assertRaises(ElectionLifecycleError):
            activate_election(self.election.pk, actor_user=self.election_admin)
        with self.assertRaises(ElectionLifecycleError):
            close_election(self.election.pk, actor_user=self.election_admin)
