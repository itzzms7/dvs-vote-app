from django.test import TestCase, Client
from django.contrib.auth.models import User, Group
from django.urls import reverse
from EVotingApp.decorators import role_required
from django.http import HttpResponse


class Module2AuthenticationAndRBACTests(TestCase):
    def setUp(self):
        self.client = Client()

        # Create Groups
        self.super_admin_group = Group.objects.create(name='Super Admin')
        self.election_admin_group = Group.objects.create(name='Election Administrator')
        self.auditor_group = Group.objects.create(name='Auditor')

        # Create Users
        self.superuser = User.objects.create_superuser(username='superadmin', password='password123', email='super@example.com')

        self.election_admin = User.objects.create_user(username='electionadmin', password='password123', is_staff=True)
        self.election_admin.groups.add(self.election_admin_group)

        self.auditor = User.objects.create_user(username='auditor', password='password123', is_staff=True)
        self.auditor.groups.add(self.auditor_group)

        self.regular_user = User.objects.create_user(username='voteruser', password='password123')

    def test_admin_login_superuser_success(self):
        response = self.client.post(reverse('AdminLogin'), {
            'username': 'superadmin',
            'password': 'password123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Welcome Admin (superadmin)')

    def test_admin_login_election_admin_success(self):
        response = self.client.post(reverse('AdminLogin'), {
            'username': 'electionadmin',
            'password': 'password123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Welcome Admin (electionadmin)')

    def test_admin_login_invalid_credentials_rejected(self):
        response = self.client.post(reverse('AdminLogin'), {
            'username': 'superadmin',
            'password': 'wrongpassword'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Invalid Admin credentials!')

    def test_role_required_decorator_blocks_unauthenticated(self):
        @role_required(['Super Admin', 'Election Administrator'])
        def dummy_view(request):
            return HttpResponse('Secret Content')

        from django.test import RequestFactory
        factory = RequestFactory()
        request = factory.get('/admin/dummy/')
        from django.contrib.auth.models import AnonymousUser
        request.user = AnonymousUser()

        response = dummy_view(request)
        self.assertEqual(response.status_code, 302)  # Redirects to Admin login

    def test_role_required_decorator_allows_authorized_group(self):
        @role_required(['Election Administrator'])
        def dummy_view(request):
            return HttpResponse('Secret Content')

        from django.test import RequestFactory
        factory = RequestFactory()
        request = factory.get('/admin/dummy/')
        request.user = self.election_admin

        response = dummy_view(request)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.content.decode(), 'Secret Content')

    def test_role_required_decorator_blocks_unauthorized_user(self):
        @role_required(['Super Admin'])
        def dummy_view(request):
            return HttpResponse('Secret Content')

        from django.test import RequestFactory
        factory = RequestFactory()
        request = factory.get('/admin/dummy/')
        request.user = self.regular_user

        response = dummy_view(request)
        self.assertEqual(response.status_code, 403)
