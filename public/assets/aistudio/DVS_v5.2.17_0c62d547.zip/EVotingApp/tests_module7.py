import json
from datetime import timedelta
from django.test import TestCase, Client
from django.utils import timezone
from django.contrib.auth.models import User, Group
from EVotingApp.models import (
    Election,
    Candidate,
    Voter,
    VoterEligibility,
    ElectionAdminAssignment,
    PendingVoterOnboarding,
)


class Module7Phase3PublicExperienceTests(TestCase):
    def setUp(self):
        self.client = Client()
        now = timezone.now()

        # 1. Active Election
        self.active_election, _ = Election.objects.update_or_create(
            election_id=2026,
            defaults={
                'title': 'General Lok Sabha Election 2026',
                'description': 'National parliamentary general election.',
                'election_type': 'GENERAL',
                'status': 'ACTIVE',
                'deployment_status': 'DEPLOYED',
                'contract_address': '0x5FbDB2315678afecb367f032d93F642f64180aa3',
                'candidates_locked_on_chain': True,
                'voting_window_locked_on_chain': True,
                'results_published': False,
                'results_verified': False,
                'start_datetime': now - timedelta(days=1),
                'end_datetime': now + timedelta(days=2),
            },
        )
        Candidate.objects.update_or_create(
            election=self.active_election,
            candidate_id_num=1,
            defaults={
                'name': 'Rahul Gandhi',
                'symbol': 'Congress',
                'description': 'Indian National Congress Candidate',
                'display_order': 1,
                'is_active': True,
                'is_synced_on_chain': True,
            },
        )
        Candidate.objects.update_or_create(
            election=self.active_election,
            candidate_id_num=2,
            defaults={
                'name': 'Narendar Modi',
                'symbol': 'BJP',
                'description': 'Bharatiya Janata Party Candidate',
                'display_order': 2,
                'is_active': True,
                'is_synced_on_chain': True,
            },
        )

        # 2. Scheduled Election
        self.scheduled_election = Election.objects.create(
            election_id=2027,
            title='Municipal Council Election 2027',
            description='Upcoming civic municipal council ballot.',
            election_type='STATE',
            status='SCHEDULED',
            start_datetime=now + timedelta(days=14),
            end_datetime=now + timedelta(days=15),
        )

        # 3. Completed (Finalized) Election
        self.finalized_election = Election.objects.create(
            election_id=2025,
            title='University Senate Referendum 2025',
            description='Completed institutional governance election.',
            election_type='INSTITUTIONAL',
            status='FINALIZED',
            results_published=True,
            results_verified=True,
            reconciled_at=now - timedelta(days=5),
            finalized_at=now - timedelta(days=4),
        )
        Candidate.objects.create(
            election=self.finalized_election,
            candidate_id_num=1,
            name='Dr. Ananya Rao',
            symbol='Academic Reform Slate',
            description='Faculty senate representative',
            display_order=1,
            is_active=True,
        )

        # Register a voter with sensitive fields to verify zero leakage on public routes
        self.secret_voter = Voter.objects.create(
            name='Private Citizen SecretName',
            aadhar_number='987654321099',
            bound_wallet='0x70997970C51812dc3A010C7d01b50e0d17dc79C8',
            is_synthetic=True,
        )
        VoterEligibility.objects.create(
            voter=self.secret_voter,
            election=self.active_election,
            is_eligible=True,
        )

    def test_landing_page_renders_real_elections_and_spotlight(self):
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
        html = response.content.decode('utf-8')
        self.assertIn('General Lok Sabha Election 2026', html)
        self.assertIn('Municipal Council Election 2027', html)
        self.assertIn('University Senate Referendum 2025', html)
        self.assertIn('/vote/', html)
        self.assertIn('/elections/', html)
        self.assertNotIn('style="', html)

    def test_public_elections_json_endpoint_preserved(self):
        response = self.client.get('/public/elections/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response['Content-Type'], 'application/json')
        payload = response.json()
        self.assertIn('elections', payload)
        election_ids = [e['election_id'] for e in payload['elections']]
        self.assertIn(2026, election_ids)

    def test_elections_directory_html_and_filters(self):
        res_all = self.client.get('/elections/')
        self.assertEqual(res_all.status_code, 200)
        html_all = res_all.content.decode('utf-8')
        self.assertIn('General Lok Sabha Election 2026', html_all)
        self.assertIn('Municipal Council Election 2027', html_all)
        self.assertIn('University Senate Referendum 2025', html_all)
        self.assertNotIn('style="', html_all)

        res_active = self.client.get('/elections/?status=ACTIVE')
        html_active = res_active.content.decode('utf-8')
        self.assertIn('General Lok Sabha Election 2026', html_active)
        self.assertNotIn('Municipal Council Election 2027', html_active)

        res_sched = self.client.get('/elections/?status=SCHEDULED')
        html_sched = res_sched.content.decode('utf-8')
        self.assertIn('Municipal Council Election 2027', html_sched)
        self.assertNotIn('General Lok Sabha Election 2026', html_sched)

        res_comp = self.client.get('/elections/?status=COMPLETED')
        html_comp = res_comp.content.decode('utf-8')
        self.assertIn('University Senate Referendum 2025', html_comp)
        self.assertNotIn('General Lok Sabha Election 2026', html_comp)

        res_empty = self.client.get('/elections/?q=NonExistentElectionXYZ')
        html_empty = res_empty.content.decode('utf-8')
        self.assertIn('No Matching Elections Found', html_empty)

    def test_election_detail_publication_states_and_privacy(self):
        res_live = self.client.get('/elections/2026/')
        self.assertEqual(res_live.status_code, 200)
        html_live = res_live.content.decode('utf-8')
        self.assertIn('Candidate-Wise Results Are Sealed', html_live)
        self.assertIn('Rahul Gandhi', html_live)
        self.assertIn('Narendar Modi', html_live)
        self.assertNotIn('result-tally', html_live)
        self.assertNotIn('987654321099', html_live)
        self.assertNotIn('Private Citizen SecretName', html_live)
        self.assertNotIn('0x70997970C51812dc3A010C7d01b50e0d17dc79C8', html_live)
        self.assertNotIn('style="', html_live)

        self.active_election.status = 'CLOSED'
        self.active_election.results_published = True
        self.active_election.results_verified = False
        self.active_election.save()

        res_prov = self.client.get('/elections/2026/')
        html_prov = res_prov.content.decode('utf-8')
        self.assertIn('Provisional Results:', html_prov)
        self.assertIn('result-tally', html_prov)

        self.active_election.results_verified = True
        self.active_election.reconciled_at = timezone.now()
        self.active_election.save()

        res_ver = self.client.get('/elections/2026/')
        html_ver = res_ver.content.decode('utf-8')
        self.assertIn('Verified Results:', html_ver)
        self.assertIn('Blockchain Verified', html_ver)

        res_fin = self.client.get('/elections/2025/')
        self.assertEqual(res_fin.status_code, 200)
        html_fin = res_fin.content.decode('utf-8')
        self.assertIn('Official Finalized Outcome:', html_fin)
        self.assertIn('Dr. Ananya Rao', html_fin)

    def test_election_detail_404_for_unknown_election(self):
        res_404 = self.client.get('/elections/999999/')
        self.assertEqual(res_404.status_code, 404)
        self.assertIn('Election Not Found', res_404.content.decode('utf-8'))


class Module7Phase4AdminPortalAndRBACTests(TestCase):
    def setUp(self):
        self.client = Client()
        now = timezone.now()

        self.election_2026, _ = Election.objects.update_or_create(
            election_id=2026,
            defaults={
                'title': 'General Lok Sabha Election 2026',
                'description': 'Primary national election.',
                'election_type': 'GENERAL',
                'status': 'SCHEDULED',
                'deployment_status': 'DEPLOYED',
                'contract_address': '0x5FbDB2315678afecb367f032d93F642f64180aa3',
                'start_datetime': now + timedelta(days=1),
                'end_datetime': now + timedelta(days=3),
            },
        )
        self.election_2027 = Election.objects.create(
            election_id=2027,
            title='State Assembly Election 2027',
            description='Unassigned state election.',
            election_type='GENERAL',
            status='DRAFT',
            deployment_status='NOT_DEPLOYED',
        )

        # Create role groups and staff users
        self.grp_super, _ = Group.objects.get_or_create(name='Super Admin')
        self.grp_admin, _ = Group.objects.get_or_create(name='Election Administrator')
        self.grp_worker, _ = Group.objects.get_or_create(name='Election Worker')
        self.grp_auditor, _ = Group.objects.get_or_create(name='Auditor')

        self.super_user = User.objects.create_user(username='super_ops', password='password123')
        self.super_user.groups.add(self.grp_super)

        self.election_admin = User.objects.create_user(username='elec_admin', password='password123')
        self.election_admin.groups.add(self.grp_admin)
        ElectionAdminAssignment.objects.create(
            election=self.election_2026,
            user=self.election_admin,
            role='ELECTION_ADMIN',
        )

        self.election_worker = User.objects.create_user(username='poll_worker', password='password123')
        self.election_worker.groups.add(self.grp_worker)
        ElectionAdminAssignment.objects.create(
            election=self.election_2026,
            user=self.election_worker,
            role='ELECTION_WORKER',
        )

        self.auditor_user = User.objects.create_user(username='audit_observer', password='password123')
        self.auditor_user.groups.add(self.grp_auditor)
        ElectionAdminAssignment.objects.create(
            election=self.election_2026,
            user=self.auditor_user,
            role='AUDITOR',
        )

    def test_super_admin_create_draft_election_never_auto_deploys(self):
        self.client.force_login(self.super_user)
        res = self.client.post(
            '/api/control/elections/create/',
            data=json.dumps({
                'title': 'Civic Referendum 2028',
                'description': 'Municipal infrastructure referendum.',
                'election_type': 'REFERENDUM',
                'result_publication_policy': 'OFFICIAL_AFTER_FINALIZE',
            }),
            content_type='application/json',
        )
        self.assertEqual(res.status_code, 201)
        payload = res.json()
        self.assertTrue(payload['success'])
        self.assertEqual(payload['election']['status'], 'DRAFT')
        self.assertEqual(payload['election']['deployment_status'], 'NOT_DEPLOYED')

        created_el = Election.objects.get(election_id=payload['election']['election_id'])
        self.assertEqual(created_el.contract_address, '')
        self.assertEqual(created_el.deployment_status, 'NOT_DEPLOYED')

    def test_super_admin_staff_and_role_assignment_api(self):
        self.client.force_login(self.super_user)
        res = self.client.post(
            '/api/control/staff/',
            data=json.dumps({
                'operation': 'CREATE_OR_UPDATE_STAFF',
                'username': 'new_booth_worker',
                'password': 'workerpass123',
                'role': 'ELECTION_WORKER',
                'election_id': 2026,
            }),
            content_type='application/json',
        )
        self.assertEqual(res.status_code, 201)
        data = res.json()
        self.assertEqual(data['staff']['portal_role'], 'ELECTION_WORKER')
        self.assertEqual(data['assignment']['role'], 'ELECTION_WORKER')

        # Non-Super Admin is blocked from staff management
        self.client.force_login(self.election_admin)
        res_forbidden = self.client.post(
            '/api/control/staff/',
            data=json.dumps({'operation': 'CREATE_OR_UPDATE_STAFF', 'username': 'x'}),
            content_type='application/json',
        )
        self.assertEqual(res_forbidden.status_code, 403)

    def test_simplified_single_step_voter_registration_and_isolation(self):
        self.client.force_login(self.election_admin)
        # Also assign election_admin to election_2027 to test cross-election isolation
        ElectionAdminAssignment.objects.create(
            election=self.election_2027,
            user=self.election_admin,
            role='ELECTION_ADMIN',
        )

        # 1. Register new voter on Election 2026 -> automatically eligible ONLY in 2026
        res1 = self.client.post(
            '/api/control/elections/2026/voters/add/',
            data=json.dumps({
                'name': 'Kavita Deshmukh',
                'aadhar_number': '234567890123',
                'bound_wallet': '0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC',
                'is_synthetic': True,
            }),
            content_type='application/json',
        )
        self.assertEqual(res1.status_code, 201)
        d1 = res1.json()
        self.assertEqual(d1['registration_outcome'], 'CREATED_AND_ELIGIBLE')
        self.assertTrue(d1['eligibility']['is_eligible'])

        voter_obj = Voter.objects.get(aadhar_number='234567890123')
        self.assertTrue(VoterEligibility.objects.filter(voter=voter_obj, election=self.election_2026, is_eligible=True).exists())
        # Must NOT have global eligibility in Election 2027
        self.assertFalse(VoterEligibility.objects.filter(voter=voter_obj, election=self.election_2027).exists())

        # 2. Re-register same voter in Election 2026 -> idempotent ALREADY_ELIGIBLE_IN_ELECTION
        res_dup = self.client.post(
            '/api/control/elections/2026/voters/add/',
            data=json.dumps({
                'name': 'Attempted Name Overwrite',
                'aadhar_number': '234567890123',
            }),
            content_type='application/json',
        )
        self.assertEqual(res_dup.status_code, 201)
        self.assertEqual(res_dup.json()['registration_outcome'], 'ALREADY_ELIGIBLE_IN_ELECTION')
        voter_obj.refresh_from_db()
        # Existing voter name must NOT be overwritten
        self.assertEqual(voter_obj.name, 'Kavita Deshmukh')

        # 3. Conflicting wallet on existing voter is rejected without overwriting wallet
        res_conflict = self.client.post(
            '/api/control/elections/2027/voters/add/',
            data=json.dumps({
                'name': 'Kavita Deshmukh',
                'aadhar_number': '234567890123',
                'bound_wallet': '0x90F79bf6EB2c4f870365E785982E1f101E93b906',
            }),
            content_type='application/json',
        )
        self.assertEqual(res_conflict.status_code, 400)
        voter_obj.refresh_from_db()
        self.assertEqual(voter_obj.bound_wallet, '0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC')

        # 4. Enroll existing voter in Election 2027 without conflicting wallet -> EXISTING_VOTER_ADDED_TO_ELECTION
        res_2027 = self.client.post(
            '/api/control/elections/2027/voters/add/',
            data=json.dumps({
                'aadhar_number': '234567890123',
            }),
            content_type='application/json',
        )
        self.assertEqual(res_2027.status_code, 201)
        self.assertEqual(res_2027.json()['registration_outcome'], 'EXISTING_VOTER_ADDED_TO_ELECTION')
        self.assertTrue(VoterEligibility.objects.filter(voter=voter_obj, election=self.election_2027, is_eligible=True).exists())

    def test_election_worker_strict_scoped_permissions(self):
        self.client.force_login(self.election_worker)

        # 1. Worker can access /control/ and sees Election Worker badge, not Super Admin or Candidate/Lifecycle tabs
        portal_res = self.client.get('/control/?election_id=2026')
        self.assertEqual(portal_res.status_code, 200)
        html = portal_res.content.decode('utf-8')
        self.assertIn('Election Worker', html)
        self.assertIn('panel-voters', html)
        self.assertIn('panel-identity', html)
        self.assertNotIn('id="panel-candidates"', html)
        self.assertNotIn('id="panel-lifecycle"', html)
        self.assertNotIn('id="panel-staff"', html)

        # 2. Worker CAN assist with voter registration on assigned Election 2026
        reg_res = self.client.post(
            '/api/control/elections/2026/voters/add/',
            data=json.dumps({
                'name': 'Rohan Verma',
                'aadhar_number': '345678901234',
                'is_synthetic': True,
            }),
            content_type='application/json',
        )
        self.assertEqual(reg_res.status_code, 201)

        # 3. Worker CAN stage external identity verification on assigned Election 2026
        ver_res = self.client.post(
            '/api/control/elections/2026/identity/verify/',
            data=json.dumps({
                'provider_id': 'simulated_civic_registry',
                'identifier': '456789012345',
                'parameters': {'full_name': 'Meera Krishnan'},
            }),
            content_type='application/json',
        )
        self.assertEqual(ver_res.status_code, 200)
        pending_id = ver_res.json()['pending_onboarding']['onboarding_id']

        # 4. Worker CANNOT approve pending onboarding (403)
        approve_res = self.client.post(
            f'/api/control/elections/2026/onboarding/{pending_id}/review/',
            data=json.dumps({'decision': 'APPROVE'}),
            content_type='application/json',
        )
        self.assertEqual(approve_res.status_code, 403)

        # 5. Worker CANNOT deploy, modify candidates, lock roster, open/close/finalize election, or revoke eligibility
        self.assertEqual(self.client.post('/api/control/elections/2026/deploy/').status_code, 403)
        self.assertEqual(
            self.client.post(
                '/api/control/elections/2026/candidates/',
                data=json.dumps({'candidate_id': 9, 'name': 'X', 'symbol': 'Y'}),
                content_type='application/json',
            ).status_code,
            403,
        )
        self.assertEqual(self.client.post('/api/control/elections/2026/candidates/lock/').status_code, 403)
        self.assertEqual(self.client.post('/api/control/elections/2026/activate/').status_code, 403)
        self.assertEqual(self.client.post('/api/control/elections/2026/close/').status_code, 403)
        self.assertEqual(self.client.post('/api/control/elections/2026/finalize/').status_code, 403)

        # 6. Worker CANNOT access unassigned Election 2027 (even for read or voter registration)
        self.assertEqual(self.client.get('/api/control/elections/2027/voters/').status_code, 403)
        self.assertEqual(
            self.client.post(
                '/api/control/elections/2027/voters/add/',
                data=json.dumps({'name': 'Test', 'aadhar_number': '567890123456'}),
                content_type='application/json',
            ).status_code,
            403,
        )

    def test_auditor_workspace_is_strictly_read_only(self):
        self.client.force_login(self.auditor_user)
        res = self.client.get('/control/?election_id=2026')
        self.assertEqual(res.status_code, 200)
        html = res.content.decode('utf-8')
        self.assertIn('Read-Only Mode', html)
        self.assertNotIn('id="form-register-voter"', html)
        self.assertNotIn('id="form-add-candidate"', html)

        # Auditor can read voters and candidates
        self.assertEqual(self.client.get('/api/control/elections/2026/voters/').status_code, 200)
        self.assertEqual(self.client.get('/api/control/elections/2026/candidates/').status_code, 200)

        # Auditor is blocked (403) from all mutations including worker_write endpoints
        self.assertEqual(
            self.client.post(
                '/api/control/elections/2026/voters/add/',
                data=json.dumps({'name': 'Test', 'aadhar_number': '678901234567'}),
                content_type='application/json',
            ).status_code,
            403,
        )
        self.assertEqual(
            self.client.post(
                '/api/control/elections/2026/identity/verify/',
                data=json.dumps({'provider_id': 'local_database', 'identifier': '678901234567'}),
                content_type='application/json',
            ).status_code,
            403,
        )


from eth_account import Account
from eth_account.messages import encode_defunct
from web3 import Web3
from EVotingApp.services import (
    get_web3_provider,
    load_contract_artifact,
    deploy_election_contract,
    sync_and_lock_candidates,
    activate_election,
    assign_voter_eligibility,
)
from EVotingApp.tests_module6 import (
    build_mock_webauthn_keypair,
    build_registration_credential_payload,
    build_authentication_credential_payload,
)


class Module7Phase5GuidedVoterJourneyTests(TestCase):
    def setUp(self):
        self.client = Client()
        now = timezone.now()

        self.grp_super, _ = Group.objects.get_or_create(name='Super Admin')
        self.grp_admin, _ = Group.objects.get_or_create(name='Election Administrator')
        self.grp_worker, _ = Group.objects.get_or_create(name='Election Worker')

        self.election_admin = User.objects.create_user(username='phase5_admin', password='password123')
        self.election_admin.groups.add(self.grp_admin)

        self.election_worker = User.objects.create_user(username='phase5_worker', password='password123')
        self.election_worker.groups.add(self.grp_worker)

        self.active_election = Election.objects.create(
            election_id=5050,
            title='Civic Assembly General Election 2026',
            description='Official municipal assembly election.',
            election_type='GENERAL',
            status='DRAFT',
            deployment_status='NOT_DEPLOYED',
            start_datetime=now - timedelta(hours=1),
            end_datetime=now + timedelta(days=2),
        )
        Candidate.objects.create(
            election=self.active_election,
            candidate_id_num=1,
            name='Aarav Kulkarni',
            symbol='Congress',
            description='Civic Infrastructure & Education Platform',
            display_order=1,
            is_active=True,
        )
        Candidate.objects.create(
            election=self.active_election,
            candidate_id_num=2,
            name='Meera Deshmukh',
            symbol='BJP',
            description='Urban Renewal & Clean Energy Platform',
            display_order=2,
            is_active=True,
        )

        ElectionAdminAssignment.objects.create(
            election=self.active_election,
            user=self.election_admin,
            role='ELECTION_ADMIN',
        )
        ElectionAdminAssignment.objects.create(
            election=self.active_election,
            user=self.election_worker,
            role='ELECTION_WORKER',
        )

        self.scheduled_election = Election.objects.create(
            election_id=5051,
            title='Upcoming District Referendum 2027',
            description='Scheduled district referendum.',
            election_type='REFERENDUM',
            status='SCHEDULED',
            start_datetime=now + timedelta(days=10),
            end_datetime=now + timedelta(days=12),
        )

        self.voter_acct = Account.create('PHASE5_VOTER_KEY_SEED')
        self.voter = Voter.objects.create(
            name='Siddharth Nair',
            aadhar_number='512351235123',
            bound_wallet=None,
            is_synthetic=True,
        )
        VoterEligibility.objects.create(
            voter=self.voter,
            election=self.active_election,
            is_eligible=True,
            has_voted=False,
        )

    def _authenticate_wallet_with_aadhar(self, client, eth_acct, aadhar=''):
        chal_res = client.get('/api/wallet/challenge/', {'address': eth_acct.address}, HTTP_HOST='localhost:3000')
        self.assertEqual(chal_res.status_code, 200)
        chal_data = chal_res.json()
        signed = Account.sign_message(encode_defunct(text=chal_data['challenge']), eth_acct.key)
        ver_res = client.post(
            '/api/wallet/verify/',
            data=json.dumps({
                'address': eth_acct.address,
                'nonce': chal_data['nonce'],
                'signature': signed.signature.hex(),
                'aadhar': aadhar,
            }),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(ver_res.status_code, 200)
        return ver_res.json()

    def test_step_a_and_d_election_entry_and_candidate_cards(self):
        w3 = get_web3_provider()
        if not w3.is_connected():
            self.skipTest('Hardhat node not running')

        deploy_election_contract(self.active_election.pk, actor_user=self.election_admin)
        sync_and_lock_candidates(self.active_election.pk, lock_on_chain=True, actor_user=self.election_admin)
        activate_election(self.active_election.pk, actor_user=self.election_admin)

        # 1. Active election renders simplified election entry, candidate cards, and omits stepper/self-service accordion
        res = self.client.get(f'/vote/?election_id={self.active_election.election_id}')
        self.assertEqual(res.status_code, 200)
        html = res.content.decode('utf-8')
        self.assertIn('Civic Assembly General Election 2026', html)
        self.assertIn('Active Voting', html)
        self.assertIn('Aarav Kulkarni', html)
        self.assertIn('Meera Deshmukh', html)
        self.assertIn('data-candidate-card="1"', html)
        self.assertIn('data-candidate-card="2"', html)
        self.assertIn('id="modal-ballot-review"', html)
        self.assertIn('Preparing your ballot.', html)
        self.assertNotIn('id="voter-journey-stepper"', html)
        self.assertNotIn('id="voter-security-accordion"', html)
        self.assertNotIn('id="modal-revoke-passkey"', html)
        self.assertNotIn('<table border=1', html)
        self.assertNotIn('style="', html)
        self.assertNotIn('<span', html)

        # 2. Preselected candidate via /CastVote?t1=2&election_id=5050 marks candidate #2 selected
        res_cast = self.client.get(f'/CastVote?t1=2&election_id={self.active_election.election_id}')
        self.assertEqual(res_cast.status_code, 200)
        html_cast = res_cast.content.decode('utf-8')
        self.assertIn('value="2"', html_cast)
        self.assertIn('Selected on Ballot', html_cast)
        self.assertNotIn('style="', html_cast)
        self.assertNotIn('<span', html_cast)

        # 3. Scheduled election (5051) shows clear non-voting state and hides candidate cards
        res_sched = self.client.get(f'/vote/?election_id={self.scheduled_election.election_id}')
        self.assertEqual(res_sched.status_code, 200)
        html_sched = res_sched.content.decode('utf-8')
        self.assertIn('Upcoming District Referendum 2027', html_sched)
        self.assertIn('Ballot Submission Is Not Currently Open', html_sched)
        self.assertNotIn('data-candidate-card=', html_sched)

        # 4. Verify simplified progress messages in metamask.js
        with open('EVotingApp/static/metamask.js', 'r', encoding='utf-8') as f:
            mm_js = f.read()
        self.assertIn('Preparing your ballot.', mm_js)
        self.assertIn('Waiting for voting authorization.', mm_js)
        self.assertIn('Confirming your vote.', mm_js)
        self.assertIn('Vote successfully recorded.', mm_js)
        self.assertNotIn('updateStepperState', mm_js)

    def test_step_b_and_self_service_passkey_lifecycle_and_admin_isolation(self):
        # 1. Wallet verification with 12-digit Voter ID binds wallet and establishes voter session
        self._authenticate_wallet_with_aadhar(self.client, self.voter_acct, aadhar='512351235123')

        status_res = self.client.get(
            f'/api/wallet/status/?election_id={self.active_election.election_id}',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(status_res.status_code, 200)
        s_data = status_res.json()
        self.assertTrue(s_data['authenticated'])
        self.assertEqual(s_data['voter_name'], 'Siddharth Nair')
        self.assertEqual(s_data['aadhar_masked'], 'XXXXXXXX5123')
        self.assertNotIn('512351235123', json.dumps(s_data))
        self.assertTrue(s_data['eligibility']['is_eligible'])
        self.assertFalse(s_data['eligibility']['has_voted'])

        # 2. Voter enrolls a passkey via self-service
        opt_res = self.client.post('/api/auth/passkey/register/options/', HTTP_HOST='localhost:3000').json()
        priv, cose_key = build_mock_webauthn_keypair()
        cred_id_b64, reg_payload = build_registration_credential_payload(opt_res['challenge'], cose_key)
        reg_ver = self.client.post(
            '/api/auth/passkey/register/verify/',
            data=json.dumps({'credential': reg_payload, 'device_label': 'Voter Personal Laptop'}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(reg_ver.status_code, 200)
        cred_pk = reg_ver.json()['credential_id']

        # 3. Voter views registered passkeys via /api/auth/passkey/list/
        list_res = self.client.get('/api/auth/passkey/list/', HTTP_HOST='localhost:3000')
        self.assertEqual(list_res.status_code, 200)
        pks = list_res.json()['passkeys']
        self.assertEqual(len(pks), 1)
        self.assertEqual(pks[0]['device_label'], 'Voter Personal Laptop')
        self.assertTrue(pks[0]['is_active'])

        # 4. Election Admin and Election Worker are strictly blocked (403) from revoking voter passkeys
        admin_client = Client()
        admin_client.force_login(self.election_admin)
        self.assertEqual(
            admin_client.post(f'/api/auth/passkey/{cred_pk}/revoke/', HTTP_HOST='localhost:3000').status_code,
            403,
        )
        worker_client = Client()
        worker_client.force_login(self.election_worker)
        self.assertEqual(
            worker_client.post(f'/api/auth/passkey/{cred_pk}/revoke/', HTTP_HOST='localhost:3000').status_code,
            403,
        )

        # 5. Voter self-service revocation enforces last-credential confirmation
        rev_denied = self.client.post(
            f'/api/auth/passkey/{cred_pk}/revoke/',
            data=json.dumps({'confirm_disable_passkey': False}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(rev_denied.status_code, 400)

        rev_ok = self.client.post(
            f'/api/auth/passkey/{cred_pk}/revoke/',
            data=json.dumps({'confirm_disable_passkey': True}),
            content_type='application/json',
            HTTP_HOST='localhost:3000',
        )
        self.assertEqual(rev_ok.status_code, 200)
        self.assertEqual(rev_ok.json()['auth_mode'], 'WALLET_ONLY')

    def test_step_f_and_g_end_to_end_ballot_submission_and_verified_receipt(self):
        w3 = get_web3_provider()
        if not w3.is_connected():
            self.skipTest('Hardhat node not running')

        # Deploy, lock candidates, and activate election 5050
        contract_addr = deploy_election_contract(self.active_election.pk, actor_user=self.election_admin)
        sync_and_lock_candidates(self.active_election.pk, lock_on_chain=True, actor_user=self.election_admin)
        activate_election(self.active_election.pk, actor_user=self.election_admin)

        # Use unlocked Hardhat account #1 as the voter's wallet so it can broadcast a real transaction
        voter_wallet = w3.eth.accounts[1]
        self.voter.bound_wallet = voter_wallet
        self.voter.save(update_fields=['bound_wallet'])

        session = self.client.session
        session['authenticated_wallet'] = voter_wallet
        session['authenticated_voter_id'] = self.voter.pk
        session.save()

        # 1. Request EIP-712 ballot permit for Candidate #2
        permit_res = self.client.post(
            '/api/ballot/permit/',
            data=json.dumps({
                'election_id': self.active_election.election_id,
                'candidate_id': 2,
                'aadhar': '512351235123',
            }),
            content_type='application/json',
        )
        self.assertEqual(permit_res.status_code, 200)
        permit = permit_res.json()['permit']

        # 2. Voter submits direct on-chain transaction castVoteWithPermit
        abi, _, _ = load_contract_artifact()
        contract = w3.eth.contract(address=Web3.to_checksum_address(contract_addr), abi=abi)
        tx_hash = contract.functions.castVoteWithPermit(
            int(permit['candidateId']),
            Web3.to_bytes(hexstr=permit['voterNullifier']),
            int(permit['deadline']),
            Web3.to_bytes(hexstr=permit['nonce']),
            int(permit['v']),
            Web3.to_bytes(hexstr=permit['r']),
            Web3.to_bytes(hexstr=permit['s']),
        ).transact({'from': voter_wallet})
        w3.eth.wait_for_transaction_receipt(tx_hash)

        # 3. Confirm vote with backend and verify official receipt response
        confirm_res = self.client.post(
            '/api/ballot/confirm/',
            data=json.dumps({
                'tx_hash': tx_hash.hex(),
                'nullifier': permit['voterNullifier'],
                'permit_nonce': permit['nonce'],
            }),
            content_type='application/json',
        )
        self.assertEqual(confirm_res.status_code, 200)
        c_data = confirm_res.json()
        self.assertTrue(c_data['success'])
        self.assertIn('DVS-5050-', c_data['receipt_reference'])
        self.assertEqual(c_data['election_title'], 'Civic Assembly General Election 2026')

        # 4. Reloading /vote/?election_id=5050 renders the verified receipt and marks Ballot Recorded
        vote_page = self.client.get(f'/vote/?election_id={self.active_election.election_id}')
        self.assertEqual(vote_page.status_code, 200)
        page_html = vote_page.content.decode('utf-8')
        self.assertIn(c_data['receipt_reference'], page_html)
        self.assertIn('Ballot Recorded', page_html)
        self.assertIn('Ballot Cast &amp; Verified', page_html)

        # 5. Duplicate permit request after confirmed vote is rejected with 409
        dup_permit = self.client.post(
            '/api/ballot/permit/',
            data=json.dumps({
                'election_id': self.active_election.election_id,
                'candidate_id': 1,
                'aadhar': '512351235123',
            }),
            content_type='application/json',
        )
        self.assertEqual(dup_permit.status_code, 409)

