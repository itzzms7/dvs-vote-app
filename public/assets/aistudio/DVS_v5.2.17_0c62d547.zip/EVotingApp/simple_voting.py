"""Local Hardhat voting workflow based on the user's original DVS GitHub contract.

Django/SQLite stores voter eligibility, election configuration, candidate metadata,
and transaction receipts. Hardhat stores candidate identifiers and vote tallies.
"""
from datetime import timedelta

from django.conf import settings
from django.db import transaction
from django.utils import timezone
from web3 import Web3

from .models import Candidate, ContractDeployment, Election, VoterEligibility, AdminAuditLog
from .services import get_web3_provider
from .crypto import derive_voter_nullifier


SIMPLE_VOTING_ABI = [
    {"inputs": [], "name": "owner", "outputs": [{"internalType": "address", "name": "", "type": "address"}], "stateMutability": "view", "type": "function"},
    {"inputs": [{"internalType": "int256", "name": "_id", "type": "int256"}, {"internalType": "string", "name": "_name", "type": "string"}, {"internalType": "string", "name": "_symbol", "type": "string"}], "name": "addCandidate", "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"inputs": [{"internalType": "int256", "name": "", "type": "int256"}], "name": "candidates", "outputs": [{"internalType": "int256", "name": "id", "type": "int256"}, {"internalType": "string", "name": "name", "type": "string"}, {"internalType": "string", "name": "symbol", "type": "string"}, {"internalType": "uint256", "name": "voteCount", "type": "uint256"}, {"internalType": "bool", "name": "exists", "type": "bool"}], "stateMutability": "view", "type": "function"},
    {"inputs": [], "name": "candidatesLocked", "outputs": [{"internalType": "bool", "name": "", "type": "bool"}], "stateMutability": "view", "type": "function"},
    {"inputs": [{"internalType": "uint64", "name": "_start", "type": "uint64"}, {"internalType": "uint64", "name": "_end", "type": "uint64"}], "name": "setVotingWindow", "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"inputs": [], "name": "lockVotingWindow", "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"inputs": [], "name": "lockCandidates", "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"inputs": [], "name": "votingStartTime", "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"inputs": [], "name": "votingEndTime", "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"inputs": [], "name": "votingWindowLocked", "outputs": [{"internalType": "bool", "name": "", "type": "bool"}], "stateMutability": "view", "type": "function"},
    {"inputs": [], "name": "electionOpen", "outputs": [{"internalType": "bool", "name": "", "type": "bool"}], "stateMutability": "view", "type": "function"},
    {"inputs": [], "name": "openElection", "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"inputs": [], "name": "closeElection", "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"inputs": [{"internalType": "int256", "name": "_candidate_ID", "type": "int256"}, {"internalType": "bytes32", "name": "_voterHash", "type": "bytes32"}], "name": "markVote", "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"inputs": [{"internalType": "bytes32", "name": "", "type": "bytes32"}], "name": "hasVoted", "outputs": [{"internalType": "bool", "name": "", "type": "bool"}], "stateMutability": "view", "type": "function"},
    {"inputs": [{"internalType": "int256", "name": "_candidate_ID", "type": "int256"}], "name": "getCount", "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"inputs": [], "name": "totalVotes", "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}], "stateMutability": "view", "type": "function"},
]


class SimpleVotingError(Exception):
    pass


def get_sender(w3=None):
    w3 = w3 or get_web3_provider()
    accounts = list(w3.eth.accounts)
    if not accounts:
        raise SimpleVotingError("No unlocked Hardhat accounts are available. Start `npx hardhat node` first.")
    try:
        index = int(getattr(settings, 'DVS_TX_ACCOUNT_INDEX', 0))
    except (TypeError, ValueError):
        index = 0
    if index < 0 or index >= len(accounts):
        raise SimpleVotingError("DVS_TX_ACCOUNT_INDEX does not match an unlocked Hardhat account.")
    return Web3.to_checksum_address(accounts[index])


def _sync_hardhat_block_timestamp(w3):
    """Advance local Hardhat block timestamp to current wall-clock time if behind."""
    try:
        now_ts = int(timezone.now().timestamp())
        latest = w3.eth.get_block('latest')
        latest_ts = int(latest['timestamp']) if latest and 'timestamp' in latest else 0
        if now_ts > latest_ts:
            w3.provider.make_request('evm_setNextBlockTimestamp', [now_ts])
            w3.provider.make_request('evm_mine', [])
    except Exception:
        pass


def get_contract(election, w3=None):
    w3 = w3 or get_web3_provider()
    if not w3.is_connected():
        raise SimpleVotingError("Hardhat node is offline. Start `npx hardhat node` and try again.")
    expected_chain = int(getattr(election, 'chain_id', 31337) or 31337)
    if int(w3.eth.chain_id) != expected_chain:
        raise SimpleVotingError(f"Connected chain ID is {w3.eth.chain_id}; this election expects {expected_chain}.")
    address = str(election.contract_address or '').strip()
    if not Web3.is_address(address):
        raise SimpleVotingError("Attach the deployed Remix contract address to this election first.")
    checksum = Web3.to_checksum_address(address)
    code = w3.eth.get_code(checksum)
    if not code or code == b'':
        if getattr(election, 'pk', None) and getattr(election, 'deployment_status', '') != 'CHAIN_RESET_REDEPLOY_REQUIRED':
            election.deployment_status = 'CHAIN_RESET_REDEPLOY_REQUIRED'
            election.save(update_fields=['deployment_status', 'updated_at'])
        raise SimpleVotingError("No contract code exists at the saved address on this Hardhat node. Deploy again and attach the new address.")
    return w3, w3.eth.contract(address=checksum, abi=SIMPLE_VOTING_ABI)


def transact(w3, function_call, sender=None):
    from .services import _resolve_deployer_account_and_key, _execute_deployer_tx
    _sync_hardhat_block_timestamp(w3)
    sender = sender or get_sender(w3)
    try:
        dep_addr, dep_key = _resolve_deployer_account_and_key(w3)
    except Exception:
        dep_addr, dep_key = None, None

    try:
        if dep_addr and dep_key and sender.lower() == dep_addr.lower():
            tx_hash, receipt = _execute_deployer_tx(
                w3, function_call, deployer=dep_addr, deployer_key=dep_key, timeout=60
            )
            tx_hash_hex = tx_hash.hex() if isinstance(tx_hash, bytes) else str(tx_hash)
            if not tx_hash_hex.startswith('0x'):
                tx_hash_hex = '0x' + tx_hash_hex
            if not receipt or int(receipt.status) != 1:
                raise SimpleVotingError("The blockchain rejected the transaction.")
            return tx_hash_hex, receipt

        tx_hash = function_call.transact({'from': sender})
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=60)
    except SimpleVotingError:
        raise
    except Exception as exc:
        msg = str(exc)
        if 'already cast' in msg.lower() or 'already voted' in msg.lower():
            raise SimpleVotingError("This voter has already cast a ballot in this election.") from exc
        if 'only owner' in msg.lower() or 'owner' in msg.lower():
            raise SimpleVotingError("The contract owner must be the first Hardhat account (account #0) used by the Django backend.") from exc
        raise SimpleVotingError(f"Blockchain transaction failed: {msg[:220]}") from exc
    if int(receipt.status) != 1:
        raise SimpleVotingError("The blockchain rejected the transaction.")
    return tx_hash.hex(), receipt


def _assert_owner(w3, contract):
    from .services import _resolve_deployer_account_and_key
    owner = Web3.to_checksum_address(contract.functions.owner().call())
    try:
        dep_addr, _ = _resolve_deployer_account_and_key(w3)
        if dep_addr and owner.lower() == dep_addr.lower():
            return owner
    except Exception:
        pass
    sender = get_sender(w3)
    if owner.lower() != sender.lower():
        raise SimpleVotingError(
            "The contract was not deployed from the configured Hardhat backend account. "
            "Deploy it in Remix using the first account shown by `npx hardhat node`."
        )
    return sender


def sync_candidate(election, candidate, w3=None, contract=None, sender=None):
    w3 = w3 or get_web3_provider()
    if contract is None:
        w3, contract = get_contract(election, w3)
    sender = sender or _assert_owner(w3, contract)
    if contract.functions.candidates(candidate.candidate_id_num).call()[4]:
        existing = contract.functions.candidates(candidate.candidate_id_num).call()
        if str(existing[1]) != candidate.name or str(existing[2]) != candidate.symbol:
            raise SimpleVotingError(
                f"Candidate #{candidate.candidate_id_num} already exists on-chain with different details. "
                "Deploy a fresh contract before changing the candidate roster."
            )
        candidate.is_synced_on_chain = True
        candidate.save(update_fields=['is_synced_on_chain'])
        return None
    if contract.functions.candidatesLocked().call():
        raise SimpleVotingError("The on-chain candidate roster is already locked.")
    tx_hash, receipt = transact(
        w3,
        contract.functions.addCandidate(candidate.candidate_id_num, candidate.name, candidate.symbol),
        sender,
    )
    candidate.is_synced_on_chain = True
    candidate.save(update_fields=['is_synced_on_chain'])
    return tx_hash, receipt


def attach_contract_to_election(election, address):
    if not Web3.is_address(address):
        raise SimpleVotingError("Enter a valid 0x-prefixed 20-byte contract address from Remix.")
    w3 = get_web3_provider()
    if not w3.is_connected():
        raise SimpleVotingError("Hardhat node is offline. Start `npx hardhat node` first.")
    if int(w3.eth.chain_id) != int(election.chain_id or 31337):
        raise SimpleVotingError(f"Hardhat chain ID mismatch: expected {election.chain_id}, received {w3.eth.chain_id}.")
    checksum = Web3.to_checksum_address(address)
    code = w3.eth.get_code(checksum)
    if not code or code == b'':
        raise SimpleVotingError("No deployed contract was found at this address on the connected Hardhat node.")
    contract = w3.eth.contract(address=checksum, abi=SIMPLE_VOTING_ABI)
    sender = _assert_owner(w3, contract)
    if contract.functions.candidatesLocked().call():
        raise SimpleVotingError("This contract's candidate roster is already locked. Deploy a fresh contract for a new election.")

    # Register all DB candidates on the newly attached contract.
    for candidate in election.candidates.filter(is_active=True).order_by('display_order', 'candidate_id_num'):
        sync_candidate(election, candidate, w3=w3, contract=contract, sender=sender)

    election.contract_address = checksum
    election.chain_id = int(w3.eth.chain_id)
    election.deployment_status = 'DEPLOYED'
    election.deployment_tx_hash = ''  # Deployed manually in Remix; the on-chain address is the source of truth.
    election.deployment_block_number = None
    election.save(update_fields=[
        'contract_address', 'chain_id', 'deployment_status',
        'deployment_tx_hash', 'deployment_block_number', 'updated_at'
    ])
    ContractDeployment.objects.filter(election=election, is_active_deployment=True).update(
        is_active_deployment=False, superseded_at=timezone.now()
    )
    ContractDeployment.objects.create(
        election=election,
        contract_address=checksum,
        chain_id=election.chain_id,
        authority_address=sender,
        is_active_deployment=True,
    )
    return checksum


def update_voting_window(election, start_datetime, end_datetime, actor_user=None):
    if not start_datetime or not end_datetime or end_datetime <= start_datetime:
        raise SimpleVotingError("Set a valid opening and closing time. The closing time must be later.")
    if election.status in ('ACTIVE', 'CLOSED', 'FINALIZED') or election.voting_window_locked_on_chain:
        raise SimpleVotingError("The voting schedule is locked for this election.")
    if election.contract_address:
        w3, contract = get_contract(election)
        sender = _assert_owner(w3, contract)
        if contract.functions.votingWindowLocked().call():
            raise SimpleVotingError("The on-chain voting window is already locked.")
        transact(
            w3,
            contract.functions.setVotingWindow(int(start_datetime.timestamp()), int(end_datetime.timestamp())),
            sender,
        )
    election.start_datetime = start_datetime
    election.end_datetime = end_datetime
    election.status = 'SCHEDULED'
    election.save(update_fields=['start_datetime', 'end_datetime', 'status', 'updated_at'])
    return election


def lock_candidate_roster(election, actor_user=None):
    active_candidates = list(election.candidates.filter(is_active=True).order_by('display_order', 'candidate_id_num'))
    if not active_candidates:
        raise SimpleVotingError("Add at least one active candidate before locking the roster.")
    if not election.contract_address:
        raise SimpleVotingError("Attach the Remix contract address before locking the roster.")
    if not election.start_datetime or not election.end_datetime or election.end_datetime <= election.start_datetime:
        raise SimpleVotingError("Configure the election opening and closing times before locking the roster.")

    w3, contract = get_contract(election)
    sender = _assert_owner(w3, contract)
    for candidate in active_candidates:
        sync_candidate(election, candidate, w3=w3, contract=contract, sender=sender)

    if not contract.functions.votingWindowLocked().call():
        transact(
            w3,
            contract.functions.setVotingWindow(int(election.start_datetime.timestamp()), int(election.end_datetime.timestamp())),
            sender,
        )
        transact(w3, contract.functions.lockVotingWindow(), sender)
    if not contract.functions.candidatesLocked().call():
        transact(w3, contract.functions.lockCandidates(), sender)

    election.candidates_locked_on_chain = True
    election.voting_window_locked_on_chain = True
    election.deployment_status = 'DEPLOYED'
    election.save(update_fields=[
        'candidates_locked_on_chain', 'voting_window_locked_on_chain',
        'deployment_status', 'updated_at'
    ])
    if election.status == 'DRAFT':
        election.status = 'SCHEDULED'
        election.save(update_fields=['status', 'updated_at'])
    return election


def open_election(election):
    if not election.contract_address or not election.candidates_locked_on_chain or not election.voting_window_locked_on_chain:
        raise SimpleVotingError("Election setup is incomplete: attach the contract, configure dates, and lock the candidate roster.")
    now = timezone.now()
    if not election.start_datetime or not election.end_datetime:
        raise SimpleVotingError("Election opening and closing times are not configured.")
    if now < election.start_datetime:
        raise SimpleVotingError("The scheduled opening time has not arrived yet.")
    if now >= election.end_datetime:
        raise SimpleVotingError("The scheduled election window has already ended.")
    w3, contract = get_contract(election)
    if not contract.functions.electionOpen().call():
        sender = _assert_owner(w3, contract)
        tx_hash, receipt = transact(w3, contract.functions.openElection(), sender)
    else:
        tx_hash, receipt = '', None
    election.status = 'ACTIVE'
    election.auto_transition_last_action = 'ACTIVATED'
    election.auto_transition_last_error = ''
    election.auto_transition_in_progress = False
    election.save(update_fields=['status', 'auto_transition_last_action', 'auto_transition_last_error', 'auto_transition_in_progress', 'updated_at'])
    return {'election_id': election.election_id, 'status': election.status, 'tx_hash': tx_hash, 'block_number': receipt.blockNumber if receipt else None}


def close_election(election):
    if election.contract_address:
        w3, contract = get_contract(election)
        if contract.functions.electionOpen().call():
            sender = _assert_owner(w3, contract)
            tx_hash, receipt = transact(w3, contract.functions.closeElection(), sender)
        else:
            tx_hash, receipt = '', None
    else:
        tx_hash, receipt = '', None
    election.status = 'CLOSED'
    election.auto_transition_last_action = 'CLOSED'
    election.auto_transition_last_error = ''
    election.auto_transition_in_progress = False
    election.save(update_fields=['status', 'auto_transition_last_action', 'auto_transition_last_error', 'auto_transition_in_progress', 'updated_at'])
    return {'election_id': election.election_id, 'status': election.status, 'tx_hash': tx_hash, 'block_number': receipt.blockNumber if receipt else None}


def run_election_lifecycle_scheduler(now=None):
    from .services import _ensure_aware_datetime
    now = _ensure_aware_datetime(now or timezone.now())
    report = {'activated': [], 'closed': [], 'skipped': [], 'errors': [], 'evaluated_at': now.isoformat()}

    # Ensure any election whose start_datetime is still in the future is in SCHEDULED state
    future_active = Election.objects.filter(
        status='ACTIVE',
        start_datetime__isnull=False,
        start_datetime__gt=now,
    )
    for election in future_active:
        election.status = 'SCHEDULED'
        election.save(update_fields=['status', 'updated_at'])

    due_open = Election.objects.filter(
        status='SCHEDULED',
        start_datetime__isnull=False,
        start_datetime__lte=now,
    ).order_by('start_datetime')
    for election in due_open:
        try:
            end_dt = _ensure_aware_datetime(election.end_datetime)
            if end_dt and now >= end_dt:
                close_election(election)
                report['closed'].append({'election_id': election.election_id})
                continue
            if election.contract_address:
                result = open_election(election)
                report['activated'].append(result)
            else:
                election.status = 'ACTIVE'
                election.auto_transition_last_action = 'ACTIVATED'
                election.auto_transition_last_error = ''
                election.auto_transition_in_progress = False
                election.save(update_fields=[
                    'status', 'auto_transition_last_action',
                    'auto_transition_last_error', 'auto_transition_in_progress', 'updated_at',
                ])
                report['activated'].append({
                    'election_id': election.election_id,
                    'status': election.status,
                    'tx_hash': '',
                    'block_number': None,
                })
        except Exception as exc:
            election.auto_transition_last_error = str(exc)[:1000]
            election.auto_transition_last_attempt_at = now
            election.auto_transition_last_action = 'ACTIVATION_ERROR'
            election.auto_transition_in_progress = False
            election.save(update_fields=['auto_transition_last_error', 'auto_transition_last_attempt_at', 'auto_transition_last_action', 'auto_transition_in_progress', 'updated_at'])
            report['errors'].append({'election_id': election.election_id, 'action': 'ACTIVATION', 'error': str(exc)[:300]})

    due_close = Election.objects.filter(
        status__in=['SCHEDULED', 'ACTIVE'],
        end_datetime__isnull=False,
        end_datetime__lte=now,
    ).order_by('end_datetime')
    for election in due_close:
        try:
            result = close_election(election)
            report['closed'].append(result)
        except Exception as exc:
            election.auto_transition_last_error = str(exc)[:1000]
            election.auto_transition_last_attempt_at = now
            election.auto_transition_last_action = 'CLOSURE_ERROR'
            election.save(update_fields=['auto_transition_last_error', 'auto_transition_last_attempt_at', 'auto_transition_last_action', 'updated_at'])
            report['errors'].append({'election_id': election.election_id, 'action': 'CLOSURE', 'error': str(exc)[:300]})
    return report


def cast_vote_for_voter(election, candidate, voter):
    """Submit the ballot after rechecking time boundaries and SQLite eligibility."""
    import secrets
    from .models import BallotReceipt
    from .services import _ensure_aware_datetime, is_election_voting_open

    now = _ensure_aware_datetime(timezone.now())
    start_dt = _ensure_aware_datetime(election.start_datetime)
    end_dt = _ensure_aware_datetime(election.end_datetime)

    if not start_dt or not end_dt:
        raise SimpleVotingError("Voting is not currently open for this election.")
    if now < start_dt or now >= end_dt:
        if now >= end_dt and election.status not in ('CLOSED', 'FINALIZED'):
            election.status = 'CLOSED'
            election.save(update_fields=['status', 'updated_at'])
        raise SimpleVotingError("This election is outside its configured voting window.")
    if not is_election_voting_open(election, now=now):
        raise SimpleVotingError("Voting is not currently open for this election.")
    if not candidate or not candidate.is_active or candidate.election_id != election.pk:
        raise SimpleVotingError("The selected candidate does not belong to this election.")

    eligibility = VoterEligibility.objects.select_for_update().filter(voter=voter, election=election).first()
    if not eligibility or not eligibility.is_eligible:
        raise SimpleVotingError("This voter is not eligible for the selected election.")
    if eligibility.has_voted:
        raise SimpleVotingError("A ballot has already been recorded for this voter in this election.")

    # Election-specific HMAC nullifier: the raw Voter ID never reaches the public chain.
    voter_hash_hex = derive_voter_nullifier(election.election_id, voter.aadhar_number)
    voter_hash = Web3.to_bytes(hexstr=voter_hash_hex)

    if BallotReceipt.objects.filter(election=election, voter=voter).exists() or BallotReceipt.objects.filter(election=election, voter_hash=Web3.to_hex(voter_hash)).exists():
        raise SimpleVotingError("A ballot has already been recorded for this voter in this election.")

    if election.contract_address:
        if not election.candidates_locked_on_chain or not election.voting_window_locked_on_chain:
            raise SimpleVotingError("This election is not ready to accept votes.")
        w3, contract = get_contract(election)
        if contract.functions.hasVoted(voter_hash).call():
            raise SimpleVotingError("A ballot has already been recorded for this voter in this election.")
        onchain_candidate = contract.functions.candidates(candidate.candidate_id_num).call()
        if not onchain_candidate[4]:
            raise SimpleVotingError("The selected candidate is not registered in the election contract.")

        # Final recheck immediately before submitting the transaction
        now_check = _ensure_aware_datetime(timezone.now())
        if not (start_dt <= now_check < end_dt):
            raise SimpleVotingError("This election is outside its configured voting window.")

        sender = get_sender(w3)
        tx_hash, receipt = transact(
            w3,
            contract.functions.markVote(candidate.candidate_id_num, voter_hash),
            sender,
        )
        clean_hash = tx_hash if str(tx_hash).startswith('0x') else '0x' + str(tx_hash)
        block_num = int(receipt.blockNumber)
        contract_addr = Web3.to_checksum_address(election.contract_address)
    else:
        # Final recheck immediately before recording the ballot
        now_check = _ensure_aware_datetime(timezone.now())
        if not (start_dt <= now_check < end_dt):
            raise SimpleVotingError("This election is outside its configured voting window.")
        clean_hash = '0x' + secrets.token_hex(32)
        block_num = 0
        contract_addr = ''

    confirmed_at = timezone.now()
    tx_short = clean_hash[2:10].upper()
    receipt_reference = f"DVS-{election.election_id}-{block_num}-{tx_short}"
    return {
        'tx_hash': clean_hash,
        'block_number': block_num,
        'contract_address': contract_addr,
        'confirmed_at': confirmed_at,
        'receipt_reference': receipt_reference,
        'voter_hash': Web3.to_hex(voter_hash),
    }


def election_is_open_now(election, now=None):
    from .services import is_election_voting_open
    return is_election_voting_open(election, now=now)


def get_candidate_vote_count(election, candidate_id):
    if not election.contract_address:
        from .models import BallotReceipt
        return BallotReceipt.objects.filter(election=election, candidate_id=int(candidate_id)).count()
    w3, contract = get_contract(election)
    return int(contract.functions.getCount(int(candidate_id)).call())

