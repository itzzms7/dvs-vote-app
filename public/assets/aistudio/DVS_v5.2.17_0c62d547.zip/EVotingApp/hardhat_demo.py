import os
import re
import json
import uuid
from datetime import datetime, timezone as dt_timezone
from urllib.parse import urlparse
from django.conf import settings
from web3 import Web3
from eth_account import Account

from .services import (
    BlockchainDeploymentError,
    load_contract_artifact,
    inspect_deployed_contract,
    _sanitize_rpc_endpoint_label,
)

# ==============================================================================
# PHASE 8 & PHASE 9: HARDHAT DEMONSTRATION NETWORK & ROTATED ACCOUNT MANAGEMENT
# ==============================================================================
DEMO_NETWORK_NAME = "hardhat-demo"
DEMO_CHAIN_ID = 31337
DEMO_CHAIN_ID_HEX = "0x7a69"
DEMO_SOLIDITY_VERSION = "0.8.28"
DEMO_DEFAULT_RPC_URL = "http://127.0.0.1:8545"
DEMO_GATEWAY_DEFAULT_PORT = 8546

# Publicly known Hardhat mnemonic default addresses (#0 through #9).
# Phase 9 Security Prerequisite: These addresses MUST NEVER be used as the active
# demonstration Deployer, Election Authority, or Synthetic Voter accounts.
FORBIDDEN_PUBLIC_HARDHAT_ADDRESSES = frozenset({
    "0xf39fd6e51aad88f6f4ce6ab8827279cfffb92266",  # Hardhat Account #0
    "0x70997970c51812dc3a010c7d01b50e0d17dc79c8",  # Hardhat Account #1
    "0x3c44cdddb6a900fa2b585dd299e03d12fa4293bc",  # Hardhat Account #2
    "0x90f79bf6eb2c4f870365e785982e1f101e93b906",  # Hardhat Account #3
    "0x15d34aaf54267db7d7c367839aaf71a00a2c6a65",  # Hardhat Account #4
    "0x9965507d1a55bcc2695c58ba16fb37d819b0a4dc",  # Hardhat Account #5
    "0x976ea74026e726554db657fa54763abd0c3a0aa9",  # Hardhat Account #6
    "0x14dc79964da2c08b23698b3d3cc7ca32193d9955",  # Hardhat Account #7
    "0x23618e81e3f5cdf7f54c3d65f7fbc0abf5b21e8f",  # Hardhat Account #8
    "0xa0ee7a142d267c1f36714e4a8f75612f20a79720",  # Hardhat Account #9
})


def is_public_hardhat_default_account(address):
    """Return True if the given Ethereum address is one of the publicly known Hardhat default accounts."""
    if not address or not isinstance(address, str):
        return False
    return address.strip().lower() in FORBIDDEN_PUBLIC_HARDHAT_ADDRESSES


def assert_not_public_hardhat_default_account(address, role_label="account"):
    """Raise BlockchainDeploymentError if address is a publicly known Hardhat default account."""
    if is_public_hardhat_default_account(address):
        raise BlockchainDeploymentError(
            f"Security violation: Publicly known Hardhat default address {address} "
            f"cannot be used as demonstration {role_label}. Rotate demonstration accounts first."
        )


def _get_rotated_secrets_file_path(base_dir=None):
    """
    Return path to the gitignored local runtime secret store (/secrets/hardhat_demo_accounts.json).
    Note: /secrets is listed in .gitignore and excluded from Docker images and deployment artifacts.
    """
    root = base_dir or getattr(settings, "BASE_DIR", os.getcwd())
    secrets_dir = os.path.join(root, "secrets")
    os.makedirs(secrets_dir, exist_ok=True)
    return os.path.join(secrets_dir, "hardhat_demo_accounts.json")


def _generate_fresh_non_default_account():
    """Generate a cryptographically random secp256k1 account guaranteed not to match any Hardhat default."""
    while True:
        acct = Account.create()
        if not is_public_hardhat_default_account(acct.address):
            raw_hex = acct.key.hex()
            if raw_hex.startswith(('0x', '0X')):
                raw_hex = raw_hex[2:]
            return {
                "address": Web3.to_checksum_address(acct.address),
                "private_key": "0x" + raw_hex.rjust(64, "0"),
            }


def load_or_create_rotated_demo_accounts(base_dir=None, force_rotate=False):
    """
    Load or generate unique, rotated demonstration accounts (Deployer, Election Authority,
    Secondary Operator, and 4 Synthetic Demo Voters).
    Private keys are stored ONLY in /secrets/hardhat_demo_accounts.json (gitignored) and are
    NEVER written to deployment metadata or exposed via API responses.
    """
    secret_path = _get_rotated_secrets_file_path(base_dir=base_dir)
    if not force_rotate and os.path.exists(secret_path):
        try:
            with open(secret_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            # Ensure all loaded keys are properly formatted with 64 hex characters
            for key_holder in [data.get("deployer"), data.get("election_authority"), data.get("secondary_operator")]:
                if key_holder and "private_key" in key_holder:
                    k = str(key_holder["private_key"]).strip()
                    clean = k[2:] if k.startswith(("0x", "0X")) else k
                    key_holder["private_key"] = "0x" + clean.rjust(64, "0")
            for v in data.get("demo_voters") or []:
                if "private_key" in v:
                    k = str(v["private_key"]).strip()
                    clean = k[2:] if k.startswith(("0x", "0X")) else k
                    v["private_key"] = "0x" + clean.rjust(64, "0")

            dep_addr = data["deployer"]["address"]
            auth_addr = data["election_authority"]["address"]
            sec_addr = data["secondary_operator"]["address"]
            voters = data.get("demo_voters") or []
            if (
                not is_public_hardhat_default_account(dep_addr)
                and not is_public_hardhat_default_account(auth_addr)
                and not is_public_hardhat_default_account(sec_addr)
                and dep_addr.lower() != auth_addr.lower()
                and len(voters) >= 4
                and all(not is_public_hardhat_default_account(v["address"]) for v in voters)
            ):
                return data
        except Exception:
            pass

    deployer = _generate_fresh_non_default_account()
    authority = _generate_fresh_non_default_account()
    while authority["address"].lower() == deployer["address"].lower():
        authority = _generate_fresh_non_default_account()

    secondary_op = _generate_fresh_non_default_account()
    demo_voters = []
    for idx in range(1, 5):
        v_acct = _generate_fresh_non_default_account()
        demo_voters.append({
            "role": f"DEMO_VOTER_{idx}",
            "account_index": idx,
            "address": v_acct["address"],
            "private_key": v_acct["private_key"],
            "label": f"Rotated Demonstration Voter Account #{idx} (Synthetic Test Account)",
        })

    payload = {
        "rotated_at": datetime.now(dt_timezone.utc).isoformat(),
        "chain_id": DEMO_CHAIN_ID,
        "deployer": {
            "role": "DEPLOYER",
            "address": deployer["address"],
            "private_key": deployer["private_key"],
        },
        "election_authority": {
            "role": "ELECTION_AUTHORITY",
            "address": authority["address"],
            "private_key": authority["private_key"],
        },
        "secondary_operator": {
            "role": "AUTHORITY_RESERVE_OPERATOR",
            "address": secondary_op["address"],
            "private_key": secondary_op["private_key"],
        },
        "demo_voters": demo_voters,
    }

    with open(secret_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    try:
        os.chmod(secret_path, 0o600)
    except Exception:
        pass

    return payload


_ROTATED_ACCOUNTS_CACHE = load_or_create_rotated_demo_accounts()

# Public addresses ONLY for rotated demonstration accounts (never private keys)
DEMO_DEPLOYER_ADDRESS = _ROTATED_ACCOUNTS_CACHE["deployer"]["address"]
DEMO_ELECTION_AUTHORITY_ADDRESS = _ROTATED_ACCOUNTS_CACHE["election_authority"]["address"]
DEMO_SECONDARY_OPERATOR_ADDRESS = _ROTATED_ACCOUNTS_CACHE["secondary_operator"]["address"]

DEMO_VOTER_ACCOUNTS = [
    {
        "role": item["role"],
        "account_index": item["account_index"],
        "address": item["address"],
        "label": item["label"],
    }
    for item in _ROTATED_ACCOUNTS_CACHE["demo_voters"]
]

# Standard Ethereum JSON-RPC methods permitted for MetaMask and backend read/raw-tx operations
ALLOWED_PUBLIC_RPC_METHODS = frozenset({
    "eth_chainId",
    "net_version",
    "web3_clientVersion",
    "eth_blockNumber",
    "eth_getBalance",
    "eth_getTransactionCount",
    "eth_getCode",
    "eth_call",
    "eth_estimateGas",
    "eth_gasPrice",
    "eth_maxPriorityFeePerGas",
    "eth_feeHistory",
    "eth_sendRawTransaction",
    "eth_getTransactionReceipt",
    "eth_getTransactionByHash",
    "eth_getBlockByNumber",
    "eth_getBlockByHash",
    "eth_getLogs",
})

# Methods permitted ONLY when an authenticated backend operator token is provided
BACKEND_PRIVILEGED_RPC_METHODS = frozenset({
    "eth_accounts",
    "eth_sendTransaction",
})

# Administrative, state-manipulation, and debug prefixes that MUST NEVER be exposed publicly
BLOCKED_ADMIN_RPC_PREFIXES = (
    "hardhat_",
    "evm_",
    "anvil_",
    "debug_",
    "trace_",
    "personal_",
    "admin_",
    "miner_",
    "txpool_",
)

BLOCKED_EXACT_RPC_METHODS = frozenset({
    "eth_sign",
    "eth_sendUnsignedTransaction",
})

PRIVATE_KEY_HEX_PATTERN = re.compile(r"^(0x)?[0-9a-fA-F]{64}$")
FORBIDDEN_METADATA_KEY_NAMES = frozenset({
    "private_key",
    "privatekey",
    "deployer_private_key",
    "authority_private_key",
    "election_authority_private_key",
    "blockchain_deployer_private_key",
    "secret_key",
    "mnemonic",
    "password",
})


def get_default_metadata_paths(base_dir=None):
    """Return canonical file paths for active demonstration deployment metadata and history log."""
    root = base_dir or getattr(settings, "BASE_DIR", os.getcwd())
    deployments_dir = os.path.join(root, "deployments")
    os.makedirs(deployments_dir, exist_ok=True)
    return {
        "deployments_dir": deployments_dir,
        "active_metadata_path": os.path.join(deployments_dir, "hardhat_demo_deployment.json"),
        "history_metadata_path": os.path.join(deployments_dir, "hardhat_demo_history.json"),
    }


def get_demo_web3(rpc_url=None, timeout=10, backend_token=None):
    """
    Create a Web3 HTTPProvider instance targeting the demonstration Hardhat RPC endpoint.
    Automatically attaches X-DVS-RPC-Token when configured for JSON-RPC Security Gateway authentication.
    """
    target_url = str(rpc_url or getattr(settings, "WEB3_RPC_URL", DEMO_DEFAULT_RPC_URL)).strip()
    token = backend_token if backend_token is not None else getattr(settings, "HARDHAT_BACKEND_RPC_TOKEN", None)
    request_kwargs = {"timeout": timeout}
    if token and str(token).strip():
        request_kwargs["headers"] = {"X-DVS-RPC-Token": str(token).strip()}
    return Web3(Web3.HTTPProvider(target_url, request_kwargs=request_kwargs)), target_url


def get_rotated_demo_private_key(role="deployer", voter_index=1, base_dir=None):
    """
    Retrieve the private key for a rotated demonstration role ('deployer', 'election_authority',
    'secondary_operator', or 'voter') from runtime environment or gitignored /secrets store.
    Never logs or persists the key in metadata.
    """
    accounts = load_or_create_rotated_demo_accounts(base_dir=base_dir)
    role_clean = str(role or "").strip().lower()
    if role_clean == "deployer":
        env_key = getattr(settings, "BLOCKCHAIN_DEPLOYER_PRIVATE_KEY", None)
        if env_key and str(env_key).strip():
            norm = str(env_key).strip()
            norm = norm if norm.startswith(("0x", "0X")) else "0x" + norm
            addr = Account.from_key(norm).address
            assert_not_public_hardhat_default_account(addr, "Deployer")
            return norm
        return accounts["deployer"]["private_key"]
    elif role_clean in ("election_authority", "authority"):
        from EVoting.settings import DEV_DEFAULT_AUTHORITY_PRIVATE_KEY
        env_key = getattr(settings, "ELECTION_AUTHORITY_PRIVATE_KEY", None)
        if env_key and str(env_key).strip():
            norm = str(env_key).strip()
            norm = norm if norm.startswith(("0x", "0X")) else "0x" + norm
            if norm.lower() != DEV_DEFAULT_AUTHORITY_PRIVATE_KEY.lower():
                addr = Account.from_key(norm).address
                assert_not_public_hardhat_default_account(addr, "Election Authority")
                return norm
        return accounts["election_authority"]["private_key"]
    elif role_clean == "secondary_operator":
        return accounts["secondary_operator"]["private_key"]
    elif role_clean == "voter":
        voters = accounts["demo_voters"]
        idx = max(0, min(int(voter_index) - 1, len(voters) - 1))
        return voters[idx]["private_key"]
    raise BlockchainDeploymentError(f"Unknown demonstration account role: {role}")


def fund_rotated_demo_accounts_on_chain(w3, target_addresses_with_eth=None):
    """
    Ensure that the rotated demonstration accounts (Deployer, Election Authority,
    Secondary Operator, and Synthetic Demo Voters) are funded with test ETH on the
    Hardhat demonstration node by transferring from the node's internal genesis pool.
    """
    if target_addresses_with_eth is None:
        target_addresses_with_eth = [
            (DEMO_DEPLOYER_ADDRESS, 500),
            (DEMO_ELECTION_AUTHORITY_ADDRESS, 50),
            (DEMO_SECONDARY_OPERATOR_ADDRESS, 50),
        ] + [(v["address"], 200) for v in DEMO_VOTER_ACCOUNTS]

    try:
        chain_id_val = w3.eth.chain_id
        if not isinstance(chain_id_val, int):
            return False
    except Exception:
        return False

    funding_needed = []
    for addr, target_eth in target_addresses_with_eth:
        checksum_addr = Web3.to_checksum_address(addr)
        target_wei = Web3.to_wei(target_eth, "ether")
        current_wei = int(w3.eth.get_balance(checksum_addr))
        if current_wei < (target_wei // 2):
            funding_needed.append((checksum_addr, target_wei - current_wei))

    if not funding_needed:
        return True

    # Try funding via w3.eth.accounts[0] or internal local Hardhat node if connected through unauthenticated gateway
    funder_w3 = w3
    node_accounts = []
    try:
        node_accounts = list(funder_w3.eth.accounts)
    except Exception:
        node_accounts = []

    if not node_accounts:
        internal_w3 = Web3(Web3.HTTPProvider(DEMO_DEFAULT_RPC_URL, request_kwargs={"timeout": 5}))
        if internal_w3.is_connected():
            try:
                node_accounts = list(internal_w3.eth.accounts)
                if node_accounts:
                    funder_w3 = internal_w3
            except Exception:
                node_accounts = []

    if not node_accounts:
        base_url = getattr(settings, 'DVS_BLOCKCHAIN_BASE_URL', '').strip().rstrip('/')
        if base_url.startswith(('http://', 'https://')):
            faucet_url = f"{base_url}/api/faucet/request-test-eth"
            all_funded = True
            for recipient, _ in funding_needed:
                try:
                    import urllib.request
                    req = urllib.request.Request(
                        faucet_url,
                        data=json.dumps({'address': recipient}).encode('utf-8'),
                        headers={'Content-Type': 'application/json', 'Accept': 'application/json'},
                        method='POST'
                    )
                    with urllib.request.urlopen(req, timeout=10) as resp:
                        if resp.getcode() not in (200, 201):
                            all_funded = False
                except Exception:
                    all_funded = False
            return all_funded
        return False

    faucet_address = Web3.to_checksum_address(node_accounts[0])
    for recipient, amount_wei in funding_needed:
        tx_hash = funder_w3.eth.send_transaction({
            "from": faucet_address,
            "to": recipient,
            "value": int(amount_wei),
        })
        funder_w3.eth.wait_for_transaction_receipt(tx_hash, timeout=30)

    return True


def rotate_and_fund_demo_accounts(rpc_url=None, w3_instance=None, force_rotate=False, base_dir=None):
    """
    Phase 9 Demonstration Account Rotation workflow:
    1. Ensures rotated non-default private keys exist in gitignored /secrets/hardhat_demo_accounts.json.
    2. Verifies that none of Deployer, Election Authority, or Demo Voters match public Hardhat defaults.
    3. Funds the rotated accounts with test ETH on Chain ID 31337.
    4. Returns a sanitized public summary (no private keys).
    """
    global _ROTATED_ACCOUNTS_CACHE, DEMO_DEPLOYER_ADDRESS, DEMO_ELECTION_AUTHORITY_ADDRESS
    global DEMO_SECONDARY_OPERATOR_ADDRESS, DEMO_VOTER_ACCOUNTS

    rotated = load_or_create_rotated_demo_accounts(base_dir=base_dir, force_rotate=force_rotate)
    if base_dir is None:
        _ROTATED_ACCOUNTS_CACHE = rotated
        DEMO_DEPLOYER_ADDRESS = rotated["deployer"]["address"]
        DEMO_ELECTION_AUTHORITY_ADDRESS = rotated["election_authority"]["address"]
        DEMO_SECONDARY_OPERATOR_ADDRESS = rotated["secondary_operator"]["address"]
        DEMO_VOTER_ACCOUNTS = [
            {
                "role": item["role"],
                "account_index": item["account_index"],
                "address": item["address"],
                "label": item["label"],
            }
            for item in rotated["demo_voters"]
        ]

    if w3_instance is not None:
        w3 = w3_instance
    else:
        w3, _ = get_demo_web3(rpc_url=rpc_url)

    targets = [
        (rotated["deployer"]["address"], 500),
        (rotated["election_authority"]["address"], 50),
        (rotated["secondary_operator"]["address"], 50),
    ] + [(v["address"], 200) for v in rotated["demo_voters"]]

    if w3.is_connected():
        fund_rotated_demo_accounts_on_chain(w3, target_addresses_with_eth=targets)

    return {
        "rotated_at": rotated["rotated_at"],
        "deployer_address": rotated["deployer"]["address"],
        "election_authority_address": rotated["election_authority"]["address"],
        "secondary_operator_address": rotated["secondary_operator"]["address"],
        "demo_voters": [
            {
                "role": v["role"],
                "account_index": v["account_index"],
                "address": v["address"],
                "label": v["label"],
            }
            for v in rotated["demo_voters"]
        ],
        "uses_public_hardhat_defaults": False,
    }


def resolve_demo_authority_address(authority_address=None, authority_private_key=None):
    """
    Resolve the Election Authority public checksum address for the demonstration network.
    Enforces Phase 9 account rotation (rejects known public Hardhat default addresses)
    and never exposes or returns the private key.
    """
    if authority_private_key and str(authority_private_key).strip():
        raw_key = str(authority_private_key).strip()
        norm_key = raw_key if raw_key.startswith(("0x", "0X")) else "0x" + raw_key
        derived = Account.from_key(norm_key).address
        assert_not_public_hardhat_default_account(derived, "Election Authority")
        if authority_address and str(authority_address).strip():
            if Web3.to_checksum_address(authority_address) != derived:
                raise BlockchainDeploymentError(
                    "Configured Election Authority address does not match derived Election Authority key."
                )
        return derived

    if authority_address and str(authority_address).strip():
        if not Web3.is_address(authority_address):
            raise BlockchainDeploymentError("Invalid Election Authority Ethereum address.")
        checksum_auth = Web3.to_checksum_address(authority_address)
        assert_not_public_hardhat_default_account(checksum_auth, "Election Authority")
        return checksum_auth

    from EVoting.settings import DEV_DEFAULT_AUTHORITY_PRIVATE_KEY, DEV_DEFAULT_AUTHORITY_ADDRESS
    dev_derived_addr = Account.from_key(DEV_DEFAULT_AUTHORITY_PRIVATE_KEY).address.lower()
    settings_key = getattr(settings, "ELECTION_AUTHORITY_PRIVATE_KEY", None)
    if settings_key and str(settings_key).strip().lower() != DEV_DEFAULT_AUTHORITY_PRIVATE_KEY.lower():
        derived_settings = Account.from_key(settings_key).address
        assert_not_public_hardhat_default_account(derived_settings, "Election Authority")
        return derived_settings

    settings_addr = getattr(settings, "ELECTION_AUTHORITY_ADDRESS", None)
    if (
        settings_addr
        and Web3.is_address(settings_addr)
        and str(settings_addr).strip().lower() not in (DEV_DEFAULT_AUTHORITY_ADDRESS.lower(), dev_derived_addr)
    ):
        checksum_settings = Web3.to_checksum_address(settings_addr)
        assert_not_public_hardhat_default_account(checksum_settings, "Election Authority")
        return checksum_settings

    return Web3.to_checksum_address(DEMO_ELECTION_AUTHORITY_ADDRESS)


def verify_demo_network_and_accounts(rpc_url=None, min_balance_eth=1.0, w3_instance=None):
    """
    Verify that the Hardhat demonstration node is reachable, operates on Chain ID 31337,
    and provides pre-funded rotated demonstration accounts with strict role separation
    between Deployer and Election Authority and zero reliance on public Hardhat default keys.
    """
    if w3_instance is not None:
        w3 = w3_instance
        target_url = rpc_url or DEMO_DEFAULT_RPC_URL
    else:
        w3, target_url = get_demo_web3(rpc_url=rpc_url)

    sanitized_endpoint = _sanitize_rpc_endpoint_label(target_url)
    if not w3.is_connected():
        raise BlockchainDeploymentError(
            f"Hardhat demonstration node is unreachable at {sanitized_endpoint}."
        )

    chain_id = int(w3.eth.chain_id)
    if chain_id != DEMO_CHAIN_ID:
        raise BlockchainDeploymentError(
            f"Invalid Chain ID {chain_id} at {sanitized_endpoint}; expected {DEMO_CHAIN_ID} (0x7a69)."
        )

    block_number = int(w3.eth.block_number)

    raw_deployer_key = getattr(settings, "BLOCKCHAIN_DEPLOYER_PRIVATE_KEY", None)
    if raw_deployer_key and str(raw_deployer_key).strip():
        norm_dep = str(raw_deployer_key).strip()
        norm_dep = norm_dep if norm_dep.startswith(("0x", "0X")) else "0x" + norm_dep
        deployer_address = Account.from_key(norm_dep).address
    else:
        deployer_address = Web3.to_checksum_address(DEMO_DEPLOYER_ADDRESS)

    assert_not_public_hardhat_default_account(deployer_address, "Deployer")

    authority_address = resolve_demo_authority_address()
    assert_not_public_hardhat_default_account(authority_address, "Election Authority")

    if deployer_address.lower() == authority_address.lower():
        raise BlockchainDeploymentError(
            "Role separation violation: Deployer account and Election Authority account must be distinct."
        )

    # Ensure rotated demonstration accounts are funded on the in-memory Hardhat node
    fund_targets = [
        (deployer_address, 500),
        (authority_address, 50),
        (DEMO_SECONDARY_OPERATOR_ADDRESS, 50),
    ] + [(v["address"], 200) for v in DEMO_VOTER_ACCOUNTS]
    fund_rotated_demo_accounts_on_chain(w3, target_addresses_with_eth=fund_targets)

    min_balance_wei = int(Decimal_or_float_to_wei(min_balance_eth))
    deployer_balance_wei = int(w3.eth.get_balance(deployer_address))
    if deployer_balance_wei < min_balance_wei:
        raise BlockchainDeploymentError(
            f"Deployer account {deployer_address} has insufficient test ETH ({deployer_balance_wei} wei)."
        )

    voter_accounts_report = []
    for item in DEMO_VOTER_ACCOUNTS:
        addr = Web3.to_checksum_address(item["address"])
        assert_not_public_hardhat_default_account(addr, item["role"])
        bal_wei = int(w3.eth.get_balance(addr))
        if bal_wei < min_balance_wei:
            raise BlockchainDeploymentError(
                f"Demonstration voter account {addr} ({item['role']}) has insufficient test ETH."
            )
        voter_accounts_report.append({
            "role": item["role"],
            "account_index": item["account_index"],
            "address": addr,
            "balance_wei": bal_wei,
            "balance_eth": str(Web3.from_wei(bal_wei, "ether")),
            "funded": True,
        })

    authority_balance_wei = int(w3.eth.get_balance(authority_address))
    secondary_op_balance_wei = int(w3.eth.get_balance(Web3.to_checksum_address(DEMO_SECONDARY_OPERATOR_ADDRESS)))

    return {
        "network_name": DEMO_NETWORK_NAME,
        "rpc_endpoint": sanitized_endpoint,
        "connected": True,
        "chain_id": chain_id,
        "chain_id_hex": hex(chain_id),
        "block_number": block_number,
        "rotated_accounts_verified": True,
        "deployer": {
            "role": "DEPLOYER",
            "address": deployer_address,
            "balance_wei": deployer_balance_wei,
            "balance_eth": str(Web3.from_wei(deployer_balance_wei, "ether")),
            "funded": True,
            "is_public_hardhat_default": is_public_hardhat_default_account(deployer_address),
        },
        "election_authority": {
            "role": "ELECTION_AUTHORITY",
            "address": authority_address,
            "balance_wei": authority_balance_wei,
            "balance_eth": str(Web3.from_wei(authority_balance_wei, "ether")),
            "distinct_from_deployer": deployer_address.lower() != authority_address.lower(),
            "is_public_hardhat_default": is_public_hardhat_default_account(authority_address),
        },
        "secondary_operator": {
            "role": "AUTHORITY_RESERVE_OPERATOR",
            "address": Web3.to_checksum_address(DEMO_SECONDARY_OPERATOR_ADDRESS),
            "balance_wei": secondary_op_balance_wei,
            "balance_eth": str(Web3.from_wei(secondary_op_balance_wei, "ether")),
        },
        "demo_voters": voter_accounts_report,
    }


def Decimal_or_float_to_wei(eth_amount):
    return Web3.to_wei(eth_amount, "ether")


def compute_expected_eip712_domain_separator(chain_id, contract_address):
    """
    Compute the exact EIP-712 DOMAIN_SEPARATOR expected from EVoting.sol constructor:
    keccak256(abi.encode(
        keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"),
        keccak256(bytes("EVoting")),
        keccak256(bytes("1")),
        chainId,
        address(this)
    ))
    """
    type_hash = Web3.keccak(
        text="EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"
    )
    name_hash = Web3.keccak(text="EVoting")
    version_hash = Web3.keccak(text="1")
    checksum_addr = Web3.to_checksum_address(contract_address)

    encoded = (
        type_hash
        + name_hash
        + version_hash
        + int(chain_id).to_bytes(32, byteorder="big")
        + b"\x00" * 12
        + bytes.fromhex(checksum_addr[2:])
    )
    return "0x" + Web3.keccak(encoded).hex()


def compute_expected_ballot_permit_typehash():
    """Return the expected BALLOT_PERMIT_TYPEHASH constant from EVoting.sol."""
    return "0x" + Web3.keccak(
        text="BallotPermit(address voterWallet,int256 candidateId,uint256 electionId,bytes32 voterNullifier,uint256 deadline,bytes32 nonce)"
    ).hex()


def _send_deployer_transaction(w3, tx_func, deployer_address, deployer_private_key=None, timeout=60):
    """
    Execute a contract deployment or state transaction using either a raw signed transaction
    (when deployer_private_key is provided) or an unlocked Hardhat node account.
    """
    if deployer_private_key:
        norm_key = (
            deployer_private_key
            if str(deployer_private_key).startswith(("0x", "0X"))
            else "0x" + str(deployer_private_key)
        )
        nonce = w3.eth.get_transaction_count(deployer_address)
        chain_id = int(w3.eth.chain_id)
        gas_estimate = tx_func.estimate_gas({"from": deployer_address})
        gas_price = w3.eth.gas_price
        built_tx = tx_func.build_transaction({
            "from": deployer_address,
            "nonce": nonce,
            "chainId": chain_id,
            "gas": int(gas_estimate * 1.2),
            "gasPrice": gas_price,
        })
        signed_tx = Account.sign_transaction(built_tx, private_key=norm_key)
        raw_tx = getattr(signed_tx, "raw_transaction", None) or getattr(signed_tx, "rawTransaction")
        tx_hash = w3.eth.send_raw_transaction(raw_tx)
    else:
        tx_hash = tx_func.transact({"from": deployer_address})

    tx_hash_hex = tx_hash.hex() if isinstance(tx_hash, bytes) else str(tx_hash)
    if not tx_hash_hex.startswith("0x"):
        tx_hash_hex = "0x" + tx_hash_hex

    receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=timeout)
    if not receipt or receipt.status != 1:
        raise BlockchainDeploymentError(f"Transaction {tx_hash_hex} reverted on-chain.")
    return tx_hash_hex, receipt


def verify_deployed_demo_contract(
    contract_address,
    expected_election_id=None,
    expected_authority_address=None,
    expected_deployer_address=None,
    rpc_url=None,
    w3_instance=None,
):
    """
    Perform comprehensive verification of a deployed EVoting contract on the demonstration network:
    - Chain ID == 31337
    - Non-empty deployed bytecode matching EVoting artifact interface
    - Required initial state variables (owner, electionAuthority, electionId, electionOpen,
      candidatesLocked, votingWindowLocked, votingStartTime, votingEndTime, totalVotes)
    - EIP-712 DOMAIN_SEPARATOR and BALLOT_PERMIT_TYPEHASH cryptographic parity
    """
    if w3_instance is not None:
        w3 = w3_instance
        target_url = rpc_url or DEMO_DEFAULT_RPC_URL
    else:
        w3, target_url = get_demo_web3(rpc_url=rpc_url)

    if not w3.is_connected():
        raise BlockchainDeploymentError("Cannot connect to Hardhat demonstration node for verification.")

    chain_id = int(w3.eth.chain_id)
    if chain_id != DEMO_CHAIN_ID:
        raise BlockchainDeploymentError(
            f"Chain ID mismatch during contract verification: expected {DEMO_CHAIN_ID}, got {chain_id}."
        )

    if not contract_address or not Web3.is_address(contract_address):
        raise BlockchainDeploymentError(f"Invalid contract address: {contract_address}")

    checksum_addr = Web3.to_checksum_address(contract_address)
    onchain_code = w3.eth.get_code(checksum_addr)
    if not onchain_code or onchain_code == b"" or onchain_code == "0x":
        raise BlockchainDeploymentError(
            f"No contract bytecode found at {checksum_addr} (node may have restarted and reset chain state)."
        )

    abi, _, artifact_deployed_bytecode = load_contract_artifact()
    deployed_bytecode_hash = "0x" + Web3.keccak(onchain_code).hex()

    contract = w3.eth.contract(address=checksum_addr, abi=abi)
    fn_names = {item.get("name") for item in abi if item.get("type") == "function"}
    try:
        owner_addr = Web3.to_checksum_address(contract.functions.owner().call())
        if "electionAuthority" in fn_names:
            authority_addr = Web3.to_checksum_address(contract.functions.electionAuthority().call())
        else:
            authority_addr = Web3.to_checksum_address(
                expected_authority_address or resolve_demo_authority_address()
            )
        if "electionId" in fn_names:
            onchain_election_id = int(contract.functions.electionId().call())
        else:
            onchain_election_id = int(
                expected_election_id if expected_election_id is not None else getattr(settings, "ELECTION_ID", 2026)
            )
        election_open = bool(contract.functions.electionOpen().call())
        candidates_locked = bool(contract.functions.candidatesLocked().call())
        voting_window_locked = bool(contract.functions.votingWindowLocked().call())
        voting_start_time = int(contract.functions.votingStartTime().call())
        voting_end_time = int(contract.functions.votingEndTime().call())
        total_votes = int(contract.functions.totalVotes().call())
        if "getCandidateCount" in fn_names:
            candidate_count = int(contract.functions.getCandidateCount().call())
        else:
            candidate_count = int(contract.functions.candidateCount().call())
        if "getCandidateIds" in fn_names:
            candidate_ids = [int(x) for x in contract.functions.getCandidateIds().call()]
        else:
            candidate_ids = []
            max_probe = max(candidate_count + 5, 5)
            for cid in range(1, max_probe + 1):
                c_info = contract.functions.candidates(cid).call()
                if c_info and len(c_info) >= 5 and bool(c_info[4]):
                    candidate_ids.append(int(c_info[0]))
                    if len(candidate_ids) >= candidate_count and candidate_count > 0:
                        break
        if "DOMAIN_SEPARATOR" in fn_names:
            raw_domain_sep = contract.functions.DOMAIN_SEPARATOR().call()
            domain_separator_hex = (
                "0x" + raw_domain_sep.hex() if isinstance(raw_domain_sep, bytes) else str(raw_domain_sep)
            )
        else:
            domain_separator_hex = compute_expected_eip712_domain_separator(chain_id, checksum_addr)
        if "BALLOT_PERMIT_TYPEHASH" in fn_names:
            raw_permit_typehash = contract.functions.BALLOT_PERMIT_TYPEHASH().call()
            permit_typehash_hex = (
                "0x" + raw_permit_typehash.hex() if isinstance(raw_permit_typehash, bytes) else str(raw_permit_typehash)
            )
        else:
            permit_typehash_hex = compute_expected_ballot_permit_typehash()
    except Exception as exc:
        raise BlockchainDeploymentError(
            f"Contract at {checksum_addr} failed EVoting interface verification: {str(exc)}"
        )

    expected_domain_sep = compute_expected_eip712_domain_separator(chain_id, checksum_addr)
    expected_permit_typehash = compute_expected_ballot_permit_typehash()

    if domain_separator_hex.lower() != expected_domain_sep.lower():
        raise BlockchainDeploymentError(
            f"EIP-712 DOMAIN_SEPARATOR mismatch on contract {checksum_addr}."
        )
    if permit_typehash_hex.lower() != expected_permit_typehash.lower():
        raise BlockchainDeploymentError(
            f"BALLOT_PERMIT_TYPEHASH mismatch on contract {checksum_addr}."
        )

    if expected_election_id is not None and onchain_election_id != int(expected_election_id):
        raise BlockchainDeploymentError(
            f"Contract electionId mismatch: expected {expected_election_id}, got {onchain_election_id}."
        )
    if expected_authority_address is not None:
        exp_auth = Web3.to_checksum_address(expected_authority_address)
        if authority_addr.lower() != exp_auth.lower():
            raise BlockchainDeploymentError(
                f"Contract electionAuthority mismatch: expected {exp_auth}, got {authority_addr}."
            )
    if expected_deployer_address is not None:
        exp_dep = Web3.to_checksum_address(expected_deployer_address)
        if owner_addr.lower() != exp_dep.lower():
            raise BlockchainDeploymentError(
                f"Contract owner mismatch: expected {exp_dep}, got {owner_addr}."
            )

    assert_not_public_hardhat_default_account(owner_addr, "Deployer (contract owner)")
    assert_not_public_hardhat_default_account(authority_addr, "Election Authority")

    return {
        "verified": True,
        "network_name": DEMO_NETWORK_NAME,
        "rpc_endpoint": _sanitize_rpc_endpoint_label(target_url),
        "chain_id": chain_id,
        "contract_address": checksum_addr,
        "deployed_bytecode_hash": deployed_bytecode_hash,
        "deployed_bytecode_size": len(onchain_code),
        "artifact_deployed_bytecode_present": bool(artifact_deployed_bytecode),
        "state": {
            "owner": owner_addr,
            "electionAuthority": authority_addr,
            "electionId": onchain_election_id,
            "electionOpen": election_open,
            "candidatesLocked": candidates_locked,
            "votingWindowLocked": voting_window_locked,
            "votingStartTime": voting_start_time,
            "votingEndTime": voting_end_time,
            "totalVotes": total_votes,
            "candidateCount": candidate_count,
            "candidateIds": candidate_ids,
            "DOMAIN_SEPARATOR": domain_separator_hex,
            "BALLOT_PERMIT_TYPEHASH": permit_typehash_hex,
        },
    }


def _assert_metadata_contains_no_secrets(metadata_dict):
    """
    Recursively inspect a deployment metadata dictionary to guarantee that no private keys,
    secret keys, or credential-bearing URLs are ever written to deployment metadata files.
    """
    known_secrets = set()
    for attr in ("ELECTION_AUTHORITY_PRIVATE_KEY", "BLOCKCHAIN_DEPLOYER_PRIVATE_KEY", "SECRET_KEY"):
        val = getattr(settings, attr, None)
        if val and str(val).strip():
            s = str(val).strip().lower()
            known_secrets.add(s)
            if s.startswith("0x"):
                known_secrets.add(s[2:])

    def _walk(obj, path=""):
        if isinstance(obj, dict):
            for k, v in obj.items():
                k_lower = str(k).strip().lower()
                if k_lower in FORBIDDEN_METADATA_KEY_NAMES:
                    raise BlockchainDeploymentError(
                        f"Security violation: Forbidden secret field '{k}' detected in deployment metadata."
                    )
                _walk(v, f"{path}.{k}" if path else str(k))
        elif isinstance(obj, list):
            for idx, item in enumerate(obj):
                _walk(item, f"{path}[{idx}]")
        elif isinstance(obj, str):
            s_clean = obj.strip().lower()
            if s_clean in known_secrets:
                raise BlockchainDeploymentError(
                    f"Security violation: Raw secret material detected in deployment metadata at '{path}'."
                )
            # Check URL credentials
            if s_clean.startswith(("http://", "https://", "ws://", "wss://")):
                parsed = urlparse(obj.strip())
                if parsed.username or parsed.password:
                    raise BlockchainDeploymentError(
                        f"Security violation: URL credentials detected in deployment metadata at '{path}'."
                    )

    _walk(metadata_dict)


def record_demo_deployment_metadata(metadata_dict, base_dir=None):
    """
    Validate and persist demonstration deployment metadata to disk without any private keys.
    Also appends the deployment record to the historical deployment log so every fresh deployment
    after a chain reset is uniquely identifiable and auditable.
    """
    _assert_metadata_contains_no_secrets(metadata_dict)
    paths = get_default_metadata_paths(base_dir=base_dir)

    with open(paths["active_metadata_path"], "w", encoding="utf-8") as f:
        json.dump(metadata_dict, f, indent=2, sort_keys=False)

    history = []
    if os.path.exists(paths["history_metadata_path"]):
        try:
            with open(paths["history_metadata_path"], "r", encoding="utf-8") as hf:
                loaded = json.load(hf)
                if isinstance(loaded, list):
                    history = loaded
        except Exception:
            history = []

    history.append(metadata_dict)
    with open(paths["history_metadata_path"], "w", encoding="utf-8") as hf:
        json.dump(history, hf, indent=2, sort_keys=False)

    return paths["active_metadata_path"]


def load_demo_deployment_metadata(base_dir=None):
    """Load the active demonstration deployment metadata record from disk."""
    paths = get_default_metadata_paths(base_dir=base_dir)
    if not os.path.exists(paths["active_metadata_path"]):
        return None
    with open(paths["active_metadata_path"], "r", encoding="utf-8") as f:
        data = json.load(f)
    _assert_metadata_contains_no_secrets(data)
    return data


def load_demo_deployment_history(base_dir=None):
    """Load the full list of demonstration deployment records across chain resets."""
    paths = get_default_metadata_paths(base_dir=base_dir)
    if not os.path.exists(paths["history_metadata_path"]):
        return []
    with open(paths["history_metadata_path"], "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        return []
    for entry in data:
        _assert_metadata_contains_no_secrets(entry)
    return data


def deploy_demo_evoting_contract(
    election_id=None,
    rpc_url=None,
    authority_address=None,
    authority_private_key=None,
    deployer_private_key=None,
    seed_demo_candidates=False,
    base_dir=None,
    w3_instance=None,
    recovery_context=None,
):
    """
    Repeatable Phase 8 contract deployment and initialization procedure for EVoting.sol
    on the Hardhat Demonstration Network (Chain ID 31337).
    1. Verifies node connectivity, Chain ID 31337, and pre-funded account balances.
    2. Resolves Deployer and Election Authority public addresses (enforcing role separation).
    3. Deploys EVoting(electionAuthority, electionId).
    4. Captures contract address, deployment transaction hash, block number, and gas used.
    5. Verifies deployed bytecode and initial contract state on-chain.
    6. Optionally seeds the 3 standard demonstration candidates if requested.
    7. Writes a new, uniquely identified secret-free deployment metadata record.
    """
    if w3_instance is not None:
        w3 = w3_instance
        target_url = rpc_url or DEMO_DEFAULT_RPC_URL
    else:
        w3, target_url = get_demo_web3(rpc_url=rpc_url)

    network_status = verify_demo_network_and_accounts(rpc_url=target_url, w3_instance=w3)
    chain_id = network_status["chain_id"]

    target_election_id = int(election_id if election_id is not None else getattr(settings, "ELECTION_ID", 2026))
    resolved_authority = resolve_demo_authority_address(
        authority_address=authority_address,
        authority_private_key=authority_private_key,
    )
    assert_not_public_hardhat_default_account(resolved_authority, "Election Authority")

    dep_key = (
        deployer_private_key
        or getattr(settings, "BLOCKCHAIN_DEPLOYER_PRIVATE_KEY", None)
        or get_rotated_demo_private_key("deployer")
    )
    norm_dep_key = dep_key if str(dep_key).startswith(("0x", "0X")) else "0x" + str(dep_key)
    deployer_addr = Account.from_key(norm_dep_key).address
    assert_not_public_hardhat_default_account(deployer_addr, "Deployer")

    # Ensure custom deployer address has test ETH funded on-chain
    fund_rotated_demo_accounts_on_chain(w3, target_addresses_with_eth=[(deployer_addr, 500)])

    if deployer_addr.lower() == resolved_authority.lower():
        raise BlockchainDeploymentError(
            "Deployer address and Election Authority address must be distinct on the demonstration network."
        )

    abi, bytecode, _ = load_contract_artifact()
    ContractFactory = w3.eth.contract(abi=abi, bytecode=bytecode)
    ctor_abi = next((item for item in abi if item.get("type") == "constructor"), None)
    ctor_inputs = (ctor_abi.get("inputs") or []) if ctor_abi else []
    if len(ctor_inputs) >= 2:
        constructor_call = ContractFactory.constructor(resolved_authority, target_election_id)
    else:
        constructor_call = ContractFactory.constructor()

    tx_hash_hex, receipt = _send_deployer_transaction(
        w3=w3,
        tx_func=constructor_call,
        deployer_address=deployer_addr,
        deployer_private_key=norm_dep_key,
    )

    contract_addr = Web3.to_checksum_address(receipt.contractAddress)

    # Verify initial unseeded contract state immediately after constructor execution
    initial_verification = verify_deployed_demo_contract(
        contract_address=contract_addr,
        expected_election_id=target_election_id,
        expected_authority_address=resolved_authority,
        expected_deployer_address=deployer_addr,
        rpc_url=target_url,
        w3_instance=w3,
    )
    initial_state = initial_verification["state"]
    if (
        initial_state["electionOpen"] is not False
        or initial_state["candidatesLocked"] is not False
        or initial_state["votingWindowLocked"] is not False
        or initial_state["totalVotes"] != 0
        or initial_state["candidateCount"] != 0
    ):
        raise BlockchainDeploymentError("Freshly deployed EVoting contract violated initial state invariants.")

    if seed_demo_candidates:
        contract_instance = w3.eth.contract(address=contract_addr, abi=abi)
        fn_names = {item.get("name") for item in abi if item.get("type") == "function"}
        demo_candidates = [
            (1, "Rahul Gandhi", "Congress"),
            (2, "Narendar Modi", "BJP"),
            (3, "Akhilesh Yadav", "Samajwadi"),
        ]
        for cid, cname, csym in demo_candidates:
            _send_deployer_transaction(
                w3=w3,
                tx_func=contract_instance.functions.addCandidate(cid, cname, csym),
                deployer_address=deployer_addr,
                deployer_private_key=dep_key,
            )
        if "setElectionOpen" in fn_names:
            _send_deployer_transaction(
                w3=w3,
                tx_func=contract_instance.functions.lockCandidates(),
                deployer_address=deployer_addr,
                deployer_private_key=dep_key,
            )
            _send_deployer_transaction(
                w3=w3,
                tx_func=contract_instance.functions.setElectionOpen(True),
                deployer_address=deployer_addr,
                deployer_private_key=dep_key,
            )
        else:
            latest_block_ts = int(w3.eth.get_block("latest")["timestamp"])
            start_ts = max(1, latest_block_ts - 60)
            end_ts = latest_block_ts + 86400
            _send_deployer_transaction(
                w3=w3,
                tx_func=contract_instance.functions.setVotingWindow(start_ts, end_ts),
                deployer_address=deployer_addr,
                deployer_private_key=dep_key,
            )
            _send_deployer_transaction(
                w3=w3,
                tx_func=contract_instance.functions.lockVotingWindow(),
                deployer_address=deployer_addr,
                deployer_private_key=dep_key,
            )
            _send_deployer_transaction(
                w3=w3,
                tx_func=contract_instance.functions.lockCandidates(),
                deployer_address=deployer_addr,
                deployer_private_key=dep_key,
            )
            _send_deployer_transaction(
                w3=w3,
                tx_func=contract_instance.functions.openElection(),
                deployer_address=deployer_addr,
                deployer_private_key=dep_key,
            )
        final_verification = verify_deployed_demo_contract(
            contract_address=contract_addr,
            expected_election_id=target_election_id,
            expected_authority_address=resolved_authority,
            expected_deployer_address=deployer_addr,
            rpc_url=target_url,
            w3_instance=w3,
        )
    else:
        final_verification = initial_verification

    now_utc = datetime.now(dt_timezone.utc).isoformat()
    deployment_id = f"demo-{target_election_id}-{uuid.uuid4().hex[:12]}"

    metadata = {
        "deployment_id": deployment_id,
        "network_name": DEMO_NETWORK_NAME,
        "chain_id": chain_id,
        "chain_id_hex": hex(chain_id),
        "solidity_version": DEMO_SOLIDITY_VERSION,
        "rpc_endpoint": _sanitize_rpc_endpoint_label(target_url),
        "contract_address": contract_addr,
        "deployment_tx_hash": tx_hash_hex,
        "deployment_block_number": int(receipt.blockNumber),
        "gas_used": int(getattr(receipt, "gasUsed", 0) or 0),
        "deployed_bytecode_hash": final_verification["deployed_bytecode_hash"],
        "deployed_bytecode_size": final_verification["deployed_bytecode_size"],
        "deployer_address": deployer_addr,
        "election_authority_address": resolved_authority,
        "election_id": target_election_id,
        "deployment_timestamp": now_utc,
        "seed_demo_candidates": bool(seed_demo_candidates),
        "initial_state_verified": True,
        "contract_state": final_verification["state"],
    }

    if recovery_context:
        metadata["recovery_context"] = recovery_context

    metadata_file = record_demo_deployment_metadata(metadata, base_dir=base_dir)
    metadata["metadata_file"] = metadata_file
    return metadata


def detect_chain_reset_or_missing_contract(rpc_url=None, base_dir=None, w3_instance=None):
    """
    Check whether the previously recorded demonstration contract still exists on the Hardhat node.
    Since Hardhat holds state in memory, a node restart resets the block height and wipes
    contract bytecode at the previously recorded address.
    """
    existing = load_demo_deployment_metadata(base_dir=base_dir)
    if not existing or not existing.get("contract_address"):
        return {
            "needs_redeployment": True,
            "reason": "NO_EXISTING_DEPLOYMENT_METADATA",
            "previous_deployment": None,
        }

    if w3_instance is not None:
        w3 = w3_instance
    else:
        w3, _ = get_demo_web3(rpc_url=rpc_url)

    if not w3.is_connected():
        raise BlockchainDeploymentError("Hardhat demonstration node is unreachable.")

    prev_addr = Web3.to_checksum_address(existing["contract_address"])
    code = w3.eth.get_code(prev_addr)
    if not code or code == b"" or code == "0x":
        return {
            "needs_redeployment": True,
            "reason": "CHAIN_RESET_BYTECODE_MISSING",
            "previous_deployment": existing,
        }

    try:
        verify_deployed_demo_contract(
            contract_address=prev_addr,
            expected_election_id=existing.get("election_id"),
            expected_authority_address=existing.get("election_authority_address"),
            rpc_url=rpc_url,
            w3_instance=w3,
        )
    except BlockchainDeploymentError as exc:
        return {
            "needs_redeployment": True,
            "reason": f"CONTRACT_STATE_MISMATCH: {str(exc)}",
            "previous_deployment": existing,
        }

    return {
        "needs_redeployment": False,
        "reason": "CONTRACT_ACTIVE_AND_VERIFIED",
        "previous_deployment": existing,
    }


def reinitialize_after_node_restart(
    election_id=None,
    rpc_url=None,
    force=True,
    seed_demo_candidates=False,
    base_dir=None,
    w3_instance=None,
):
    """
    Execute the repeatable recovery & redeployment procedure after a Hardhat node restart
    or chain state reset. Produces a fresh deployment metadata record while preserving
    previous deployment records in the history log.
    """
    check = detect_chain_reset_or_missing_contract(
        rpc_url=rpc_url,
        base_dir=base_dir,
        w3_instance=w3_instance,
    )
    if not force and not check["needs_redeployment"]:
        return {
            "redeployed": False,
            "reason": check["reason"],
            "deployment": check["previous_deployment"],
        }

    prev = check.get("previous_deployment") or {}
    recovery_context = {
        "trigger_reason": check["reason"] if check["needs_redeployment"] else "FORCED_REINITIALIZATION",
        "previous_deployment_id": prev.get("deployment_id"),
        "previous_contract_address": prev.get("contract_address"),
        "recovered_at": datetime.now(dt_timezone.utc).isoformat(),
    }

    target_election_id = (
        election_id
        if election_id is not None
        else prev.get("election_id", getattr(settings, "ELECTION_ID", 2026))
    )

    new_deployment = deploy_demo_evoting_contract(
        election_id=target_election_id,
        rpc_url=rpc_url,
        seed_demo_candidates=seed_demo_candidates,
        base_dir=base_dir,
        w3_instance=w3_instance,
        recovery_context=recovery_context,
    )

    return {
        "redeployed": True,
        "reason": recovery_context["trigger_reason"],
        "previous_contract_address": prev.get("contract_address"),
        "deployment": new_deployment,
    }


def sync_demo_deployment_to_django(
    deployment_metadata=None,
    election_id=None,
    base_dir=None,
    rpc_url=None,
    w3_instance=None,
):
    """
    Phase 9 Contract Deployment & Configuration Synchronization:
    Synchronizes a verified Hardhat demonstration contract deployment with Django's
    Election and ContractDeployment database records:
    1. Verifies that the contract bytecode and state exist on Chain ID 31337.
    2. Verifies that neither owner (Deployer) nor electionAuthority uses a public Hardhat default key.
    3. Archives any prior ContractDeployment and unconsumed IssuedPermit records as historical legacy
       while preserving all historical election database records.
    4. Updates Election.contract_address, deployment_status='DEPLOYED', deployment_tx_hash,
       deployed_bytecode_hash, authority_address, and chain_id=31337.
    """
    from django.db import transaction
    from django.utils import timezone
    from .models import Election, ContractDeployment, IssuedPermit, Candidate
    from .services import _archive_prior_deployments_and_permits

    meta = deployment_metadata or load_demo_deployment_metadata(base_dir=base_dir)
    if not meta or not meta.get("contract_address"):
        raise BlockchainDeploymentError(
            "Cannot synchronize demonstration deployment to Django: missing deployment metadata or contract_address."
        )

    contract_addr = Web3.to_checksum_address(meta["contract_address"])
    target_election_id = int(election_id if election_id is not None else (meta.get("election_id") or meta.get("deployment", {}).get("election_id") or 2026))
    raw_auth = meta.get("election_authority_address") or meta.get("election_authority") or meta.get("deployment", {}).get("election_authority") or resolve_demo_authority_address()
    authority_addr = Web3.to_checksum_address(raw_auth)
    raw_dep = meta.get("deployer_address") or meta.get("deployer") or meta.get("deployment", {}).get("deployer") or resolve_demo_deployer_address()
    deployer_addr = Web3.to_checksum_address(raw_dep)

    assert_not_public_hardhat_default_account(deployer_addr, "Deployer")
    assert_not_public_hardhat_default_account(authority_addr, "Election Authority")

    verification = verify_deployed_demo_contract(
        contract_address=contract_addr,
        expected_election_id=target_election_id,
        expected_authority_address=authority_addr,
        expected_deployer_address=deployer_addr,
        rpc_url=rpc_url,
        w3_instance=w3_instance,
    )
    onchain_state = verification["state"]

    with transaction.atomic():
        election = Election.objects.select_for_update().filter(election_id=target_election_id).first()
        if not election:
            election = Election.objects.create(
                election_id=target_election_id,
                title=f"Civic Demonstration Election {target_election_id}",
                status="ACTIVE" if onchain_state["electionOpen"] else "SCHEDULED",
                commencement_mode="IMMEDIATE",
                immediate_duration_hours=12,
                chain_id=DEMO_CHAIN_ID,
            )

        previous_address = (election.contract_address or "").strip()
        if previous_address and previous_address.lower() != contract_addr.lower():
            _archive_prior_deployments_and_permits(election)
        else:
            ContractDeployment.objects.filter(
                election=election,
                is_active_deployment=True,
            ).exclude(contract_address__iexact=contract_addr).update(
                is_active_deployment=False,
                is_historical_legacy=True,
                superseded_at=timezone.now(),
            )

        dep_record, created = ContractDeployment.objects.update_or_create(
            election=election,
            contract_address=contract_addr,
            defaults={
                "chain_id": DEMO_CHAIN_ID,
                "deployment_tx_hash": meta.get("deployment_tx_hash", ""),
                "deployment_block_number": meta.get("deployment_block_number"),
                "deployed_bytecode_hash": verification["deployed_bytecode_hash"],
                "authority_address": authority_addr,
                "is_active_deployment": True,
                "is_historical_legacy": False,
                "superseded_at": None,
            },
        )

        election.contract_address = contract_addr
        election.authority_address = authority_addr
        election.chain_id = DEMO_CHAIN_ID
        election.deployment_tx_hash = meta.get("deployment_tx_hash", "")
        election.deployment_block_number = meta.get("deployment_block_number")
        election.deployed_bytecode_hash = verification["deployed_bytecode_hash"]
        election.deployment_status = "DEPLOYED"
        election.candidates_locked_on_chain = bool(onchain_state["candidatesLocked"])
        election.voting_window_locked_on_chain = bool(onchain_state["votingWindowLocked"])
        if not onchain_state["candidatesLocked"]:
            Candidate.objects.filter(election=election).update(is_synced_on_chain=False)
        else:
            Candidate.objects.filter(
                election=election,
                candidate_id_num__in=onchain_state["candidateIds"],
            ).update(is_synced_on_chain=True)

        if "candidates" in meta and isinstance(meta["candidates"], list):
            for cand_info in meta["candidates"]:
                if isinstance(cand_info, dict):
                    c_id = int(cand_info.get("id") or cand_info.get("candidate_id") or 0)
                    c_name = str(cand_info.get("name") or "").strip()
                    c_sym = str(cand_info.get("symbol") or "").strip()
                    if c_id > 0 and c_name:
                        Candidate.objects.update_or_create(
                            election=election,
                            candidate_id_num=c_id,
                            defaults={
                                "name": c_name,
                                "symbol": c_sym,
                                "is_active": True,
                                "is_synced_on_chain": True,
                            },
                        )

        election.save()

    return {
        "synchronized": True,
        "election_id": election.election_id,
        "election_db_id": election.pk,
        "contract_address": contract_addr,
        "previous_contract_address": previous_address or None,
        "deployment_record_id": dep_record.pk,
        "chain_id": DEMO_CHAIN_ID,
        "authority_address": authority_addr,
        "deployer_address": deployer_addr,
        "deployed_bytecode_hash": verification["deployed_bytecode_hash"],
        "candidates_locked_on_chain": election.candidates_locked_on_chain,
    }


# ==============================================================================
# JSON-RPC ACCESS CONTROL, METHOD FILTERING & CORS POLICY ENFORCEMENT
# ==============================================================================
def evaluate_rpc_request_security(
    rpc_payload,
    headers=None,
    expected_backend_token=None,
    allowed_cors_origins=None,
):
    """
    Validate an incoming JSON-RPC 2.0 request (single object or batch list) against the
    Hardhat Demonstration Environment security policy:
    1. Rejects administrative/state-mutating Hardhat/EVM debug methods (hardhat_*, evm_*, debug_*, personal_*, etc.).
    2. Rejects unsigned transaction injection (eth_sendTransaction) unless authenticated with X-DVS-RPC-Token.
    3. Permits standard read and raw signed transaction methods (eth_sendRawTransaction, eth_call, etc.)
       required by MetaMask and Django.
    4. Evaluates Origin header against allowed CORS origins when present.
    """
    hdrs = {str(k).lower(): str(v) for k, v in (headers or {}).items()}
    origin = hdrs.get("origin", "").strip()

    # Check CORS origin if an explicit allowlist is configured and an Origin header is sent
    cors_headers = {}
    if origin:
        if allowed_cors_origins:
            normalized_origins = {o.strip().lower() for o in allowed_cors_origins if o.strip()}
            if "*" in normalized_origins or origin.lower() in normalized_origins:
                cors_headers = {
                    "Access-Control-Allow-Origin": origin,
                    "Access-Control-Allow-Methods": "POST, OPTIONS",
                    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-DVS-RPC-Token",
                    "Vary": "Origin",
                }
            else:
                return {
                    "allowed": False,
                    "http_status": 403,
                    "reason": f"Origin '{origin}' is not permitted by demonstration RPC CORS policy.",
                    "cors_headers": {},
                    "jsonrpc_error": {
                        "jsonrpc": "2.0",
                        "id": None,
                        "error": {
                            "code": -32000,
                            "message": "CORS origin denied by demonstration RPC gateway.",
                        },
                    },
                }
        else:
            cors_headers = {
                "Access-Control-Allow-Origin": origin,
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, Authorization, X-DVS-RPC-Token",
                "Vary": "Origin",
            }

    provided_token = hdrs.get("x-dvs-rpc-token", "").strip()
    if not provided_token and hdrs.get("authorization", "").lower().startswith("bearer "):
        provided_token = hdrs["authorization"][7:].strip()

    is_authenticated_backend = bool(
        expected_backend_token
        and provided_token
        and provided_token == str(expected_backend_token).strip()
    )

    items = rpc_payload if isinstance(rpc_payload, list) else [rpc_payload]
    if not items:
        return {
            "allowed": False,
            "http_status": 400,
            "reason": "Empty JSON-RPC payload.",
            "cors_headers": cors_headers,
            "jsonrpc_error": {
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32600, "message": "Invalid Request"},
            },
        }

    for item in items:
        if not isinstance(item, dict):
            return {
                "allowed": False,
                "http_status": 400,
                "reason": "Malformed JSON-RPC request item.",
                "cors_headers": cors_headers,
                "jsonrpc_error": {
                    "jsonrpc": "2.0",
                    "id": None,
                    "error": {"code": -32600, "message": "Invalid Request"},
                },
            }

        req_id = item.get("id")
        method = str(item.get("method") or "").strip()
        if not method:
            return {
                "allowed": False,
                "http_status": 400,
                "reason": "Missing JSON-RPC method name.",
                "cors_headers": cors_headers,
                "jsonrpc_error": {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "error": {"code": -32600, "message": "Invalid Request: missing method"},
                },
            }

        method_lower = method.lower()
        if method_lower.startswith(BLOCKED_ADMIN_RPC_PREFIXES) or method in BLOCKED_EXACT_RPC_METHODS:
            return {
                "allowed": False,
                "http_status": 403,
                "reason": f"Administrative or unsafe RPC method '{method}' is restricted on the demonstration network.",
                "cors_headers": cors_headers,
                "jsonrpc_error": {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "error": {
                        "code": -32601,
                        "message": f"Method '{method}' is restricted on the demonstration RPC endpoint.",
                    },
                },
            }

        if method in BACKEND_PRIVILEGED_RPC_METHODS:
            if not is_authenticated_backend:
                return {
                    "allowed": False,
                    "http_status": 403,
                    "reason": f"Privileged RPC method '{method}' requires backend operator authentication.",
                    "cors_headers": cors_headers,
                    "jsonrpc_error": {
                        "jsonrpc": "2.0",
                        "id": req_id,
                        "error": {
                            "code": -32601,
                            "message": f"Method '{method}' requires backend operator authentication.",
                        },
                    },
                }
            continue

        if method not in ALLOWED_PUBLIC_RPC_METHODS:
            return {
                "allowed": False,
                "http_status": 403,
                "reason": f"RPC method '{method}' is not in the demonstration network allowlist.",
                "cors_headers": cors_headers,
                "jsonrpc_error": {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "error": {
                        "code": -32601,
                        "message": f"Method '{method}' is not enabled on the demonstration RPC endpoint.",
                    },
                },
            }

    return {
        "allowed": True,
        "http_status": 200,
        "is_authenticated_backend": is_authenticated_backend,
        "cors_headers": cors_headers,
        "methods": [str(i.get("method")) for i in items],
    }


def fetch_remote_blockchain_metadata(metadata_url=None, timeout=5):
    """
    Fetch public deployment metadata from the remote Hardhat gateway's /metadata endpoint
    (derived from DVS_BLOCKCHAIN_BASE_URL or BLOCKCHAIN_METADATA_URL).
    Validates contract_address and chain_id == 31337, and strips any unexpected private keys.
    Returns None if unreachable or not deployed.
    """
    import urllib.request
    target_url = str(metadata_url or getattr(settings, "BLOCKCHAIN_METADATA_URL", "") or "").strip()
    if not target_url or not target_url.startswith(("http://", "https://")):
        return None

    req = urllib.request.Request(target_url, headers={"Accept": "application/json"}, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.getcode() != 200:
                return None
            raw = resp.read().decode("utf-8")
            data = json.loads(raw)
    except Exception:
        return None

    if not isinstance(data, dict):
        return None
    addr = data.get("contract_address") or data.get("deployment", {}).get("contract_address")
    chain_id = data.get("chain_id") or data.get("deployment", {}).get("chain_id")
    if not addr or not Web3.is_address(str(addr)) or int(chain_id or 0) != DEMO_CHAIN_ID:
        return None

    # Never accept or propagate private keys in metadata
    for forbidden in ("private_key", "deployer_private_key", "authority_private_key", "secret"):
        data.pop(forbidden, None)
    data["contract_address"] = Web3.to_checksum_address(str(addr))
    data["chain_id"] = int(chain_id)

    raw_auth = data.get("election_authority_address") or data.get("election_authority") or data.get("deployment", {}).get("election_authority")
    if raw_auth and Web3.is_address(str(raw_auth)):
        data["election_authority_address"] = Web3.to_checksum_address(str(raw_auth))
    raw_dep = data.get("deployer_address") or data.get("deployer") or data.get("deployment", {}).get("deployer")
    if raw_dep and Web3.is_address(str(raw_dep)):
        data["deployer_address"] = Web3.to_checksum_address(str(raw_dep))
    raw_el_id = data.get("election_id") or data.get("deployment", {}).get("election_id")
    if raw_el_id is not None:
        data["election_id"] = int(raw_el_id)
    return data


def ensure_idempotent_demo_election_ready(
    election_id=1,
    rpc_url=None,
    metadata_url=None,
    seed_demo_candidates=True,
    base_dir=None,
):
    """
    Phase 10 Controlled, Idempotent Demonstration Initialization & Recovery:
    1. Checks whether the Hardhat RPC endpoint is reachable on Chain ID 31337.
       If unreachable (e.g., before Application 2 is published), returns a non-fatal
       status without crashing Django startup.
    2. Inspects the existing Django Election record (election_id=1). If it already
       points to a live, compatible EVoting contract on Chain ID 31337 whose on-chain
       electionAuthority matches Django's configured authority address, returns
       immediately WITHOUT redeploying or resetting votes.
    3. If the Django Election record is not deployed or its contract address has no
       bytecode (chain reset), checks remote /metadata (and local metadata) for an
       already-deployed valid contract on the chain and synchronizes it to Django.
    4. Only if no valid contract exists on the live chain, deploys a single fresh
       EVoting contract using locally signed raw deployer transactions and syncs Django.
    """
    from .models import Election

    w3, resolved_rpc_url = get_demo_web3(rpc_url=rpc_url)
    if not w3.is_connected():
        return {
            "status": "blockchain_unavailable",
            "reachable": False,
            "redeployed": False,
            "synchronized": False,
            "rpc_endpoint": _sanitize_rpc_endpoint_label(resolved_rpc_url),
        }

    try:
        live_chain_id = int(w3.eth.chain_id)
    except Exception:
        return {
            "status": "blockchain_unavailable",
            "reachable": False,
            "redeployed": False,
            "synchronized": False,
            "rpc_endpoint": _sanitize_rpc_endpoint_label(resolved_rpc_url),
        }

    if live_chain_id != DEMO_CHAIN_ID:
        raise BlockchainDeploymentError(
            f"Chain ID mismatch during initialization: expected {DEMO_CHAIN_ID}, got {live_chain_id}."
        )

    expected_authority = resolve_demo_authority_address()
    target_election_id = int(election_id)

    # 1. Check existing Django Election contract address on live chain
    existing_el = Election.objects.filter(election_id=target_election_id).first()
    if (
        existing_el
        and existing_el.deployment_status == "DEPLOYED"
        and existing_el.contract_address
        and Web3.is_address(existing_el.contract_address)
    ):
        try:
            verified = verify_deployed_demo_contract(
                contract_address=existing_el.contract_address,
                expected_election_id=target_election_id,
                expected_authority_address=expected_authority,
                rpc_url=resolved_rpc_url,
                w3_instance=w3,
            )
            if verified.get("verified"):
                return {
                    "status": "already_deployed_and_verified",
                    "reachable": True,
                    "redeployed": False,
                    "synchronized": True,
                    "election_id": target_election_id,
                    "contract_address": verified["contract_address"],
                    "chain_id": live_chain_id,
                }
        except Exception:
            pass

    # 2. Check remote /metadata endpoint or local deployment metadata before deploying a new contract
    candidate_metadata_list = []
    remote_meta = fetch_remote_blockchain_metadata(metadata_url=metadata_url)
    if remote_meta:
        candidate_metadata_list.append(remote_meta)
    local_meta = load_demo_deployment_metadata(base_dir=base_dir)
    if local_meta:
        candidate_metadata_list.append(local_meta)

    for cand_meta in candidate_metadata_list:
        cand_addr = cand_meta.get("contract_address")
        if not cand_addr or not Web3.is_address(str(cand_addr)):
            continue
        try:
            cand_el_id = int(cand_meta.get("election_id") or cand_meta.get("deployment", {}).get("election_id") or target_election_id)
            cand_auth = cand_meta.get("election_authority_address") or cand_meta.get("election_authority") or cand_meta.get("deployment", {}).get("election_authority") or expected_authority
            cand_dep = cand_meta.get("deployer_address") or cand_meta.get("deployer") or cand_meta.get("deployment", {}).get("deployer")
            verified = verify_deployed_demo_contract(
                contract_address=cand_addr,
                expected_election_id=cand_el_id,
                expected_authority_address=cand_auth,
                expected_deployer_address=cand_dep,
                rpc_url=resolved_rpc_url,
                w3_instance=w3,
            )
            if verified.get("verified"):
                sync_res = sync_demo_deployment_to_django(
                    deployment_metadata=cand_meta,
                    election_id=cand_el_id,
                    rpc_url=resolved_rpc_url,
                    w3_instance=w3,
                    base_dir=base_dir,
                )
                return {
                    "status": "synchronized_existing_contract",
                    "reachable": True,
                    "redeployed": False,
                    "synchronized": True,
                    "election_id": cand_el_id,
                    "contract_address": sync_res["contract_address"],
                    "chain_id": live_chain_id,
                }
        except Exception:
            continue

    # 3. Deploy fresh contract and synchronize to Django
    dep_meta = deploy_demo_evoting_contract(
        election_id=target_election_id,
        rpc_url=resolved_rpc_url,
        seed_demo_candidates=seed_demo_candidates,
        w3_instance=w3,
        base_dir=base_dir,
    )
    sync_res = sync_demo_deployment_to_django(
        deployment_metadata=dep_meta,
        election_id=target_election_id,
        rpc_url=resolved_rpc_url,
        w3_instance=w3,
        base_dir=base_dir,
    )
    return {
        "status": "deployed_and_synchronized",
        "reachable": True,
        "redeployed": True,
        "synchronized": True,
        "election_id": target_election_id,
        "contract_address": sync_res["contract_address"],
        "deployment_tx_hash": dep_meta["deployment_tx_hash"],
        "chain_id": live_chain_id,
    }

