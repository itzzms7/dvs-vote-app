import json
from datetime import timedelta
from unittest.mock import patch, MagicMock
from django.test import TestCase, Client
from django.contrib.auth.models import User, Group
from django.utils import timezone
from web3 import Web3

from EVotingApp.models import (
    Election,
    Candidate,
    ElectionAdminAssignment,
    AdminAuditLog,
    Voter,
    VoterEligibility,
)
from EVotingApp.services import (
    get_web3_provider,
    load_contract_artifact,
    deploy_election_contract,
    add_election_candidate,
    update_election_candidate,
    deactivate_election_candidate,
    sync_and_lock_candidates,
    verify_election_candidate_parity,
    activate_election,
    get_election_candidates_status,
    ElectionLifecycleError,
    BlockchainDeploymentError,
)


class Module4CandidateManagementTests(TestCase):
    def setUp(self):
        self.client = Client()

        self.super_group, _ = Group.objects.get_or_create(name='Super Admin')
        self.admin_group, _ = Group.objects.get_or_create(name='Election Administrator')
        self.auditor_group, _ = Group.objects.get_or_create(name='Auditor')

        self.election_admin = User.objects.create_user(
            username='cand_admin', password='password123', is_staff=True
        )
        self.election_admin.groups.add(self.admin_group)

        self.auditor = User.objects.create_user(
            username='cand_auditor', password='password123', is_staff=True
        )
        self.auditor.groups.add(self.auditor_group)

        self.election = Election.objects.create(
            title='2026 Municipal Assembly Election',
            description='Municipal Election for Candidate Management Verification',
            election_type='GENERAL',
            election_id=4040,
            status='DRAFT',
            deployment_status='NOT_DEPLOYED',
            start_datetime=timezone.now() - timedelta(minutes=5),
            end_datetime=timezone.now() + timedelta(days=2),
        )
        Candidate.objects.create(
            election=self.election, candidate_id_num=1, name='Rahul Gandhi', symbol='Congress', display_order=1
        )
        Candidate.objects.create(
            election=self.election, candidate_id_num=2, name='Narendar Modi', symbol='BJP', display_order=2
        )
        Candidate.objects.create(
            election=self.election, candidate_id_num=3, name='Akhilesh Yadav', symbol='Samajwadi', display_order=3
        )

        ElectionAdminAssignment.objects.create(
            election=self.election, user=self.election_admin, role='ELECTION_ADMIN'
        )
        ElectionAdminAssignment.objects.create(
            election=self.election, user=self.auditor, role='AUDITOR'
        )

    def test_draft_candidate_crud_and_validation_rules(self):
        """
        Verify candidate addition, update, deactivation, and validation in DRAFT state:
        - Rejects non-positive ID, empty name/symbol, duplicate ID, and duplicate name.
        - Allows full metadata updates and deactivation before contract deployment.
        - Creates CANDIDATE_ADDED, CANDIDATE_UPDATED, and CANDIDATE_DEACTIVATED audit logs.
        """
        # 1. Valid candidate creation in DRAFT
        cand_4 = add_election_candidate(
            election_db_id=self.election.pk,
            candidate_id_num=4,
            name='Arvind Kejriwal',
            symbol='AAP',
            description='Civic Reform Candidate',
            display_order=4,
            actor_user=self.election_admin,
        )
        self.assertEqual(cand_4.candidate_id_num, 4)
        self.assertEqual(cand_4.name, 'Arvind Kejriwal')
        self.assertTrue(cand_4.is_active)
        self.assertFalse(cand_4.is_synced_on_chain)

        # 2. Reject duplicate candidate_id_num
        with self.assertRaises(ElectionLifecycleError):
            add_election_candidate(
                self.election.pk, 4, 'Another Candidate', 'Independent', actor_user=self.election_admin
            )

        # 3. Reject duplicate candidate name (case-insensitive)
        with self.assertRaises(ElectionLifecycleError):
            add_election_candidate(
                self.election.pk, 5, 'arvind kejriwal', 'Independent', actor_user=self.election_admin
            )

        # 4. Reject invalid IDs or empty fields
        with self.assertRaises(ElectionLifecycleError):
            add_election_candidate(self.election.pk, 0, 'Zero ID', 'Sym', actor_user=self.election_admin)
        with self.assertRaises(ElectionLifecycleError):
            add_election_candidate(self.election.pk, -1, 'Negative ID', 'Sym', actor_user=self.election_admin)
        with self.assertRaises(ElectionLifecycleError):
            add_election_candidate(self.election.pk, 6, '   ', 'Sym', actor_user=self.election_admin)
        with self.assertRaises(ElectionLifecycleError):
            add_election_candidate(self.election.pk, 6, 'Valid Name', '   ', actor_user=self.election_admin)

        # 5. Update candidate in DRAFT (name, symbol, description, display_order)
        updated_4 = update_election_candidate(
            election_db_id=self.election.pk,
            candidate_id_num=4,
            name='Dr. Arvind Kejriwal',
            symbol='Broom',
            description='Updated Platform Description',
            display_order=10,
            actor_user=self.election_admin,
        )
        self.assertEqual(updated_4.name, 'Dr. Arvind Kejriwal')
        self.assertEqual(updated_4.symbol, 'Broom')
        self.assertEqual(updated_4.display_order, 10)

        # 6. Deactivate candidate in DRAFT
        deactivated = deactivate_election_candidate(
            self.election.pk, 4, actor_user=self.election_admin
        )
        self.assertFalse(deactivated.is_active)

        # Verify audit logs recorded
        logs = AdminAuditLog.objects.filter(target_model='Election', target_id=str(self.election.pk))
        actions = set(logs.values_list('action', flat=True))
        self.assertIn('CANDIDATE_ADDED', actions)
        self.assertIn('CANDIDATE_UPDATED', actions)
        self.assertIn('CANDIDATE_DEACTIVATED', actions)

    def test_two_elections_with_distinct_candidate_rosters_and_empty_constructor(self):
        """
        Prove that:
        1. Newly deployed EVoting contracts initialize with an empty candidate roster (0 candidates).
        2. Two newly created elections can have completely different candidate rosters on-chain,
           including custom candidates at IDs 1, 2, 3 (not legacy 2026 candidates) and custom IDs 101, 102.
        """
        w3 = get_web3_provider()
        if not w3.is_connected():
            self.skipTest("Hardhat node not running")

        abi, _, _ = load_contract_artifact()

        # Election A: Custom candidates at IDs 1, 2, 3 (different from Legacy Election 2026)
        election_a = Election.objects.create(
            title='Green Energy Council Election',
            election_type='INSTITUTIONAL',
            election_id=4101,
            status='DRAFT',
            deployment_status='NOT_DEPLOYED',
            start_datetime=timezone.now() - timedelta(minutes=5),
            end_datetime=timezone.now() + timedelta(days=2),
        )
        add_election_candidate(election_a.pk, 1, 'Dr. Maya Nair', 'Solar', actor_user=self.election_admin)
        add_election_candidate(election_a.pk, 2, 'Vikram Sen', 'Wind', actor_user=self.election_admin)
        add_election_candidate(election_a.pk, 3, 'Zoya Khan', 'Hydro', actor_user=self.election_admin)

        # Election B: Completely different candidate IDs (101, 102) and names
        election_b = Election.objects.create(
            title='University Senate Election',
            election_type='INSTITUTIONAL',
            election_id=4102,
            status='DRAFT',
            deployment_status='NOT_DEPLOYED',
            start_datetime=timezone.now() - timedelta(minutes=5),
            end_datetime=timezone.now() + timedelta(days=2),
        )
        add_election_candidate(election_b.pk, 101, 'Prof. R. Subramanian', 'Book', actor_user=self.election_admin)
        add_election_candidate(election_b.pk, 102, 'Meera Iyer', 'Lamp', actor_user=self.election_admin)

        # Deploy both contracts (DRAFT -> CONTRACT DEPLOYED -> SCHEDULED, roster unlocked & empty on-chain)
        addr_a = deploy_election_contract(election_a.pk, actor_user=self.election_admin)
        addr_b = deploy_election_contract(election_b.pk, actor_user=self.election_admin)
        self.assertNotEqual(addr_a.lower(), addr_b.lower())

        contract_a = w3.eth.contract(address=Web3.to_checksum_address(addr_a), abi=abi)
        contract_b = w3.eth.contract(address=Web3.to_checksum_address(addr_b), abi=abi)

        # Immediately after constructor deployment, both contracts have 0 candidates and are unlocked
        self.assertEqual(contract_a.functions.getCandidateCount().call(), 0)
        self.assertEqual(contract_a.functions.getCandidateIds().call(), [])
        self.assertFalse(contract_a.functions.candidates(1).call()[4])
        self.assertFalse(contract_a.functions.candidatesLocked().call())
        self.assertFalse(contract_a.functions.electionOpen().call())

        self.assertEqual(contract_b.functions.getCandidateCount().call(), 0)
        self.assertEqual(contract_b.functions.getCandidateIds().call(), [])
        self.assertFalse(contract_b.functions.candidates(1).call()[4])
        self.assertFalse(contract_b.functions.candidatesLocked().call())

        # Synchronize and lock both rosters
        sync_and_lock_candidates(election_a.pk, lock_on_chain=True, actor_user=self.election_admin)
        sync_and_lock_candidates(election_b.pk, lock_on_chain=True, actor_user=self.election_admin)

        # Verify Election A on-chain roster
        self.assertEqual(contract_a.functions.getCandidateIds().call(), [1, 2, 3])
        c1_a = contract_a.functions.candidates(1).call()
        self.assertEqual((c1_a[1], c1_a[2], c1_a[4]), ('Dr. Maya Nair', 'Solar', True))
        self.assertFalse(contract_a.functions.candidates(101).call()[4])

        # Verify Election B on-chain roster
        self.assertEqual(contract_b.functions.getCandidateIds().call(), [101, 102])
        c101_b = contract_b.functions.candidates(101).call()
        self.assertEqual((c101_b[1], c101_b[2], c101_b[4]), ('Prof. R. Subramanian', 'Book', True))
        self.assertFalse(contract_b.functions.candidates(1).call()[4])

        # Activate both elections and verify parity passes
        activate_election(election_a.pk, actor_user=self.election_admin)
        activate_election(election_b.pk, actor_user=self.election_admin)
        election_a.refresh_from_db()
        election_b.refresh_from_db()
        self.assertEqual(election_a.status, 'ACTIVE')
        self.assertEqual(election_b.status, 'ACTIVE')

    def test_deployment_and_candidate_locking_sequence_and_activation_guards(self):
        """
        Verify the strict sequence:
        DRAFT -> CONTRACT DEPLOYED -> SCHEDULED -> CANDIDATE SYNCHRONIZATION -> CANDIDATE LOCK -> ACTIVE
        - Deployment does not prematurely lock the candidate roster.
        - Activation rejects elections with unsynchronized candidates or an unlocked roster.
        - Candidate locking is irreversible.
        """
        w3 = get_web3_provider()
        if not w3.is_connected():
            self.skipTest("Hardhat node not running")

        # 1. Deploy from DRAFT -> SCHEDULED (unlocked)
        deploy_election_contract(self.election.pk, actor_user=self.election_admin)
        self.election.refresh_from_db()
        self.assertEqual(self.election.status, 'SCHEDULED')
        self.assertEqual(self.election.deployment_status, 'DEPLOYED')
        self.assertFalse(self.election.candidates_locked_on_chain)

        # 2. Activation must fail while candidates are unsynchronized and roster is unlocked
        with self.assertRaises(ElectionLifecycleError):
            activate_election(self.election.pk, actor_user=self.election_admin)

        # 3. Synchronize candidates WITHOUT locking (CANDIDATE SYNCHRONIZATION step)
        sync_and_lock_candidates(self.election.pk, lock_on_chain=False, actor_user=self.election_admin)
        self.election.refresh_from_db()
        self.assertFalse(self.election.candidates_locked_on_chain)
        for c in self.election.candidates.filter(is_active=True):
            self.assertTrue(c.is_synced_on_chain)

        # 4. Activation must still fail because roster is not locked yet
        with self.assertRaises(ElectionLifecycleError):
            activate_election(self.election.pk, actor_user=self.election_admin)

        # 5. Add another candidate while still in SCHEDULED & unlocked state
        cand_4 = add_election_candidate(
            self.election.pk, 4, 'Meera Deshmukh', 'Lantern', sync_on_chain=True, actor_user=self.election_admin
        )
        self.assertTrue(cand_4.is_synced_on_chain)

        # 6. Lock candidate roster (CANDIDATE LOCK step)
        sync_and_lock_candidates(self.election.pk, lock_on_chain=True, actor_user=self.election_admin)
        self.election.refresh_from_db()
        self.assertTrue(self.election.candidates_locked_on_chain)

        # 7. Verify candidate locking is irreversible
        with self.assertRaises(ElectionLifecycleError):
            sync_and_lock_candidates(self.election.pk, lock_on_chain=True, actor_user=self.election_admin)

        # 8. Activate election (ACTIVE step) -> succeeds and locks voting window
        activate_election(self.election.pk, actor_user=self.election_admin)
        self.election.refresh_from_db()
        self.assertEqual(self.election.status, 'ACTIVE')
        self.assertTrue(self.election.voting_window_locked_on_chain)

        # Verify audit logs for CANDIDATES_SYNCED and CANDIDATES_SYNCED_AND_LOCKED
        actions = set(
            AdminAuditLog.objects.filter(target_model='Election', target_id=str(self.election.pk))
            .values_list('action', flat=True)
        )
        self.assertIn('CANDIDATES_SYNCED', actions)
        self.assertIn('CANDIDATES_SYNCED_AND_LOCKED', actions)

    def test_candidate_synchronization_parity_and_failure_safety(self):
        """
        Verify candidate synchronization integrity:
        - Deactivated candidates before locking are excluded from on-chain synchronization.
        - Failed on-chain transaction does not mark candidate as synchronized.
        - Parity verification detects missing on-chain candidates, unexpected extra on-chain candidates,
          and name/symbol mismatches.
        """
        w3 = get_web3_provider()
        if not w3.is_connected():
            self.skipTest("Hardhat node not running")

        # Deactivate candidate #3 while in DRAFT before deployment
        deactivate_election_candidate(self.election.pk, 3, actor_user=self.election_admin)

        # Deploy contract (leaves candidates 1 and 2 unsynced on-chain)
        contract_addr = deploy_election_contract(self.election.pk, actor_user=self.election_admin)
        self.election.refresh_from_db()
        abi, _, _ = load_contract_artifact()
        contract = w3.eth.contract(address=Web3.to_checksum_address(contract_addr), abi=abi)

        # Parity check must fail before synchronization because DB candidates 1 & 2 are missing on-chain
        with self.assertRaises(ElectionLifecycleError):
            verify_election_candidate_parity(self.election, w3=w3, contract=contract)

        # Simulate a failed on-chain transaction (status == 0) when adding candidate #5
        mock_receipt = MagicMock()
        mock_receipt.status = 0
        mock_contract = MagicMock()
        mock_contract.functions.candidatesLocked.return_value.call.return_value = False
        mock_contract.functions.candidates.return_value.call.return_value = [0, '', '', 0, False]
        mock_contract.functions.addCandidate.return_value.transact.return_value = b'\x11' * 32

        with patch.object(w3.eth, 'contract', return_value=mock_contract), \
             patch.object(w3.eth, 'wait_for_transaction_receipt', return_value=mock_receipt), \
             patch('EVotingApp.services.get_web3_provider', return_value=w3):
            with self.assertRaises(BlockchainDeploymentError):
                add_election_candidate(
                    self.election.pk,
                    5,
                    'Failed Tx Candidate',
                    'Broken',
                    sync_on_chain=True,
                    actor_user=self.election_admin,
                )

        cand_5 = Candidate.objects.get(election=self.election, candidate_id_num=5)
        self.assertFalse(cand_5.is_synced_on_chain)
        # Deactivate cand_5 so we can test clean sync of active candidates 1 & 2
        deactivate_election_candidate(self.election.pk, 5, actor_user=self.election_admin)

        # Sync active candidates (only 1 and 2 should be registered on-chain; deactivated 3 and 5 excluded)
        sync_and_lock_candidates(self.election.pk, lock_on_chain=False, actor_user=self.election_admin)
        self.assertEqual(contract.functions.getCandidateIds().call(), [1, 2])
        self.assertFalse(contract.functions.candidates(3).call()[4])
        self.assertFalse(contract.functions.candidates(5).call()[4])

        # Parity check succeeds for [1, 2]
        parity = verify_election_candidate_parity(self.election, w3=w3, contract=contract)
        self.assertEqual(parity['candidate_ids'], [1, 2])

        # Inject an unexpected candidate #99 directly on-chain bypassing Django DB
        deployer = w3.eth.accounts[0]
        tx = contract.functions.addCandidate(99, 'Rogue OnChain Candidate', 'Rogue').transact({'from': deployer})
        w3.eth.wait_for_transaction_receipt(tx)

        # Parity check must now reject the unexpected on-chain candidate ID #99
        with self.assertRaises(ElectionLifecycleError) as ctx:
            verify_election_candidate_parity(self.election, w3=w3, contract=contract)
        self.assertIn('99', str(ctx.exception))

    def test_onchain_candidate_sync_immutability_and_roster_locking(self):
        """
        Verify end-to-end on-chain candidate synchronization and locking via API:
        1. Deploy contract with lock_roster=False in SCHEDULED state, then sync initial roster.
        2. Add Candidate #4 via API and verify it is immediately written to EVoting.sol on-chain.
        3. Verify on-chain candidates cannot have their on-chain (name, symbol) mutated or deactivated,
           while off-chain description/display_order remain editable before lock.
        4. Lock roster via /api/control/elections/<id>/candidates/lock/ and verify all further mutations fail.
        """
        w3 = get_web3_provider()
        if not w3.is_connected():
            self.skipTest("Hardhat node not running")

        self.client.login(username='cand_admin', password='password123')

        # 1. Deploy with lock_roster=False
        deploy_res = self.client.post(
            f'/api/control/elections/{self.election.election_id}/deploy/',
            data=json.dumps({'force': True, 'lock_roster': False}),
            content_type='application/json',
        )
        self.assertEqual(deploy_res.status_code, 200)
        deploy_data = deploy_res.json()
        self.assertFalse(deploy_data['candidates_locked_on_chain'])
        contract_addr = deploy_data['contract_address']

        # Sync existing candidates 1..3 without locking
        sync_res = self.client.post(
            f'/api/control/elections/{self.election.election_id}/candidates/lock/',
            data=json.dumps({'lock': False}),
            content_type='application/json',
        )
        self.assertEqual(sync_res.status_code, 200)
        self.assertFalse(sync_res.json()['candidates_locked_on_chain'])

        # 2. Add Candidate #4 via Control API while roster is unlocked in SCHEDULED state
        add_res = self.client.post(
            f'/api/control/elections/{self.election.election_id}/candidates/',
            data=json.dumps({
                'candidate_id': 4,
                'name': 'Priyanka Sharma',
                'symbol': 'Independent Torch',
                'description': 'Independent Candidate',
                'display_order': 4,
            }),
            content_type='application/json',
        )
        self.assertEqual(add_res.status_code, 201, add_res.content)
        cand_payload = add_res.json()['candidate']
        self.assertTrue(cand_payload['is_synced_on_chain'])

        # Verify Candidate #4 exists directly on the deployed smart contract
        abi, _, _ = load_contract_artifact()
        contract = w3.eth.contract(address=Web3.to_checksum_address(contract_addr), abi=abi)
        onchain_c4 = contract.functions.candidates(4).call()
        self.assertTrue(onchain_c4[4])  # exists == True
        self.assertEqual(onchain_c4[1], 'Priyanka Sharma')
        self.assertEqual(onchain_c4[2], 'Independent Torch')

        # 3. Attempting to alter on-chain name or deactivate an already-synced on-chain candidate is blocked
        bad_update_res = self.client.post(
            f'/api/control/elections/{self.election.election_id}/candidates/4/update/',
            data=json.dumps({'name': 'Tampered On-Chain Name'}),
            content_type='application/json',
        )
        self.assertEqual(bad_update_res.status_code, 400)

        bad_deact_res = self.client.post(
            f'/api/control/elections/{self.election.election_id}/candidates/4/deactivate/',
            data=json.dumps({}),
            content_type='application/json',
        )
        self.assertEqual(bad_deact_res.status_code, 400)

        # Updating off-chain description & display_order before roster lock succeeds
        ok_update_res = self.client.post(
            f'/api/control/elections/{self.election.election_id}/candidates/4/update/',
            data=json.dumps({'description': 'Verified Civic Platform', 'display_order': 2}),
            content_type='application/json',
        )
        self.assertEqual(ok_update_res.status_code, 200)
        self.assertEqual(ok_update_res.json()['candidate']['display_order'], 2)

        # 4. Lock candidate roster on-chain via API
        lock_res = self.client.post(
            f'/api/control/elections/{self.election.election_id}/candidates/lock/',
            data=json.dumps({'lock': True}),
            content_type='application/json',
        )
        self.assertEqual(lock_res.status_code, 200)
        self.assertTrue(lock_res.json()['candidates_locked_on_chain'])
        self.assertTrue(contract.functions.candidatesLocked().call())

        # 5. Verify any candidate addition or update after roster lock is rejected with 400
        post_lock_add = self.client.post(
            f'/api/control/elections/{self.election.election_id}/candidates/',
            data=json.dumps({'candidate_id': 5, 'name': 'Late Candidate', 'symbol': 'Clock'}),
            content_type='application/json',
        )
        self.assertEqual(post_lock_add.status_code, 400)

        post_lock_upd = self.client.post(
            f'/api/control/elections/{self.election.election_id}/candidates/4/update/',
            data=json.dumps({'description': 'Cannot edit after lock'}),
            content_type='application/json',
        )
        self.assertEqual(post_lock_upd.status_code, 400)

    def test_ballot_visibility_and_election_candidate_isolation(self):
        """
        Verify that ballots display and permit voting ONLY for active, synchronized candidates
        from a locked roster belonging to the selected ACTIVE election.
        """
        w3 = get_web3_provider()
        if not w3.is_connected():
            self.skipTest("Hardhat node not running")

        # Deactivate candidate #3 before deployment
        deactivate_election_candidate(self.election.pk, 3, actor_user=self.election_admin)

        # Deploy, sync & lock candidates [1, 2], and activate self.election (4040)
        deploy_election_contract(self.election.pk, actor_user=self.election_admin)
        sync_and_lock_candidates(self.election.pk, lock_on_chain=True, actor_user=self.election_admin)
        activate_election(self.election.pk, actor_user=self.election_admin)

        # Create a second election (4099) with candidate #77 ('Other Election Candidate')
        other_election = Election.objects.create(
            title='Other District Election',
            election_type='GENERAL',
            election_id=4099,
            status='DRAFT',
            deployment_status='NOT_DEPLOYED',
        )
        add_election_candidate(
            other_election.pk, 77, 'Other District Nominee', 'Star', actor_user=self.election_admin
        )

        # Render voter ballot for election 4040
        vote_res = self.client.get(f'/vote/?election_id={self.election.election_id}')
        self.assertEqual(vote_res.status_code, 200)
        html = vote_res.content.decode('utf-8')
        self.assertIn('Rahul Gandhi', html)
        self.assertIn('Narendar Modi', html)
        self.assertNotIn('Akhilesh Yadav', html)  # Deactivated before lock
        self.assertNotIn('Other District Nominee', html)  # Belongs to election 4099

        # Verify /api/ballot/permit/ rejects deactivated candidate #3 and other election's candidate #77
        voter = Voter.objects.create(
            name='Verified Ballot Voter',
            aadhar_number='404011223344',
            bound_wallet='0x70997970C51812dc3A010C7d01b50e0d17dc79C8',
            has_voted=False,
        )
        VoterEligibility.objects.create(election=self.election, voter=voter, is_eligible=True, has_voted=False)

        session = self.client.session
        session['authenticated_wallet'] = '0x70997970C51812dc3A010C7d01b50e0d17dc79C8'
        session.save()

        # Attempt permit for deactivated candidate #3 -> 400
        res_deactivated = self.client.post(
            '/api/ballot/permit/',
            data=json.dumps({
                'election_id': self.election.election_id,
                'candidate_id': 3,
                'aadhar': '404011223344',
            }),
            content_type='application/json',
        )
        self.assertEqual(res_deactivated.status_code, 400)

        # Attempt permit for other election's candidate #77 -> 400
        res_other = self.client.post(
            '/api/ballot/permit/',
            data=json.dumps({
                'election_id': self.election.election_id,
                'candidate_id': 77,
                'aadhar': '404011223344',
            }),
            content_type='application/json',
        )
        self.assertEqual(res_other.status_code, 400)

        # Attempt permit for valid active synchronized candidate #1 -> 200
        res_valid = self.client.post(
            '/api/ballot/permit/',
            data=json.dumps({
                'election_id': self.election.election_id,
                'candidate_id': 1,
                'aadhar': '404011223344',
            }),
            content_type='application/json',
        )
        self.assertEqual(res_valid.status_code, 200)
        self.assertTrue(res_valid.json()['success'])

    def test_auditor_can_view_candidates_but_cannot_modify(self):
        """Verify Auditor has read access to GET /candidates/ but is blocked with 403 on all mutations."""
        self.client.login(username='cand_auditor', password='password123')

        get_res = self.client.get(f'/api/control/elections/{self.election.election_id}/candidates/')
        self.assertEqual(get_res.status_code, 200)
        self.assertEqual(len(get_res.json()['candidates']), 3)

        post_res = self.client.post(
            f'/api/control/elections/{self.election.election_id}/candidates/',
            data=json.dumps({'candidate_id': 5, 'name': 'Unauthorized', 'symbol': 'None'}),
            content_type='application/json',
        )
        self.assertEqual(post_res.status_code, 403)

