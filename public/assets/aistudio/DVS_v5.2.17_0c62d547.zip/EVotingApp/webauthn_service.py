"""
Module 6 — WebAuthn / Passkey Cryptographic & Ceremony Service.
Implements W3C WebAuthn Level 3 registration, assertion verification,
session-bound atomic challenge consumption, opaque userHandle cross-checking,
4-case authenticator counter evaluation, and step-up credential management.
"""

import json
import hmac
import secrets
from datetime import timedelta
from django.conf import settings
from django.db import transaction
from django.utils import timezone

import webauthn
from webauthn import (
    generate_registration_options,
    verify_registration_response,
    generate_authentication_options,
    verify_authentication_response,
    options_to_json,
    base64url_to_bytes,
)
from webauthn.helpers import (
    bytes_to_base64url,
    parse_authenticator_data,
    parse_client_data_json,
    parse_registration_credential_json,
    parse_authentication_credential_json,
)
from webauthn.helpers.structs import (
    AuthenticatorSelectionCriteria,
    ResidentKeyRequirement,
    UserVerificationRequirement,
    PublicKeyCredentialDescriptor,
    AuthenticatorTransport,
)

from .models import (
    Voter,
    WebAuthnCredential,
    WebAuthnChallenge,
    AdminAuditLog,
)


class WebAuthnError(Exception):
    """Base exception for WebAuthn ceremony or policy errors."""


class WebAuthnChallengeError(WebAuthnError):
    """Raised when a challenge is missing, expired, replayed, or session-mismatched."""


class WebAuthnOriginError(WebAuthnError):
    """Raised when Host header, Origin, or RP ID validation fails."""


class WebAuthnAuthenticationError(WebAuthnError):
    """Raised when assertion verification, userHandle cross-check, or counter check fails."""


class WebAuthnStepUpRequiredError(WebAuthnError):
    """Raised when fresh step-up authentication is required before credential mutation."""


class WebAuthnManagementError(WebAuthnError):
    """Raised for credential ownership or last-credential revocation guard violations."""


def validate_host_header(host_header: str) -> str:
    """
    Validate incoming HTTP Host header against explicit settings.WEBAUTHN_ALLOWED_HOSTS.
    Rejects unexpected or poisoned Host headers.
    """
    if not host_header:
        raise WebAuthnOriginError("Missing HTTP Host header.")
    hostname = host_header.split(':')[0].strip().lower()
    allowed_hosts = getattr(settings, 'WEBAUTHN_ALLOWED_HOSTS', ['localhost', '127.0.0.1', 'testserver'])
    rp_id = getattr(settings, 'WEBAUTHN_RP_ID', 'localhost').strip().lower()
    if hostname not in allowed_hosts and hostname != rp_id:
        raise WebAuthnOriginError(f"Untrusted Host header '{hostname}'.")
    return hostname


def consume_webauthn_challenge(
    challenge_b64url: str,
    expected_type: str,
    session_key: str,
    expected_voter_id: int = None
) -> WebAuthnChallenge:
    """
    Atomically consumes an unused, unexpired WebAuthn challenge bound to the session (and voter if specified).
    Uses a single conditional UPDATE statement so concurrent requests cannot reuse the same challenge
    on either SQLite or PostgreSQL.
    """
    if not challenge_b64url or not session_key:
        raise WebAuthnChallengeError("Missing challenge or session binding.")

    now = timezone.now()
    filters = {
        'challenge': challenge_b64url,
        'challenge_type': expected_type,
        'session_key': session_key,
        'is_used': False,
        'expires_at__gt': now,
    }
    if expected_voter_id is not None:
        filters['voter_id'] = expected_voter_id

    with transaction.atomic():
        rows_updated = WebAuthnChallenge.objects.filter(**filters).update(
            is_used=True,
            consumed_at=now,
        )
        if rows_updated != 1:
            raise WebAuthnChallengeError(
                "WebAuthn challenge is invalid, expired, session-mismatched, or already consumed."
            )
        return WebAuthnChallenge.objects.get(challenge=challenge_b64url)


def is_step_up_fresh(session_dict: dict) -> bool:
    """
    Check whether the voter session has completed fresh step-up authentication
    (via EIP-191 wallet verification or UV-verified passkey assertion) within WEBAUTHN_STEP_UP_TTL_SECONDS.
    """
    ttl = int(getattr(settings, 'WEBAUTHN_STEP_UP_TTL_SECONDS', 300))
    step_up_ts = session_dict.get('step_up_authenticated_at')
    if not step_up_ts:
        return False
    try:
        elapsed = timezone.now().timestamp() - float(step_up_ts)
        return 0 <= elapsed <= ttl
    except (TypeError, ValueError):
        return False


def _parse_transports_list(transports_str: str):
    if not transports_str:
        return None
    mapping = {
        'internal': AuthenticatorTransport.INTERNAL,
        'usb': AuthenticatorTransport.USB,
        'nfc': AuthenticatorTransport.NFC,
        'ble': AuthenticatorTransport.BLE,
        'hybrid': AuthenticatorTransport.HYBRID,
    }
    result = []
    for item in transports_str.split(','):
        key = item.strip().lower()
        if key in mapping:
            result.append(mapping[key])
    return result or None


def generate_passkey_registration_options(
    voter: Voter,
    session_key: str,
    step_up_verified: bool = False,
    host_header: str = 'localhost',
) -> dict:
    """
    Generate W3C WebAuthn PublicKeyCredentialCreationOptions for an authenticated voter.
    - Enforces active voter status.
    - Requires fresh step-up authentication if voter already has an active passkey.
    - Encodes only the opaque 32-byte voter.webauthn_user_handle into user.id.
    - Binds challenge to voter and session_key.
    """
    validate_host_header(host_header)

    if not voter or voter.status != 'ACTIVE':
        raise WebAuthnError("Voter account is not active.")
    if not session_key:
        raise WebAuthnChallengeError("Active session required for passkey registration.")

    existing_active = list(voter.passkeys.filter(is_active=True))
    if existing_active and not step_up_verified:
        raise WebAuthnStepUpRequiredError(
            "Fresh step-up authentication is required before enrolling an additional passkey."
        )

    exclude_credentials = [
        PublicKeyCredentialDescriptor(
            id=base64url_to_bytes(cred.credential_id),
            transports=_parse_transports_list(cred.transports),
        )
        for cred in existing_active
    ]

    rp_id = getattr(settings, 'WEBAUTHN_RP_ID', 'localhost')
    rp_name = getattr(settings, 'WEBAUTHN_RP_NAME', 'Decentralized Voting System (DVS)')
    user_handle_bytes = bytes.fromhex(voter.webauthn_user_handle)
    challenge_bytes = secrets.token_bytes(32)

    options = generate_registration_options(
        rp_id=rp_id,
        rp_name=rp_name,
        user_id=user_handle_bytes,
        user_name=f"voter-{voter.webauthn_user_handle[:8]}",
        user_display_name=voter.name,
        challenge=challenge_bytes,
        authenticator_selection=AuthenticatorSelectionCriteria(
            resident_key=ResidentKeyRequirement.PREFERRED,
            user_verification=UserVerificationRequirement.PREFERRED,
        ),
        exclude_credentials=exclude_credentials,
    )

    challenge_b64url = bytes_to_base64url(options.challenge)
    expiry_seconds = int(getattr(settings, 'CHALLENGE_EXPIRY_SECONDS', 300))
    WebAuthnChallenge.objects.create(
        challenge=challenge_b64url,
        challenge_type='REGISTRATION',
        voter=voter,
        session_key=session_key,
        user_verification_req='preferred',
        expires_at=timezone.now() + timedelta(seconds=expiry_seconds),
    )

    return json.loads(options_to_json(options))


def verify_passkey_registration(
    voter: Voter,
    session_key: str,
    credential_payload: dict,
    device_label: str = 'Personal Authenticator',
    step_up_verified: bool = False,
    host_header: str = 'localhost',
    ip_address: str = None,
) -> WebAuthnCredential:
    """
    Verify WebAuthn registration attestation and persist WebAuthnCredential.
    - Never accepts voter_id from client payload; uses session-authenticated voter.
    - Consumes registration challenge atomically before accepting ceremony result.
    - Enforces explicit WEBAUTHN_RP_ID and WEBAUTHN_ALLOWED_ORIGINS.
    """
    validate_host_header(host_header)

    if not voter or voter.status != 'ACTIVE':
        raise WebAuthnError("Voter account is not active.")
    if not isinstance(credential_payload, dict):
        raise WebAuthnError("Invalid credential payload format.")

    existing_active_count = voter.passkeys.filter(is_active=True).count()
    if existing_active_count > 0 and not step_up_verified:
        raise WebAuthnStepUpRequiredError(
            "Fresh step-up authentication is required before enrolling an additional passkey."
        )

    try:
        reg_cred = parse_registration_credential_json(credential_payload)
        client_data = parse_client_data_json(reg_cred.response.client_data_json)
        challenge_b64url = bytes_to_base64url(client_data.challenge)
    except Exception:
        raise WebAuthnError("Malformed WebAuthn registration payload.")

    # 1. Atomically consume session-bound and voter-bound challenge FIRST
    consumed_challenge = consume_webauthn_challenge(
        challenge_b64url=challenge_b64url,
        expected_type='REGISTRATION',
        session_key=session_key,
        expected_voter_id=voter.pk,
    )

    expected_rp_id = getattr(settings, 'WEBAUTHN_RP_ID', 'localhost')
    allowed_origins = getattr(
        settings,
        'WEBAUTHN_ALLOWED_ORIGINS',
        ['http://localhost:3000', 'http://127.0.0.1:3000']
    )

    if client_data.origin not in allowed_origins:
        raise WebAuthnOriginError("Untrusted WebAuthn origin.")

    # 2. Cryptographically verify registration response
    try:
        verified = verify_registration_response(
            credential=credential_payload,
            expected_challenge=base64url_to_bytes(consumed_challenge.challenge),
            expected_rp_id=expected_rp_id,
            expected_origin=allowed_origins,
            require_user_presence=True,
            require_user_verification=False,
        )
    except Exception:
        raise WebAuthnError("WebAuthn registration verification failed.")

    cred_id_b64 = bytes_to_base64url(verified.credential_id)
    if WebAuthnCredential.objects.filter(credential_id=cred_id_b64).exists():
        raise WebAuthnManagementError("Credential ID is already registered.")

    raw_transports = credential_payload.get('response', {}).get('transports') or []
    if isinstance(raw_transports, list):
        transports_str = ','.join(str(t).strip().lower() for t in raw_transports if t)
    else:
        transports_str = ''

    clean_label = str(device_label or 'Personal Authenticator').strip()[:100] or 'Personal Authenticator'

    with transaction.atomic():
        cred = WebAuthnCredential.objects.create(
            voter=voter,
            credential_id=cred_id_b64,
            public_key_cose_hex=verified.credential_public_key.hex(),
            sign_count=int(verified.sign_count or 0),
            registered_with_uv=bool(verified.user_verified),
            transports=transports_str,
            aaguid=str(verified.aaguid or '')[:36],
            device_label=clean_label,
            is_active=True,
            created_ip=ip_address,
        )
        AdminAuditLog.objects.create(
            actor=None,
            action='PASSKEY_REGISTERED',
            target_model='WebAuthnCredential',
            target_id=str(cred.pk),
            details=json.dumps({
                'voter_id': voter.pk,
                'device_label': clean_label,
                'registered_with_uv': bool(verified.user_verified),
                'sign_count': int(verified.sign_count or 0),
            }),
            ip_address=ip_address,
        )

    return cred


def generate_passkey_authentication_options(
    session_key: str,
    voter: Voter = None,
    require_uv: bool = False,
    challenge_type: str = 'AUTHENTICATION',
    host_header: str = 'localhost',
) -> dict:
    """
    Generate W3C WebAuthn PublicKeyCredentialRequestOptions.
    - Prevents user/credential enumeration: if voter is None, inactive, or has no active passkeys,
      still generates a valid cryptographic challenge and returns 200 OK options.
    - Forces UV=required whenever challenge_type == 'STEP_UP'.
    """
    validate_host_header(host_header)

    if not session_key:
        raise WebAuthnChallengeError("Session key required for authentication challenge.")

    effective_require_uv = bool(require_uv or (challenge_type == 'STEP_UP'))

    allow_credentials = []
    if voter and voter.status == 'ACTIVE':
        active_creds = list(voter.passkeys.filter(is_active=True))
        allow_credentials = [
            PublicKeyCredentialDescriptor(
                id=base64url_to_bytes(c.credential_id),
                transports=_parse_transports_list(c.transports),
            )
            for c in active_creds
        ]

    rp_id = getattr(settings, 'WEBAUTHN_RP_ID', 'localhost')
    uv_req = (
        UserVerificationRequirement.REQUIRED
        if effective_require_uv
        else UserVerificationRequirement.PREFERRED
    )
    challenge_bytes = secrets.token_bytes(32)

    options = generate_authentication_options(
        rp_id=rp_id,
        challenge=challenge_bytes,
        allow_credentials=allow_credentials if allow_credentials else None,
        user_verification=uv_req,
    )

    challenge_b64url = bytes_to_base64url(options.challenge)
    expiry_seconds = int(getattr(settings, 'CHALLENGE_EXPIRY_SECONDS', 300))
    WebAuthnChallenge.objects.create(
        challenge=challenge_b64url,
        challenge_type=challenge_type,
        voter=voter if (voter and voter.status == 'ACTIVE') else None,
        session_key=session_key,
        user_verification_req='required' if effective_require_uv else 'preferred',
        expires_at=timezone.now() + timedelta(seconds=expiry_seconds),
    )

    return json.loads(options_to_json(options))


def verify_passkey_authentication(
    session_key: str,
    credential_payload: dict,
    challenge_type: str = 'AUTHENTICATION',
    require_uv: bool = False,
    host_header: str = 'localhost',
    ip_address: str = None,
) -> tuple:
    """
    Verify WebAuthn assertion and resolve voter identity safely:
    1. Validate Host header and consume session-bound challenge atomically.
    2. Lookup registered WebAuthnCredential by credential_id.
    3. Resolve Voter strictly from server-side credential.voter relationship.
    4. Verify cryptographic signature, origin, RP ID, UP=1, and UV requirement from current ceremony flags.
    5. Apply the approved 4-case counter evaluation matrix (suspending credential on Case D2 regression).
    6. Cross-check optional client userHandle against voter.webauthn_user_handle.
    """
    validate_host_header(host_header)

    if not isinstance(credential_payload, dict):
        raise WebAuthnAuthenticationError("Invalid assertion payload format.")

    try:
        auth_cred = parse_authentication_credential_json(credential_payload)
        client_data = parse_client_data_json(auth_cred.response.client_data_json)
        auth_data = parse_authenticator_data(auth_cred.response.authenticator_data)
        challenge_b64url = bytes_to_base64url(client_data.challenge)
        cred_id_b64 = auth_cred.id
    except Exception:
        raise WebAuthnAuthenticationError("Malformed WebAuthn assertion payload.")

    # 1. Atomically consume challenge FIRST
    consumed_challenge = consume_webauthn_challenge(
        challenge_b64url=challenge_b64url,
        expected_type=challenge_type,
        session_key=session_key,
    )

    expected_rp_id = getattr(settings, 'WEBAUTHN_RP_ID', 'localhost')
    allowed_origins = getattr(
        settings,
        'WEBAUTHN_ALLOWED_ORIGINS',
        ['http://localhost:3000', 'http://127.0.0.1:3000']
    )
    if client_data.origin not in allowed_origins:
        raise WebAuthnOriginError("Untrusted WebAuthn origin.")

    # 2. Lookup registered WebAuthnCredential by credential ID
    cred_obj = (
        WebAuthnCredential.objects.select_related('voter')
        .filter(credential_id=cred_id_b64, is_active=True)
        .first()
    )
    if not cred_obj:
        raise WebAuthnAuthenticationError("Unknown or revoked passkey credential.")

    # 3. Resolve Voter strictly from trusted server-side credential relationship
    voter = cred_obj.voter
    if voter.status != 'ACTIVE':
        raise WebAuthnAuthenticationError("Associated voter account is not active.")

    if consumed_challenge.voter_id and consumed_challenge.voter_id != voter.pk:
        raise WebAuthnAuthenticationError("Credential does not belong to challenge voter.")

    effective_require_uv = bool(
        require_uv
        or (consumed_challenge.user_verification_req == 'required')
        or (challenge_type == 'STEP_UP')
    )

    # 4. Verify signature, RP ID, origin, UP=1, and UV requirement from current ceremony flags
    if not bool(auth_data.flags.up):
        raise WebAuthnAuthenticationError("Authenticator did not assert User Presence (UP=1).")

    ceremony_uv_flag = bool(auth_data.flags.uv)
    if effective_require_uv and not ceremony_uv_flag:
        raise WebAuthnAuthenticationError("User Verification (UV=1) is required for this ceremony.")

    # Pass credential_current_sign_count=0 so our 4-case counter evaluation handles counter semantics
    try:
        verified = verify_authentication_response(
            credential=credential_payload,
            expected_challenge=base64url_to_bytes(consumed_challenge.challenge),
            expected_rp_id=expected_rp_id,
            expected_origin=allowed_origins,
            credential_public_key=bytes.fromhex(cred_obj.public_key_cose_hex),
            credential_current_sign_count=0,
            require_user_verification=effective_require_uv,
        )
    except Exception:
        raise WebAuthnAuthenticationError("Assertion cryptographic verification failed.")

    ceremony_uv = bool(ceremony_uv_flag and verified.user_verified)

    # 5. Cross-check optional userHandle against voter.webauthn_user_handle
    raw_user_handle = credential_payload.get('response', {}).get('userHandle')
    if raw_user_handle:
        try:
            incoming_handle_hex = base64url_to_bytes(raw_user_handle).hex()
        except Exception:
            incoming_handle_hex = ''
        if not hmac.compare_digest(incoming_handle_hex.lower(), voter.webauthn_user_handle.lower()):
            AdminAuditLog.objects.create(
                actor=None,
                action='AUTHENTICATOR_USERHANDLE_MISMATCH',
                target_model='WebAuthnCredential',
                target_id=str(cred_obj.pk),
                details=json.dumps({'voter_id': voter.pk}),
                ip_address=ip_address,
            )
            raise WebAuthnAuthenticationError("Assertion userHandle mismatch.")

    # 6. Evaluate the 4-case Authenticator Counter Matrix
    stored_count = int(cred_obj.sign_count or 0)
    incoming_count = int(auth_data.sign_count or 0)

    if stored_count == 0 and incoming_count == 0:
        # Case A: Both zero (platform authenticator without counter support)
        new_stored_count = 0
    elif stored_count == 0 and incoming_count > 0:
        # Case B: First nonzero counter
        new_stored_count = incoming_count
    elif stored_count > 0 and incoming_count == 0:
        # Case C: Stored nonzero, incoming zero (OS reset/proxy). Accept, keep stored_count, log notice.
        new_stored_count = stored_count
        AdminAuditLog.objects.create(
            actor=None,
            action='PASSKEY_COUNTER_ZERO_NOTICE',
            target_model='WebAuthnCredential',
            target_id=str(cred_obj.pk),
            details=json.dumps({
                'voter_id': voter.pk,
                'stored_count': stored_count,
                'incoming_count': incoming_count,
            }),
            ip_address=ip_address,
        )
    elif stored_count > 0 and incoming_count > stored_count:
        # Case D1: Standard monotonic increment
        new_stored_count = incoming_count
    else:
        # Case D2: Both nonzero and incoming_count <= stored_count -> Counter Regression Anomaly!
        # Immediately suspend compromised credential (is_active=False) and record audit log.
        now_ts = timezone.now()
        cred_obj.is_active = False
        cred_obj.revoked_at = now_ts
        cred_obj.clone_warning_flag = True
        cred_obj.anomaly_count = int(cred_obj.anomaly_count or 0) + 1
        cred_obj.save(update_fields=['is_active', 'revoked_at', 'clone_warning_flag', 'anomaly_count'])
        AdminAuditLog.objects.create(
            actor=None,
            action='AUTHENTICATOR_COUNTER_ANOMALY',
            target_model='WebAuthnCredential',
            target_id=str(cred_obj.pk),
            details=json.dumps({
                'voter_id': voter.pk,
                'stored_count': stored_count,
                'incoming_count': incoming_count,
                'anomaly_count': cred_obj.anomaly_count,
                'credential_suspended': True,
            }),
            ip_address=ip_address,
        )
        raise WebAuthnAuthenticationError(
            "Authenticator signature counter regression detected; credential suspended."
        )

    cred_obj.sign_count = new_stored_count
    cred_obj.last_used_at = timezone.now()
    cred_obj.save(update_fields=['sign_count', 'last_used_at'])

    AdminAuditLog.objects.create(
        actor=None,
        action='PASSKEY_AUTHENTICATED',
        target_model='WebAuthnCredential',
        target_id=str(cred_obj.pk),
        details=json.dumps({
            'voter_id': voter.pk,
            'ceremony_uv': ceremony_uv,
            'sign_count': new_stored_count,
        }),
        ip_address=ip_address,
    )

    return voter, cred_obj, ceremony_uv


def list_voter_passkeys(voter: Voter) -> list:
    """Return metadata for a voter's registered passkeys without exposing public key material."""
    if not voter:
        return []
    records = []
    for cred in voter.passkeys.all().order_by('-created_at'):
        records.append({
            'id': cred.pk,
            'credential_id_masked': f"{cred.credential_id[:10]}...{cred.credential_id[-6:]}" if len(cred.credential_id) > 16 else cred.credential_id,
            'device_label': cred.device_label,
            'registered_with_uv': cred.registered_with_uv,
            'sign_count': cred.sign_count,
            'is_active': cred.is_active,
            'clone_warning_flag': cred.clone_warning_flag,
            'created_at': cred.created_at.isoformat() if cred.created_at else None,
            'last_used_at': cred.last_used_at.isoformat() if cred.last_used_at else None,
            'revoked_at': cred.revoked_at.isoformat() if cred.revoked_at else None,
        })
    return records


def revoke_voter_passkey(
    voter: Voter,
    credential_pk: int,
    step_up_verified: bool = False,
    confirm_disable_passkey: bool = False,
    ip_address: str = None,
) -> dict:
    """
    Voter self-service passkey revocation.
    - Requires fresh step-up authentication.
    - Enforces last-credential protection unless confirm_disable_passkey=True.
    - Preserves voter session and EIP-191 wallet fallback.
    """
    if not voter or voter.status != 'ACTIVE':
        raise WebAuthnManagementError("Active voter account required.")
    if not step_up_verified:
        raise WebAuthnStepUpRequiredError("Fresh step-up authentication required to revoke a passkey.")

    with transaction.atomic():
        cred = WebAuthnCredential.objects.filter(pk=credential_pk, voter=voter).first()
        if not cred:
            raise WebAuthnManagementError("Passkey credential not found for this voter.")
        if not cred.is_active:
            raise WebAuthnManagementError("Passkey is already revoked.")

        active_count = WebAuthnCredential.objects.filter(voter=voter, is_active=True).count()
        is_last = (active_count == 1)
        if is_last and not confirm_disable_passkey:
            raise WebAuthnManagementError(
                "Revoking your only active passkey requires explicit confirmation (confirm_disable_passkey=true)."
            )

        cred.is_active = False
        cred.revoked_at = timezone.now()
        cred.save(update_fields=['is_active', 'revoked_at'])

        AdminAuditLog.objects.create(
            actor=None,
            action='PASSKEY_REVOKED_BY_VOTER',
            target_model='WebAuthnCredential',
            target_id=str(cred.pk),
            details=json.dumps({
                'voter_id': voter.pk,
                'device_label': cred.device_label,
                'last_credential_revoked': is_last,
            }),
            ip_address=ip_address,
        )

    return {
        'credential_id': cred.pk,
        'status': 'revoked',
        'remaining_active_passkeys': active_count - 1,
        'auth_mode': 'WALLET_ONLY' if is_last else 'PASSKEY_AND_WALLET',
    }


def superadmin_suspend_voter_passkeys(
    voter_id: int,
    actor_user,
    reason: str,
    ip_address: str = None,
) -> dict:
    """
    Documented, audited Super Admin procedure to suspend account-wide passkeys.
    Election Administrators are strictly prohibited from calling this procedure.
    """
    if not actor_user or not actor_user.is_authenticated:
        raise WebAuthnManagementError("Authentication required.")
    is_super = actor_user.is_superuser or actor_user.groups.filter(name='Super Admin').exists()
    if not is_super:
        raise WebAuthnManagementError("Only a Super Admin may perform account-wide passkey suspension.")

    clean_reason = str(reason or '').strip()
    if not clean_reason:
        raise WebAuthnManagementError("A documented security justification reason is required.")

    voter = Voter.objects.filter(pk=voter_id).first()
    if not voter:
        raise WebAuthnManagementError("Voter not found.")

    now = timezone.now()
    with transaction.atomic():
        revoked_count = WebAuthnCredential.objects.filter(voter=voter, is_active=True).update(
            is_active=False,
            revoked_at=now,
        )
        voter.security_flagged = True
        voter.security_flag_reason = clean_reason[:255]
        voter.save(update_fields=['security_flagged', 'security_flag_reason'])

        AdminAuditLog.objects.create(
            actor=actor_user,
            action='SUPERADMIN_ACCOUNT_PASSKEY_SUSPENSION',
            target_model='Voter',
            target_id=str(voter.pk),
            details=json.dumps({
                'revoked_credentials': revoked_count,
                'reason': clean_reason[:200],
            }),
            ip_address=ip_address,
        )

    return {
        'voter_id': voter.pk,
        'revoked_credentials': revoked_count,
        'security_flagged': True,
    }


def archive_voter_account(
    voter_id: int,
    actor_user,
    reason: str,
    ip_address: str = None,
) -> dict:
    """
    Audited voter archival workflow.
    Marks Voter status='ARCHIVED' and revokes active passkeys while preserving
    all historical credentials, audit logs, and verification records.
    """
    voter = Voter.objects.filter(pk=voter_id).first()
    if not voter:
        raise WebAuthnManagementError("Voter not found.")

    now = timezone.now()
    with transaction.atomic():
        revoked_count = WebAuthnCredential.objects.filter(voter=voter, is_active=True).update(
            is_active=False,
            revoked_at=now,
        )
        voter.status = 'ARCHIVED'
        voter.save(update_fields=['status'])

        AdminAuditLog.objects.create(
            actor=actor_user,
            action='VOTER_ACCOUNT_ARCHIVED',
            target_model='Voter',
            target_id=str(voter.pk),
            details=json.dumps({
                'revoked_credentials': revoked_count,
                'reason': str(reason or '')[:200],
            }),
            ip_address=ip_address,
        )

    return {
        'voter_id': voter.pk,
        'status': voter.status,
        'revoked_credentials': revoked_count,
    }
