import secrets
from django.db import models
from django.conf import settings


class Voter(models.Model):
    STATUS_CHOICES = [
        ('ACTIVE', 'Active'),
        ('DEACTIVATED', 'Deactivated'),
        ('ARCHIVED', 'Archived'),
    ]
    name = models.CharField(max_length=100)
    aadhar_number = models.CharField(max_length=12, unique=True)
    phone = models.CharField(max_length=20, blank=True, default='')
    bound_wallet = models.CharField(max_length=42, blank=True, null=True, unique=True)
    webauthn_user_handle = models.CharField(max_length=64, unique=True, editable=False)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='ACTIVE')
    security_flagged = models.BooleanField(default=False)
    security_flag_reason = models.CharField(max_length=255, blank=True, default='')
    has_voted = models.BooleanField(default=False)
    voted_at = models.DateTimeField(blank=True, null=True)
    is_synthetic = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True, null=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.webauthn_user_handle:
            while True:
                candidate = secrets.token_bytes(32).hex()
                if not Voter.objects.filter(webauthn_user_handle=candidate).exists():
                    self.webauthn_user_handle = candidate
                    break
        if 'update_fields' in kwargs and kwargs['update_fields'] is not None:
            uf = set(kwargs['update_fields'])
            if 'webauthn_user_handle' in uf and self.pk:
                existing = Voter.objects.filter(pk=self.pk).values_list('webauthn_user_handle', flat=True).first()
                if existing and existing != self.webauthn_user_handle:
                    self.webauthn_user_handle = existing
        super().save(*args, **kwargs)

    def __str__(self):
        type_str = " [SYNTHETIC]" if self.is_synthetic else ""
        return f"{self.name} ({self.aadhar_number}){type_str}"


class AuthChallenge(models.Model):
    wallet_address = models.CharField(max_length=42)
    nonce = models.CharField(max_length=64, unique=True)
    domain = models.CharField(max_length=100)
    challenge_text = models.TextField(blank=True, default='')
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    is_used = models.BooleanField(default=False)

    def __str__(self):
        return f"Challenge for {self.wallet_address} ({self.nonce[:10]}...)"


class Election(models.Model):
    ELECTION_TYPE_CHOICES = [
        ('ELECTION', 'Election'),
        ('POLL', 'Poll'),
        ('REFERENDUM', 'Referendum'),
    ]
    STATUS_CHOICES = [
        ('DRAFT', 'Draft'),
        ('SCHEDULED', 'Scheduled'),
        ('ACTIVE', 'Active'),
        ('CLOSED', 'Closed'),
        ('FINALIZED', 'Finalized'),
    ]
    DEPLOYMENT_STATUS_CHOICES = [
        ('NOT_DEPLOYED', 'Not Deployed'),
        ('PENDING_DEPLOYMENT', 'Pending Deployment'),
        ('DEPLOYED', 'Deployed'),
        ('DEPLOYMENT_FAILED', 'Deployment Failed'),
        ('CHAIN_RESET_REDEPLOY_REQUIRED', 'Chain Reset — Redeployment Required'),
    ]
    RESULT_PUBLICATION_CHOICES = [
        ('HIDDEN_UNTIL_CLOSE', 'Hidden During Active Voting'),
        ('PROVISIONAL_AFTER_CLOSE', 'Provisional After Closure'),
        ('OFFICIAL_AFTER_FINALIZE', 'Official After Finalization'),
    ]

    COMMENCEMENT_MODE_CHOICES = [
        ('SCHEDULED', 'Scheduled Election'),
        ('IMMEDIATE', 'Immediate Election'),
    ]

    title = models.CharField(max_length=200)
    description = models.TextField(blank=True, default='')
    election_type = models.CharField(max_length=20, choices=ELECTION_TYPE_CHOICES, default='ELECTION')
    commencement_mode = models.CharField(max_length=20, choices=COMMENCEMENT_MODE_CHOICES, default='SCHEDULED')
    immediate_duration_hours = models.PositiveSmallIntegerField(blank=True, null=True)
    start_datetime = models.DateTimeField(blank=True, null=True)
    end_datetime = models.DateTimeField(blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='DRAFT')

    contract_address = models.CharField(max_length=42, blank=True, default='')
    legacy_contract_address = models.CharField(max_length=42, blank=True, default='')
    chain_id = models.BigIntegerField(default=31337)
    election_id = models.BigIntegerField(default=2026, unique=True)
    authority_address = models.CharField(max_length=42, blank=True, default='')
    deployment_tx_hash = models.CharField(max_length=66, blank=True, default='')
    deployment_block_number = models.BigIntegerField(blank=True, null=True)
    deployed_bytecode_hash = models.CharField(max_length=66, blank=True, default='')
    deployment_status = models.CharField(max_length=40, choices=DEPLOYMENT_STATUS_CHOICES, default='NOT_DEPLOYED')
    candidates_locked_on_chain = models.BooleanField(default=False)
    voting_window_locked_on_chain = models.BooleanField(default=False)

    result_publication_policy = models.CharField(
        max_length=30,
        choices=RESULT_PUBLICATION_CHOICES,
        default='HIDDEN_UNTIL_CLOSE'
    )
    results_published = models.BooleanField(default=False)
    results_verified = models.BooleanField(default=False)
    reconciled_at = models.DateTimeField(blank=True, null=True)
    finalized_at = models.DateTimeField(blank=True, null=True)

    auto_transition_in_progress = models.BooleanField(default=False)
    auto_transition_last_attempt_at = models.DateTimeField(blank=True, null=True)
    auto_transition_last_error = models.TextField(blank=True, default='')
    auto_transition_last_action = models.CharField(max_length=50, blank=True, default='')

    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='created_elections'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.title} (#{self.election_id} - {self.status})"


class ContractDeployment(models.Model):
    election = models.ForeignKey(Election, on_delete=models.CASCADE, related_name='deployments')
    contract_address = models.CharField(max_length=42)
    chain_id = models.BigIntegerField(default=31337)
    deployment_tx_hash = models.CharField(max_length=66, blank=True, default='')
    deployment_block_number = models.BigIntegerField(blank=True, null=True)
    deployed_bytecode_hash = models.CharField(max_length=66, blank=True, default='')
    authority_address = models.CharField(max_length=42, blank=True, default='')
    is_active_deployment = models.BooleanField(default=True)
    is_historical_legacy = models.BooleanField(default=False)
    superseded_at = models.DateTimeField(blank=True, null=True)
    deployed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-deployed_at', '-id']

    def __str__(self):
        state_label = 'ACTIVE' if self.is_active_deployment else 'HISTORICAL'
        return f"[{self.election.election_id}] {self.contract_address} ({state_label})"


class Candidate(models.Model):
    election = models.ForeignKey(Election, on_delete=models.CASCADE, related_name='candidates')
    candidate_id_num = models.IntegerField()
    name = models.CharField(max_length=150)
    symbol = models.CharField(max_length=100)
    symbol_image = models.ImageField(upload_to='candidate_symbols/%Y/%m/', blank=True, null=True)
    description = models.TextField(blank=True, default='')
    display_order = models.IntegerField(default=1)
    is_active = models.BooleanField(default=True)
    is_synced_on_chain = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['display_order', 'candidate_id_num']
        unique_together = ('election', 'candidate_id_num')

    def __str__(self):
        return f"[{self.election.election_id}] #{self.candidate_id_num} {self.name} ({self.symbol})"


class VoterEligibility(models.Model):
    voter = models.ForeignKey(Voter, on_delete=models.CASCADE, related_name='eligibilities')
    election = models.ForeignKey(Election, on_delete=models.CASCADE, related_name='voter_eligibilities')
    is_eligible = models.BooleanField(default=True)
    has_voted = models.BooleanField(default=False)
    voted_at = models.DateTimeField(blank=True, null=True)
    assigned_at = models.DateTimeField(auto_now_add=True)
    assigned_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='assigned_eligibilities'
    )

    class Meta:
        verbose_name_plural = 'Voter Eligibilities'
        unique_together = ('voter', 'election')

    def __str__(self):
        return f"{self.voter.name} -> {self.election.title} (Eligible: {self.is_eligible}, Voted: {self.has_voted})"


class ElectionAdminAssignment(models.Model):
    ROLE_CHOICES = [
        ('ELECTION_ADMIN', 'Election Administrator'),
        ('ELECTION_WORKER', 'Election Worker'),
        ('AUDITOR', 'Auditor'),
    ]
    election = models.ForeignKey(Election, on_delete=models.CASCADE, related_name='admin_assignments')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='election_assignments')
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='ELECTION_ADMIN')
    assigned_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('election', 'user')

    def __str__(self):
        return f"{self.user.username} - {self.role} on {self.election.title}"


class AdminAuditLog(models.Model):
    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='audit_logs'
    )
    action = models.CharField(max_length=100)
    target_model = models.CharField(max_length=100, blank=True, default='')
    target_id = models.CharField(max_length=100, blank=True, default='')
    details = models.TextField(blank=True, default='')
    ip_address = models.GenericIPAddressField(blank=True, null=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        actor_name = self.actor.username if self.actor else 'System'
        return f"[{self.timestamp}] {actor_name}: {self.action} ({self.target_model} #{self.target_id})"


class IssuedPermit(models.Model):
    permit_nonce = models.CharField(max_length=66, unique=True)
    voter = models.ForeignKey(Voter, on_delete=models.CASCADE, related_name='permits')
    election_ref = models.ForeignKey(
        Election,
        on_delete=models.CASCADE,
        related_name='permits',
        null=True,
        blank=True
    )
    deployment_ref = models.ForeignKey(
        ContractDeployment,
        on_delete=models.SET_NULL,
        related_name='permits',
        null=True,
        blank=True
    )
    candidate_id = models.IntegerField()
    election_id = models.BigIntegerField()
    voter_nullifier = models.CharField(max_length=66)
    deadline = models.BigIntegerField()
    contract_address = models.CharField(max_length=42, blank=True, default='')
    tx_hash = models.CharField(max_length=66, blank=True, default='')
    block_number = models.BigIntegerField(blank=True, null=True)
    is_consumed_on_chain = models.BooleanField(default=False)
    is_historical_legacy = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Permit {self.permit_nonce[:12]}... for Voter {self.voter_id} (Election {self.election_id})"


class BallotReceipt(models.Model):
    """Database record for a transaction confirmed by the election contract."""
    voter = models.ForeignKey(Voter, on_delete=models.PROTECT, related_name='ballot_receipts')
    election = models.ForeignKey(Election, on_delete=models.PROTECT, related_name='ballot_receipts')
    candidate_id = models.IntegerField()
    voter_hash = models.CharField(max_length=66)
    contract_address = models.CharField(max_length=42)
    tx_hash = models.CharField(max_length=66, unique=True)
    block_number = models.PositiveBigIntegerField()
    receipt_reference = models.CharField(max_length=100, unique=True)
    confirmed_at = models.DateTimeField()

    class Meta:
        ordering = ['-confirmed_at', '-id']

    def __str__(self):
        return f"{self.receipt_reference} — Election #{self.election.election_id}"


class WebAuthnCredential(models.Model):
    """
    Stores FIDO2 / WebAuthn public key credentials bound to verified Voter accounts.
    Uses models.PROTECT on voter deletion to prevent accidental destruction of credential history.
    Never collects, transmits, or stores biometric templates, fingerprint images, or device PINs.
    """
    voter = models.ForeignKey(
        'Voter',
        on_delete=models.PROTECT,
        related_name='passkeys'
    )
    credential_id = models.CharField(max_length=255, unique=True)
    public_key_cose_hex = models.TextField()
    sign_count = models.BigIntegerField(default=0)
    registered_with_uv = models.BooleanField(default=False)
    transports = models.CharField(max_length=200, blank=True, default='')
    aaguid = models.CharField(max_length=36, blank=True, default='')
    device_label = models.CharField(max_length=100, default='Personal Authenticator')
    is_active = models.BooleanField(default=True)
    clone_warning_flag = models.BooleanField(default=False)
    anomaly_count = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    last_used_at = models.DateTimeField(blank=True, null=True)
    revoked_at = models.DateTimeField(blank=True, null=True)
    created_ip = models.GenericIPAddressField(blank=True, null=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        state = 'ACTIVE' if self.is_active else 'REVOKED'
        return f"Passkey [{self.device_label}] for Voter #{self.voter_id} ({state})"


class WebAuthnChallenge(models.Model):
    """
    Cryptographically secure, session-bound, single-use challenges for WebAuthn ceremonies.
    Disposable ephemeral tokens (300s TTL) consumed atomically via conditional UPDATE.
    """
    CHALLENGE_TYPE_CHOICES = [
        ('REGISTRATION', 'Registration'),
        ('AUTHENTICATION', 'Authentication'),
        ('STEP_UP', 'Step-Up Verification'),
    ]
    challenge = models.CharField(max_length=128, unique=True)
    challenge_type = models.CharField(max_length=20, choices=CHALLENGE_TYPE_CHOICES)
    voter = models.ForeignKey(
        'Voter',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='webauthn_challenges'
    )
    session_key = models.CharField(max_length=64, db_index=True)
    user_verification_req = models.CharField(max_length=20, default='preferred')
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField(db_index=True)
    is_used = models.BooleanField(default=False, db_index=True)
    consumed_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Challenge [{self.challenge_type}] (Used: {self.is_used})"


class PendingVoterOnboarding(models.Model):
    """
    Staging model for external identity verifications awaiting administrative review.
    Enforces ephemeral encrypted storage of identity identifiers and conditional active uniqueness.
    Note on data erasure: Clearing encrypted_identity_payload upon review performs logical
    application-level deletion; physical storage blocks in SQLite/WAL or backups remain subject
    to database VACUUM and backup retention policies.
    """
    STATUS_CHOICES = [
        ('PENDING_REVIEW', 'Pending Administrative Review'),
        ('PROCESSING', 'Processing Approval'),
        ('APPROVED', 'Approved & Onboarded'),
        ('REJECTED', 'Rejected'),
    ]
    provider_id = models.CharField(max_length=50)
    provider_type = models.CharField(max_length=30)
    masked_identifier = models.CharField(max_length=20)
    external_reference_hash = models.CharField(max_length=66, db_index=True)
    identity_blind_index = models.CharField(max_length=66, db_index=True)
    encrypted_identity_payload = models.TextField(blank=True, default='')
    proposed_name = models.CharField(max_length=100)
    claimed_wallet = models.CharField(max_length=42, blank=True, default='')
    target_election = models.ForeignKey(
        'Election',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='pending_onboardings'
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING_REVIEW', db_index=True)
    processing_claim_token = models.CharField(max_length=64, blank=True, default='')
    is_synthetic = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    reviewed_at = models.DateTimeField(blank=True, null=True)
    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='reviewed_onboardings'
    )
    resulting_voter = models.ForeignKey(
        'Voter',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='originating_onboardings'
    )

    class Meta:
        ordering = ['-created_at']
        constraints = [
            models.UniqueConstraint(
                fields=['provider_id', 'external_reference_hash'],
                condition=models.Q(status='PENDING_REVIEW'),
                name='unique_active_pending_onboarding'
            )
        ]

    def __str__(self):
        return f"Pending Onboarding [{self.masked_identifier}] -> {self.status}"


class ExternalProviderVerificationRecord(models.Model):
    """
    Permanent audit record of external identity verifications.
    Preserved even if associated Voter or User records are deleted (SET_NULL).
    """
    STATUS_CHOICES = [
        ('VERIFIED', 'Verified'),
        ('NOT_FOUND', 'Not Found'),
        ('REJECTED', 'Rejected'),
        ('UNAVAILABLE', 'Provider Unavailable'),
        ('ERROR', 'System Error'),
    ]
    voter = models.ForeignKey(
        'Voter',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='provider_verification_records'
    )
    provider_id = models.CharField(max_length=50)
    provider_name = models.CharField(max_length=100)
    provider_type = models.CharField(max_length=30)
    is_simulated = models.BooleanField(default=False)
    masked_identifier = models.CharField(max_length=20)
    external_reference_hash = models.CharField(max_length=66, blank=True, default='')
    verification_status = models.CharField(max_length=20, choices=STATUS_CHOICES)
    failure_code = models.CharField(max_length=50, blank=True, default='')
    sanitized_attributes_json = models.TextField(blank=True, default='{}')
    response_latency_ms = models.IntegerField(default=0)
    verified_at = models.DateTimeField(auto_now_add=True)
    verified_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='conducted_provider_verifications'
    )
    ip_address = models.GenericIPAddressField(blank=True, null=True)

    class Meta:
        ordering = ['-verified_at']

    def __str__(self):
        return f"Verification [{self.provider_id}] {self.masked_identifier} -> {self.verification_status}"