from django.contrib import admin
from .models import (
    Voter,
    AuthChallenge,
    Election,
    ContractDeployment,
    Candidate,
    VoterEligibility,
    ElectionAdminAssignment,
    AdminAuditLog,
    IssuedPermit,
)

admin.site.register(Voter)
admin.site.register(AuthChallenge)
admin.site.register(Election)
admin.site.register(ContractDeployment)
admin.site.register(Candidate)
admin.site.register(VoterEligibility)
admin.site.register(ElectionAdminAssignment)
admin.site.register(AdminAuditLog)
admin.site.register(IssuedPermit)