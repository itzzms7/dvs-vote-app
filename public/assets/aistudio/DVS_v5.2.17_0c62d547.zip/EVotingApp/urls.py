from django.urls import path
from . import views

urlpatterns = [
    # Health & Operational Readiness Routes
    path('healthz/', views.health_check_view, name='healthz'),
    path('api/health/', views.health_check_view, name='api_health'),

    # Legacy and Public Routes
    path('', views.index, name='index'),
    path('index.html', views.index, name='index_html'),
    path('elections/', views.elections_directory_view, name='elections_directory'),
    path('elections/<int:election_id>/', views.election_detail_view, name='election_detail_page'),
    path('public/elections/', views.public_elections_view, name='public_elections'),
    path('vote/', views.Vote, name='vote_portal'),
    path('Vote.html', views.Vote, name='Vote'),
    path('control/', views.control_portal_view, name='control_portal'),
    path('control/officials/<int:user_id>/delete/', views.control_official_delete_view, name='control_official_delete'),
    path('admin/', views.Admin, name='admin_slash'),
    path('Admin.html', views.Admin, name='Admin'),
    path('AdminLogin', views.AdminLogin, name='AdminLogin'),
    path('AdminLogout', views.AdminLogout, name='AdminLogout'),
    path('ViewCount', views.ViewCount, name='ViewCount'),
    path('ViewCountAction', views.ViewCountAction, name='ViewCountAction'),

    # Voter authentication and ballot submission (SQLite eligibility + local Hardhat transaction)
    path('api/voter/authenticate/', views.api_voter_authenticate, name='api_voter_authenticate'),
    path('api/voter/cast/', views.api_voter_cast_vote, name='api_voter_cast_vote'),

    # Module 3 & Module 7 Public & Control APIs
    path('api/public/elections/', views.api_public_elections, name='api_public_elections'),
    path('api/public/elections/<int:election_id>/', views.api_public_election_detail, name='api_public_election_detail'),
    path('api/control/elections/create/', views.api_control_create_election, name='api_control_create_election'),
    path('api/control/elections/<int:election_id>/update/', views.api_control_update_election, name='api_control_update_election'),
    path('api/control/staff/', views.api_control_staff_management, name='api_control_staff_management'),
    path('api/control/elections/<int:election_id>/audit/', views.api_control_election_audit, name='api_control_election_audit'),
    path('api/control/elections/<int:election_id>/deploy/', views.api_control_deploy_election, name='api_control_deploy_election'),
    path('api/control/elections/<int:election_id>/window/', views.api_control_configure_window, name='api_control_configure_window'),
    path('api/control/elections/<int:election_id>/activate/', views.api_control_activate_election, name='api_control_activate_election'),
    path('api/control/elections/<int:election_id>/close/', views.api_control_close_election, name='api_control_close_election'),
    path('api/control/elections/<int:election_id>/reconcile/', views.api_control_reconcile_election, name='api_control_reconcile_election'),
    path('api/control/elections/<int:election_id>/publish/', views.api_control_publish_results, name='api_control_publish_results'),
    path('api/control/elections/<int:election_id>/finalize/', views.api_control_finalize_election, name='api_control_finalize_election'),
    path('api/control/lifecycle/scheduler/', views.api_control_trigger_scheduler, name='api_control_trigger_scheduler'),
    path('api/control/blockchain/sync/', views.api_control_blockchain_sync, name='api_control_blockchain_sync'),

    # Module 4 Candidate Management Control APIs
    path('api/control/elections/<int:election_id>/candidates/', views.api_control_candidates, name='api_control_candidates'),
    path('api/control/elections/<int:election_id>/candidates/<int:candidate_id>/update/', views.api_control_candidate_update, name='api_control_candidate_update'),
    path('api/control/elections/<int:election_id>/candidates/<int:candidate_id>/deactivate/', views.api_control_candidate_deactivate, name='api_control_candidate_deactivate'),
    path('api/control/elections/<int:election_id>/candidates/lock/', views.api_control_candidates_lock, name='api_control_candidates_lock'),

    # Module 5 Voter Registration & Eligibility Control APIs
    path('api/control/elections/<int:election_id>/voters/', views.api_control_election_voters, name='api_control_election_voters'),
    path('api/control/elections/<int:election_id>/voters/add/', views.api_control_election_voter_add, name='api_control_election_voter_add'),
    path('api/control/elections/<int:election_id>/voters/<int:voter_id>/eligibility/', views.api_control_election_voter_eligibility, name='api_control_election_voter_eligibility'),
    path('api/control/elections/<int:election_id>/voters/import-csv/', views.api_control_election_voters_import_csv, name='api_control_election_voters_import_csv'),
    path('api/control/voters/<int:voter_id>/wallet/', views.api_control_voter_wallet_update, name='api_control_voter_wallet_update'),

    # Identity Provider and voter-security administration APIs
    path('api/control/elections/<int:election_id>/voters/<int:voter_id>/flag-security/', views.api_control_election_flag_voter_security, name='api_control_election_flag_voter_security'),
    path('api/identity/providers/', views.api_identity_providers_list, name='api_identity_providers_list'),
    path('api/control/elections/<int:election_id>/identity/verify/', views.api_control_election_identity_verify, name='api_control_election_identity_verify'),
    path('api/control/elections/<int:election_id>/identity/records/', views.api_control_election_identity_records, name='api_control_election_identity_records'),
    path('api/control/elections/<int:election_id>/onboarding/<int:onboarding_id>/review/', views.api_control_election_onboarding_review, name='api_control_election_onboarding_review'),
]