import io
import json
import os
import shutil
import subprocess
import tempfile
import time
from datetime import timedelta

from django.conf import settings
from django.contrib.auth.models import User
from django.core.exceptions import ImproperlyConfigured
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.management import call_command
from django.core.management.base import CommandError
from django.test import Client, TestCase, override_settings
from django.utils import timezone
from PIL import Image
from web3 import Web3

from EVoting.settings import validate_and_load_settings
from EVotingApp.hardhat_demo import (
    deploy_demo_evoting_contract,
    load_demo_deployment_metadata,
    reinitialize_after_node_restart,
    verify_demo_network_and_accounts,
    verify_deployed_demo_contract,
)
from EVotingApp.models import BallotReceipt, Candidate, ContractDeployment, Election, Voter, VoterEligibility
from EVotingApp.services import (
    BlockchainDeploymentError,
    ElectionLifecycleError,
    get_application_health_status,
    initialize_system_superuser,
    load_contract_artifact,
    validate_blockchain_configuration,
)


def _make_png_bytes():
    buf = io.BytesIO()
    img = Image.new("RGB", (64, 64), color=(140, 29, 64))
    img.save(buf, format="PNG")
    return buf.getvalue()


class RenderDeploymentReadinessTestSuite(TestCase):
    """
    Comprehensive 23-point verification suite for DVS Task 9:
    Render Deployment Preparation and Automatic Startup.
    """

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.hardhat_proc = None
        cls.rpc_url = "http://127.0.0.1:8545"
        w3 = Web3(Web3.HTTPProvider(cls.rpc_url, request_kwargs={"timeout": 2}))
        if not w3.is_connected():
            cls.hardhat_proc = subprocess.Popen(
                ["npx", "--no-install", "hardhat", "node", "--hostname", "127.0.0.1", "--port", "8545"],
                cwd=settings.BASE_DIR,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            for _ in range(40):
                if w3.is_connected():
                    break
                time.sleep(0.5)

    @classmethod
    def tearDownClass(cls):
        if cls.hardhat_proc is not None:
            try:
                cls.hardhat_proc.terminate()
                cls.hardhat_proc.wait(timeout=5)
            except Exception:
                try:
                    cls.hardhat_proc.kill()
                except Exception:
                    pass
        super().tearDownClass()

    def setUp(self):
        self.temp_dir = tempfile.mkdtemp(prefix="dvs_render_test_")
        self.client = Client()

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    # =========================================================================
    # 1–5. Dependency & Build Verification
    # =========================================================================
    def test_01_to_05_dependency_and_build_verification(self):
        # 1. package.json and package-lock.json exist with hardhat in devDependencies and Node engine pinned
        pkg_path = os.path.join(settings.BASE_DIR, "package.json")
        lock_path = os.path.join(settings.BASE_DIR, "package-lock.json")
        self.assertTrue(os.path.exists(pkg_path))
        self.assertTrue(os.path.exists(lock_path))
        with open(pkg_path, "r", encoding="utf-8") as f:
            pkg = json.load(f)
        self.assertIn("hardhat", pkg.get("devDependencies", {}))
        self.assertIn("node", pkg.get("engines", {}))

        # 2. npx --no-install hardhat --version succeeds from local node_modules
        ver_proc = subprocess.run(
            ["npx", "--no-install", "hardhat", "--version"],
            cwd=settings.BASE_DIR,
            capture_output=True,
            text=True,
            timeout=30,
        )
        self.assertEqual(ver_proc.returncode, 0, msg=ver_proc.stderr)
        self.assertTrue(ver_proc.stdout.strip())

        # 3. npx --no-install hardhat compile compiles EVoting.sol
        comp_proc = subprocess.run(
            ["npx", "--no-install", "hardhat", "compile"],
            cwd=settings.BASE_DIR,
            capture_output=True,
            text=True,
            timeout=60,
        )
        self.assertEqual(comp_proc.returncode, 0, msg=comp_proc.stderr)

        # 4. EVoting.json artifact exists and contains valid ABI and bytecode
        abi, bytecode, deployed_bytecode = load_contract_artifact()
        self.assertIsInstance(abi, list)
        self.assertGreater(len(bytecode), 200)
        self.assertGreater(len(deployed_bytecode), 200)
        fn_names = {item.get("name") for item in abi if item.get("type") == "function"}
        for required_fn in (
            "owner",
            "addCandidate",
            "setVotingWindow",
            "lockVotingWindow",
            "lockCandidates",
            "openElection",
            "closeElection",
            "markVote",
            "getCount",
            "totalVotes",
            "hasVoted",
        ):
            self.assertIn(required_fn, fn_names)

        # 5. python3 manage.py collectstatic --noinput succeeds
        static_out = io.StringIO()
        call_command("collectstatic", interactive=False, verbosity=0, stdout=static_out)
        self.assertTrue(os.path.isdir(settings.STATIC_ROOT))

    # =========================================================================
    # 6–7. Production Configuration Validation
    # =========================================================================
    def test_06_and_07_production_rpc_configuration_validation(self):
        base_prod_env = {
            "DJANGO_ENV": "production",
            "DJANGO_DEBUG": "False",
            "DJANGO_SECRET_KEY": "a" * 64,
            "DJANGO_ALLOWED_HOSTS": "dvs-portal.onrender.com,localhost,127.0.0.1",
            "DJANGO_CSRF_TRUSTED_ORIGINS": "https://dvs-portal.onrender.com",
            "DATABASE_URL": "postgresql://dvs_admin:secret_password@localhost:5432/dvs_production",
            "WEB3_RPC_URL": "http://127.0.0.1:8545",
            "ALLOW_LOCAL_RPC_IN_PRODUCTION": "True",
            "REQUIRE_HTTPS_RPC": "False",
            "CHAIN_ID": "31337",
            "ELECTION_AUTHORITY_PRIVATE_KEY": getattr(settings, "ELECTION_AUTHORITY_PRIVATE_KEY"),
            "BLOCKCHAIN_DEPLOYER_PRIVATE_KEY": getattr(settings, "BLOCKCHAIN_DEPLOYER_PRIVATE_KEY"),
            "ELECTION_NULLIFIER_PEPPER": "prod-nullifier-pepper-secret-value-2026",
            "ONBOARDING_ENCRYPTION_KEY": "prod-onboarding-encryption-key-2026",
            "PROVIDER_REFERENCE_SALT": "prod-provider-reference-salt-2026",
        }

        # 6a. Production accepts http://127.0.0.1:8545 when ALLOW_LOCAL_RPC_IN_PRODUCTION=True
        cfg = validate_and_load_settings(env=base_prod_env, base_dir=settings.BASE_DIR)
        self.assertTrue(cfg["IS_PRODUCTION"])
        self.assertEqual(cfg["WEB3_RPC_URL"], "http://127.0.0.1:8545")
        self.assertTrue(cfg["ALLOW_LOCAL_RPC_IN_PRODUCTION"])
        self.assertEqual(cfg["CHAIN_ID"], 31337)
        self.assertEqual(cfg["DATABASES"]["default"]["ENGINE"], "django.db.backends.postgresql")
        self.assertTrue(cfg["SESSION_COOKIE_SECURE"])
        self.assertTrue(cfg["CSRF_COOKIE_SECURE"])
        self.assertTrue(cfg["SECURE_SSL_REDIRECT"])
        self.assertEqual(cfg["SECURE_HSTS_SECONDS"], 31536000)
        self.assertTrue(cfg["SECURE_HSTS_INCLUDE_SUBDOMAINS"])
        self.assertTrue(cfg["SECURE_HSTS_PRELOAD"])
        self.assertEqual(cfg["X_FRAME_OPTIONS"], "DENY")

        bc_val = validate_blockchain_configuration(config_override=cfg, is_production=True)
        self.assertTrue(bc_val["valid"])

        # 6b. Production rejects http://127.0.0.1:8545 when ALLOW_LOCAL_RPC_IN_PRODUCTION=False
        env_no_local = dict(base_prod_env, ALLOW_LOCAL_RPC_IN_PRODUCTION="False")
        with self.assertRaises(ImproperlyConfigured):
            validate_and_load_settings(env=env_no_local, base_dir=settings.BASE_DIR)
        with self.assertRaises(BlockchainDeploymentError):
            validate_blockchain_configuration(
                config_override=dict(cfg, ALLOW_LOCAL_RPC_IN_PRODUCTION=False),
                is_production=True,
            )

        # 7. Arbitrary remote non-HTTPS RPC rejected in production even when ALLOW_LOCAL_RPC_IN_PRODUCTION=True
        env_remote_http = dict(
            base_prod_env,
            WEB3_RPC_URL="http://rpc.insecure-remote-node.example.com:8545",
            ALLOW_LOCAL_RPC_IN_PRODUCTION="True",
            REQUIRE_HTTPS_RPC="False",
        )
        with self.assertRaises(ImproperlyConfigured):
            validate_and_load_settings(env=env_remote_http, base_dir=settings.BASE_DIR)
        with self.assertRaises(BlockchainDeploymentError):
            validate_blockchain_configuration(
                config_override=dict(
                    cfg,
                    WEB3_RPC_URL="http://rpc.insecure-remote-node.example.com:8545",
                    ALLOW_LOCAL_RPC_IN_PRODUCTION=True,
                    REQUIRE_HTTPS_RPC=False,
                ),
                is_production=True,
            )

        # RENDER_EXTERNAL_HOSTNAME automatically populates ALLOWED_HOSTS and CSRF_TRUSTED_ORIGINS
        env_render_host = dict(base_prod_env)
        env_render_host.pop("DJANGO_ALLOWED_HOSTS", None)
        env_render_host.pop("DJANGO_CSRF_TRUSTED_ORIGINS", None)
        env_render_host["RENDER_EXTERNAL_HOSTNAME"] = "dvs-portal-live.onrender.com"
        cfg_render = validate_and_load_settings(env=env_render_host, base_dir=settings.BASE_DIR)
        self.assertIn("dvs-portal-live.onrender.com", cfg_render["ALLOWED_HOSTS"])
        self.assertIn("https://dvs-portal-live.onrender.com", cfg_render["CSRF_TRUSTED_ORIGINS"])

    # =========================================================================
    # 8–11. Superuser Initialization Verification
    # =========================================================================
    def test_08_to_11_suhail_superuser_initialization(self):
        User.objects.filter(username="Suhail").delete()
        test_secret_pw = "SuhailRenderTestSecret#2026"

        # 8. Suhail superuser created on clean database (without requiring DJANGO_SUPERUSER_EMAIL)
        env_suhail = {
            "DJANGO_SUPERUSER_USERNAME": "Suhail",
            "DJANGO_SUPERUSER_PASSWORD": test_secret_pw,
        }
        res1 = initialize_system_superuser(env=env_suhail, strict=True)
        self.assertEqual(res1["status"], "CREATED")
        self.assertTrue(res1["created"])
        self.assertEqual(res1["username"], "Suhail")
        self.assertNotIn(test_secret_pw, json.dumps(res1))

        suhail = User.objects.get(username="Suhail")
        self.assertTrue(suhail.is_superuser)
        self.assertTrue(suhail.is_staff)
        self.assertTrue(suhail.is_active)
        self.assertTrue(suhail.groups.filter(name="Super Admin").exists())
        self.assertTrue(suhail.check_password(test_secret_pw))

        # 9. Repeated init_superuser execution is idempotent and preserves existing password
        env_second = {
            "DJANGO_SUPERUSER_USERNAME": "Suhail",
            "DJANGO_SUPERUSER_PASSWORD": "DifferentPasswordShouldNotOverwrite#999",
        }
        res2 = initialize_system_superuser(env=env_second, strict=True)
        self.assertEqual(res2["status"], "ALREADY_EXISTS")
        self.assertFalse(res2["created"])
        self.assertFalse(res2["password_modified"])
        self.assertEqual(User.objects.filter(username="Suhail").count(), 1)
        suhail.refresh_from_db()
        self.assertTrue(suhail.check_password(test_secret_pw))

        # 10. Existing non-superuser Suhail conflict is rejected (never silently elevated)
        User.objects.filter(username="Suhail").delete()
        regular_suhail = User.objects.create_user(
            username="Suhail",
            email="regular@example.com",
            password="RegularUserPass#123",
            is_staff=True,
            is_superuser=False,
        )
        with self.assertRaises(ElectionLifecycleError) as ctx:
            initialize_system_superuser(env=env_suhail, strict=True)
        self.assertIn("Security conflict", str(ctx.exception))
        regular_suhail.refresh_from_db()
        self.assertFalse(regular_suhail.is_superuser)

        # Clean up conflict user and re-create valid Suhail superuser
        User.objects.filter(username="Suhail").delete()
        initialize_system_superuser(env=env_suhail, strict=True)

        # 11. Missing superuser password rejected in production startup
        with self.assertRaises(ElectionLifecycleError):
            initialize_system_superuser(env={"DJANGO_SUPERUSER_USERNAME": "Suhail"}, strict=True)
        with override_settings(IS_PRODUCTION=True):
            with patch_environ({"DJANGO_SUPERUSER_USERNAME": "Suhail", "DJANGO_SUPERUSER_PASSWORD": ""}):
                with self.assertRaises(CommandError):
                    call_command("init_superuser")

    # =========================================================================
    # 12–15 & 20. Single-Service Startup, Contract Deployment, Health & Chain Reset
    # =========================================================================
    def test_12_to_15_and_20_hardhat_startup_deploy_health_and_reset_detection(self):
        # 12 & 13. Hardhat node reachable on 127.0.0.1:8545 with Chain ID 31337
        net_status = verify_demo_network_and_accounts(rpc_url=self.rpc_url)
        self.assertTrue(net_status["connected"])
        self.assertEqual(net_status["chain_id"], 31337)

        # 14. EVoting.sol deployed automatically and contract code verified on-chain
        dep = deploy_demo_evoting_contract(
            election_id=2026,
            rpc_url=self.rpc_url,
            base_dir=self.temp_dir,
        )
        self.assertEqual(dep["chain_id"], 31337)
        self.assertTrue(Web3.is_address(dep["contract_address"]))
        ver = verify_deployed_demo_contract(
            contract_address=dep["contract_address"],
            expected_election_id=2026,
            rpc_url=self.rpc_url,
        )
        self.assertTrue(ver["verified"])
        self.assertGreater(ver["deployed_bytecode_size"], 500)

        # Also record in default metadata path so /api/health/ discovers it
        deploy_demo_evoting_contract(election_id=2026, rpc_url=self.rpc_url)

        # 15. /api/health/ returns healthy status with database, RPC, Chain ID 31337, and contract_deployed=True
        health_resp = self.client.get("/api/health/")
        self.assertEqual(health_resp.status_code, 200)
        h_data = health_resp.json()
        self.assertEqual(h_data["status"], "ok")
        self.assertEqual(h_data["database"]["status"], "ok")
        self.assertTrue(h_data["blockchain"]["reachable"])
        self.assertEqual(h_data["blockchain"]["configured_chain_id"], 31337)
        self.assertEqual(h_data["blockchain"]["live_chain_id"], 31337)
        self.assertTrue(h_data["blockchain"]["chain_id_valid"])
        self.assertTrue(h_data["blockchain"]["contract_deployed"])
        self.assertGreater(h_data["blockchain"]["contract_bytecode_size"], 500)

        # 20. Hardhat chain reset detection after restart (stale address with no bytecode on-chain)
        stale_election = Election.objects.create(
            election_id=9901,
            title="Pre-Restart Election",
            description="Created before container restart",
            election_type="ELECTION",
            commencement_mode="SCHEDULED",
            start_datetime=timezone.now() - timedelta(minutes=10),
            end_datetime=timezone.now() + timedelta(hours=2),
            status="ACTIVE",
            deployment_status="DEPLOYED",
            contract_address="0x000000000000000000000000000000000000dEaD",
            chain_id=31337,
            candidates_locked_on_chain=True,
            voting_window_locked_on_chain=True,
        )
        from EVotingApp.services import verify_live_election_contract_on_chain
        with self.assertRaises(BlockchainDeploymentError):
            verify_live_election_contract_on_chain(stale_election)
        stale_election.refresh_from_db()
        self.assertEqual(stale_election.deployment_status, "CHAIN_RESET_REDEPLOY_REQUIRED")

        # Recovery via reinitialize_after_node_restart deploys a fresh contract cleanly
        rec = reinitialize_after_node_restart(
            election_id=9901,
            rpc_url=self.rpc_url,
            force=True,
            base_dir=self.temp_dir,
        )
        self.assertTrue(rec["redeployed"])
        self.assertTrue(Web3.is_address(rec["deployment"]["contract_address"]))

    # =========================================================================
    # 16–19 & 21–23. End-to-End Wizard, Voting, Media & Android API Verification
    # =========================================================================
    def test_16_to_19_and_21_to_23_wizard_voting_media_and_android_apis(self):
        media_dir = os.path.join(self.temp_dir, "persistent_media")
        os.makedirs(media_dir, exist_ok=True)

        with override_settings(MEDIA_ROOT=media_dir):
            # 16. Superuser Suhail logs in and accesses Create Elections (/control/)
            test_pw = "SuhailWizardTestSecret#2026"
            User.objects.filter(username="Suhail").delete()
            initialize_system_superuser(
                env={"DJANGO_SUPERUSER_USERNAME": "Suhail", "DJANGO_SUPERUSER_PASSWORD": test_pw},
                strict=True,
            )
            login_resp = self.client.post("/AdminLogin", {"username": "Suhail", "password": test_pw})
            self.assertIn(login_resp.status_code, (200, 302))

            wizard_get = self.client.get("/control/?section=create_elections")
            self.assertEqual(wizard_get.status_code, 200)
            self.assertContains(wizard_get, "Create Elections")

            # Seed registered voters in central Voter table
            Voter.objects.create(
                aadhar_number="910000000001",
                name="Aarav Sharma",
                phone="9876543210",
                status="ACTIVE",
            )
            Voter.objects.create(
                aadhar_number="910000000002",
                name="Priya Nair",
                phone="9876543211",
                status="ACTIVE",
            )

            # 17. Election created through the 4-step wizard
            now = timezone.localtime(timezone.now())
            start_str = (now - timedelta(minutes=5)).strftime("%Y-%m-%dT%H:%M")
            end_str = (now + timedelta(hours=2)).strftime("%Y-%m-%dT%H:%M")

            # Step 1: Election Details
            r_step1 = self.client.post(
                "/control/",
                {
                    "wizard_action": "step1_next",
                    "election_title": "2026 National Assembly Election",
                    "election_description": "Official general election created via 4-step wizard.",
                    "election_type": "ELECTION",
                    "start_datetime": start_str,
                    "end_datetime": end_str,
                },
            )
            self.assertIn(r_step1.status_code, (200, 302))

            # Step 2: Add 2 Candidates with party symbol uploads
            sym1 = SimpleUploadedFile("lotus.png", _make_png_bytes(), content_type="image/png")
            r_cand1 = self.client.post(
                "/control/",
                {
                    "wizard_action": "add_candidate",
                    "candidate_name": "Candidate Alpha",
                    "candidate_party": "Civic Unity Party",
                    "candidate_symbol_image": sym1,
                },
            )
            self.assertIn(r_cand1.status_code, (200, 302))

            sym2 = SimpleUploadedFile("hand.png", _make_png_bytes(), content_type="image/png")
            r_cand2 = self.client.post(
                "/control/",
                {
                    "wizard_action": "step2_next",
                    "candidate_name": "Candidate Beta",
                    "candidate_party": "Progressive Alliance",
                    "candidate_symbol_image": sym2,
                },
            )
            self.assertIn(r_cand2.status_code, (200, 302))

            # Step 3: Include Registered Voters
            r_voters = self.client.post(
                "/control/",
                {
                    "wizard_action": "step3_next",
                    "included_voters_input": "910000000001\n910000000002",
                },
            )
            self.assertIn(r_voters.status_code, (200, 302))

            # Step 4: Review & Create Election
            r_create = self.client.post(
                "/control/",
                {
                    "wizard_action": "create_election",
                },
            )
            self.assertIn(r_create.status_code, (200, 302))

            election = Election.objects.get(title="2026 National Assembly Election")
            self.assertEqual(election.election_type, "ELECTION")
            self.assertEqual(election.status, "ACTIVE")
            self.assertEqual(election.deployment_status, "DEPLOYED")
            self.assertTrue(Web3.is_address(election.contract_address))
            self.assertTrue(election.candidates_locked_on_chain)
            self.assertTrue(election.voting_window_locked_on_chain)

            # 21. Candidate symbol image uploaded and served from /media/...
            cand_alpha = Candidate.objects.get(election=election, candidate_id_num=1)
            self.assertTrue(cand_alpha.symbol_image.name.startswith("candidate_symbols/"))
            media_url = cand_alpha.symbol_image.url
            self.assertTrue(media_url.startswith("/media/candidate_symbols/"))
            media_resp = self.client.get(media_url)
            self.assertEqual(media_resp.status_code, 200)
            for _ in media_resp.streaming_content:
                pass

            # 22. Public election API returns election details and candidate symbol URL
            pub_list_resp = self.client.get("/api/public/elections/")
            self.assertEqual(pub_list_resp.status_code, 200)
            pub_elections = pub_list_resp.json()["elections"]
            matching_pub = [e for e in pub_elections if e["election_id"] == election.election_id]
            self.assertEqual(len(matching_pub), 1)
            self.assertEqual(len(matching_pub[0]["candidates"]), 2)
            self.assertEqual(matching_pub[0]["candidates"][0]["symbol_image_url"], media_url)

            # Active election hides live candidate-wise results before end_datetime
            self.assertFalse(matching_pub[0]["results"]["visible"])

            # 18. Eligible voter authenticates and submits a vote (on-chain transaction recorded)
            voter_client = Client()
            auth_resp = voter_client.post(
                "/api/voter/authenticate/",
                data=json.dumps({"voter_id": "910000000001", "election_id": election.election_id}),
                content_type="application/json",
            )
            self.assertEqual(auth_resp.status_code, 200)
            auth_json = auth_resp.json()
            self.assertTrue(auth_json["success"])
            self.assertFalse(auth_json["has_voted"])

            cast_resp = voter_client.post(
                "/api/voter/cast/",
                data=json.dumps({"election_id": election.election_id, "candidate_id": 1}),
                content_type="application/json",
            )
            self.assertEqual(cast_resp.status_code, 200, msg=cast_resp.content.decode())
            cast_json = cast_resp.json()
            self.assertTrue(cast_json["success"])
            self.assertTrue(cast_json["tx_hash"].startswith("0x"))
            self.assertGreaterEqual(cast_json["block_number"], 1)
            self.assertTrue(cast_json["receipt_reference"].startswith(f"DVS-{election.election_id}-"))

            # 19. Duplicate vote rejected
            dup_resp = voter_client.post(
                "/api/voter/cast/",
                data=json.dumps({"election_id": election.election_id, "candidate_id": 1}),
                content_type="application/json",
            )
            self.assertEqual(dup_resp.status_code, 409)

            # 23. Closed election returns results
            election.end_datetime = timezone.now() - timedelta(minutes=1)
            election.save(update_fields=["end_datetime", "updated_at"])

            detail_resp = self.client.get(f"/api/public/elections/{election.election_id}/")
            self.assertEqual(detail_resp.status_code, 200)
            detail_json = detail_resp.json()
            self.assertEqual(detail_json["status"], "CLOSED")
            self.assertTrue(detail_json["results"]["visible"])
            votes_by_cid = {c["candidate_id"]: c["votes"] for c in detail_json["results"]["candidates"]}
            self.assertEqual(votes_by_cid[1], 1)
            self.assertEqual(votes_by_cid[2], 0)

    # =========================================================================
    # 24–28. Final Render Compatibility, Proxy HTTPS, DB Guard & Android CSRF
    # =========================================================================
    def test_24_to_28_final_render_compatibility_and_android_csrf(self):
        # 24. Production startup script fails when DATABASE_URL is missing in production
        env_missing_db = os.environ.copy()
        env_missing_db.update({
            "DJANGO_ENV": "production",
            "DJANGO_DEBUG": "False",
            "DJANGO_SECRET_KEY": "s" * 64,
            "DJANGO_SUPERUSER_USERNAME": "Suhail",
            "DJANGO_SUPERUSER_PASSWORD": "SuhailTestPassword#2026",
        })
        env_missing_db.pop("DATABASE_URL", None)
        env_missing_db.pop("DB_ENGINE", None)
        proc_no_db = subprocess.run(
            ["bash", "scripts/render_start.sh"],
            cwd=settings.BASE_DIR,
            env=env_missing_db,
            capture_output=True,
            text=True,
            timeout=15,
        )
        self.assertNotEqual(proc_no_db.returncode, 0)
        self.assertIn("DATABASE_URL (PostgreSQL) is required in production", proc_no_db.stderr)

        # 25. HTTPS redirection, HSTS, X-Frame-Options=DENY, and /api/health/ SSL-redirect exemption
        with override_settings(
            IS_PRODUCTION=True,
            DEBUG=False,
            ALLOW_LOCAL_RPC_IN_PRODUCTION=True,
            ALLOWED_HOSTS=["dvs-portal.onrender.com", "localhost", "127.0.0.1", "testserver"],
            CSRF_TRUSTED_ORIGINS=["https://dvs-portal.onrender.com"],
            SECURE_SSL_REDIRECT=True,
            SECURE_PROXY_SSL_HEADER=("HTTP_X_FORWARDED_PROTO", "https"),
            SECURE_REDIRECT_EXEMPT=[r"^api/health/$", r"^healthz/$"],
            SECURE_HSTS_SECONDS=31536000,
            SECURE_HSTS_INCLUDE_SUBDOMAINS=True,
            SECURE_HSTS_PRELOAD=True,
            SESSION_COOKIE_SECURE=True,
            CSRF_COOKIE_SECURE=True,
            X_FRAME_OPTIONS="DENY",
        ):
            # Internal HTTP health probe without X-Forwarded-Proto is exempt from 301 redirect
            health_http = self.client.get("/api/health/", HTTP_HOST="dvs-portal.onrender.com")
            self.assertEqual(health_http.status_code, 200)

            # Plain HTTP request to public endpoint redirects 301 to HTTPS
            pub_http = self.client.get("/api/public/elections/", HTTP_HOST="dvs-portal.onrender.com")
            self.assertEqual(pub_http.status_code, 301)
            self.assertTrue(pub_http["Location"].startswith("https://dvs-portal.onrender.com/api/public/elections/"))

            # Proxied HTTPS request (X-Forwarded-Proto: https) succeeds with 200 (no redirect loop), HSTS & X-Frame-Options: DENY
            pub_https = self.client.get(
                "/api/public/elections/",
                HTTP_HOST="dvs-portal.onrender.com",
                HTTP_X_FORWARDED_PROTO="https",
            )
            self.assertEqual(pub_https.status_code, 200)
            self.assertIn("max-age=31536000", pub_https.headers.get("Strict-Transport-Security", ""))
            self.assertIn("includeSubDomains", pub_https.headers.get("Strict-Transport-Security", ""))
            self.assertIn("preload", pub_https.headers.get("Strict-Transport-Security", ""))
            self.assertEqual(pub_https.headers.get("X-Frame-Options"), "DENY")
            self.assertIn("csrftoken", pub_https.cookies)
            self.assertTrue(pub_https.cookies["csrftoken"]["secure"])

        # 26–28. Strict Android HTTP Client CSRF + Session flow (Client(enforce_csrf_checks=True))
        Voter.objects.filter(aadhar_number="920000000001").delete()
        voter = Voter.objects.create(
            aadhar_number="920000000001",
            name="Rohan Verma",
            phone="9876500001",
            status="ACTIVE",
        )
        dep = deploy_demo_evoting_contract(election_id=2027, rpc_url=self.rpc_url, base_dir=self.temp_dir)
        from EVotingApp.simple_voting import attach_contract_to_election, lock_candidate_roster, open_election, sync_candidate, update_voting_window
        now = timezone.now()
        el = Election.objects.create(
            election_id=2027,
            title="Android CSRF Verification Election",
            description="Strict CSRF mobile client test",
            election_type="ELECTION",
            commencement_mode="SCHEDULED",
            start_datetime=now - timedelta(minutes=5),
            end_datetime=now + timedelta(hours=1),
            status="SCHEDULED",
        )
        cand = Candidate.objects.create(
            election=el,
            candidate_id_num=1,
            name="Mobile Candidate One",
            symbol="Star",
            description="Party A",
            display_order=1,
            is_active=True,
        )
        VoterEligibility.objects.create(voter=voter, election=el, is_eligible=True, has_voted=False)
        attach_contract_to_election(el, dep["contract_address"])
        sync_candidate(el, cand)
        update_voting_window(el, el.start_datetime, el.end_datetime)
        lock_candidate_roster(el)
        open_election(el)

        android_client = Client(enforce_csrf_checks=True)

        # Step A: Android client calls GET /api/public/elections/ and obtains csrftoken cookie
        r_elections = android_client.get("/api/public/elections/")
        self.assertEqual(r_elections.status_code, 200)
        self.assertIn("csrftoken", r_elections.cookies)
        csrf_token = r_elections.cookies["csrftoken"].value
        self.assertTrue(len(csrf_token) >= 32)

        # Step B: POST /api/voter/authenticate/ WITHOUT X-CSRFToken header is rejected (HTTP 403)
        r_auth_no_csrf = android_client.post(
            "/api/voter/authenticate/",
            data=json.dumps({"voter_id": "920000000001", "election_id": el.election_id}),
            content_type="application/json",
        )
        self.assertEqual(r_auth_no_csrf.status_code, 403)

        # Step C: POST /api/voter/authenticate/ WITH X-CSRFToken header succeeds (HTTP 200) and sets sessionid
        r_auth_ok = android_client.post(
            "/api/voter/authenticate/",
            data=json.dumps({"voter_id": "920000000001", "election_id": el.election_id}),
            content_type="application/json",
            HTTP_X_CSRFTOKEN=csrf_token,
        )
        self.assertEqual(r_auth_ok.status_code, 200, msg=r_auth_ok.content.decode())
        self.assertIn("sessionid", r_auth_ok.cookies)
        self.assertTrue(r_auth_ok.json()["success"])
        self.assertFalse(r_auth_ok.json()["has_voted"])

        # Step D: POST /api/voter/cast/ WITHOUT X-CSRFToken header is rejected (HTTP 403)
        r_cast_no_csrf = android_client.post(
            "/api/voter/cast/",
            data=json.dumps({"election_id": el.election_id, "candidate_id": 1}),
            content_type="application/json",
        )
        self.assertEqual(r_cast_no_csrf.status_code, 403)

        # Step E: POST /api/voter/cast/ WITH X-CSRFToken + sessionid cookies succeeds (HTTP 200)
        r_cast_ok = android_client.post(
            "/api/voter/cast/",
            data=json.dumps({"election_id": el.election_id, "candidate_id": 1}),
            content_type="application/json",
            HTTP_X_CSRFTOKEN=csrf_token,
        )
        self.assertEqual(r_cast_ok.status_code, 200, msg=r_cast_ok.content.decode())
        cast_payload = r_cast_ok.json()
        self.assertTrue(cast_payload["success"])
        self.assertTrue(cast_payload["tx_hash"].startswith("0x"))
        self.assertTrue(cast_payload["receipt_reference"].startswith("DVS-2027-"))

    # =========================================================================
    # 29. Task 10: Local Production-Parity Compose, Caddy & LAN HTTPS Parity
    # =========================================================================
    def test_29_task10_local_production_parity_compose_and_lan_https(self):
        compose_path = os.path.join(settings.BASE_DIR, "compose.yaml")
        caddy_path = os.path.join(settings.BASE_DIR, "Caddyfile")
        env_local_example_path = os.path.join(settings.BASE_DIR, ".env.local.example")
        dockerignore_path = os.path.join(settings.BASE_DIR, ".dockerignore")
        render_yaml_path = os.path.join(settings.BASE_DIR, "render.yaml")

        for req_path in (compose_path, caddy_path, env_local_example_path, dockerignore_path, render_yaml_path):
            self.assertTrue(os.path.isfile(req_path), msg=f"Missing required file: {req_path}")

        with open(compose_path, "r", encoding="utf-8") as f:
            compose_txt = f.read()
        self.assertIn("dockerfile: ./Dockerfile", compose_txt)
        self.assertIn('command: ["bash", "scripts/render_start.sh"]', compose_txt)
        self.assertIn("postgres:15-bookworm", compose_txt)
        self.assertIn("dvs_postgres_data:/var/lib/postgresql/data", compose_txt)
        self.assertIn("dvs_media_data:/var/data/media", compose_txt)
        self.assertIn("caddy:2-alpine", compose_txt)
        # Hardhat port 8545 must NEVER be published to host ports
        self.assertNotIn("8545:8545", compose_txt)

        with open(caddy_path, "r", encoding="utf-8") as f:
            caddy_txt = f.read()
        self.assertIn("tls internal", caddy_txt)
        self.assertIn("reverse_proxy dvs-portal:10000", caddy_txt)
        self.assertIn("header_up X-Forwarded-Proto https", caddy_txt)
        self.assertIn("header_up X-Forwarded-Host {http.request.host}", caddy_txt)

        with open(env_local_example_path, "r", encoding="utf-8") as f:
            env_ex = f.read()
        for expected_line in (
            "DJANGO_ENV=production",
            "DJANGO_DEBUG=False",
            "WEB3_RPC_URL=http://127.0.0.1:8545",
            "ALLOW_LOCAL_RPC_IN_PRODUCTION=True",
            "REQUIRE_HTTPS_RPC=False",
            "CHAIN_ID=31337",
            "PORT=10000",
            "MEDIA_ROOT=/var/data/media",
            "DJANGO_SUPERUSER_USERNAME=Suhail",
        ):
            self.assertIn(expected_line, env_ex)

        # Create an active election and eligible voter for LAN HTTPS Android simulation
        voter_lan = Voter.objects.create(
            aadhar_number="930000000001",
            name="Ananya Iyer",
            phone="9876500002",
            status="ACTIVE",
        )
        dep_lan = deploy_demo_evoting_contract(election_id=2028, rpc_url=self.rpc_url, base_dir=self.temp_dir)
        from EVotingApp.simple_voting import attach_contract_to_election, lock_candidate_roster, open_election, sync_candidate, update_voting_window
        now = timezone.now()
        el_lan = Election.objects.create(
            election_id=2028,
            title="LAN HTTPS Parity Election",
            description="Local Caddy HTTPS proxy parity test",
            election_type="ELECTION",
            commencement_mode="SCHEDULED",
            start_datetime=now - timedelta(minutes=5),
            end_datetime=now + timedelta(hours=1),
            status="SCHEDULED",
        )
        cand_lan = Candidate.objects.create(
            election=el_lan,
            candidate_id_num=1,
            name="LAN Candidate Alpha",
            symbol="Sun",
            description="Party LAN",
            display_order=1,
            is_active=True,
        )
        VoterEligibility.objects.create(voter=voter_lan, election=el_lan, is_eligible=True, has_voted=False)
        attach_contract_to_election(el_lan, dep_lan["contract_address"])
        sync_candidate(el_lan, cand_lan)
        update_voting_window(el_lan, el_lan.start_datetime, el_lan.end_datetime)
        lock_candidate_roster(el_lan)
        open_election(el_lan)

        # Simulate physical Android client over laptop LAN IP (192.168.1.50:8443) behind Caddy TLS proxy
        with override_settings(
            IS_PRODUCTION=True,
            DEBUG=False,
            ALLOW_LOCAL_RPC_IN_PRODUCTION=True,
            ALLOWED_HOSTS=["localhost", "127.0.0.1", "192.168.1.50", ".onrender.com"],
            CSRF_TRUSTED_ORIGINS=[
                "https://localhost",
                "https://127.0.0.1",
                "https://192.168.1.50",
                "https://localhost:8443",
                "https://127.0.0.1:8443",
                "https://192.168.1.50:8443",
            ],
            SECURE_SSL_REDIRECT=True,
            SECURE_PROXY_SSL_HEADER=("HTTP_X_FORWARDED_PROTO", "https"),
            USE_X_FORWARDED_HOST=True,
            SESSION_COOKIE_SECURE=True,
            CSRF_COOKIE_SECURE=True,
            X_FRAME_OPTIONS="DENY",
        ):
            lan_client = Client(enforce_csrf_checks=True)
            lan_headers = {
                "HTTP_HOST": "192.168.1.50:8443",
                "HTTP_X_FORWARDED_HOST": "192.168.1.50:8443",
                "HTTP_X_FORWARDED_PROTO": "https",
                "HTTP_ORIGIN": "https://192.168.1.50:8443",
            }
            r_lan_health = lan_client.get("/api/health/", **lan_headers)
            self.assertEqual(r_lan_health.status_code, 200)
            self.assertIn("csrftoken", r_lan_health.cookies)
            self.assertTrue(r_lan_health.cookies["csrftoken"]["secure"])
            lan_csrf = r_lan_health.cookies["csrftoken"].value

            r_lan_pub = lan_client.get("/api/public/elections/", **lan_headers)
            self.assertEqual(r_lan_pub.status_code, 200)
            self.assertEqual(r_lan_pub.headers.get("X-Frame-Options"), "DENY")

            # Authenticate over LAN HTTPS with X-CSRFToken and Origin: https://192.168.1.50:8443
            r_lan_auth = lan_client.post(
                "/api/voter/authenticate/",
                data=json.dumps({"voter_id": "930000000001", "election_id": 2028}),
                content_type="application/json",
                HTTP_X_CSRFTOKEN=lan_csrf,
                **lan_headers,
            )
            self.assertEqual(r_lan_auth.status_code, 200, msg=r_lan_auth.content.decode())
            self.assertTrue(r_lan_auth.json()["success"])
            self.assertIn("sessionid", r_lan_auth.cookies)
            self.assertTrue(r_lan_auth.cookies["sessionid"]["secure"])

            # Cast ballot over LAN HTTPS with X-CSRFToken and sessionid
            r_lan_cast = lan_client.post(
                "/api/voter/cast/",
                data=json.dumps({"election_id": 2028, "candidate_id": 1}),
                content_type="application/json",
                HTTP_X_CSRFTOKEN=lan_csrf,
                **lan_headers,
            )
            self.assertEqual(r_lan_cast.status_code, 200, msg=r_lan_cast.content.decode())
            self.assertTrue(r_lan_cast.json()["success"])
            self.assertTrue(r_lan_cast.json()["tx_hash"].startswith("0x"))


class patch_environ:
    def __init__(self, overrides):
        self.overrides = overrides
        self.previous = {}

    def __enter__(self):
        for k, v in self.overrides.items():
            self.previous[k] = os.environ.get(k)
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = str(v)

    def __exit__(self, exc_type, exc_val, exc_tb):
        for k, prev in self.previous.items():
            if prev is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = prev
