from django.test import TestCase
from django.contrib.auth.models import User
from django.db.utils import IntegrityError
from EVotingApp.models import (
    Voter, Election, Candidate, VoterEligibility,
    ElectionAdminAssignment, AdminAuditLog, IssuedPermit
)


class Module1DatabaseArchitectureTests(TestCase):
    def test_legacy_election_data_seeded_correctly(self):
        """Verify that the data migration seeded Election 2026 with default candidates and eligibilities."""
        election = Election.objects.get(election_id=2026)
        self.assertEqual(election.title, 'Legacy General Election 2026')
        self.assertEqual(election.status, 'ACTIVE')
        self.assertEqual(election.deployment_status, 'DEPLOYED')
        self.assertTrue(election.candidates_locked_on_chain)
        self.assertEqual(election.candidates.count(), 3)

        candidates = list(election.candidates.order_by('candidate_id_num').values_list('candidate_id_num', 'name'))
        self.assertEqual(candidates, [
            (1, 'Rahul Gandhi'),
            (2, 'Narendar Modi'),
            (3, 'Akhilesh Yadav')
        ])

    def test_existing_voters_preserved_and_assigned_eligibility(self):
        """Verify that actual Voter records in DB have corresponding VoterEligibility records."""
        voters = Voter.objects.all()
        election = Election.objects.get(election_id=2026)
        
        for voter in voters:
            eligibility = VoterEligibility.objects.get(voter=voter, election=election)
            self.assertTrue(eligibility.is_eligible)
            self.assertEqual(eligibility.has_voted, voter.has_voted)

    def test_voter_eligibility_unique_together_constraint(self):
        """Verify that duplicate eligibility records for the same voter and election raise IntegrityError."""
        voter = Voter.objects.create(name='Test Voter Unique', aadhar_number='888888888888')
        election = Election.objects.create(title='Test Election 1', election_id=3001)

        VoterEligibility.objects.create(voter=voter, election=election)

        with self.assertRaises(IntegrityError):
            VoterEligibility.objects.create(voter=voter, election=election)

    def test_candidate_unique_together_constraint(self):
        """Verify duplicate candidate_id_num per election raises IntegrityError."""
        election = Election.objects.create(title='Test Election 2', election_id=3002)
        Candidate.objects.create(election=election, candidate_id_num=1, name='Candidate A', symbol='A')

        with self.assertRaises(IntegrityError):
            Candidate.objects.create(election=election, candidate_id_num=1, name='Candidate B', symbol='B')

    def test_election_admin_assignment(self):
        """Verify ElectionAdminAssignment associates users with elections and roles."""
        user = User.objects.create_user(username='admin_user', password='password123')
        election = Election.objects.get(election_id=2026)

        assignment = ElectionAdminAssignment.objects.create(
            election=election,
            user=user,
            role='ELECTION_ADMIN'
        )
        self.assertEqual(assignment.role, 'ELECTION_ADMIN')
        self.assertEqual(user.election_assignments.count(), 1)

    def test_admin_audit_log_recording(self):
        """Verify AdminAuditLog records actor, action, target and details."""
        user = User.objects.create_user(username='audit_user', password='password123')
        log = AdminAuditLog.objects.create(
            actor=user,
            action='ELECTION_CREATED',
            target_model='Election',
            target_id='2026',
            details='{"title": "Legacy General Election 2026"}'
        )
        self.assertEqual(log.actor, user)
        self.assertIn('audit_user', str(log))
