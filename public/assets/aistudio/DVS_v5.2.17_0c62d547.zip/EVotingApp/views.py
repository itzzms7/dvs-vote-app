import os
import json
import time
import secrets
from datetime import timedelta
from django.shortcuts import render, redirect
from django.conf import settings
from django.http import JsonResponse, HttpResponseForbidden
from django.utils import timezone
from django.utils.dateparse import parse_datetime
from django.db import models, transaction
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User, Group
from django.views.decorators.csrf import ensure_csrf_cookie
from django.views.decorators.http import require_http_methods
from web3 import Web3

from .models import (
    Voter,
    AuthChallenge,
    IssuedPermit,
    Election,
    ContractDeployment,
    Candidate,
    VoterEligibility,
    BallotReceipt,
    ElectionAdminAssignment,
    AdminAuditLog,
    PendingVoterOnboarding,
)
from .simple_voting import (
    SimpleVotingError, attach_contract_to_election, update_voting_window,
    lock_candidate_roster, open_election, close_election as close_simple_election,
    run_election_lifecycle_scheduler, cast_vote_for_voter, election_is_open_now,
    get_candidate_vote_count, sync_candidate,
)
from .crypto import (
    derive_voter_nullifier,
    verify_eip191_signature,
    sign_eip712_ballot_permit,
)
from .decorators import (
    role_required,
    election_permission_required,
    get_user_portal_role,
    get_user_election_role,
)
from .services import (
    load_contract_artifact,
    inspect_deployed_contract,
    deploy_election_contract,
    add_election_candidate,
    update_election_candidate,
    deactivate_election_candidate,
    sync_and_lock_candidates,
    get_election_candidates_status,
    validate_immediate_duration,
    configure_voting_window,
    activate_election,
    close_election,
    execute_automatic_lifecycle_transitions,
    get_election_lifecycle_operational_status,
    reconcile_election_results,
    authorize_result_publication,
    finalize_election,
    get_public_election_summary,
    register_voter,
    register_voters_from_multiline_text,
    register_officials_from_multiline_text,
    WIZARD_ELECTION_TYPE_CHOICES,
    compute_election_lifecycle_status,
    is_election_voting_open,
    is_election_publicly_visible,
    sync_election_lifecycle_state,
    validate_wizard_election_details,
    validate_and_store_wizard_candidate_image,
    validate_and_include_wizard_voters,
    get_included_voters_details,
    create_election_from_wizard_state,
    update_voter_record,
    bind_or_update_voter_wallet,
    assign_voter_eligibility,
    revoke_voter_eligibility,
    import_synthetic_voters_from_csv,
    get_election_voters_summary,
    validate_aadhar_format,
    validate_wallet_format,
    mask_aadhar,
    get_application_health_status,
    get_web3_provider,
    _sanitize_rpc_endpoint_label,
    BlockchainDeploymentError,
    ElectionLifecycleError,
    VoterValidationError,
    VoterEligibilityError,
)

# ==========================================
# 1. WEB3 AND SMART CONTRACT SETUP
# ==========================================
class _SettingsAwareWeb3Proxy:
    """
    Delegates Web3 access to get_web3_provider() so runtime changes to
    settings.WEB3_RPC_URL and settings.HARDHAT_BACKEND_RPC_TOKEN are honored,
    while remaining compatible with unittest.mock.patch('EVotingApp.views.w3').
    """
    def __getattr__(self, name):
        return getattr(get_web3_provider(), name)


w3 = _SettingsAwareWeb3Proxy()
contract_address = getattr(settings, 'CONTRACT_ADDRESS', '0x5FbDB2315678afecb367f032d93F642f64180aa3')

try:
    contract_abi, _, _ = load_contract_artifact()
except Exception:
    contract_abi = [
        {
            "inputs": [{"internalType": "int256", "name": "_candidate_ID", "type": "int256"}],
            "name": "getCount",
            "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
            "stateMutability": "view",
            "type": "function",
        },
        {
            "inputs": [
                {"internalType": "int256", "name": "_candidate_ID", "type": "int256"},
                {"internalType": "bytes32", "name": "_voterHash", "type": "bytes32"},
            ],
            "name": "markVote",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function",
        },
        {
            "inputs": [],
            "name": "totalVotes",
            "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
            "stateMutability": "view",
            "type": "function",
        },
    ]

try:
    _INITIAL_CONTRACT = get_web3_provider().eth.contract(
        address=Web3.to_checksum_address(contract_address),
        abi=contract_abi,
    )
    contract = _INITIAL_CONTRACT
except Exception:
    _INITIAL_CONTRACT = None
    contract = None


def get_active_contract(election=None):
    """Resolve the active Web3 contract instance for the given election or global contract_address."""
    target_addr = getattr(settings, 'CONTRACT_ADDRESS', contract_address)
    if election and election.contract_address:
        target_addr = election.contract_address
    elif contract is not None and contract is not _INITIAL_CONTRACT:
        return contract, target_addr

    if contract is not None and contract is not _INITIAL_CONTRACT:
        return contract, target_addr

    try:
        abi, _, _ = load_contract_artifact()
    except Exception:
        abi = contract_abi

    return w3.eth.contract(address=Web3.to_checksum_address(target_addr), abi=abi), target_addr


def resolve_candidate_symbol_path(symbol_text):
    """Map candidate party/symbol label to its static symbol asset."""
    sym_lower = str(symbol_text or '').strip().lower()
    if 'congress' in sym_lower:
        return '/static/symbols/congress.png', 'Congress Symbol'
    if 'bjp' in sym_lower:
        return '/static/symbols/bjp.png', 'BJP Symbol'
    if 'samajwadi' in sym_lower or 'samajvadi' in sym_lower:
        return '/static/symbols/samajvadi.png', 'Samajwadi Symbol'
    return '/static/images/images.jpg', f'{symbol_text} Symbol'


# ==========================================
# 2. BLOCKCHAIN INTERACTION FUNCTIONS
# ==========================================

def saveVote(candidate_id, voter_name, aadhar):
    """
    Legacy administrative relayer fallback vote handler.
    Uses HMAC-salted nullifiers and checks database state prior to on-chain submission.
    """
    if not w3.is_connected():
        return False, 'Blockchain Service Unavailable: Local Ethereum node is offline.'

    try:
        election = Election.objects.filter(election_id=settings.ELECTION_ID).first()
        active_contract, active_addr = get_active_contract(election)
        accounts = w3.eth.accounts
        if not accounts:
            return False, 'Blockchain Error: No unlocked relayer account available.'
        admin_account = accounts[0]

        nullifier_hex = derive_voter_nullifier(settings.ELECTION_ID, aadhar)
        voter_hash = Web3.to_bytes(hexstr=nullifier_hex)

        tx_hash = active_contract.functions.markVote(int(candidate_id), voter_hash).transact({'from': admin_account})
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
        if receipt.status != 1:
            return False, 'Blockchain Rejection: Transaction reverted on-chain.'

        with transaction.atomic():
            voter_obj = Voter.objects.select_for_update().filter(aadhar_number=str(aadhar).strip()).first()
            if voter_obj:
                voter_obj.has_voted = True
                voter_obj.voted_at = timezone.now()
                voter_obj.save(update_fields=['has_voted', 'voted_at'])
                if election:
                    VoterEligibility.objects.filter(voter=voter_obj, election=election).update(
                        has_voted=True,
                        voted_at=timezone.now(),
                    )

        return True, 'Your vote saved inside Ethereum Blockchain!'
    except Exception as e:
        error_msg = str(e)
        if "revert" in error_msg.lower() or "already" in error_msg.lower():
            return False, 'Blockchain Rejection: You have already voted'
        return False, f'Technical Error: {error_msg[:120]}'


def getVote(candidate_id):
    """
    Read candidate tally from the active smart contract.
    Raises RuntimeError if the node is unreachable instead of silently returning 0.
    """
    if not w3.is_connected():
        raise RuntimeError("Blockchain node unavailable")
    election = Election.objects.filter(election_id=settings.ELECTION_ID).first()
    active_contract, _ = get_active_contract(election)
    return active_contract.functions.getCount(int(candidate_id)).call()


# ==========================================
# 3. METAMASK WALLET & EIP-712 PERMIT APIs
# ==========================================

@require_http_methods(["GET"])
def api_wallet_challenge(request):
    raw_address = request.GET.get('address', '').strip()
    if not raw_address or not Web3.is_address(raw_address):
        return JsonResponse({'error': 'Invalid Ethereum wallet address.'}, status=400)

    checksum_address = Web3.to_checksum_address(raw_address)
    nonce = secrets.token_hex(32)
    now = timezone.now()
    expires_at = now + timedelta(seconds=getattr(settings, 'CHALLENGE_EXPIRY_SECONDS', 300))
    domain = request.get_host() or 'localhost:3000'

    challenge_text = (
        f"Decentralized E-Voting System (DVS) Authentication\n"
        f"Domain: {domain}\n"
        f"Wallet: {checksum_address}\n"
        f"Nonce: {nonce}\n"
        f"Issued At: {now.isoformat()}\n"
        f"Expires At: {expires_at.isoformat()}\n"
        f"Statement: Sign this one-time challenge to prove ownership of your wallet."
    )

    AuthChallenge.objects.create(
        wallet_address=checksum_address,
        nonce=nonce,
        domain=domain,
        challenge_text=challenge_text,
        expires_at=expires_at,
        is_used=False,
    )

    return JsonResponse({
        'address': checksum_address,
        'nonce': nonce,
        'challenge': challenge_text,
        'expires_at': expires_at.isoformat(),
    })


@require_http_methods(["POST"])
def api_wallet_verify(request):
    try:
        body = json.loads(request.body.decode('utf-8'))
    except Exception:
        return JsonResponse({'error': 'Invalid JSON payload.'}, status=400)

    raw_address = str(body.get('address', '')).strip()
    nonce = str(body.get('nonce', '')).strip()
    signature = str(body.get('signature', '')).strip()
    raw_aadhar = str(body.get('aadhar', '')).strip()

    if not raw_address or not Web3.is_address(raw_address) or not nonce or not signature:
        return JsonResponse({'error': 'Missing address, nonce, or signature.'}, status=400)

    checksum_address = Web3.to_checksum_address(raw_address)

    with transaction.atomic():
        challenge_obj = (
            AuthChallenge.objects.select_for_update()
            .filter(nonce=nonce, wallet_address__iexact=checksum_address)
            .first()
        )
        if not challenge_obj:
            return JsonResponse({'error': 'Challenge not found for this wallet.'}, status=400)

        if challenge_obj.is_used:
            return JsonResponse({'error': 'Challenge nonce has already been used.'}, status=400)

        if timezone.now() > challenge_obj.expires_at:
            return JsonResponse({'error': 'Authentication challenge has expired.'}, status=400)

        if not verify_eip191_signature(challenge_obj.challenge_text, signature, checksum_address):
            return JsonResponse({'error': 'Cryptographic signature verification failed.'}, status=401)

        challenge_obj.is_used = True
        challenge_obj.save(update_fields=['is_used'])

        bound_voter = Voter.objects.filter(bound_wallet__iexact=checksum_address, status='ACTIVE').first()
        if not bound_voter and raw_aadhar:
            try:
                clean_aadhar = validate_aadhar_format(raw_aadhar)
                candidate_voter = Voter.objects.select_for_update().filter(
                    aadhar_number=clean_aadhar,
                    status='ACTIVE',
                ).first()
                if candidate_voter and not candidate_voter.bound_wallet:
                    candidate_voter.bound_wallet = checksum_address
                    candidate_voter.save(update_fields=['bound_wallet'])
                    bound_voter = candidate_voter
            except Exception:
                pass

    now_ts = int(time.time())
    request.session['authenticated_wallet'] = checksum_address
    request.session['wallet_authenticated_at'] = now_ts
    request.session['step_up_authenticated_at'] = now_ts
    if bound_voter:
        request.session['authenticated_voter_id'] = bound_voter.pk
    if not request.session.session_key:
        request.session.save()

    return JsonResponse({
        'success': True,
        'wallet': checksum_address,
        'voter_id': bound_voter.pk if bound_voter else request.session.get('authenticated_voter_id'),
    })


@require_http_methods(["POST"])
def api_wallet_disconnect(request):
    request.session.pop('authenticated_wallet', None)
    request.session.pop('wallet_authenticated_at', None)
    request.session.pop('passkey_authenticated', None)
    request.session.pop('authenticated_voter_id', None)
    request.session.pop('step_up_authenticated_at', None)
    return JsonResponse({'success': True})


@require_http_methods(["GET"])
def api_wallet_status(request):
    wallet = request.session.get('authenticated_wallet')
    voter = _resolve_session_voter(request)
    voter_id = voter.pk if voter else request.session.get('authenticated_voter_id')
    active_passkeys = 0
    if voter:
        active_passkeys = voter.passkeys.filter(is_active=True).count()

    raw_election_id = request.GET.get('election_id')
    try:
        selected_election_id = int(raw_election_id) if raw_election_id else getattr(settings, 'ELECTION_ID', 2026)
    except (TypeError, ValueError):
        selected_election_id = getattr(settings, 'ELECTION_ID', 2026)

    election = Election.objects.filter(election_id=selected_election_id).first()
    target_chain_id = election.chain_id if election else getattr(settings, 'CHAIN_ID', 31337)
    _, active_contract_addr = get_active_contract(election)

    eligibility_info = None
    verified_receipt = None
    if voter and election:
        elig = VoterEligibility.objects.filter(voter=voter, election=election).first()
        if elig:
            is_elig = bool(elig.is_eligible)
            has_voted_el = bool(elig.has_voted)
            voted_at_val = elig.voted_at.isoformat() if elig.voted_at else None
        elif election.election_id == getattr(settings, 'ELECTION_ID', 2026):
            is_elig = True
            has_voted_el = bool(voter.has_voted)
            voted_at_val = voter.voted_at.isoformat() if voter.voted_at else None
        else:
            is_elig = False
            has_voted_el = False
            voted_at_val = None

        eligibility_info = {
            'election_id': election.election_id,
            'election_title': election.title,
            'is_eligible': is_elig,
            'has_voted': has_voted_el,
            'voted_at': voted_at_val,
        }
        if has_voted_el:
            consumed_permit = (
                IssuedPermit.objects.filter(
                    voter=voter,
                    election_id=election.election_id,
                    is_consumed_on_chain=True,
                )
                .order_by('-created_at')
                .first()
            )
            if consumed_permit:
                tx_short = (consumed_permit.tx_hash or '')[2:10].upper() or 'CONFIRMED'
                verified_receipt = {
                    'tx_hash': consumed_permit.tx_hash,
                    'block_number': consumed_permit.block_number,
                    'contract_address': consumed_permit.contract_address,
                    'election_id': election.election_id,
                    'election_title': election.title,
                    'confirmed_at': voted_at_val,
                    'receipt_reference': f"DVS-{election.election_id}-{consumed_permit.block_number or 0}-{tx_short}",
                }

    public_metamask_rpc = _sanitize_rpc_endpoint_label(
        getattr(settings, 'METAMASK_RPC_URL', None) or getattr(settings, 'WEB3_RPC_URL', 'http://127.0.0.1:8545')
    )

    return JsonResponse({
        'authenticated': bool(wallet),
        'wallet': wallet,
        'passkey_authenticated': bool(request.session.get('passkey_authenticated')),
        'step_up_fresh': is_step_up_fresh(request.session),
        'voter_id': voter_id,
        'voter_name': voter.name if voter else None,
        'aadhar_masked': mask_aadhar(voter.aadhar_number) if voter else None,
        'bound_wallet': voter.bound_wallet if voter else None,
        'active_passkeys_count': active_passkeys,
        'chain_id': target_chain_id,
        'chain_id_hex': hex(int(target_chain_id)),
        'network_name': 'Hardhat Demonstration Network',
        'rpc_url': public_metamask_rpc,
        'contract_address': active_contract_addr,
        'eligibility': eligibility_info,
        'verified_receipt': verified_receipt,
    })


@require_http_methods(["POST"])
def api_ballot_permit(request):
    wallet = request.session.get('authenticated_wallet')
    if not wallet:
        return JsonResponse(
            {'error': 'Wallet not authenticated. Please connect MetaMask and sign the challenge.'},
            status=401,
        )

    try:
        body = json.loads(request.body.decode('utf-8'))
    except Exception:
        return JsonResponse({'error': 'Invalid JSON request body.'}, status=400)

    aadhar = str(body.get('aadhar', '')).strip()
    try:
        candidate_id = int(body.get('candidate_id'))
    except (TypeError, ValueError):
        return JsonResponse({'error': 'Invalid candidate ID.'}, status=400)

    if len(aadhar) != 12 or not aadhar.isdigit():
        return JsonResponse({'error': 'Invalid 12-digit voter identification number.'}, status=400)

    election_id = int(body.get('election_id', getattr(settings, 'ELECTION_ID', 1)))
    election = Election.objects.filter(election_id=election_id).first()

    if not election:
        return JsonResponse({'error': 'Specified election not found.'}, status=404)

    sync_election_lifecycle_state(election=election)
    if election.status != 'ACTIVE' or (
        election.start_datetime and election.end_datetime and not is_election_voting_open(election)
    ):
        return JsonResponse(
            {'error': f'Election is currently {election.status} and not accepting ballots.'},
            status=403,
        )

    if not election.candidates_locked_on_chain:
        return JsonResponse(
            {'error': 'Election candidate roster is not locked on-chain.'},
            status=403,
        )

    valid_candidate_ids = set(
        election.candidates.filter(
            is_active=True,
            is_synced_on_chain=True,
        ).values_list('candidate_id_num', flat=True)
    )

    if candidate_id not in valid_candidate_ids:
        return JsonResponse(
            {'error': 'Selected candidate is not an active, synchronized candidate in this election.'},
            status=400,
        )

    active_contract, active_contract_addr = get_active_contract(election)
    nullifier_hex = derive_voter_nullifier(election_id, aadhar)

    if election.deployment_status == 'CHAIN_RESET_REDEPLOY_REQUIRED':
        return JsonResponse(
            {
                'error': 'Stale contract address detected after blockchain reset. Fresh contract redeployment is required.',
                'code': 'CHAIN_RESET_REDEPLOY_REQUIRED',
            },
            status=409,
        )

    # Check on-chain contract bytecode, Chain ID, and nullifier state if node is connected
    if w3.is_connected() and active_contract:
        has_recorded_deployment = bool(
            getattr(election, 'deployed_bytecode_hash', '') or getattr(election, 'deployment_tx_hash', '')
        )
        if has_recorded_deployment:
            try:
                live_chain_id = w3.eth.chain_id
                expected_cid = int(election.chain_id or getattr(settings, 'CHAIN_ID', 31337))
                if isinstance(live_chain_id, int) and live_chain_id != expected_cid:
                    return JsonResponse(
                        {'error': f'Chain ID mismatch: node reported {live_chain_id}, expected {expected_cid}.'},
                        status=503,
                    )
                onchain_code = w3.eth.get_code(Web3.to_checksum_address(active_contract_addr))
                if isinstance(onchain_code, (bytes, bytearray)) and len(onchain_code) == 0:
                    election.deployment_status = 'CHAIN_RESET_REDEPLOY_REQUIRED'
                    election.save(update_fields=['deployment_status', 'updated_at'])
                    return JsonResponse(
                        {
                            'error': 'Stale or missing smart contract bytecode detected on-chain (chain reset). Fresh contract redeployment is required.',
                            'code': 'CHAIN_RESET_REDEPLOY_REQUIRED',
                        },
                        status=409,
                    )
            except Exception:
                pass

        try:
            nullifier_bytes = Web3.to_bytes(hexstr=nullifier_hex)
            if active_contract.functions.hasVoted(nullifier_bytes).call():
                return JsonResponse(
                    {'error': 'On-chain verification indicates this voter has already cast a ballot.'},
                    status=409,
                )
        except Exception:
            pass

    with transaction.atomic():
        if election:
            election = Election.objects.select_for_update().get(pk=election.pk)
            sync_election_lifecycle_state(election=election)
            if election.status != 'ACTIVE' or (
                election.start_datetime and election.end_datetime and not is_election_voting_open(election)
            ):
                return JsonResponse(
                    {'error': f'Election is currently {election.status} and not accepting ballots.'},
                    status=403,
                )

        voter = Voter.objects.select_for_update().filter(aadhar_number=aadhar).first()
        if not voter:
            return JsonResponse({'error': 'Voter ID is not registered in the authorized electoral roll.'}, status=403)

        if election:
            eligibility = VoterEligibility.objects.select_for_update().filter(
                voter=voter, election=election
            ).first()
            if not eligibility and election.election_id == getattr(settings, 'ELECTION_ID', 2026):
                eligibility, _ = VoterEligibility.objects.get_or_create(
                    voter=voter,
                    election=election,
                    defaults={'is_eligible': True, 'has_voted': voter.has_voted}
                )

            if not eligibility or not eligibility.is_eligible:
                return JsonResponse({'error': 'Voter is not registered or eligible for this specific election.'}, status=403)
            if eligibility.has_voted:
                return JsonResponse({'error': 'Voter has already cast a ballot in this election.'}, status=409)
            if election.election_id == getattr(settings, 'ELECTION_ID', 2026) and voter.has_voted:
                return JsonResponse({'error': 'This voter has already cast a confirmed ballot.'}, status=409)
        else:
            if voter.has_voted:
                return JsonResponse({'error': 'This voter has already cast a confirmed ballot.'}, status=409)

        # Enforce 1-to-1 wallet-to-voter Sybil binding
        if voter.bound_wallet and voter.bound_wallet.lower() != wallet.lower():
            return JsonResponse(
                {'error': 'This voter identity is already bound to a different Ethereum wallet.'},
                status=403,
            )

        existing_wallet_owner = (
            Voter.objects.filter(bound_wallet__iexact=wallet)
            .exclude(pk=voter.pk)
            .first()
        )
        if existing_wallet_owner:
            return JsonResponse(
                {'error': 'Connected wallet is already bound to another registered voter.'},
                status=403,
            )

        voter.bound_wallet = wallet
        voter.save(update_fields=['bound_wallet'])
        request.session['authenticated_voter_id'] = voter.pk

        permit_nonce = '0x' + secrets.token_hex(32)
        deadline = int(time.time()) + getattr(settings, 'PERMIT_EXPIRY_SECONDS', 600)
        chain_id = election.chain_id if election else getattr(settings, 'CHAIN_ID', 31337)

        permit_payload = None

        # 1. Try remote authority permit signing service if available on the gateway
        bc_base_url = str(getattr(settings, 'DVS_BLOCKCHAIN_BASE_URL', '') or '').strip().rstrip('/')
        if bc_base_url and bc_base_url.startswith(('http://', 'https://')):
            remote_sign_url = f"{bc_base_url}/api/authority/sign-ballot-permit"
            try:
                sign_req_payload = json.dumps({
                    'voter_wallet': wallet,
                    'candidate_id': int(candidate_id),
                    'voter_nullifier': nullifier_hex,
                    'deadline': int(deadline),
                    'nonce': permit_nonce,
                }).encode('utf-8')
                s_req = urllib.request.Request(
                    remote_sign_url,
                    data=sign_req_payload,
                    headers={'Content-Type': 'application/json', 'Accept': 'application/json'},
                    method='POST',
                )
                with urllib.request.urlopen(s_req, timeout=5) as s_resp:
                    if s_resp.getcode() == 200:
                        s_data = json.loads(s_resp.read().decode('utf-8'))
                        if s_data.get('status') == 'success' and 'v' in s_data:
                            permit_payload = {
                                'v': s_data['v'],
                                'r': s_data['r'],
                                's': s_data['s'],
                                'signer': s_data.get('signer'),
                                'voter_wallet': wallet,
                                'candidate_id': candidate_id,
                                'election_id': election_id,
                                'voter_nullifier': nullifier_hex,
                                'deadline': deadline,
                                'nonce': permit_nonce,
                                'contract_address': active_contract_addr,
                                'chain_id': chain_id,
                            }
            except Exception:
                pass

        # 2. Local signing fallback if remote signing was not used or failed
        if not permit_payload:
            signing_authority_key = getattr(settings, 'ELECTION_AUTHORITY_PRIVATE_KEY', None)
            if not signing_authority_key:
                return JsonResponse({'error': 'Election Authority private key not configured.'}, status=500)

            if election and election.authority_address:
                from eth_account import Account
                from EVoting.settings import DEV_DEFAULT_AUTHORITY_PRIVATE_KEY
                derived_current = Account.from_key(signing_authority_key).address
                if derived_current.lower() != election.authority_address.lower():
                    # If using rotated demonstration authority and settings has default dev key, check rotated key
                    used_rotated = False
                    if signing_authority_key.lower() == DEV_DEFAULT_AUTHORITY_PRIVATE_KEY.lower():
                        try:
                            from .hardhat_demo import get_rotated_demo_private_key
                            rot_key = get_rotated_demo_private_key('election_authority')
                            if Account.from_key(rot_key).address.lower() == election.authority_address.lower():
                                signing_authority_key = rot_key
                                used_rotated = True
                        except Exception:
                            pass
                    if not used_rotated:
                        return JsonResponse(
                            {
                                'error': 'Election Authority signing key does not match the election contract authority address.',
                            },
                            status=500,
                        )

            permit_payload = sign_eip712_ballot_permit(
                voter_wallet=wallet,
                candidate_id=candidate_id,
                election_id=election_id,
                voter_nullifier=nullifier_hex,
                deadline=deadline,
                nonce=permit_nonce,
                chain_id=chain_id,
                contract_address=active_contract_addr,
                authority_private_key=signing_authority_key,
            )

        active_dep = None
        if election:
            active_dep = ContractDeployment.objects.filter(
                election=election,
                contract_address__iexact=active_contract_addr,
                is_active_deployment=True,
            ).first()

        IssuedPermit.objects.create(
            permit_nonce=permit_nonce,
            voter=voter,
            election_ref=election,
            deployment_ref=active_dep,
            candidate_id=candidate_id,
            election_id=election_id,
            voter_nullifier=nullifier_hex,
            deadline=deadline,
            contract_address=active_contract_addr,
            is_consumed_on_chain=False,
            is_historical_legacy=False,
        )

    return JsonResponse({
        'success': True,
        'permit': permit_payload,
    })


@require_http_methods(["POST"])
def api_confirm_vote(request):
    try:
        body = json.loads(request.body.decode('utf-8'))
    except Exception:
        return JsonResponse({'error': 'Invalid JSON payload.'}, status=400)

    tx_hash = str(body.get('tx_hash', '')).strip()
    nullifier_hex = str(body.get('nullifier', '')).strip()
    permit_nonce = str(body.get('permit_nonce', '')).strip()

    if not tx_hash or not nullifier_hex:
        return JsonResponse({'error': 'Missing transaction hash or nullifier.'}, status=400)

    if not w3.is_connected():
        return JsonResponse({'error': 'Blockchain RPC node is unavailable.'}, status=503)

    if permit_nonce:
        permit_obj = IssuedPermit.objects.filter(permit_nonce=permit_nonce).first()
        if not permit_obj:
            return JsonResponse({'error': 'Specified permit nonce not found.'}, status=400)
        if permit_obj.is_historical_legacy:
            return JsonResponse(
                {'error': 'Historical permit from a superseded contract cannot be used on the replacement contract.'},
                status=400,
            )
    else:
        permit_obj = (
            IssuedPermit.objects.filter(voter_nullifier=nullifier_hex, is_historical_legacy=False)
            .order_by('-created_at')
            .first()
        )
        if not permit_obj:
            if IssuedPermit.objects.filter(voter_nullifier=nullifier_hex, is_historical_legacy=True).exists():
                return JsonResponse(
                    {'error': 'Historical permit from a superseded contract cannot be used on the replacement contract.'},
                    status=400,
                )

    election = (
        permit_obj.election_ref
        if (permit_obj and permit_obj.election_ref)
        else Election.objects.filter(election_id=settings.ELECTION_ID).first()
    )
    active_contract, active_contract_addr = get_active_contract(election)

    if permit_obj:
        if permit_obj.is_consumed_on_chain:
            return JsonResponse({'error': 'This ballot permit has already been confirmed and consumed.'}, status=409)
        if permit_obj.contract_address and permit_obj.contract_address.lower() != active_contract_addr.lower():
            return JsonResponse(
                {'error': 'Permit contract address does not match the active election contract.'},
                status=400,
            )

    clean_tx_hash = tx_hash if tx_hash.startswith('0x') else '0x' + tx_hash
    if IssuedPermit.objects.filter(tx_hash__iexact=clean_tx_hash, is_consumed_on_chain=True).exists():
        return JsonResponse({'error': 'Transaction hash has already been recorded for a confirmed vote.'}, status=409)

    try:
        receipt = w3.eth.get_transaction_receipt(clean_tx_hash)
    except Exception as e:
        return JsonResponse({'error': f'Could not fetch transaction receipt: {str(e)}'}, status=400)

    if not receipt or receipt.status != 1:
        return JsonResponse({'error': 'Transaction failed or reverted on-chain.'}, status=400)

    receipt_to = (receipt.get('to') or '').lower()
    if receipt_to != active_contract_addr.lower():
        return JsonResponse(
            {'error': 'Transaction was not submitted to the active election smart contract.'},
            status=400,
        )

    # Verify VoteCast event in the transaction receipt
    try:
        events = active_contract.events.VoteCast().process_receipt(receipt)
    except Exception:
        events = []

    matching_event = None
    for ev in events:
        if (ev.get('address') or '').lower() != active_contract_addr.lower():
            continue
        ev_nullifier = '0x' + ev['args']['voterNullifier'].hex().lower()
        if ev_nullifier == nullifier_hex.lower():
            if permit_obj and int(ev['args']['candidateId']) != int(permit_obj.candidate_id):
                return JsonResponse({'error': 'On-chain VoteCast candidateId does not match issued permit.'}, status=400)
            if election and int(ev['args']['electionId']) != int(election.election_id):
                return JsonResponse({'error': 'On-chain VoteCast electionId does not match election.'}, status=400)
            matching_event = ev
            break

    if not matching_event:
        return JsonResponse({'error': 'No matching VoteCast event found in transaction receipt.'}, status=400)

    nullifier_bytes = Web3.to_bytes(hexstr=nullifier_hex)
    if not active_contract.functions.hasVoted(nullifier_bytes).call():
        return JsonResponse({'error': 'Nullifier was not marked as voted on the smart contract.'}, status=400)

    now = timezone.now()
    with transaction.atomic():
        if permit_obj:
            permit_obj.is_consumed_on_chain = True
            permit_obj.tx_hash = clean_tx_hash
            permit_obj.block_number = receipt.blockNumber
            permit_obj.contract_address = active_contract_addr
            permit_obj.save(update_fields=['is_consumed_on_chain', 'tx_hash', 'block_number', 'contract_address'])

            voter = Voter.objects.select_for_update().get(pk=permit_obj.voter_id)
            if not election or election.election_id == getattr(settings, 'ELECTION_ID', 2026):
                voter.has_voted = True
                voter.voted_at = now
                voter.save(update_fields=['has_voted', 'voted_at'])

            if election:
                VoterEligibility.objects.filter(voter=voter, election=election).update(
                    has_voted=True,
                    voted_at=now,
                )

    el_id_num = election.election_id if election else getattr(settings, 'ELECTION_ID', 2026)
    el_title = election.title if election else 'Civic Election'
    tx_short = clean_tx_hash[2:10].upper()

    return JsonResponse({
        'success': True,
        'tx_hash': clean_tx_hash,
        'block_number': receipt.blockNumber,
        'contract_address': active_contract_addr,
        'election_id': el_id_num,
        'election_title': el_title,
        'confirmed_at': now.isoformat(),
        'receipt_reference': f"DVS-{el_id_num}-{receipt.blockNumber}-{tx_short}",
    })


# ==========================================
# 4. MODULE 3 & MODULE 4 PUBLIC & CONTROL ENDPOINTS
# ==========================================

@ensure_csrf_cookie
@require_http_methods(["GET"])
def health_check_view(request):
    """
    Lightweight operational health-check endpoint at /healthz/ and /api/health/.
    Reports application availability, database connectivity, and configuration validity
    without exposing any private keys, credentials, or RPC tokens.
    """
    report = get_application_health_status(check_blockchain=True)
    http_code = report.pop('http_status', 200)
    return JsonResponse(report, status=http_code)


@ensure_csrf_cookie
@require_http_methods(["GET"])
def public_elections_view(request):
    """Public election listing endpoint at /public/elections/."""
    now = timezone.now()
    sync_election_lifecycle_state(now=now)
    elections = [
        el for el in Election.objects.exclude(status='DRAFT').order_by('-created_at')
        if is_election_publicly_visible(el, now=now)
    ]
    summaries = [get_public_election_summary(el) for el in elections]
    return JsonResponse({'elections': summaries})


@ensure_csrf_cookie
@require_http_methods(["GET"])
def api_public_elections(request):
    now = timezone.now()
    sync_election_lifecycle_state(now=now)
    elections = [
        el for el in Election.objects.exclude(status='DRAFT').order_by('-created_at')
        if is_election_publicly_visible(el, now=now)
    ]
    summaries = [get_public_election_summary(el) for el in elections]
    return JsonResponse({'elections': summaries})


@ensure_csrf_cookie
@require_http_methods(["GET"])
def api_public_election_detail(request, election_id):
    now = timezone.now()
    sync_election_lifecycle_state(now=now)
    election = (
        Election.objects.filter(election_id=election_id).first()
        or Election.objects.filter(pk=election_id).first()
    )
    if not election:
        return JsonResponse({'error': 'Election not found.'}, status=404)
    if not is_election_publicly_visible(election, now=now) and not (
        request.user.is_authenticated and request.user.is_superuser
    ):
        return JsonResponse({'error': 'Election is not currently available.'}, status=404)
    return JsonResponse(get_public_election_summary(election))


PORTAL_ROLE_LABELS = {
    'SUPER_ADMIN': 'Super Administrator',
    'ELECTION_ADMIN': 'Election Administrator',
    'ELECTION_WORKER': 'Election Worker',
    'AUDITOR': 'Election Auditor (Read-Only)',
}


def _get_accessible_elections_for_user(user, portal_role):
    """Return QuerySet of Elections the authenticated staff user is authorized to view."""
    if portal_role == 'SUPER_ADMIN':
        return Election.objects.all().order_by('-created_at')
    if portal_role == 'AUDITOR' and user.groups.filter(name='Auditor').exists():
        return Election.objects.all().order_by('-created_at')
    assigned_ids = ElectionAdminAssignment.objects.filter(user=user).values_list('election_id', flat=True)
    return Election.objects.filter(pk__in=assigned_ids).order_by('-created_at')


def _build_control_portal_context(request, extra_context=None):
    """
    Build the complete server-verified context for the Standalone Administration Portal (/control/).
    Adapts navigation, capabilities, and metrics to the authenticated user's role and assigned elections.
    """
    user = request.user
    portal_role = get_user_portal_role(user)
    portal_role_label = PORTAL_ROLE_LABELS.get(portal_role, 'Staff Member')

    accessible_qs = _get_accessible_elections_for_user(user, portal_role)
    accessible_elections = list(accessible_qs)

    raw_selected_id = request.GET.get('election_id')
    selected_election = None
    if raw_selected_id and str(raw_selected_id).isdigit():
        req_id = int(raw_selected_id)
        for el in accessible_elections:
            if el.election_id == req_id or el.pk == req_id:
                selected_election = el
                break
    if not selected_election and accessible_elections:
        selected_election = accessible_elections[0]

    effective_election_role = get_user_election_role(user, selected_election) if selected_election else portal_role
    effective_election_role_label = PORTAL_ROLE_LABELS.get(effective_election_role, portal_role_label)

    # Platform-level summary counts across accessible elections
    total_elections = len(accessible_elections)
    active_elections_count = sum(1 for el in accessible_elections if el.status == 'ACTIVE')
    scheduled_elections_count = sum(1 for el in accessible_elections if el.status == 'SCHEDULED')
    completed_elections_count = sum(1 for el in accessible_elections if el.status in ('CLOSED', 'FINALIZED'))
    draft_elections_count = sum(1 for el in accessible_elections if el.status == 'DRAFT')

    # Real operational alerts derived from database state
    operational_alerts = []
    for el in accessible_elections:
        if el.status == 'DRAFT' and el.deployment_status == 'NOT_DEPLOYED':
            operational_alerts.append({
                'level': 'info',
                'election_id': el.election_id,
                'message': f"Election #{el.election_id} ({el.title}) is in Draft state and requires preparation before activation.",
            })
        elif el.deployment_status == 'DEPLOYMENT_FAILED':
            operational_alerts.append({
                'level': 'error',
                'election_id': el.election_id,
                'message': f"Election #{el.election_id} ({el.title}) encountered a preparation failure and requires recovery.",
            })
        elif getattr(el, 'auto_transition_last_error', None):
            operational_alerts.append({
                'level': 'error',
                'election_id': el.election_id,
                'message': f"Election #{el.election_id} ({el.title}) automated lifecycle error: {el.auto_transition_last_error}",
            })
        elif el.status == 'CLOSED' and not el.results_verified:
            operational_alerts.append({
                'level': 'warning',
                'election_id': el.election_id,
                'message': f"Election #{el.election_id} ({el.title}) is closed and awaiting tally reconciliation.",
            })

    pending_onboarding_qs = PendingVoterOnboarding.objects.filter(status='PENDING_REVIEW')
    if selected_election and portal_role != 'SUPER_ADMIN':
        pending_onboarding_qs = pending_onboarding_qs.filter(
            models.Q(target_election=selected_election) | models.Q(target_election__isnull=True)
        )
    pending_onboarding_count = pending_onboarding_qs.count()
    if pending_onboarding_count > 0:
        operational_alerts.append({
            'level': 'warning',
            'election_id': selected_election.election_id if selected_election else None,
            'message': f"{pending_onboarding_count} identity verification record(s) are awaiting administrative review.",
        })

    selected_summary = _build_public_election_context(selected_election) if selected_election else None
    selected_lifecycle_operational = (
        get_election_lifecycle_operational_status(selected_election)
        if selected_election else None
    )
    selected_stats = None
    if selected_election:
        total_reg = VoterEligibility.objects.filter(election=selected_election).count()
        eligible_cnt = VoterEligibility.objects.filter(election=selected_election, is_eligible=True).count()
        voted_cnt = VoterEligibility.objects.filter(election=selected_election, has_voted=True).count()
        cand_cnt = Candidate.objects.filter(election=selected_election, is_active=True).count()
        synced_cand_cnt = Candidate.objects.filter(election=selected_election, is_active=True, is_synced_on_chain=True).count()
        selected_stats = {
            'registered_voters': total_reg,
            'eligible_voters': eligible_cnt,
            'confirmed_votes': voted_cnt,
            'active_candidates': cand_cnt,
            'synced_candidates': synced_cand_cnt,
            'pending_onboarding': pending_onboarding_count,
        }

    staff_users = []
    staff_assignments = []
    if portal_role == 'SUPER_ADMIN':
        for u in User.objects.all().order_by('username'):
            u_groups = list(u.groups.values_list('name', flat=True))
            u_role = get_user_portal_role(u)
            if u_role or u.is_staff or u.is_superuser:
                staff_users.append({
                    'id': u.pk,
                    'username': u.username,
                    'is_superuser': u.is_superuser,
                    'groups': u_groups,
                    'portal_role': u_role or 'STAFF',
                    'portal_role_label': PORTAL_ROLE_LABELS.get(u_role, 'Staff Member'),
                })
        for asgn in ElectionAdminAssignment.objects.select_related('election', 'user').order_by('-assigned_at'):
            staff_assignments.append({
                'id': asgn.pk,
                'election_id': asgn.election.election_id,
                'election_title': asgn.election.title,
                'user_id': asgn.user.pk,
                'username': asgn.user.username,
                'role': asgn.role,
                'role_label': dict(ElectionAdminAssignment.ROLE_CHOICES).get(asgn.role, asgn.role),
                'assigned_at': asgn.assigned_at,
            })

    is_superuser_admin = bool(user.is_superuser)
    requested_section = (
        request.GET.get('section')
        or request.POST.get('section')
        or ''
    ).strip().lower()
    if requested_section in ('create-elections', 'voters', 'officials'):
        active_admin_section = requested_section
    else:
        active_admin_section = 'create-elections' if is_superuser_admin else 'voters'

    registered_voters = list(Voter.objects.all().order_by('-created_at', '-id'))
    registered_officials = []
    wizard_step = 1
    wizard_details = {}
    wizard_candidates = []
    wizard_included_voters = []
    if is_superuser_admin:
        officials_qs = (
            User.objects.filter(is_superuser=False)
            .exclude(groups__name='Super Admin')
            .filter(
                models.Q(is_staff=True)
                | models.Q(groups__name__in=['Election Administrator', 'Election Worker', 'Auditor'])
            )
            .distinct()
            .order_by('-date_joined', '-id')
        )
        for u in officials_qs:
            registered_officials.append({
                'id': u.pk,
                'official_id': u.username,
                'name': u.first_name or u.get_full_name() or u.username,
            })

        wizard_state = _get_or_init_create_election_wizard(request)
        wizard_step = int(wizard_state.get('step', 1) or 1)
        wizard_details = dict(wizard_state.get('details') or {})
        wizard_candidates = list(wizard_state.get('candidates') or [])
        wizard_included_voters = get_included_voters_details(wizard_state.get('included_voter_ids') or [])

    ctx = {
        'portal_role': portal_role,
        'portal_role_label': portal_role_label,
        'effective_election_role': effective_election_role,
        'effective_election_role_label': effective_election_role_label,
        'can_manage_platform': is_superuser_admin,
        'can_write_election': effective_election_role in ('SUPER_ADMIN', 'ELECTION_ADMIN'),
        'can_worker_assist': effective_election_role in ('SUPER_ADMIN', 'ELECTION_ADMIN', 'ELECTION_WORKER'),
        'is_read_only_auditor': effective_election_role == 'AUDITOR',
        'active_admin_section': active_admin_section,
        'registered_voters': registered_voters,
        'registered_voters_count': len(registered_voters),
        'registered_officials': registered_officials,
        'registered_officials_count': len(registered_officials),
        'wizard_step': wizard_step,
        'wizard_details': wizard_details,
        'wizard_candidates': wizard_candidates,
        'wizard_candidates_count': len(wizard_candidates),
        'wizard_included_voters': wizard_included_voters,
        'wizard_included_voters_count': len(wizard_included_voters),
        'election_type_choices': WIZARD_ELECTION_TYPE_CHOICES,
        'accessible_elections': accessible_elections,
        'selected_election': selected_election,
        'selected_summary': selected_summary,
        'selected_lifecycle_operational': selected_lifecycle_operational,
        'selected_stats': selected_stats,
        'total_elections': total_elections,
        'active_elections_count': active_elections_count,
        'scheduled_elections_count': scheduled_elections_count,
        'completed_elections_count': completed_elections_count,
        'draft_elections_count': draft_elections_count,
        'pending_onboarding_count': pending_onboarding_count,
        'operational_alerts': operational_alerts,
        'staff_users': staff_users,
        'staff_assignments': staff_assignments,
        'blockchain_info': {
            'base_url': '',
            'web3_rpc_url': _sanitize_rpc_endpoint_label(getattr(settings, 'WEB3_RPC_URL', '')),
            'metamask_rpc_url': getattr(settings, 'METAMASK_RPC_URL', ''),
            'chain_id': getattr(settings, 'CHAIN_ID', 31337),
            'contract_address': selected_election.contract_address if (selected_election and selected_election.contract_address) else getattr(settings, 'DVS_CONTRACT_ADDRESS', ''),
        },
    }
    if extra_context:
        ctx.update(extra_context)
    return ctx


def _get_or_init_create_election_wizard(request):
    """Retrieve or initialize the 4-step Create Elections wizard state in request.session."""
    default_state = {
        'step': 1,
        'details': {
            'title': '',
            'description': '',
            'election_type': 'ELECTION',
            'election_type_label': dict(WIZARD_ELECTION_TYPE_CHOICES).get('ELECTION', 'Election'),
            'start_datetime_iso': '',
            'end_datetime_iso': '',
            'start_datetime_input': '',
            'end_datetime_input': '',
        },
        'candidates': [],
        'included_voter_ids': [],
    }
    state = request.session.get('create_election_wizard')
    if not isinstance(state, dict):
        request.session['create_election_wizard'] = default_state
        request.session.modified = True
        return default_state

    if 'step' not in state or state['step'] not in (1, 2, 3, 4):
        state['step'] = 1
    if not isinstance(state.get('details'), dict):
        state['details'] = dict(default_state['details'])
    if not isinstance(state.get('candidates'), list):
        state['candidates'] = []
    if not isinstance(state.get('included_voter_ids'), list):
        state['included_voter_ids'] = []
    return state


def _handle_create_election_wizard_post(request):
    """
    Process POST actions for the 4-step Create Elections wizard.
    Returns (redirect_response_or_None, extra_context_dict).
    """
    wizard_state = _get_or_init_create_election_wizard(request)
    action = str(request.POST.get('wizard_action') or '').strip()
    extra_ctx = {'active_admin_section': 'create-elections'}

    if action == 'go_back':
        current_step = int(wizard_state.get('step', 1) or 1)
        raw_target = request.POST.get('target_step')
        if raw_target and str(raw_target).isdigit():
            target_step = max(1, min(4, int(raw_target)))
        else:
            target_step = max(1, current_step - 1)
        wizard_state['step'] = target_step
        request.session['create_election_wizard'] = wizard_state
        request.session.modified = True
        return None, extra_ctx

    if action == 'step1_next':
        raw_title = request.POST.get('election_title', '')
        raw_desc = request.POST.get('election_description', '')
        raw_type = request.POST.get('election_type', 'ELECTION')
        raw_start = request.POST.get('start_datetime', '')
        raw_end = request.POST.get('end_datetime', '')

        type_map = dict(WIZARD_ELECTION_TYPE_CHOICES)
        clean_raw_type = str(raw_type or 'ELECTION').strip().upper()
        wizard_state['details'] = {
            'title': str(raw_title or '').strip(),
            'description': str(raw_desc or '').strip(),
            'election_type': clean_raw_type,
            'election_type_label': type_map.get(clean_raw_type, 'Election'),
            'start_datetime_iso': '',
            'end_datetime_iso': '',
            'start_datetime_input': str(raw_start or '').strip(),
            'end_datetime_input': str(raw_end or '').strip(),
        }
        try:
            validated = validate_wizard_election_details(
                title=raw_title,
                description=raw_desc,
                election_type=raw_type,
                start_datetime_raw=raw_start,
                end_datetime_raw=raw_end,
            )
            wizard_state['details'] = validated
            wizard_state['step'] = 2
        except ElectionLifecycleError as exc:
            wizard_state['step'] = 1
            extra_ctx['wizard_error'] = str(exc)

        request.session['create_election_wizard'] = wizard_state
        request.session.modified = True
        return None, extra_ctx

    if action == 'add_candidate':
        wizard_state['step'] = 2
        c_name = str(request.POST.get('candidate_name') or '').strip()
        c_party = str(request.POST.get('candidate_party') or '').strip()
        uploaded_file = request.FILES.get('candidate_symbol_image') if request.FILES else None

        try:
            if not c_name:
                raise ElectionLifecycleError('Candidate name is required.')
            if len(c_name) > 150:
                raise ElectionLifecycleError('Candidate name cannot exceed 150 characters.')
            if not c_party:
                raise ElectionLifecycleError('Party name is required.')
            if len(c_party) > 100:
                raise ElectionLifecycleError('Party name cannot exceed 100 characters.')
            saved_name, saved_url = validate_and_store_wizard_candidate_image(uploaded_file)
            wizard_state['candidates'].append({
                'name': c_name,
                'party': c_party,
                'symbol_image_name': saved_name,
                'symbol_image_url': saved_url,
            })
            extra_ctx['wizard_success'] = f"Candidate '{c_name}' ({c_party}) added."
        except ElectionLifecycleError as exc:
            extra_ctx['wizard_error'] = str(exc)
            extra_ctx['candidate_name_input'] = c_name
            extra_ctx['candidate_party_input'] = c_party

        request.session['create_election_wizard'] = wizard_state
        request.session.modified = True
        return None, extra_ctx

    if action == 'remove_candidate':
        wizard_state['step'] = 2
        raw_idx = request.POST.get('remove_candidate_index', '')
        if str(raw_idx).isdigit():
            idx = int(raw_idx)
            if 0 <= idx < len(wizard_state['candidates']):
                removed = wizard_state['candidates'].pop(idx)
                extra_ctx['wizard_success'] = f"Removed candidate '{removed.get('name', '')}'."
        request.session['create_election_wizard'] = wizard_state
        request.session.modified = True
        return None, extra_ctx

    if action == 'step2_next':
        c_name = str(request.POST.get('candidate_name') or '').strip()
        c_party = str(request.POST.get('candidate_party') or '').strip()
        uploaded_file = request.FILES.get('candidate_symbol_image') if request.FILES else None

        if c_name or c_party or uploaded_file:
            try:
                if not c_name:
                    raise ElectionLifecycleError('Candidate name is required.')
                if len(c_name) > 150:
                    raise ElectionLifecycleError('Candidate name cannot exceed 150 characters.')
                if not c_party:
                    raise ElectionLifecycleError('Party name is required.')
                if len(c_party) > 100:
                    raise ElectionLifecycleError('Party name cannot exceed 100 characters.')
                saved_name, saved_url = validate_and_store_wizard_candidate_image(uploaded_file)
                wizard_state['candidates'].append({
                    'name': c_name,
                    'party': c_party,
                    'symbol_image_name': saved_name,
                    'symbol_image_url': saved_url,
                })
            except ElectionLifecycleError as exc:
                wizard_state['step'] = 2
                extra_ctx['wizard_error'] = str(exc)
                extra_ctx['candidate_name_input'] = c_name
                extra_ctx['candidate_party_input'] = c_party
                request.session['create_election_wizard'] = wizard_state
                request.session.modified = True
                return None, extra_ctx

        if not wizard_state.get('candidates'):
            wizard_state['step'] = 2
            extra_ctx['wizard_error'] = 'Add at least one candidate with a party name and symbol image before proceeding.'
        else:
            wizard_state['step'] = 3

        request.session['create_election_wizard'] = wizard_state
        request.session.modified = True
        return None, extra_ctx

    if action == 'include_voters':
        wizard_state['step'] = 3
        raw_voters_text = request.POST.get('included_voters_input', '')
        voter_result = validate_and_include_wizard_voters(
            raw_voters_text,
            existing_included_ids=wizard_state.get('included_voter_ids', []),
        )
        wizard_state['included_voter_ids'] = voter_result['updated_included_ids']
        extra_ctx['wizard_voter_submission_result'] = voter_result
        extra_ctx['included_voters_input_value'] = (
            raw_voters_text if voter_result['rejected_count'] > 0 else ''
        )
        request.session['create_election_wizard'] = wizard_state
        request.session.modified = True
        return None, extra_ctx

    if action == 'step3_next':
        raw_voters_text = request.POST.get('included_voters_input', '')
        if str(raw_voters_text or '').strip():
            voter_result = validate_and_include_wizard_voters(
                raw_voters_text,
                existing_included_ids=wizard_state.get('included_voter_ids', []),
            )
            wizard_state['included_voter_ids'] = voter_result['updated_included_ids']
            extra_ctx['wizard_voter_submission_result'] = voter_result
            if voter_result['rejected_count'] > 0:
                wizard_state['step'] = 3
                extra_ctx['included_voters_input_value'] = raw_voters_text
                request.session['create_election_wizard'] = wizard_state
                request.session.modified = True
                return None, extra_ctx

        if not wizard_state.get('included_voter_ids'):
            wizard_state['step'] = 3
            extra_ctx['wizard_error'] = 'Include at least one registered 12-digit voter before proceeding to review.'
        else:
            wizard_state['step'] = 4

        request.session['create_election_wizard'] = wizard_state
        request.session.modified = True
        return None, extra_ctx

    if action == 'create_election':
        try:
            election = create_election_from_wizard_state(
                wizard_state=wizard_state,
                actor_user=request.user,
            )
            request.session.pop('create_election_wizard', None)
            request.session.modified = True
            messages.success(
                request,
                f"Election '{election.title}' has been created successfully.",
            )
            return redirect('election_detail_page', election_id=election.election_id), extra_ctx
        except (ElectionLifecycleError, VoterEligibilityError, VoterValidationError) as exc:
            wizard_state['step'] = 4
            extra_ctx['wizard_error'] = str(exc)
            request.session['create_election_wizard'] = wizard_state
            request.session.modified = True
            return None, extra_ctx

    return None, extra_ctx


@require_http_methods(["GET", "POST"])
def control_portal_view(request):
    """Custom administration namespace /control/ (avoids conflict with Django's built-in /admin/)."""
    if not request.user.is_authenticated:
        if request.method == 'POST':
            return HttpResponseForbidden(
                '<h1>403 Forbidden</h1><p>Authentication is required to access the administration portal.</p>'
            )
        return redirect('Admin')

    portal_role = get_user_portal_role(request.user)
    is_authorized_admin = bool(
        request.user.is_superuser
        or portal_role in ('SUPER_ADMIN', 'ELECTION_ADMIN')
    )
    if not is_authorized_admin:
        return HttpResponseForbidden(
            '<h1>403 Forbidden</h1><p>You do not have administrative permission to access this page.</p>'
        )

    is_superuser_admin = bool(request.user.is_superuser)
    requested_section = (
        request.GET.get('section')
        or request.POST.get('section')
        or ''
    ).strip().lower()
    target_section = requested_section or (
        'create-elections' if 'wizard_action' in request.POST
        else ('officials' if 'officials_input' in request.POST else ('voters' if 'voters_input' in request.POST else ''))
    )
    if (requested_section in ('create-elections', 'officials') or target_section in ('create-elections', 'officials')) and not is_superuser_admin:
        return HttpResponseForbidden(
            '<h1>403 Forbidden</h1><p>You do not have permission to access this administrative section.</p>'
        )

    extra_ctx = {'data': f'Welcome Admin ({request.user.username})'}
    if request.method == 'POST':
        if target_section == 'create-elections':
            redirect_resp, wizard_extra = _handle_create_election_wizard_post(request)
            if redirect_resp is not None:
                return redirect_resp
            extra_ctx.update(wizard_extra)
        elif target_section == 'voters':
            raw_voters_input = request.POST.get('voters_input', '')
            submission_result = register_voters_from_multiline_text(
                raw_voters_input,
                actor_user=request.user,
            )
            preserved_input = (
                raw_voters_input
                if submission_result['rejected_count'] > 0
                else ''
            )
            extra_ctx['active_admin_section'] = 'voters'
            extra_ctx['voter_submission_result'] = submission_result
            extra_ctx['voters_input_value'] = preserved_input
        elif target_section == 'officials':
            raw_officials_input = request.POST.get('officials_input', '')
            submission_result = register_officials_from_multiline_text(
                raw_officials_input,
                actor_user=request.user,
            )
            preserved_input = (
                raw_officials_input
                if submission_result['rejected_count'] > 0
                else ''
            )
            extra_ctx['active_admin_section'] = 'officials'
            extra_ctx['official_submission_result'] = submission_result
            extra_ctx['officials_input_value'] = preserved_input

    ctx = _build_control_portal_context(request, extra_ctx)
    return render(request, 'AdminScreen.html', ctx)


@require_http_methods(["GET", "POST"])
def control_official_delete_view(request, user_id):
    """
    POST /control/officials/<user_id>/delete/
    Deletes a managed regular election official account.
    Strictly restricted to authenticated Django superusers and protects all superuser accounts.
    """
    if not request.user.is_authenticated:
        if request.method == 'POST':
            return HttpResponseForbidden(
                '<h1>403 Forbidden</h1><p>Authentication is required to access the administration portal.</p>'
            )
        return redirect('Admin')

    if not request.user.is_superuser:
        return HttpResponseForbidden(
            '<h1>403 Forbidden</h1><p>You do not have permission to manage election officials.</p>'
        )

    if request.method != 'POST':
        return HttpResponseForbidden(
            '<h1>403 Forbidden</h1><p>Deletion requires a POST request.</p>'
        )

    with transaction.atomic():
        target_user = User.objects.select_for_update().filter(pk=user_id).first()
        if not target_user:
            return HttpResponseForbidden(
                '<h1>404 Not Found</h1><p>The specified official account does not exist.</p>'
            )

        remaining_superusers = (
            User.objects.filter(is_superuser=True, is_active=True)
            .exclude(pk=target_user.pk)
            .count()
        )
        if (
            target_user.pk == request.user.pk
            or target_user.is_superuser
            or target_user.groups.filter(name='Super Admin').exists()
            or remaining_superusers < 1
        ):
            return HttpResponseForbidden(
                '<h1>403 Forbidden</h1><p>Superuser accounts cannot be deleted through this interface.</p>'
            )

        deleted_official_id = target_user.username
        deleted_name = target_user.first_name or target_user.username
        target_user.delete()
        AdminAuditLog.objects.create(
            actor=request.user,
            action='OFFICIAL_ACCOUNT_DELETED',
            target_model='User',
            target_id=str(user_id),
            details=json.dumps({
                'official_id': deleted_official_id,
                'name': deleted_name,
            }),
            ip_address=request.META.get('REMOTE_ADDR'),
        )

    return redirect('/control/?section=officials')


@election_permission_required(action='read')
def api_control_election_audit(request, election_id):
    election = request.election
    summary = get_public_election_summary(election)
    inspection = {}
    if election.contract_address:
        try:
            live_w3, live_contract = __import__('EVotingApp.simple_voting', fromlist=['get_contract']).get_contract(election)
            inspection = {
                'connected': True, 'chain_id': int(live_w3.eth.chain_id),
                'contract_address': election.contract_address,
                'owner': live_contract.functions.owner().call(),
                'total_votes': int(live_contract.functions.totalVotes().call()),
            }
        except Exception as exc:
            inspection = {'connected': False, 'error': str(exc)[:240]}
    recent_logs = list(
        AdminAuditLog.objects.filter(target_model='Election', target_id=str(election.pk))
        .order_by('-timestamp')[:25]
        .values('action', 'actor__username', 'details', 'timestamp')
    )
    return JsonResponse({'election': summary, 'onchain_inspection': inspection, 'audit_logs': recent_logs})


@require_http_methods(["POST"])
@election_permission_required(action='write')
def api_control_deploy_election(request, election_id):
    """Attach a contract deployed from Remix to the selected election."""
    election = request.election
    try:
        body = json.loads(request.body.decode('utf-8')) if request.body else {}
        address = (body.get('contract_address') or getattr(settings, 'DVS_CONTRACT_ADDRESS', '') or '').strip()
        address = attach_contract_to_election(election, address)
        AdminAuditLog.objects.create(
            actor=request.user, action='CONTRACT_ATTACHED', target_model='Election',
            target_id=str(election.pk), details=json.dumps({'contract_address': address, 'chain_id': election.chain_id})
        )
        return JsonResponse({
            'success': True, 'contract_address': address, 'chain_id': election.chain_id,
            'deployment_status': election.deployment_status,
            'candidates_synced': election.candidates.filter(is_active=True, is_synced_on_chain=True).count(),
        })
    except (SimpleVotingError, ValueError) as exc:
        return JsonResponse({'error': str(exc)}, status=400)
    except Exception as exc:
        return JsonResponse({'error': f'Contract attachment failed: {str(exc)[:240]}'}, status=400)


@require_http_methods(["GET", "POST"])
@election_permission_required(action='read')
def api_control_candidates(request, election_id):
    election = request.election
    if request.method == 'GET':
        candidates = []
        for cand in election.candidates.all().order_by('display_order', 'candidate_id_num'):
            candidates.append({
                'id': cand.pk, 'candidate_id': cand.candidate_id_num, 'name': cand.name,
                'symbol': cand.symbol, 'description': cand.description,
                'display_order': cand.display_order, 'is_active': cand.is_active,
                'is_synced_on_chain': cand.is_synced_on_chain,
                'symbol_image_url': cand.symbol_image.url if cand.symbol_image else '',
            })
        return JsonResponse({
            'candidates': candidates, 'active_count': sum(1 for item in candidates if item['is_active']),
            'candidates_locked_on_chain': election.candidates_locked_on_chain,
        })

    if election.status in ('ACTIVE', 'CLOSED', 'FINALIZED') or election.candidates_locked_on_chain:
        return JsonResponse({'error': 'The candidate roster is locked for this election.'}, status=400)
    try:
        body = request.POST if request.content_type.startswith('multipart/form-data') else json.loads(request.body.decode('utf-8') or '{}')
        candidate_id = int(body.get('candidate_id'))
        name = str(body.get('name', '')).strip()
        symbol = str(body.get('symbol', '')).strip()
        description = str(body.get('description', '')).strip()
        if candidate_id < 1 or not name or not symbol:
            raise ValueError('Ballot number, candidate name, and symbol are required.')
        image_file = request.FILES.get('symbol_image') if request.FILES else None
        if image_file:
            if image_file.content_type not in ('image/png', 'image/jpeg', 'image/webp'):
                raise ValueError('Candidate symbol image must be PNG, JPG, or WEBP.')
            if image_file.size > 5 * 1024 * 1024:
                raise ValueError('Candidate symbol image must be 5 MB or smaller.')
            try:
                from PIL import Image
                image_file.seek(0)
                probe = Image.open(image_file)
                probe.verify()
                image_file.seek(0)
            except Exception as image_error:
                raise ValueError('The uploaded candidate symbol is not a valid image file.') from image_error
        if election.candidates.filter(candidate_id_num=candidate_id).exists():
            raise ValueError('This ballot number is already assigned.')
        candidate = Candidate.objects.create(
            election=election, candidate_id_num=candidate_id, name=name, symbol=symbol,
            description=description, display_order=candidate_id,
            symbol_image=image_file, is_active=True, is_synced_on_chain=False,
        )
        AdminAuditLog.objects.create(
            actor=request.user, action='CANDIDATE_CREATED', target_model='Candidate',
            target_id=str(candidate.pk), details=json.dumps({'election_id': election.election_id, 'candidate_id': candidate_id, 'name': name})
        )
        return JsonResponse({'success': True, 'candidate': {
            'id': candidate.pk, 'candidate_id': candidate.candidate_id_num, 'name': candidate.name,
            'symbol': candidate.symbol, 'description': candidate.description,
            'display_order': candidate.display_order, 'is_active': candidate.is_active,
            'is_synced_on_chain': candidate.is_synced_on_chain,
            'symbol_image_url': candidate.symbol_image.url if candidate.symbol_image else '',
        }}, status=201)
    except (ValueError, TypeError) as exc:
        return JsonResponse({'error': str(exc)}, status=400)
    except Exception as exc:
        return JsonResponse({'error': f'Candidate could not be saved: {str(exc)[:200]}'}, status=400)


@require_http_methods(["POST"])
@election_permission_required(action='write')
def api_control_candidate_update(request, election_id, candidate_id):
    election = request.election
    try:
        body = json.loads(request.body.decode('utf-8') or '{}')
        cand = Candidate.objects.get(election=election, candidate_id_num=candidate_id)
        if cand.is_synced_on_chain and (body.get('name') not in (None, cand.name) or body.get('symbol') not in (None, cand.symbol)):
            return JsonResponse({'error': 'Candidate name and symbol are fixed after synchronization to the contract.'}, status=400)
        if 'name' in body: cand.name = str(body['name']).strip()
        if 'symbol' in body: cand.symbol = str(body['symbol']).strip()
        if 'description' in body: cand.description = str(body['description']).strip()
        if 'display_order' in body: cand.display_order = int(body['display_order'])
        cand.save()
        return JsonResponse({'success': True, 'candidate_id': cand.candidate_id_num})
    except Candidate.DoesNotExist:
        return JsonResponse({'error': 'Candidate not found.'}, status=404)
    except (ValueError, TypeError) as exc:
        return JsonResponse({'error': str(exc)}, status=400)


@require_http_methods(["POST"])
@election_permission_required(action='write')
def api_control_candidate_deactivate(request, election_id, candidate_id):
    election = request.election
    if election.candidates_locked_on_chain or election.status in ('ACTIVE', 'CLOSED', 'FINALIZED'):
        return JsonResponse({'error': 'The candidate roster is locked.'}, status=400)
    candidate = Candidate.objects.filter(election=election, candidate_id_num=candidate_id).first()
    if not candidate:
        return JsonResponse({'error': 'Candidate not found.'}, status=404)
    if candidate.is_synced_on_chain:
        return JsonResponse({'error': 'This candidate is already registered on-chain. Deploy a fresh contract to change the roster.'}, status=400)
    candidate.is_active = False
    candidate.save(update_fields=['is_active'])
    return JsonResponse({'success': True, 'candidate_id': candidate.candidate_id_num, 'is_active': False})


@require_http_methods(["POST"])
@election_permission_required(action='write')
def api_control_candidates_lock(request, election_id):
    try:
        election = lock_candidate_roster(request.election, actor_user=request.user)
        return JsonResponse({
            'success': True, 'candidates_locked_on_chain': election.candidates_locked_on_chain,
            'voting_window_locked_on_chain': election.voting_window_locked_on_chain,
        })
    except SimpleVotingError as exc:
        return JsonResponse({'error': str(exc)}, status=400)


@require_http_methods(["POST"])
@election_permission_required(action='write')
def api_control_configure_window(request, election_id):
    election = request.election
    try:
        body = json.loads(request.body.decode('utf-8') or '{}')
        mode = body.get('commencement_mode', election.commencement_mode)
        if mode == 'IMMEDIATE':
            hours = int(body.get('immediate_duration_hours') or election.immediate_duration_hours or 1)
            if hours < 1 or hours > 24:
                raise SimpleVotingError('Immediate election duration must be between 1 and 24 hours.')
            start_dt = timezone.now().replace(microsecond=0)
            end_dt = start_dt + timedelta(hours=hours)
            election.immediate_duration_hours = hours
            election.commencement_mode = 'IMMEDIATE'
            election.save(update_fields=['immediate_duration_hours', 'commencement_mode', 'updated_at'])
        else:
            start_dt = parse_datetime(body.get('start_datetime') or '')
            end_dt = parse_datetime(body.get('end_datetime') or '')
            if start_dt and timezone.is_naive(start_dt): start_dt = timezone.make_aware(start_dt, timezone.get_current_timezone())
            if end_dt and timezone.is_naive(end_dt): end_dt = timezone.make_aware(end_dt, timezone.get_current_timezone())
            election.commencement_mode = 'SCHEDULED'
            election.save(update_fields=['commencement_mode', 'updated_at'])
        updated = update_voting_window(election, start_dt, end_dt, actor_user=request.user)
        return JsonResponse({
            'success': True, 'commencement_mode': updated.commencement_mode,
            'immediate_duration_hours': updated.immediate_duration_hours,
            'start_datetime': updated.start_datetime.isoformat() if updated.start_datetime else None,
            'end_datetime': updated.end_datetime.isoformat() if updated.end_datetime else None,
            'status': updated.status,
        })
    except (SimpleVotingError, ValueError, TypeError) as exc:
        return JsonResponse({'error': str(exc)}, status=400)


@require_http_methods(["POST"])
@election_permission_required(action='write')
def api_control_activate_election(request, election_id):
    try:
        election = request.election
        report = {'activated': [], 'closed': [], 'errors': []}
        if election.status == 'ACTIVE':
            message = 'Election is already open.'
        elif election.commencement_mode == 'IMMEDIATE':
            result = open_election(election)
            report['activated'].append(result)
            message = 'Election opened.'
        else:
            report = run_election_lifecycle_scheduler()
            election.refresh_from_db()
            message = (
                'Election opened.' if election.status == 'ACTIVE'
                else 'Election is scheduled and will open automatically at its configured time.'
            )
        election.refresh_from_db()
        return JsonResponse({
            'success': True, 'status': election.status,
            'start_datetime': election.start_datetime.isoformat() if election.start_datetime else None,
            'end_datetime': election.end_datetime.isoformat() if election.end_datetime else None,
            'scheduler': report, 'message': message,
        })
    except (SimpleVotingError, Election.DoesNotExist) as exc:
        return JsonResponse({'error': str(exc)}, status=400)
    except Exception as exc:
        return JsonResponse({'error': str(exc)[:300]}, status=400)


@require_http_methods(["POST"])
@election_permission_required(action='write')
def api_control_close_election(request, election_id):
    try:
        result = close_simple_election(request.election)
        return JsonResponse({'success': True, **result})
    except SimpleVotingError as exc:
        return JsonResponse({'error': str(exc)}, status=400)


@require_http_methods(["POST"])
@election_permission_required(action='write')
def api_control_reconcile_election(request, election_id):
    election = request.election
    try:
        from .simple_voting import get_contract
        live_w3, contract = get_contract(election)
        db_receipts = list(BallotReceipt.objects.filter(election=election))
        discrepancies = []
        confirmed = 0
        for item in db_receipts:
            try:
                chain_receipt = live_w3.eth.get_transaction_receipt(item.tx_hash)
                if int(chain_receipt.status) == 1 and Web3.to_checksum_address(chain_receipt['to']) == Web3.to_checksum_address(election.contract_address):
                    confirmed += 1
                else:
                    discrepancies.append(f'Receipt {item.receipt_reference} did not match the active contract.')
            except Exception:
                discrepancies.append(f'Receipt {item.receipt_reference} could not be verified on the connected node.')
        onchain_total = int(contract.functions.totalVotes().call())
        if confirmed != onchain_total:
            discrepancies.append(f'Database confirmed receipts ({confirmed}) do not match on-chain total ({onchain_total}).')
        candidate_checks = []
        for candidate in election.candidates.filter(is_active=True).order_by('candidate_id_num'):
            onchain_count = int(contract.functions.getCount(candidate.candidate_id_num).call())
            db_count = BallotReceipt.objects.filter(election=election, candidate_id=candidate.candidate_id_num).count()
            match = onchain_count == db_count
            candidate_checks.append({'candidate_id': candidate.candidate_id_num, 'onchain_votes': onchain_count, 'database_receipts': db_count, 'match': match})
            if not match:
                discrepancies.append(f'Candidate #{candidate.candidate_id_num}: on-chain {onchain_count}, database {db_count}.')
        verified = not discrepancies
        election.results_verified = verified
        election.reconciled_at = timezone.now()
        election.save(update_fields=['results_verified', 'reconciled_at', 'updated_at'])
        report = {
            'verified': verified, 'onchain_total_votes': onchain_total,
            'db_confirmed_permits': confirmed, 'candidate_checks': candidate_checks,
            'discrepancies': discrepancies, 'reconciled_at': election.reconciled_at.isoformat(),
        }
        return JsonResponse({'success': True, 'reconciliation': report})
    except Exception as exc:
        return JsonResponse({'error': str(exc)[:300]}, status=400)


@require_http_methods(["POST"])
@election_permission_required(action='write')
def api_control_publish_results(request, election_id):
    election = request.election
    try:
        body = json.loads(request.body.decode('utf-8') or '{}')
        publish = bool(body.get('publish', True))
        if publish and election.status not in ('CLOSED', 'FINALIZED'):
            return JsonResponse({'error': 'Results can only be published after the election closes.'}, status=400)
        election.results_published = publish
        election.save(update_fields=['results_published', 'updated_at'])
        return JsonResponse({'success': True, 'results_published': election.results_published, 'result_publication_policy': election.result_publication_policy})
    except Exception as exc:
        return JsonResponse({'error': str(exc)[:220]}, status=400)


@require_http_methods(["POST"])
@election_permission_required(action='write')
def api_control_finalize_election(request, election_id):
    election = request.election
    if election.status != 'CLOSED':
        return JsonResponse({'error': 'Close the election before finalizing results.'}, status=400)
    if not election.results_verified:
        return JsonResponse({'error': 'Run result reconciliation and resolve discrepancies before finalization.'}, status=400)
    election.status = 'FINALIZED'
    election.finalized_at = timezone.now()
    election.results_published = True
    election.save(update_fields=['status', 'finalized_at', 'results_published', 'updated_at'])
    return JsonResponse({'success': True, 'status': election.status, 'finalized_at': election.finalized_at.isoformat()})


@require_http_methods(["POST"])
@role_required(['Super Admin', 'Election Administrator'])
def api_control_trigger_scheduler(request):
    try:
        report = run_election_lifecycle_scheduler()
        return JsonResponse({'success': True, 'report': report})
    except Exception as exc:
        return JsonResponse({'error': f'Scheduler execution error: {str(exc)[:240]}'}, status=500)


@require_http_methods(["GET", "POST"])
@role_required(['Super Admin', 'Election Administrator'])
def api_control_blockchain_sync(request):
    """Report local Hardhat availability without creating or mutating demo elections."""
    try:
        provider = get_web3_provider()
        connected = bool(provider.is_connected())
        chain_id = int(provider.eth.chain_id) if connected else None
        account_list = list(provider.eth.accounts) if connected else []
        election = Election.objects.filter(election_id=request.GET.get('election_id') or getattr(settings, 'ELECTION_ID', 1)).first()
        return JsonResponse({
            'success': connected, 'connected': connected,
            'web3_rpc_url': _sanitize_rpc_endpoint_label(getattr(settings, 'WEB3_RPC_URL', '')) ,
            'metamask_rpc_url': _sanitize_rpc_endpoint_label(getattr(settings, 'METAMASK_RPC_URL', '')) ,
            'chain_id': chain_id or int(getattr(settings, 'CHAIN_ID', 31337)),
            'accounts_available': len(account_list),
            'contract_address': election.contract_address if election else '',
            'deployment_status': election.deployment_status if election else 'NOT_DEPLOYED',
        })
    except Exception as exc:
        return JsonResponse({'success': False, 'connected': False, 'error': str(exc)[:220]}, status=503)


# ==========================================
# 5. CLASSIC DJANGO VIEWS (ROUTING)
# ==========================================

STATUS_BADGE_MAP = {
    'ACTIVE': ('badge-active', 'Active'),
    'SCHEDULED': ('badge-scheduled', 'Scheduled'),
    'CLOSED': ('badge-closed', 'Completed'),
    'FINALIZED': ('badge-finalized', 'Completed'),
    'DRAFT': ('badge-draft', 'Draft'),
}

STATUS_SENTENCE_MAP = {
    'ACTIVE': 'Voting is currently open for eligible participants.',
    'SCHEDULED': 'Voting is scheduled to begin on the starting date.',
    'CLOSED': 'Voting has ended for this election.',
    'FINALIZED': 'Voting has concluded and official results are finalized.',
    'DRAFT': 'This election is currently in preparation.',
}


def _build_public_election_context(election):
    """
    Build a public-safe template context dictionary for an Election instance.
    Enforces result publication policy strictly and never exposes sensitive voter data.
    """
    summary = get_public_election_summary(election)
    status_code = summary.get('status', 'DRAFT')
    badge_class, status_label = STATUS_BADGE_MAP.get(status_code, ('badge-draft', status_code.title()))
    status_sentence = STATUS_SENTENCE_MAP.get(status_code, 'Election status is available below.')

    active_candidates_qs = election.candidates.filter(is_active=True).order_by('display_order', 'candidate_id_num')
    candidate_roster = []
    for cand in active_candidates_qs:
        sym_src, sym_alt = resolve_candidate_symbol_path(cand.symbol)
        candidate_roster.append({
            'candidate_id': cand.candidate_id_num,
            'name': cand.name,
            'symbol': cand.symbol,
            'description': cand.description,
            'symbol_src': cand.symbol_image.url if cand.symbol_image else sym_src,
            'symbol_alt': sym_alt,
        })

    results_info = summary.get('results', {})
    results_visible = bool(results_info.get('visible'))
    result_rows = []
    total_tally = None
    official_winner = None

    if results_visible:
        raw_candidates = results_info.get('candidates') or []
        resolved_candidates = []
        for c in raw_candidates:
            votes_val = c.get('votes')
            if votes_val is None:
                cid_val = c.get('candidate_id')
                votes_val = max(
                    BallotReceipt.objects.filter(election=election, candidate_id=cid_val).count(),
                    IssuedPermit.objects.filter(
                        election_ref=election,
                        candidate_id=cid_val,
                        is_consumed_on_chain=True,
                        is_historical_legacy=False,
                    ).count(),
                )
            resolved_candidates.append((c, votes_val))

        total_tally = sum((v or 0) for _, v in resolved_candidates if v is not None)
        for c, votes_val in resolved_candidates:
            sym_src, sym_alt = resolve_candidate_symbol_path(c.get('symbol'))
            share_pct = (
                round((votes_val / total_tally) * 100, 1)
                if (votes_val is not None and total_tally and total_tally > 0)
                else 0.0
            )
            result_rows.append({
                'candidate_id': c.get('candidate_id'),
                'name': c.get('name'),
                'symbol': c.get('symbol'),
                'description': c.get('description'),
                'symbol_src': c.get('symbol_image_url') or sym_src,
                'symbol_alt': sym_alt,
                'votes': votes_val,
                'vote_share_percent': share_pct,
            })

        if results_info.get('classification') in ('OFFICIAL', 'VERIFIED') and total_tally and total_tally > 0:
            valid_rows = [r for r in result_rows if r['votes'] is not None]
            if valid_rows:
                max_votes = max(r['votes'] for r in valid_rows)
                top_rows = [r for r in valid_rows if r['votes'] == max_votes]
                if max_votes > 0 and len(top_rows) == 1:
                    official_winner = top_rows[0]

    return {
        'election_id': summary['election_id'],
        'title': summary['title'],
        'description': summary['description'],
        'election_type': summary['election_type'],
        'commencement_mode': election.commencement_mode,
        'immediate_duration_hours': election.immediate_duration_hours,
        'status': status_code,
        'status_badge_class': badge_class,
        'status_label': status_label,
        'status_sentence': status_sentence,
        'start_datetime': election.start_datetime,
        'end_datetime': election.end_datetime,
        'turnout': summary['turnout'],
        'results': results_info,
        'result_rows': result_rows,
        'total_tally': total_tally,
        'official_winner': official_winner,
        'candidate_count': len(candidate_roster),
        'candidate_roster': candidate_roster,
        'blockchain_audit': summary['blockchain_audit'],
    }



def _get_landing_context(extra_context=None):
    """Build landing page context from real database elections."""
    now = timezone.now()
    sync_election_lifecycle_state(now=now)
    public_qs = [
        el for el in Election.objects.exclude(status='DRAFT').order_by('-created_at')
        if is_election_publicly_visible(el, now=now)
    ]
    all_cards = [_build_public_election_context(el) for el in public_qs]

    active_elections = [c for c in all_cards if c['status'] == 'ACTIVE']
    upcoming_elections = [c for c in all_cards if c['status'] == 'SCHEDULED']
    completed_elections = [c for c in all_cards if c['status'] in ('CLOSED', 'FINALIZED')]

    spotlight_election = (
        active_elections[0]
        if active_elections
        else (upcoming_elections[0] if upcoming_elections else (completed_elections[0] if completed_elections else None))
    )

    ctx = {
        'spotlight_election': spotlight_election,
        'active_elections': active_elections,
        'upcoming_elections': upcoming_elections,
        'completed_elections': completed_elections,
        'total_public_elections': len(all_cards),
    }
    if extra_context:
        ctx.update(extra_context)
    return ctx


def CastVoteAction(request):
    if request.method == 'POST':
        candidate_id = request.POST.get('t1', False)
        voter = request.POST.get('t2', False)
        aadhar = str(request.POST.get('t3', '')).strip()

        voter_obj = Voter.objects.filter(aadhar_number=aadhar).first()
        if not voter_obj:
            return render(request, 'index.html', _get_landing_context({
                'data': 'Authorization Failed: This ID is not registered in our database.',
            }))

        if voter_obj.has_voted:
            return render(request, 'index.html', _get_landing_context({
                'data': 'Duplicate Vote Blocked: This citizen has already voted.',
            }))

        success, message = saveVote(candidate_id, voter, aadhar)
        return render(request, 'index.html', _get_landing_context({'data': message}))
    return redirect('index')


def AdminLogin(request):
    if request.method == 'POST':
        u = request.POST.get('username', '')
        p = request.POST.get('password', '')

        user = authenticate(request, username=u, password=p)
        if user is not None:
            portal_role = get_user_portal_role(user)
            if portal_role:
                login(request, user)
                user_groups = list(user.groups.values_list('name', flat=True))
                AdminAuditLog.objects.create(
                    actor=user,
                    action='ADMIN_LOGIN_SUCCESS',
                    target_model='User',
                    target_id=str(user.pk),
                    details=f'Role: {portal_role}; Groups: {user_groups or ["Assigned/Superuser"]}',
                )
                ctx = _build_control_portal_context(request, {'data': f'Welcome Admin ({user.username})'})
                return render(request, "AdminScreen.html", ctx)

        context = {'data': 'Invalid Admin credentials!'}
        return render(request, 'Admin.html', context)
    return redirect('Admin')


def AdminLogout(request):
    logout(request)
    return redirect('index')


def index(request):
    return render(request, 'index.html', _get_landing_context())


@require_http_methods(["GET"])
def elections_directory_view(request):
    """
    Browser-facing Public Elections Dashboard at /elections/.
    Automatically synchronizes election lifecycle states using the server's current time
    and separates Active (ACTIVE) and Completed (CLOSED, FINALIZED) elections
    without exposing DRAFT or pre-start (SCHEDULED) elections.
    """
    now = timezone.now()
    sync_election_lifecycle_state(now=now)

    raw_status = request.GET.get('status', 'ACTIVE').strip().upper()
    status_filter = 'COMPLETED' if raw_status == 'COMPLETED' else 'ACTIVE'

    active_qs = [
        el for el in Election.objects.filter(status='ACTIVE').order_by('-start_datetime', '-created_at')
        if is_election_publicly_visible(el, now=now) and compute_election_lifecycle_status(el, now=now) == 'ACTIVE'
    ]
    completed_qs = [
        el for el in Election.objects.filter(status__in=['CLOSED', 'FINALIZED']).order_by('-end_datetime', '-finalized_at', '-created_at')
        if is_election_publicly_visible(el, now=now) and compute_election_lifecycle_status(el, now=now) in ('CLOSED', 'FINALIZED')
    ]

    active_elections = [
        {
            'election_id': el.election_id,
            'title': el.title,
            'status': el.status,
            'start_datetime': el.start_datetime,
            'created_at': el.created_at,
        }
        for el in active_qs
    ]
    completed_elections = [
        {
            'election_id': el.election_id,
            'title': el.title,
            'status': el.status,
            'end_datetime': el.end_datetime,
            'finalized_at': el.finalized_at,
            'updated_at': el.updated_at,
        }
        for el in completed_qs
    ]

    return render(request, 'elections.html', {
        'active_elections': active_elections,
        'completed_elections': completed_elections,
        'status_filter': status_filter,
    })


@require_http_methods(["GET"])
def election_detail_view(request, election_id):
    """
    Browser-facing Public Election Detail & Results page at /elections/<election_id>/.
    Pre-start elections remain unavailable and not publicly visible until their start_datetime arrives.
    """
    now = timezone.now()
    sync_election_lifecycle_state(now=now)
    election = (
        Election.objects.filter(election_id=election_id).first()
        or Election.objects.filter(pk=election_id).first()
    )
    if not election:
        return render(
            request,
            'election_detail.html',
            {'election_not_found': True, 'requested_election_id': election_id},
            status=404,
        )

    if not is_election_publicly_visible(election, now=now) and not (
        request.user.is_authenticated and request.user.is_superuser
    ):
        return render(
            request,
            'election_detail.html',
            {'election_not_found': True, 'requested_election_id': election_id},
            status=404,
        )

    context = _build_public_election_context(election)
    context['election_not_found'] = False
    return render(request, 'election_detail.html', context)


def ViewCount(request):
    return HttpResponseForbidden('<h1>403 Forbidden</h1><p>This page is disabled.</p>')
    return render(request, 'ViewCount.html', {})


def Admin(request):
    return render(request, 'Admin.html', {})


@ensure_csrf_cookie
@require_http_methods(["POST"])
def api_voter_authenticate(request):
    """Check the entered voter ID and election eligibility using SQLite and server time boundaries."""
    try:
        body = json.loads(request.body.decode('utf-8') or '{}')
        raw_id = ''.join(ch for ch in str(body.get('voter_id', '')).strip() if ch.isdigit())
        election_id = int(body.get('election_id'))
        if len(raw_id) != 12:
            return JsonResponse({'error': 'Enter a valid 12-digit Voter ID.'}, status=400)
        now = timezone.now()
        sync_election_lifecycle_state(now=now)
        run_election_lifecycle_scheduler(now=now)
        election = Election.objects.filter(election_id=election_id).first()
        if not election or not is_election_voting_open(election, now=timezone.now()):
            return JsonResponse({'error': 'This election is not currently open for voting.'}, status=400)
        voter = Voter.objects.filter(aadhar_number=raw_id, status='ACTIVE').first()
        if not voter:
            return JsonResponse({'error': 'Voter ID was not found in the active voter registry.'}, status=404)
        if voter.security_flagged:
            return JsonResponse({'error': voter.security_flag_reason or 'This voter record requires administrator review.'}, status=403)
        eligibility = VoterEligibility.objects.filter(voter=voter, election=election, is_eligible=True).first()
        if not eligibility:
            return JsonResponse({'error': 'This voter is not registered as eligible for this election.'}, status=403)
        request.session.cycle_key()
        request.session['authenticated_voter_id'] = voter.pk
        request.session['authenticated_election_id'] = election.election_id
        request.session['voter_authenticated_at'] = timezone.now().isoformat()
        request.session.pop('authenticated_wallet', None)
        request.session.modified = True
        if eligibility.has_voted:
            return JsonResponse({
                'success': True, 'has_voted': True, 'voter_name': voter.name,
                'voter_id_masked': mask_aadhar(voter.aadhar_number), 'election_title': election.title,
            })
        return JsonResponse({
            'success': True, 'has_voted': False, 'voter_name': voter.name,
            'voter_id_masked': mask_aadhar(voter.aadhar_number),
            'election_title': election.title,
        })
    except (TypeError, ValueError, json.JSONDecodeError):
        return JsonResponse({'error': 'Invalid authentication request.'}, status=400)


@require_http_methods(["POST"])
def api_voter_cast_vote(request):
    """Submit a selected ballot, rechecking the election time window inside the atomic backend operation."""
    try:
        body = json.loads(request.body.decode('utf-8') or '{}')
        voter = _resolve_session_voter(request)
        election_id = int(body.get('election_id'))
        candidate_id = int(body.get('candidate_id'))
        if not voter or request.session.get('authenticated_election_id') != election_id:
            return JsonResponse({'error': 'Authenticate as an eligible voter before submitting a ballot.'}, status=401)
        now = timezone.now()
        sync_election_lifecycle_state(now=now)
        run_election_lifecycle_scheduler(now=now)
        election = Election.objects.filter(election_id=election_id).first()
        if not election or not is_election_voting_open(election, now=timezone.now()):
            return JsonResponse({'error': 'Voting is not currently open for this election.'}, status=400)
        candidate = Candidate.objects.filter(election=election, candidate_id_num=candidate_id, is_active=True).first()
        if not candidate:
            return JsonResponse({'error': 'Select a valid candidate from this election.'}, status=400)
        with transaction.atomic():
            election = Election.objects.select_for_update().get(pk=election.pk)
            now_inner = timezone.now()
            sync_election_lifecycle_state(election=election, now=now_inner)
            if not is_election_voting_open(election, now=now_inner):
                return JsonResponse({'error': 'Voting is not currently open for this election.'}, status=400)

            voter = Voter.objects.select_for_update().get(pk=voter.pk, status='ACTIVE')
            if voter.security_flagged:
                return JsonResponse({'error': voter.security_flag_reason or 'This voter record requires administrator review.'}, status=403)
            eligibility = VoterEligibility.objects.select_for_update().filter(
                voter=voter, election=election, is_eligible=True
            ).first()
            if not eligibility:
                return JsonResponse({'error': 'Voter eligibility could not be confirmed.'}, status=403)
            if eligibility.has_voted:
                return JsonResponse({'error': 'A ballot has already been recorded for this voter.'}, status=409)
            receipt = cast_vote_for_voter(election, candidate, voter)
            BallotReceipt.objects.create(
                voter=voter, election=election, candidate_id=candidate.candidate_id_num,
                voter_hash=receipt['voter_hash'], contract_address=receipt['contract_address'],
                tx_hash=receipt['tx_hash'], block_number=receipt['block_number'],
                receipt_reference=receipt['receipt_reference'], confirmed_at=receipt['confirmed_at'],
            )
            eligibility.has_voted = True
            eligibility.voted_at = receipt['confirmed_at']
            eligibility.save(update_fields=['has_voted', 'voted_at'])
            voter.has_voted = True
            voter.voted_at = receipt['confirmed_at']
            voter.save(update_fields=['has_voted', 'voted_at'])
        return JsonResponse({
            'success': True, 'receipt_reference': receipt['receipt_reference'],
            'tx_hash': receipt['tx_hash'], 'block_number': receipt['block_number'],
            'confirmed_at': receipt['confirmed_at'].isoformat(),
            'election_title': election.title,
        })
    except (TypeError, ValueError, json.JSONDecodeError):
        return JsonResponse({'error': 'Invalid ballot submission.'}, status=400)
    except SimpleVotingError as exc:
        return JsonResponse({'error': str(exc)}, status=400)
    except Exception as exc:
        return JsonResponse({'error': f'Ballot submission failed: {str(exc)[:220]}'}, status=500)


def _build_voter_portal_context(request, preselected_candidate_id=None, extra_context=None):
    now = timezone.now()
    try:
        sync_election_lifecycle_state(now=now)
        run_election_lifecycle_scheduler(now=now)
    except Exception:
        pass
    raw_election_id = request.GET.get('election_id', getattr(settings, 'ELECTION_ID', 2026))
    try:
        selected_election_id = int(raw_election_id)
    except (TypeError, ValueError):
        selected_election_id = getattr(settings, 'ELECTION_ID', 2026)

    election = Election.objects.filter(election_id=selected_election_id).first()
    if election and not is_election_publicly_visible(election, now=now):
        election = None

    public_elections = [
        el for el in Election.objects.exclude(status='DRAFT').order_by('-created_at')
        if is_election_publicly_visible(el, now=now)
    ]

    voting_permitted = bool(election and is_election_voting_open(election, now=now))

    if voting_permitted and election:
        candidates_qs = election.candidates.filter(
            is_active=True,
        ).order_by('display_order', 'candidate_id_num')
    else:
        candidates_qs = Candidate.objects.none()

    preselected_int = None
    if preselected_candidate_id is not None and str(preselected_candidate_id).strip().lstrip('-').isdigit():
        preselected_int = int(str(preselected_candidate_id).strip())

    candidates_list = []
    preselected_candidate = None
    for cand in candidates_qs:
        sym_src, sym_alt = resolve_candidate_symbol_path(cand.symbol)
        is_sel = bool(preselected_int is not None and cand.candidate_id_num == preselected_int)
        item = {
            'candidate_id': cand.candidate_id_num,
            'name': cand.name,
            'symbol': cand.symbol,
            'description': cand.description,
            'symbol_src': cand.symbol_image.url if cand.symbol_image else sym_src,
            'symbol_alt': sym_alt,
            'is_selected': is_sel,
        }
        if is_sel:
            preselected_candidate = item
        candidates_list.append(item)

    if election:
        eff_status = compute_election_lifecycle_status(election, now=now)
        status_badge_class, status_label = STATUS_BADGE_MAP.get(
            eff_status, ('badge-draft', eff_status.title())
        )
    else:
        status_badge_class, status_label = ('badge-closed', 'Unavailable')

    session_voter = _resolve_session_voter(request)
    session_election_authenticated = bool(session_voter and election and request.session.get('authenticated_election_id') == election.election_id)
    if not session_election_authenticated:
        session_voter = None
    voter_is_eligible = None
    voter_has_voted = False
    voter_eligibility_label = 'Verify Identity to Check'
    voter_eligibility_badge_class = 'badge-scheduled'
    verified_receipt = None

    if session_voter and election:
        elig = VoterEligibility.objects.filter(voter=session_voter, election=election).first()
        if elig:
            voter_is_eligible = bool(elig.is_eligible)
            voter_has_voted = bool(elig.has_voted)
            voted_at_val = elig.voted_at
        else:
            voter_is_eligible = False
            voter_has_voted = False
            voted_at_val = None

        if voter_has_voted:
            voter_eligibility_label = 'Ballot Recorded'
            voter_eligibility_badge_class = 'badge-finalized'
            consumed = BallotReceipt.objects.filter(voter=session_voter, election=election).first()
            if consumed:
                verified_receipt = {
                    'tx_hash': consumed.tx_hash, 'block_number': consumed.block_number,
                    'contract_address': consumed.contract_address, 'election_id': election.election_id,
                    'election_title': election.title, 'confirmed_at': consumed.confirmed_at,
                    'receipt_reference': consumed.receipt_reference,
                }
        elif voter_is_eligible:
            voter_eligibility_label = 'Eligible Voter'
            voter_eligibility_badge_class = 'badge-active'
        else:
            voter_eligibility_label = 'Not Enrolled in Election'
            voter_eligibility_badge_class = 'badge-closed'

    ctx = {
        'selected_election_id': selected_election_id,
        'election': election,
        'public_elections': public_elections,
        'status_badge_class': status_badge_class,
        'status_label': status_label,
        'voting_permitted': voting_permitted,
        'candidates': candidates_list,
        'preselected_candidate': preselected_candidate,
        'preselected_candidate_id': preselected_candidate['candidate_id'] if preselected_candidate else (preselected_int or ''),
        'session_voter': session_voter,
        'session_voter_aadhar_masked': mask_aadhar(session_voter.aadhar_number) if session_voter else None,
        'session_wallet': request.session.get('authenticated_wallet'),
        'session_passkey_authenticated': False,
        'session_election_authenticated': session_election_authenticated,
        'voter_is_eligible': voter_is_eligible,
        'voter_has_voted': voter_has_voted,
        'voter_eligibility_label': voter_eligibility_label,
        'voter_eligibility_badge_class': voter_eligibility_badge_class,
        'verified_receipt': verified_receipt,
    }
    if extra_context:
        ctx.update(extra_context)
    return ctx


def Vote(request):
    raw_cand = request.GET.get('t1') or request.GET.get('candidate_id')
    context = _build_voter_portal_context(request, preselected_candidate_id=raw_cand)
    return render(request, 'Vote.html', context)


def CastVote(request):
    candidate = request.GET.get('t1', '')
    output = (
        '<label for="input-candidate-id">Selected Candidate Ballot Number</label>'
        '<input type="text" id="input-candidate-id" name="t1" value="'
        + str(candidate)
        + '" class="inp tabular-nums" readonly>'
    )
    context = _build_voter_portal_context(
        request,
        preselected_candidate_id=candidate,
        extra_context={'data1': output},
    )
    return render(request, 'CastVote.html', context)


def ViewCountAction(request):
    return HttpResponseForbidden('<h1>403 Forbidden</h1><p>This page is disabled.</p>')
    if request.method == 'POST':
        candidate = request.POST.get('t1', False)
        try:
            cid_int = int(candidate)
            count = getVote(cid_int)
        except Exception as e:
            context = {'data': f'<p class="feedback-panel feedback-error">Blockchain RPC Error: {str(e)}</p>'}
            return render(request, 'ViewResult.html', context)

        election = Election.objects.filter(election_id=getattr(settings, 'ELECTION_ID', 2026)).first()
        cand_obj = (
            Candidate.objects.filter(election=election, candidate_id_num=cid_int, is_active=True).first()
            if election else None
        )

        output = '<table border=1 align=center width=100%>'
        arr = ['Candidate ID', 'Candidate Name', 'Symbol', 'Total Votes Received']
        output += "<tr>"
        for item in arr:
            output += "<th>" + item + "</th>"
        output += "</tr>"

        if cand_obj:
            sym_src, sym_alt = resolve_candidate_symbol_path(cand_obj.symbol)
            output += f"<tr><td>{cand_obj.candidate_id_num}</td><td>{cand_obj.name}</td>"
            output += f'<td><img src={sym_src} height=100 width=100 alt="{sym_alt}"/></td>'
            output += f'<td>{count}</td></tr>'
        elif str(candidate) == "1":
            output += "<tr><td>1</td><td>Rahul Gandhi</td>"
            output += '<td><img src=/static/symbols/congress.png height=100 width=100 alt="Congress Symbol"/></td>'
            output += '<td>' + str(count) + '</td></tr>'
        elif str(candidate) == "2":
            output += "<tr><td>2</td><td>Narendar Modi</td>"
            output += '<td><img src=/static/symbols/bjp.png height=100 width=100 alt="BJP Symbol"/></td>'
            output += '<td>' + str(count) + '</td></tr>'
        elif str(candidate) == "3":
            output += "<tr><td>3</td><td>Akhilesh Yadav</td>"
            output += '<td><img src=/static/symbols/samajvadi.png height=100 width=100 alt="Samajwadi Symbol"/></td>'
            output += '<td>' + str(count) + '</td></tr>'
        output += "</table>"
        context = {'data': output}
        return render(request, 'ViewResult.html', context)
    return redirect('ViewCount')


# ==========================================
# 5. MODULE 5: VOTER & ELIGIBILITY CONTROL ENDPOINTS
# ==========================================

@election_permission_required(action='read')
def api_control_election_voters(request, election_id):
    """
    GET /api/control/elections/<election_id>/voters/
    List voter eligibility records for an election.
    Read-only accessible to Auditor, Election Administrator, Super Admin.
    """
    election = request.election
    summary = get_election_voters_summary(election.pk)
    return JsonResponse(summary)


@election_permission_required(action='worker_write')
def api_control_election_voter_add(request, election_id):
    """
    POST /api/control/elections/<election_id>/voters/add/
    Simplified single-step election voter registration:
    - Accessible to Super Admin, assigned Election Administrator, and assigned Election Worker.
    - Registers a new voter or matches an existing active voter without overwriting existing identity or wallet bindings.
    - Automatically assigns election-specific eligibility for the selected election (never global eligibility).
    """
    election = request.election
    try:
        body = json.loads(request.body.decode('utf-8'))
    except Exception:
        return JsonResponse({'error': 'Invalid JSON request payload.'}, status=400)

    aadhar = body.get('aadhar') or body.get('aadhar_number')
    name = body.get('name')
    wallet = body.get('wallet') or body.get('bound_wallet')
    is_synthetic = bool(body.get('is_synthetic', False))

    if not aadhar:
        return JsonResponse({'error': 'Missing required Aadhaar number.'}, status=400)

    try:
        clean_aadhar = validate_aadhar_format(aadhar)
        clean_wallet = validate_wallet_format(wallet) if wallet else None
        voter = Voter.objects.filter(aadhar_number=clean_aadhar).first()

        if not voter:
            if not name or not str(name).strip():
                return JsonResponse({'error': 'Full name is required when registering a new voter.'}, status=400)
            voter = register_voter(
                name=name,
                aadhar_number=clean_aadhar,
                bound_wallet=clean_wallet,
                is_synthetic=is_synthetic,
                actor_user=request.user,
            )
            registration_outcome = 'CREATED_AND_ELIGIBLE'
        else:
            if voter.status != 'ACTIVE':
                return JsonResponse(
                    {'error': f"Voter record is currently '{voter.status}' and cannot be enrolled."},
                    status=400,
                )
            if clean_wallet:
                if voter.bound_wallet and voter.bound_wallet.lower() != clean_wallet.lower():
                    return JsonResponse(
                        {
                            'error': (
                                'Existing voter already has a different bound wallet. '
                                'Existing wallet bindings cannot be overwritten during registration.'
                            )
                        },
                        status=400,
                    )
                if not voter.bound_wallet:
                    bind_or_update_voter_wallet(voter.pk, clean_wallet, actor_user=request.user)
                    voter.refresh_from_db()

            already_eligible = VoterEligibility.objects.filter(
                voter=voter,
                election=election,
                is_eligible=True,
            ).exists()
            registration_outcome = (
                'ALREADY_ELIGIBLE_IN_ELECTION'
                if already_eligible
                else 'EXISTING_VOTER_ADDED_TO_ELECTION'
            )

        eligibility = assign_voter_eligibility(
            election_db_id=election.pk,
            voter_id=voter.pk,
            is_eligible=True,
            actor_user=request.user,
        )

        return JsonResponse({
            'success': True,
            'registration_outcome': registration_outcome,
            'voter': {
                'id': voter.pk,
                'name': voter.name,
                'aadhar_masked': mask_aadhar(voter.aadhar_number),
                'bound_wallet': voter.bound_wallet,
                'is_synthetic': voter.is_synthetic,
            },
            'eligibility': {
                'is_eligible': eligibility.is_eligible,
                'has_voted': eligibility.has_voted,
            }
        }, status=201)

    except (VoterValidationError, VoterEligibilityError) as e:
        return JsonResponse({'error': str(e)}, status=400)
    except Exception as e:
        return JsonResponse({'error': f'Registration failed: {str(e)}'}, status=500)


@election_permission_required(action='write')
def api_control_election_voter_eligibility(request, election_id, voter_id):
    """
    POST /api/control/elections/<election_id>/voters/<voter_id>/eligibility/
    Update eligibility status for a voter on this election (e.g. grant or revoke).
    """
    election = request.election
    try:
        body = json.loads(request.body.decode('utf-8'))
    except Exception:
        return JsonResponse({'error': 'Invalid JSON request payload.'}, status=400)

    is_eligible = bool(body.get('is_eligible', True))
    try:
        eligibility = assign_voter_eligibility(
            election_db_id=election.pk,
            voter_id=voter_id,
            is_eligible=is_eligible,
            actor_user=request.user,
        )
        return JsonResponse({
            'success': True,
            'is_eligible': eligibility.is_eligible,
            'has_voted': eligibility.has_voted,
        })
    except (VoterValidationError, VoterEligibilityError) as e:
        return JsonResponse({'error': str(e)}, status=400)
    except Exception as e:
        return JsonResponse({'error': f'Eligibility update failed: {str(e)}'}, status=500)


@election_permission_required(action='write')
def api_control_election_voters_import_csv(request, election_id):
    """
    POST /api/control/elections/<election_id>/voters/import-csv/
    Import synthetic voter records from CSV:
    - Supports dry_run=true for validation and preview.
    - Supports dry_run=false for atomic database commit.
    """
    election = request.election
    dry_run = True
    csv_text = ''

    if request.FILES.get('file'):
        uploaded_file = request.FILES['file']
        csv_text = uploaded_file.read().decode('utf-8', errors='replace')
        dry_run = request.POST.get('dry_run', 'true').lower() in ('true', '1', 'yes')
    else:
        try:
            body = json.loads(request.body.decode('utf-8'))
            csv_text = body.get('csv_content', '')
            dry_run = bool(body.get('dry_run', True))
        except Exception:
            return JsonResponse({'error': 'Invalid request: provide JSON with csv_content or multipart CSV file.'}, status=400)

    if not csv_text.strip():
        return JsonResponse({'error': 'CSV content is empty.'}, status=400)

    try:
        result = import_synthetic_voters_from_csv(
            csv_content_or_file=csv_text,
            default_election_id=election.pk,
            assign_eligibility=True,
            dry_run=dry_run,
            actor_user=request.user,
        )
        return JsonResponse(result)
    except VoterValidationError as e:
        return JsonResponse({'error': str(e)}, status=400)
    except Exception as e:
        return JsonResponse({'error': f'Import failed: {str(e)}'}, status=500)


@role_required(['Super Admin', 'Election Administrator'])
def api_control_voter_wallet_update(request, voter_id):
    """
    POST /api/control/voters/<voter_id>/wallet/
    Update or bind an Ethereum wallet for a voter.
    """
    if request.method != 'POST':
        return JsonResponse({'error': 'Method not allowed.'}, status=405)

    try:
        body = json.loads(request.body.decode('utf-8'))
    except Exception:
        return JsonResponse({'error': 'Invalid JSON request payload.'}, status=400)

    wallet = body.get('wallet')
    force = bool(body.get('force', False))

    try:
        voter = bind_or_update_voter_wallet(
            voter_id=voter_id,
            new_wallet=wallet,
            force=force,
            actor_user=request.user,
        )
        return JsonResponse({
            'success': True,
            'voter_id': voter.pk,
            'name': voter.name,
            'bound_wallet': voter.bound_wallet,
        })
    except VoterValidationError as e:
        return JsonResponse({'error': str(e)}, status=400)
    except Exception as e:
        return JsonResponse({'error': f'Wallet update failed: {str(e)}'}, status=500)


# ==========================================
# 8. MODULE 6: WEBAUTHN PASSKEY & IDENTITY PROVIDER APIs
# ==========================================

from .models import (
    WebAuthnCredential,
    PendingVoterOnboarding,
    ExternalProviderVerificationRecord,
)
from .webauthn_service import (
    generate_passkey_registration_options,
    verify_passkey_registration,
    generate_passkey_authentication_options,
    verify_passkey_authentication,
    list_voter_passkeys,
    revoke_voter_passkey,
    superadmin_suspend_voter_passkeys,
    is_step_up_fresh,
    WebAuthnError,
    WebAuthnChallengeError,
    WebAuthnOriginError,
    WebAuthnAuthenticationError,
    WebAuthnStepUpRequiredError,
    WebAuthnManagementError,
)
from .providers import (
    get_available_providers,
    verify_and_stage_voter_identity,
    approve_pending_onboarding,
    reject_pending_onboarding,
    ProviderError,
    ProviderSSRFError,
    ProviderJWSVerificationError,
    OnboardingStateError,
)


def _resolve_session_voter(request):
    """
    Resolve the authenticated Voter exclusively from server-side session state.
    Never accepts or trusts a voter_id from client request parameters.
    """
    voter_id = request.session.get('authenticated_voter_id')
    if voter_id:
        voter = Voter.objects.filter(pk=voter_id, status='ACTIVE').first()
        if voter:
            return voter

    wallet = request.session.get('authenticated_wallet')
    if wallet:
        voter = Voter.objects.filter(bound_wallet__iexact=wallet, status='ACTIVE').first()
        if voter:
            request.session['authenticated_voter_id'] = voter.pk
            return voter

    return None


@require_http_methods(["POST"])
def api_passkey_register_options(request):
    """
    POST /api/auth/passkey/register/options/
    Requires an existing authenticated voter session.
    Requires fresh step-up authentication if the voter already has an active passkey.
    """
    if request.user.is_authenticated and not _resolve_session_voter(request):
        return JsonResponse({'error': 'Passkey enrollment is restricted to authenticated voter accounts.'}, status=403)

    voter = _resolve_session_voter(request)
    if not voter:
        return JsonResponse(
            {'error': 'Authenticated voter session required before enrolling a passkey.'},
            status=401,
        )

    if not request.session.session_key:
        request.session.save()

    step_up_ok = is_step_up_fresh(request.session)
    host_header = request.META.get('HTTP_HOST', 'localhost')

    try:
        options = generate_passkey_registration_options(
            voter=voter,
            session_key=request.session.session_key,
            step_up_verified=step_up_ok,
            host_header=host_header,
        )
        return JsonResponse(options)
    except WebAuthnStepUpRequiredError as e:
        return JsonResponse({'error': str(e), 'code': 'STEP_UP_REQUIRED'}, status=403)
    except WebAuthnOriginError as e:
        return JsonResponse({'error': str(e)}, status=400)
    except WebAuthnError as e:
        return JsonResponse({'error': str(e)}, status=400)


@require_http_methods(["POST"])
def api_passkey_register_verify(request):
    """
    POST /api/auth/passkey/register/verify/
    Verifies WebAuthn registration attestation and stores WebAuthnCredential.
    Rejects any attempt to specify an arbitrary voter_id in the request body.
    """
    voter = _resolve_session_voter(request)
    if not voter:
        return JsonResponse(
            {'error': 'Authenticated voter session required.'},
            status=401,
        )

    try:
        body = json.loads(request.body.decode('utf-8')) if request.body else {}
    except Exception:
        return JsonResponse({'error': 'Invalid JSON payload.'}, status=400)

    # Explicitly reject attempts to register against an arbitrary voter_id
    if 'voter_id' in body and int(body.get('voter_id') or 0) != voter.pk:
        return JsonResponse(
            {'error': 'Cannot register passkey for another voter account.'},
            status=403,
        )

    credential_payload = body.get('credential')
    device_label = body.get('device_label', 'Personal Authenticator')
    step_up_ok = is_step_up_fresh(request.session)
    host_header = request.META.get('HTTP_HOST', 'localhost')

    try:
        cred = verify_passkey_registration(
            voter=voter,
            session_key=request.session.session_key or '',
            credential_payload=credential_payload,
            device_label=device_label,
            step_up_verified=step_up_ok,
            host_header=host_header,
            ip_address=request.META.get('REMOTE_ADDR'),
        )
        return JsonResponse({
            'status': 'success',
            'credential_id': cred.pk,
            'device_label': cred.device_label,
            'registered_with_uv': cred.registered_with_uv,
            'sign_count': cred.sign_count,
        })
    except WebAuthnStepUpRequiredError as e:
        return JsonResponse({'error': str(e), 'code': 'STEP_UP_REQUIRED'}, status=403)
    except WebAuthnOriginError as e:
        return JsonResponse({'error': str(e)}, status=400)
    except WebAuthnManagementError as e:
        return JsonResponse({'error': str(e)}, status=409)
    except WebAuthnError as e:
        return JsonResponse({'error': str(e)}, status=400)


@require_http_methods(["POST"])
def api_passkey_authenticate_options(request):
    """
    POST /api/auth/passkey/authenticate/options/
    Generates WebAuthn assertion request options without leaking voter/credential existence.
    """
    try:
        body = json.loads(request.body.decode('utf-8')) if request.body else {}
    except Exception:
        body = {}

    if not request.session.session_key:
        request.session.save()

    voter = _resolve_session_voter(request)
    raw_aadhar = str(body.get('aadhar', '')).strip()
    if not voter and raw_aadhar and len(raw_aadhar) == 12 and raw_aadhar.isdigit():
        voter = Voter.objects.filter(aadhar_number=raw_aadhar, status='ACTIVE').first()

    require_uv = bool(body.get('require_uv', False)) or bool(body.get('step_up', False))
    challenge_type = 'STEP_UP' if body.get('step_up') else 'AUTHENTICATION'
    host_header = request.META.get('HTTP_HOST', 'localhost')

    try:
        options = generate_passkey_authentication_options(
            session_key=request.session.session_key,
            voter=voter,
            require_uv=require_uv,
            challenge_type=challenge_type,
            host_header=host_header,
        )
        return JsonResponse(options)
    except WebAuthnOriginError as e:
        return JsonResponse({'error': str(e), 'code': 'ORIGIN_VALIDATION_FAILED'}, status=400)
    except WebAuthnError as e:
        return JsonResponse({'error': str(e), 'code': 'WEBAUTHN_CEREMONY_ERROR'}, status=400)


@require_http_methods(["POST"])
def api_passkey_authenticate_verify(request):
    """
    POST /api/auth/passkey/authenticate/verify/
    Verifies WebAuthn assertion, enforces 4-case counter rules & userHandle cross-check,
    cycles session key, and establishes passkey authentication state.
    Crucially: NEVER sets authenticated_wallet (cannot bypass MetaMask/EIP-712 voting rules).
    """
    try:
        body = json.loads(request.body.decode('utf-8')) if request.body else {}
    except Exception:
        return JsonResponse({'error': 'Invalid JSON payload.', 'code': 'INVALID_JSON'}, status=400)

    credential_payload = body.get('credential')
    require_uv = bool(body.get('require_uv', False)) or bool(body.get('step_up', False))
    challenge_type = 'STEP_UP' if body.get('step_up') else 'AUTHENTICATION'
    host_header = request.META.get('HTTP_HOST', 'localhost')

    try:
        voter, cred_obj, ceremony_uv = verify_passkey_authentication(
            session_key=request.session.session_key or '',
            credential_payload=credential_payload,
            challenge_type=challenge_type,
            require_uv=require_uv,
            host_header=host_header,
            ip_address=request.META.get('REMOTE_ADDR'),
        )
    except WebAuthnOriginError as e:
        return JsonResponse({'error': str(e), 'code': 'ORIGIN_VALIDATION_FAILED'}, status=400)
    except WebAuthnChallengeError as e:
        return JsonResponse({'error': str(e), 'code': 'CHALLENGE_INVALID'}, status=400)
    except WebAuthnAuthenticationError as e:
        return JsonResponse({'error': str(e), 'code': 'ASSERTION_VERIFICATION_FAILED'}, status=401)
    except WebAuthnError as e:
        return JsonResponse({'error': str(e), 'code': 'WEBAUTHN_CEREMONY_ERROR'}, status=400)

    # Preserve existing wallet session if it belongs to the same voter; otherwise clear mismatched wallet
    existing_wallet = request.session.get('authenticated_wallet')
    existing_wallet_ts = request.session.get('wallet_authenticated_at')
    keep_wallet = (
        existing_wallet
        and voter.bound_wallet
        and existing_wallet.lower() == voter.bound_wallet.lower()
    )

    request.session.cycle_key()
    request.session['passkey_authenticated'] = True
    request.session['authenticated_voter_id'] = voter.pk
    if ceremony_uv:
        request.session['step_up_authenticated_at'] = int(time.time())
    if keep_wallet:
        request.session['authenticated_wallet'] = existing_wallet
        request.session['wallet_authenticated_at'] = existing_wallet_ts
    else:
        request.session.pop('authenticated_wallet', None)
        request.session.pop('wallet_authenticated_at', None)

    return JsonResponse({
        'status': 'success',
        'voter_id': voter.pk,
        'voter_name': voter.name,
        'bound_wallet': voter.bound_wallet,
        'user_verified': ceremony_uv,
        'credential_id': cred_obj.pk,
        'wallet_session_active': bool(request.session.get('authenticated_wallet')),
    })


@require_http_methods(["GET"])
def api_passkey_list(request):
    """
    GET /api/auth/passkey/list/
    Lists active and revoked passkeys for the currently authenticated voter.
    """
    voter = _resolve_session_voter(request)
    if not voter:
        return JsonResponse({'error': 'Authenticated voter session required.'}, status=401)

    return JsonResponse({
        'voter_id': voter.pk,
        'voter_name': voter.name,
        'passkeys': list_voter_passkeys(voter),
    })


@require_http_methods(["POST"])
def api_passkey_revoke(request, credential_id):
    """
    POST /api/auth/passkey/<credential_id>/revoke/
    Voter self-service passkey revocation (requires fresh step-up and last-credential guard).
    Election Administrators and Auditors are strictly denied (403) from revoking voter passkeys.
    """
    if request.user.is_authenticated and not _resolve_session_voter(request):
        return JsonResponse(
            {'error': 'Administrators and Auditors cannot directly revoke individual voter passkeys via self-service.'},
            status=403,
        )

    voter = _resolve_session_voter(request)
    if not voter:
        return JsonResponse({'error': 'Authenticated voter session required.'}, status=401)

    try:
        body = json.loads(request.body.decode('utf-8')) if request.body else {}
    except Exception:
        body = {}

    confirm_disable = bool(body.get('confirm_disable_passkey', False))
    step_up_ok = is_step_up_fresh(request.session)

    try:
        res = revoke_voter_passkey(
            voter=voter,
            credential_pk=credential_id,
            step_up_verified=step_up_ok,
            confirm_disable_passkey=confirm_disable,
            ip_address=request.META.get('REMOTE_ADDR'),
        )
        return JsonResponse(res)
    except WebAuthnStepUpRequiredError as e:
        return JsonResponse({'error': str(e), 'code': 'STEP_UP_REQUIRED'}, status=403)
    except WebAuthnManagementError as e:
        return JsonResponse({'error': str(e)}, status=400)


@role_required(['Super Admin'])
@require_http_methods(["POST"])
def api_control_superadmin_suspend_passkeys(request, voter_id):
    """
    POST /api/control/voters/<voter_id>/suspend-passkeys/
    Audited Super Admin emergency procedure for account-wide passkey suspension.
    Election Administrators and Auditors are blocked (403).
    """
    try:
        body = json.loads(request.body.decode('utf-8')) if request.body else {}
    except Exception:
        return JsonResponse({'error': 'Invalid JSON payload.'}, status=400)

    try:
        res = superadmin_suspend_voter_passkeys(
            voter_id=voter_id,
            actor_user=request.user,
            reason=body.get('reason', ''),
            ip_address=request.META.get('REMOTE_ADDR'),
        )
        return JsonResponse(res)
    except WebAuthnManagementError as e:
        return JsonResponse({'error': str(e)}, status=400)


@election_permission_required(action='write')
@require_http_methods(["POST"])
def api_control_election_flag_voter_security(request, election_id, voter_id):
    """
    POST /api/control/elections/<election_id>/voters/<voter_id>/flag-security/
    Allows an assigned Election Administrator to report a suspected compromised voter
    credential and optionally suspend election-specific eligibility without granting
    account-wide passkey control.
    """
    election = request.election
    voter = Voter.objects.filter(pk=voter_id).first()
    if not voter:
        return JsonResponse({'error': 'Voter not found.'}, status=404)

    try:
        body = json.loads(request.body.decode('utf-8')) if request.body else {}
    except Exception:
        return JsonResponse({'error': 'Invalid JSON payload.'}, status=400)

    reason = str(body.get('reason', '')).strip()
    if not reason:
        return JsonResponse({'error': 'Security flag reason is required.'}, status=400)

    suspend_election_eligibility = bool(body.get('suspend_election_eligibility', True))

    with transaction.atomic():
        voter.security_flagged = True
        voter.security_flag_reason = reason[:255]
        voter.save(update_fields=['security_flagged', 'security_flag_reason'])

        eligibility_suspended = False
        if suspend_election_eligibility:
            el = VoterEligibility.objects.filter(voter=voter, election=election).first()
            if el and not el.has_voted and el.is_eligible:
                el.is_eligible = False
                el.save(update_fields=['is_eligible'])
                eligibility_suspended = True

        AdminAuditLog.objects.create(
            actor=request.user,
            action='VOTER_CREDENTIAL_SUSPECTED',
            target_model='Voter',
            target_id=str(voter.pk),
            details=json.dumps({
                'election_id': election.election_id,
                'reason': reason[:200],
                'election_eligibility_suspended': eligibility_suspended,
                'account_passkeys_modified': False,
            }),
            ip_address=request.META.get('REMOTE_ADDR'),
        )

    return JsonResponse({
        'status': 'flagged',
        'voter_id': voter.pk,
        'election_id': election.election_id,
        'security_flagged': True,
        'election_eligibility_suspended': eligibility_suspended,
        'account_passkeys_modified': False,
    })


@require_http_methods(["GET"])
def api_identity_providers_list(request):
    """
    GET /api/identity/providers/
    Public/Admin discovery endpoint listing configured identity providers and their classification.
    """
    return JsonResponse({'providers': get_available_providers()})


@election_permission_required(action='worker_write')
@require_http_methods(["POST"])
def api_control_election_identity_verify(request, election_id):
    """
    POST /api/control/elections/<election_id>/identity/verify/
    Executes identity verification against the selected provider and stages a
    PendingVoterOnboarding record (for verified external identities).
    Accessible to Super Admin, assigned Election Administrator, and assigned Election Worker; Auditor blocked (403).
    """
    election = request.election
    try:
        body = json.loads(request.body.decode('utf-8')) if request.body else {}
    except Exception:
        return JsonResponse({'error': 'Invalid JSON payload.'}, status=400)

    provider_id = body.get('provider_id', 'local_database')
    identifier = body.get('identifier', '')
    query_params = body.get('parameters') or {}

    try:
        res = verify_and_stage_voter_identity(
            provider_id=provider_id,
            identifier=identifier,
            query_params=query_params,
            target_election=election,
            actor_user=request.user,
            ip_address=request.META.get('REMOTE_ADDR'),
        )
        status_code = 503 if res.get('status') == 'UNAVAILABLE' else 200
        return JsonResponse(res, status=status_code)
    except ProviderSSRFError as e:
        return JsonResponse({'error': str(e), 'code': 'SSRF_BLOCKED'}, status=400)
    except VoterValidationError as e:
        return JsonResponse({'error': str(e), 'code': 'VOTER_VALIDATION_ERROR'}, status=409 if 'bound to another' in str(e) else 400)
    except ProviderError as e:
        return JsonResponse({'error': str(e), 'code': 'PROVIDER_VALIDATION_ERROR'}, status=400)


@election_permission_required(action='read')
@require_http_methods(["GET"])
def api_control_election_identity_records(request, election_id):
    """
    GET /api/control/elections/<election_id>/identity/records/
    Returns masked ExternalProviderVerificationRecord and PendingVoterOnboarding records.
    Accessible to Super Admin, assigned Election Admin, assigned Election Worker, and assigned Auditor (read-only).
    """
    election = request.election
    ver_records = ExternalProviderVerificationRecord.objects.all().order_by('-verified_at')[:50]
    pending_records = PendingVoterOnboarding.objects.filter(
        models.Q(target_election=election) | models.Q(target_election__isnull=True)
    ).order_by('-created_at')[:50]

    return JsonResponse({
        'election_id': election.election_id,
        'verification_records': [
            {
                'id': r.pk,
                'provider_id': r.provider_id,
                'provider_name': r.provider_name,
                'provider_type': r.provider_type,
                'is_simulated': r.is_simulated,
                'masked_identifier': r.masked_identifier,
                'verification_status': r.verification_status,
                'failure_code': r.failure_code,
                'sanitized_attributes': json.loads(r.sanitized_attributes_json or '{}'),
                'response_latency_ms': r.response_latency_ms,
                'verified_at': r.verified_at.isoformat(),
            }
            for r in ver_records
        ],
        'pending_onboardings': [
            {
                'id': p.pk,
                'provider_id': p.provider_id,
                'provider_type': p.provider_type,
                'masked_identifier': p.masked_identifier,
                'proposed_name': p.proposed_name,
                'claimed_wallet': p.claimed_wallet,
                'status': p.status,
                'is_synthetic': p.is_synthetic,
                'created_at': p.created_at.isoformat(),
                'resulting_voter_id': p.resulting_voter_id,
            }
            for p in pending_records
        ],
    })


@election_permission_required(action='write')
@require_http_methods(["POST"])
def api_control_election_onboarding_review(request, election_id, onboarding_id):
    """
    POST /api/control/elections/<election_id>/onboarding/<onboarding_id>/review/
    Approves or rejects a PendingVoterOnboarding record atomically.
    - Approval creates or reuses the Voter record without auto-binding claimed_wallet
      and without automatically granting election eligibility.
    - Election Worker and Auditor blocked with 403.
    """
    try:
        body = json.loads(request.body.decode('utf-8')) if request.body else {}
    except Exception:
        return JsonResponse({'error': 'Invalid JSON payload.'}, status=400)

    decision = str(body.get('decision', 'APPROVE')).strip().upper()
    try:
        if decision == 'APPROVE':
            res = approve_pending_onboarding(
                onboarding_id=onboarding_id,
                reviewing_admin_user=request.user,
                ip_address=request.META.get('REMOTE_ADDR'),
            )
            return JsonResponse(res)
        elif decision == 'REJECT':
            res = reject_pending_onboarding(
                onboarding_id=onboarding_id,
                reviewing_admin_user=request.user,
                reason=body.get('reason', ''),
                ip_address=request.META.get('REMOTE_ADDR'),
            )
            return JsonResponse(res)
        else:
            return JsonResponse({'error': "Decision must be 'APPROVE' or 'REJECT'."}, status=400)
    except VoterValidationError as e:
        return JsonResponse({'error': str(e)}, status=409)
    except OnboardingStateError as e:
        return JsonResponse({'error': str(e)}, status=409)


# ==========================================
# 9. MODULE 7 PHASE 4: SUPER ADMIN ELECTION & STAFF MANAGEMENT APIs
# ==========================================

@role_required(['Super Admin'])
@require_http_methods(["POST"])
def api_control_create_election(request):
    """
    POST /api/control/elections/create/
    Super Admin endpoint to create a new Election in DRAFT state.
    Never deploys a smart contract automatically on creation.
    """
    try:
        body = json.loads(request.body.decode('utf-8')) if request.body else {}
    except Exception:
        return JsonResponse({'error': 'Invalid JSON payload.'}, status=400)

    title = str(body.get('title', '')).strip()
    if not title:
        return JsonResponse({'error': 'Election title is required.'}, status=400)
    if len(title) > 200:
        return JsonResponse({'error': 'Election title cannot exceed 200 characters.'}, status=400)

    description = str(body.get('description', '')).strip()
    election_type = str(body.get('election_type', 'ELECTION')).strip().upper()
    valid_types = {k for k, _ in Election.ELECTION_TYPE_CHOICES}
    if election_type not in valid_types:
        election_type = 'ELECTION'

    policy = str(body.get('result_publication_policy', 'HIDDEN_UNTIL_CLOSE')).strip().upper()
    valid_policies = {k for k, _ in Election.RESULT_PUBLICATION_CHOICES}
    if policy not in valid_policies:
        policy = 'HIDDEN_UNTIL_CLOSE'

    raw_election_id = body.get('election_id')
    with transaction.atomic():
        if raw_election_id is not None and str(raw_election_id).strip() != '':
            try:
                election_id_num = int(raw_election_id)
            except (TypeError, ValueError):
                return JsonResponse({'error': 'Election ID must be a positive integer.'}, status=400)
            if election_id_num <= 0:
                return JsonResponse({'error': 'Election ID must be a positive integer.'}, status=400)
            if Election.objects.filter(election_id=election_id_num).exists():
                return JsonResponse({'error': f'Election #{election_id_num} already exists.'}, status=400)
        else:
            max_id = Election.objects.aggregate(m=models.Max('election_id'))['m'] or 2025
            election_id_num = int(max_id) + 1

        commencement_mode = str(body.get('commencement_mode', 'SCHEDULED')).strip().upper()
        if commencement_mode not in ('SCHEDULED', 'IMMEDIATE'):
            commencement_mode = 'SCHEDULED'

        start_dt = parse_datetime(body.get('start_datetime')) if body.get('start_datetime') else None
        end_dt = parse_datetime(body.get('end_datetime')) if body.get('end_datetime') else None

        immediate_duration = None
        if commencement_mode == 'SCHEDULED':
            if start_dt and end_dt and end_dt <= start_dt:
                return JsonResponse({'error': 'Voting close time must be later than voting open time.'}, status=400)
        else:
            # IMMEDIATE mode: start_datetime is not manually entered
            start_dt = None
            raw_duration = body.get('immediate_duration_hours')
            if raw_duration is not None and str(raw_duration).strip() != '':
                try:
                    immediate_duration = validate_immediate_duration(raw_duration)
                except ElectionLifecycleError as e:
                    return JsonResponse({'error': str(e)}, status=400)

        election = Election.objects.create(
            election_id=election_id_num,
            title=title,
            description=description,
            election_type=election_type,
            commencement_mode=commencement_mode,
            immediate_duration_hours=immediate_duration,
            status='DRAFT',
            deployment_status='NOT_DEPLOYED',
            result_publication_policy=policy,
            start_datetime=start_dt,
            end_datetime=end_dt,
            created_by=request.user,
        )

        AdminAuditLog.objects.create(
            actor=request.user,
            action='ELECTION_CREATED',
            target_model='Election',
            target_id=str(election.pk),
            details=json.dumps({
                'election_id': election.election_id,
                'title': election.title,
                'election_type': election.election_type,
                'commencement_mode': election.commencement_mode,
                'immediate_duration_hours': election.immediate_duration_hours,
                'status': election.status,
                'deployment_status': election.deployment_status,
            }),
            ip_address=request.META.get('REMOTE_ADDR'),
        )

    return JsonResponse({
        'success': True,
        'election': {
            'id': election.pk,
            'election_id': election.election_id,
            'title': election.title,
            'description': election.description,
            'election_type': election.election_type,
            'commencement_mode': election.commencement_mode,
            'immediate_duration_hours': election.immediate_duration_hours,
            'status': election.status,
            'deployment_status': election.deployment_status,
            'result_publication_policy': election.result_publication_policy,
            'start_datetime': election.start_datetime.isoformat() if election.start_datetime else None,
            'end_datetime': election.end_datetime.isoformat() if election.end_datetime else None,
        }
    }, status=201)


@election_permission_required(action='write')
@require_http_methods(["POST"])
def api_control_update_election(request, election_id):
    """
    POST /api/control/elections/<election_id>/update/
    Updates permitted election metadata (title, description, election_type, result_publication_policy, commencement_mode, immediate_duration_hours).
    Blocked once the election is FINALIZED, or if modifying commencement configuration after activation.
    """
    election = request.election
    try:
        body = json.loads(request.body.decode('utf-8')) if request.body else {}
    except Exception:
        return JsonResponse({'error': 'Invalid JSON payload.'}, status=400)

    if election.status in ('ACTIVE', 'CLOSED', 'FINALIZED'):
        if any(f in body for f in ('commencement_mode', 'start_datetime', 'end_datetime', 'immediate_duration_hours')):
            return JsonResponse({'error': 'Cannot modify commencement configuration after election activation.'}, status=400)
        if election.status == 'FINALIZED':
            return JsonResponse({'error': 'Cannot modify metadata of a finalized election.'}, status=400)

    updated_fields = []
    if 'title' in body:
        clean_title = str(body.get('title') or '').strip()
        if not clean_title:
            return JsonResponse({'error': 'Election title cannot be empty.'}, status=400)
        election.title = clean_title[:200]
        updated_fields.append('title')

    if 'description' in body:
        election.description = str(body.get('description') or '').strip()
        updated_fields.append('description')

    if 'election_type' in body:
        etype = str(body.get('election_type') or '').strip().upper()
        if etype in {k for k, _ in Election.ELECTION_TYPE_CHOICES}:
            election.election_type = etype
            updated_fields.append('election_type')

    if 'commencement_mode' in body:
        cmode = str(body.get('commencement_mode') or '').strip().upper()
        if cmode in {k for k, _ in Election.COMMENCEMENT_MODE_CHOICES}:
            election.commencement_mode = cmode
            if cmode == 'IMMEDIATE':
                election.start_datetime = None
                updated_fields.append('start_datetime')
            updated_fields.append('commencement_mode')

    if 'immediate_duration_hours' in body:
        raw_dur = body.get('immediate_duration_hours')
        if raw_dur is not None and str(raw_dur).strip() != '':
            try:
                valid_dur = validate_immediate_duration(raw_dur)
                election.immediate_duration_hours = valid_dur
                updated_fields.append('immediate_duration_hours')
            except ElectionLifecycleError as e:
                return JsonResponse({'error': str(e)}, status=400)
        elif raw_dur is None or str(raw_dur).strip() == '':
            election.immediate_duration_hours = None
            updated_fields.append('immediate_duration_hours')

    if 'result_publication_policy' in body:
        pol = str(body.get('result_publication_policy') or '').strip().upper()
        if pol in {k for k, _ in Election.RESULT_PUBLICATION_CHOICES}:
            election.result_publication_policy = pol
            updated_fields.append('result_publication_policy')

    if updated_fields:
        updated_fields.append('updated_at')
        election.save(update_fields=updated_fields)
        AdminAuditLog.objects.create(
            actor=request.user,
            action='ELECTION_METADATA_UPDATED',
            target_model='Election',
            target_id=str(election.pk),
            details=json.dumps({
                'election_id': election.election_id,
                'updated_fields': updated_fields,
            }),
            ip_address=request.META.get('REMOTE_ADDR'),
        )

    return JsonResponse({
        'success': True,
        'election': {
            'election_id': election.election_id,
            'title': election.title,
            'description': election.description,
            'election_type': election.election_type,
            'commencement_mode': election.commencement_mode,
            'immediate_duration_hours': election.immediate_duration_hours,
            'result_publication_policy': election.result_publication_policy,
            'status': election.status,
            'start_datetime': election.start_datetime.isoformat() if election.start_datetime else None,
            'end_datetime': election.end_datetime.isoformat() if election.end_datetime else None,
        }
    })


ROLE_CODE_TO_GROUP = {
    'SUPER_ADMIN': 'Super Admin',
    'ELECTION_ADMIN': 'Election Administrator',
    'ELECTION_WORKER': 'Election Worker',
    'AUDITOR': 'Auditor',
}


@role_required(['Super Admin'])
@require_http_methods(["GET", "POST"])
def api_control_staff_management(request):
    """
    GET / POST /api/control/staff/
    Super Admin endpoint to inspect and manage staff accounts, system role groups,
    and election-specific assignments (Election Administrator, Election Worker, Auditor).
    """
    if request.method == 'GET':
        staff_list = []
        for u in User.objects.all().order_by('username'):
            u_role = get_user_portal_role(u)
            if u_role or u.is_staff or u.is_superuser:
                staff_list.append({
                    'id': u.pk,
                    'username': u.username,
                    'is_superuser': u.is_superuser,
                    'portal_role': u_role,
                    'portal_role_label': PORTAL_ROLE_LABELS.get(u_role, 'Staff Member'),
                    'groups': list(u.groups.values_list('name', flat=True)),
                })
        assignments_list = [
            {
                'id': a.pk,
                'election_id': a.election.election_id,
                'election_title': a.election.title,
                'user_id': a.user.pk,
                'username': a.user.username,
                'role': a.role,
                'role_label': dict(ElectionAdminAssignment.ROLE_CHOICES).get(a.role, a.role),
                'assigned_at': a.assigned_at.isoformat(),
            }
            for a in ElectionAdminAssignment.objects.select_related('election', 'user').order_by('-assigned_at')
        ]
        return JsonResponse({'staff': staff_list, 'assignments': assignments_list})

    try:
        body = json.loads(request.body.decode('utf-8')) if request.body else {}
    except Exception:
        return JsonResponse({'error': 'Invalid JSON payload.'}, status=400)

    operation = str(body.get('operation', 'ASSIGN_ELECTION_ROLE')).strip().upper()

    if operation == 'CREATE_OR_UPDATE_STAFF':
        username = str(body.get('username', '')).strip()
        password = str(body.get('password', '')).strip()
        role_code = str(body.get('role', 'ELECTION_ADMIN')).strip().upper()

        if not username:
            return JsonResponse({'error': 'Staff username is required.'}, status=400)
        if role_code not in ROLE_CODE_TO_GROUP:
            return JsonResponse({'error': 'Invalid staff role specified.'}, status=400)

        group_name = ROLE_CODE_TO_GROUP[role_code]
        with transaction.atomic():
            user_obj = User.objects.filter(username=username).first()
            created_user = False
            if not user_obj:
                if not password or len(password) < 6:
                    return JsonResponse({'error': 'Password (minimum 6 characters) is required for a new staff account.'}, status=400)
                user_obj = User.objects.create_user(username=username, password=password)
                created_user = True
            elif password:
                if len(password) < 6:
                    return JsonResponse({'error': 'Password must be at least 6 characters.'}, status=400)
                user_obj.set_password(password)
                user_obj.save()

            managed_groups = Group.objects.filter(name__in=list(ROLE_CODE_TO_GROUP.values()))
            user_obj.groups.remove(*managed_groups)
            target_group, _ = Group.objects.get_or_create(name=group_name)
            user_obj.groups.add(target_group)

            raw_election_id = body.get('election_id')
            assignment_info = None
            if raw_election_id and role_code in ('ELECTION_ADMIN', 'ELECTION_WORKER', 'AUDITOR'):
                el = (
                    Election.objects.filter(election_id=raw_election_id).first()
                    or Election.objects.filter(pk=raw_election_id).first()
                )
                if el:
                    asgn, _ = ElectionAdminAssignment.objects.update_or_create(
                        election=el,
                        user=user_obj,
                        defaults={'role': role_code},
                    )
                    assignment_info = {
                        'id': asgn.pk,
                        'election_id': el.election_id,
                        'role': asgn.role,
                    }

            AdminAuditLog.objects.create(
                actor=request.user,
                action='STAFF_ACCOUNT_CREATED' if created_user else 'STAFF_ROLE_UPDATED',
                target_model='User',
                target_id=str(user_obj.pk),
                details=json.dumps({
                    'username': user_obj.username,
                    'role_code': role_code,
                    'group': group_name,
                    'assignment': assignment_info,
                }),
                ip_address=request.META.get('REMOTE_ADDR'),
            )

        return JsonResponse({
            'success': True,
            'created': created_user,
            'staff': {
                'id': user_obj.pk,
                'username': user_obj.username,
                'portal_role': role_code,
                'portal_role_label': PORTAL_ROLE_LABELS.get(role_code, group_name),
            },
            'assignment': assignment_info,
        }, status=201 if created_user else 200)

    elif operation == 'ASSIGN_ELECTION_ROLE':
        raw_election_id = body.get('election_id')
        username = str(body.get('username', '')).strip()
        user_id = body.get('user_id')
        role_code = str(body.get('role', 'ELECTION_ADMIN')).strip().upper()

        if role_code not in ('ELECTION_ADMIN', 'ELECTION_WORKER', 'AUDITOR'):
            return JsonResponse({'error': "Election assignment role must be 'ELECTION_ADMIN', 'ELECTION_WORKER', or 'AUDITOR'."}, status=400)

        election = (
            Election.objects.filter(election_id=raw_election_id).first()
            or Election.objects.filter(pk=raw_election_id).first()
        )
        if not election:
            return JsonResponse({'error': 'Target election not found.'}, status=404)

        user_obj = (
            User.objects.filter(pk=user_id).first()
            if user_id else User.objects.filter(username=username).first()
        )
        if not user_obj:
            return JsonResponse({'error': 'Target staff user not found.'}, status=404)

        with transaction.atomic():
            asgn, created = ElectionAdminAssignment.objects.update_or_create(
                election=election,
                user=user_obj,
                defaults={'role': role_code},
            )
            if not user_obj.is_superuser and not user_obj.groups.exists():
                grp, _ = Group.objects.get_or_create(name=ROLE_CODE_TO_GROUP[role_code])
                user_obj.groups.add(grp)

            AdminAuditLog.objects.create(
                actor=request.user,
                action='ELECTION_STAFF_ASSIGNED',
                target_model='ElectionAdminAssignment',
                target_id=str(asgn.pk),
                details=json.dumps({
                    'election_id': election.election_id,
                    'username': user_obj.username,
                    'role': role_code,
                    'created': created,
                }),
                ip_address=request.META.get('REMOTE_ADDR'),
            )

        return JsonResponse({
            'success': True,
            'assignment': {
                'id': asgn.pk,
                'election_id': election.election_id,
                'election_title': election.title,
                'user_id': user_obj.pk,
                'username': user_obj.username,
                'role': asgn.role,
                'role_label': dict(ElectionAdminAssignment.ROLE_CHOICES).get(asgn.role, asgn.role),
            }
        })

    elif operation == 'REMOVE_ELECTION_ROLE':
        assignment_id = body.get('assignment_id')
        asgn = ElectionAdminAssignment.objects.select_related('election', 'user').filter(pk=assignment_id).first()
        if not asgn:
            return JsonResponse({'error': 'Assignment record not found.'}, status=404)

        details_payload = {
            'election_id': asgn.election.election_id,
            'username': asgn.user.username,
            'removed_role': asgn.role,
        }
        asgn.delete()
        AdminAuditLog.objects.create(
            actor=request.user,
            action='ELECTION_STAFF_REMOVED',
            target_model='ElectionAdminAssignment',
            target_id=str(assignment_id),
            details=json.dumps(details_payload),
            ip_address=request.META.get('REMOTE_ADDR'),
        )
        return JsonResponse({'success': True, 'removed_id': assignment_id})

    return JsonResponse({'error': f"Unsupported staff operation '{operation}'."}, status=400)