import os
import io
import csv
import re
import json
import logging
from datetime import timedelta
from django.conf import settings
from django.db import IntegrityError, transaction
from django.utils import timezone
from web3 import Web3
from .models import (
    Voter,
    Election,
    ContractDeployment,
    Candidate,
    VoterEligibility,
    IssuedPermit,
    BallotReceipt,
    AdminAuditLog,
)

logger = logging.getLogger(__name__)


class BlockchainDeploymentError(Exception):
    """Custom exception for blockchain deployment, lifecycle, and RPC synchronization failures."""
    pass


class ElectionLifecycleError(Exception):
    """Custom exception for invalid election state transitions or invariant violations."""
    pass


class VoterValidationError(Exception):
    """Custom exception for invalid voter data or duplicate identity."""
    pass


class VoterEligibilityError(Exception):
    """Custom exception for unauthorized or invalid voter eligibility operations."""
    pass


def _sanitize_rpc_endpoint_label(rpc_url):
    """Return a sanitized RPC endpoint label (scheme://host:port) without exposing URL path tokens or query keys."""
    try:
        from urllib.parse import urlparse
        parsed = urlparse(str(rpc_url or ''))
        if parsed.scheme and parsed.hostname:
            port_part = f":{parsed.port}" if parsed.port else ""
            return f"{parsed.scheme}://{parsed.hostname}{port_part}"
    except Exception:
        pass
    return "configured-rpc-endpoint"


def get_web3_provider(timeout=None):
    """
    Retrieve Web3 connection instance from settings with configurable HTTP timeout
    and optional X-DVS-RPC-Token backend authentication header for the JSON-RPC Security Gateway.
    """
    rpc_url = getattr(settings, 'WEB3_RPC_URL', 'http://127.0.0.1:8545')
    effective_timeout = timeout if timeout is not None else getattr(settings, 'WEB3_RPC_TIMEOUT_SECONDS', 10)
    backend_token = getattr(settings, 'HARDHAT_BACKEND_RPC_TOKEN', None)
    request_kwargs = {'timeout': effective_timeout}
    if backend_token and str(backend_token).strip():
        request_kwargs['headers'] = {'X-DVS-RPC-Token': str(backend_token).strip()}
    return Web3(Web3.HTTPProvider(rpc_url, request_kwargs=request_kwargs))


def _resolve_deployer_account_and_key(w3):
    """
    Resolve the active deployer address and optional private key.
    When BLOCKCHAIN_DEPLOYER_PRIVATE_KEY is configured and w3 is connected to a live chain,
    returns (deployer_address, normalized_private_key) and ensures test ETH is funded on Chain ID 31337.
    Otherwise falls back to (w3.eth.accounts[0], None).
    """
    from eth_account import Account
    raw_dep_key = getattr(settings, 'BLOCKCHAIN_DEPLOYER_PRIVATE_KEY', None)
    is_live_w3 = False
    try:
        is_live_w3 = isinstance(w3.eth.chain_id, int)
    except Exception:
        is_live_w3 = False

    if is_live_w3 and (not raw_dep_key or not str(raw_dep_key).strip()):
        try:
            from .hardhat_demo import get_rotated_demo_private_key
            raw_dep_key = get_rotated_demo_private_key('deployer')
        except Exception:
            raw_dep_key = None

    if raw_dep_key and str(raw_dep_key).strip() and is_live_w3:
        clean_key = str(raw_dep_key).strip()
        norm_key = clean_key if clean_key.startswith(('0x', '0X')) else '0x' + clean_key
        deployer_addr = Account.from_key(norm_key).address
        try:
            if int(w3.eth.chain_id) == 31337 and int(w3.eth.get_balance(deployer_addr)) < Web3.to_wei(5, 'ether'):
                from .hardhat_demo import fund_rotated_demo_accounts_on_chain
                fund_rotated_demo_accounts_on_chain(w3, target_addresses_with_eth=[(deployer_addr, 500)])
        except Exception:
            pass
        return deployer_addr, norm_key

    accounts = w3.eth.accounts
    if not accounts:
        raise BlockchainDeploymentError("No unlocked accounts available on the connected Web3 node.")
    return accounts[0], None


def _execute_deployer_tx(w3, tx_func, deployer=None, deployer_key=None, timeout=60):
    """
    Execute a contract constructor or state-modifying function using either a raw signed
    transaction (eth_sendRawTransaction) when deployer_key is configured, or eth_sendTransaction.
    Returns (tx_hash, receipt).
    """
    from eth_account import Account
    if deployer is None and deployer_key is None:
        deployer, deployer_key = _resolve_deployer_account_and_key(w3)

    if deployer_key:
        nonce = w3.eth.get_transaction_count(deployer)
        chain_id = int(w3.eth.chain_id)
        gas_est = tx_func.estimate_gas({'from': deployer})
        gas_price = w3.eth.gas_price
        built_tx = tx_func.build_transaction({
            'from': deployer,
            'nonce': nonce,
            'chainId': chain_id,
            'gas': int(gas_est * 1.2),
            'gasPrice': gas_price,
        })
        signed = Account.sign_transaction(built_tx, private_key=deployer_key)
        raw_tx = getattr(signed, 'raw_transaction', None) or getattr(signed, 'rawTransaction')
        tx_hash = w3.eth.send_raw_transaction(raw_tx)
    else:
        tx_hash = tx_func.transact({'from': deployer})

    receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=timeout)
    return tx_hash, receipt


def verify_live_election_contract_on_chain(election, w3=None):
    """
    Phase 9 Live Chain & Contract State Verification:
    When connected to a live Web3 node (where w3.eth.chain_id is an int):
    1. Validates connected Chain ID matches configured CHAIN_ID (31337).
    2. When the election has a recorded on-chain deployment (deployed_bytecode_hash or deployment_tx_hash)
       or when verifying contract bytecode, checks w3.eth.get_code(election.contract_address).
       If bytecode is missing (b''), marks election.deployment_status = 'CHAIN_RESET_REDEPLOY_REQUIRED'
       and raises BlockchainDeploymentError so stale contract addresses are rejected after chain resets.
    """
    w3 = w3 or get_web3_provider()
    if not w3.is_connected():
        raise BlockchainDeploymentError("Blockchain Node Unavailable: Cannot verify live chain state.")

    try:
        live_chain_id = w3.eth.chain_id
    except Exception as exc:
        raise BlockchainDeploymentError(f"Failed to query Chain ID from RPC endpoint: {str(exc)}")

    if not isinstance(live_chain_id, int):
        # Mocked Web3 provider in unit tests
        return {'live': False, 'verified': True}

    expected_chain_id = int(getattr(election, 'chain_id', None) or getattr(settings, 'CHAIN_ID', 31337))
    if live_chain_id != expected_chain_id:
        raise BlockchainDeploymentError(
            f"Chain ID mismatch: RPC node reported Chain ID {live_chain_id}, expected {expected_chain_id}."
        )

    if getattr(election, 'deployment_status', '') == 'CHAIN_RESET_REDEPLOY_REQUIRED':
        raise BlockchainDeploymentError(
            f"Stale contract address {election.contract_address} detected after chain reset. "
            f"Fresh contract redeployment is required before proceeding."
        )

    if not election.contract_address or not Web3.is_address(election.contract_address):
        raise BlockchainDeploymentError("Election does not have a valid deployed contract address.")

    checksum_addr = Web3.to_checksum_address(election.contract_address)
    code = w3.eth.get_code(checksum_addr)
    if isinstance(code, (bytes, bytearray)) and len(code) == 0:
        election.deployment_status = 'CHAIN_RESET_REDEPLOY_REQUIRED'
        election.save(update_fields=['deployment_status', 'updated_at'])
        raise BlockchainDeploymentError(
            f"Stale contract address detected at {checksum_addr}: no contract bytecode found on-chain "
            f"(blockchain node may have restarted). Redeployment is required."
        )

    return {
        'live': True,
        'verified': True,
        'chain_id': live_chain_id,
        'contract_address': checksum_addr,
        'bytecode_size': len(code) if isinstance(code, (bytes, bytearray)) else 0,
    }


def load_contract_artifact():
    """
    Load compiled EVoting.sol ABI, Bytecode, and DeployedBytecode.
    Checks Hardhat build directory first and falls back to committed EVoting.json in project root
    for container deployments where /artifacts is excluded.
    """
    candidate_paths = [
        os.path.join(settings.BASE_DIR, 'artifacts', 'blocks', 'contracts', 'EVoting.sol', 'EVoting.json'),
        os.path.join(settings.BASE_DIR, 'EVoting.json'),
    ]
    artifact_path = next((p for p in candidate_paths if os.path.exists(p)), None)
    if not artifact_path:
        raise BlockchainDeploymentError(
            "Contract artifact (EVoting.json) not found in artifacts directory or project root."
        )
    try:
        with open(artifact_path, 'r') as f:
            artifact = json.load(f)
    except Exception as e:
        raise BlockchainDeploymentError(f"Failed to parse contract artifact JSON: {str(e)}")

    if 'abi' not in artifact or 'bytecode' not in artifact:
        raise BlockchainDeploymentError("Contract artifact JSON is missing required 'abi' or 'bytecode' fields.")

    return artifact['abi'], artifact['bytecode'], artifact.get('deployedBytecode', '')


def validate_blockchain_configuration(config_override=None, is_production=None):
    """
    Validate blockchain RPC endpoint, chain ID, contract address, and server-side authority/deployer
    cryptographic configuration without exposing any private key material.
    Raises BlockchainDeploymentError with a clear operational message if invalid.
    """
    from urllib.parse import urlparse
    from eth_account import Account
    from EVoting.settings import KNOWN_DEV_PRIVATE_KEYS, HEX_PRIVATE_KEY_RE

    cfg = config_override or {}
    prod_mode = (
        bool(is_production)
        if is_production is not None
        else bool(cfg.get('IS_PRODUCTION', getattr(settings, 'IS_PRODUCTION', False)))
    )

    rpc_url = str(cfg.get('WEB3_RPC_URL', getattr(settings, 'WEB3_RPC_URL', '')) or '').strip()
    if not rpc_url:
        raise BlockchainDeploymentError("Blockchain configuration error: WEB3_RPC_URL is missing.")
    if not rpc_url.startswith(('http://', 'https://', 'ws://', 'wss://')):
        raise BlockchainDeploymentError(
            "Blockchain configuration error: WEB3_RPC_URL must use http://, https://, ws://, or wss://."
        )

    parsed_rpc = urlparse(rpc_url)
    rpc_host = (parsed_rpc.hostname or '').lower()
    allow_local_rpc = bool(
        cfg.get('ALLOW_LOCAL_RPC_IN_PRODUCTION', getattr(settings, 'ALLOW_LOCAL_RPC_IN_PRODUCTION', False))
    )
    if prod_mode and rpc_host in ('127.0.0.1', 'localhost', '::1') and not allow_local_rpc:
        raise BlockchainDeploymentError(
            "Blockchain configuration error: Production WEB3_RPC_URL cannot point to 127.0.0.1 or localhost."
        )
    require_https = bool(cfg.get('REQUIRE_HTTPS_RPC', getattr(settings, 'REQUIRE_HTTPS_RPC', prod_mode)))
    if (prod_mode or require_https) and rpc_host not in ('127.0.0.1', 'localhost', '::1'):
        if not rpc_url.startswith(('https://', 'wss://')):
            raise BlockchainDeploymentError(
                "Blockchain configuration error: Remote WEB3_RPC_URL must use https:// or wss://."
            )

    raw_chain_id = cfg.get('CHAIN_ID', getattr(settings, 'CHAIN_ID', None))
    try:
        chain_id = int(raw_chain_id)
    except (TypeError, ValueError):
        raise BlockchainDeploymentError("Blockchain configuration error: CHAIN_ID must be a valid integer.")
    if chain_id <= 0:
        raise BlockchainDeploymentError("Blockchain configuration error: CHAIN_ID must be a positive integer.")

    contract_addr = str(cfg.get('CONTRACT_ADDRESS', getattr(settings, 'CONTRACT_ADDRESS', '')) or '').strip()
    if contract_addr and not Web3.is_address(contract_addr):
        raise BlockchainDeploymentError("Blockchain configuration error: CONTRACT_ADDRESS is not a valid Ethereum address.")

    raw_auth_key = str(
        cfg.get('ELECTION_AUTHORITY_PRIVATE_KEY', getattr(settings, 'ELECTION_AUTHORITY_PRIVATE_KEY', '')) or ''
    ).strip()
    if not raw_auth_key or not HEX_PRIVATE_KEY_RE.match(raw_auth_key):
        raise BlockchainDeploymentError(
            "Blockchain configuration error: ELECTION_AUTHORITY_PRIVATE_KEY must be a valid 32-byte hex key."
        )
    norm_auth_key = raw_auth_key if raw_auth_key.startswith(('0x', '0X')) else '0x' + raw_auth_key
    if prod_mode and norm_auth_key.lower() in KNOWN_DEV_PRIVATE_KEYS:
        raise BlockchainDeploymentError(
            "Blockchain configuration error: ELECTION_AUTHORITY_PRIVATE_KEY cannot use a public development key in production."
        )
    try:
        derived_auth_address = Account.from_key(norm_auth_key).address
    except Exception:
        raise BlockchainDeploymentError(
            "Blockchain configuration error: ELECTION_AUTHORITY_PRIVATE_KEY is not a valid secp256k1 key."
        )

    from EVoting.settings import DEV_DEFAULT_AUTHORITY_ADDRESS, DEV_DEFAULT_AUTHORITY_PRIVATE_KEY
    configured_auth_addr = str(
        cfg.get('ELECTION_AUTHORITY_ADDRESS', getattr(settings, 'ELECTION_AUTHORITY_ADDRESS', '')) or ''
    ).strip()
    dev_derived_auth_addr = Account.from_key(DEV_DEFAULT_AUTHORITY_PRIVATE_KEY).address.lower()
    if (
        not prod_mode
        and 'ELECTION_AUTHORITY_ADDRESS' not in cfg
        and configured_auth_addr.lower() in (DEV_DEFAULT_AUTHORITY_ADDRESS.lower(), dev_derived_auth_addr)
        and norm_auth_key.lower() != DEV_DEFAULT_AUTHORITY_PRIVATE_KEY.lower()
    ):
        configured_auth_addr = derived_auth_address

    if configured_auth_addr and configured_auth_addr != '0x0000000000000000000000000000000000000000':
        if not Web3.is_address(configured_auth_addr):
            raise BlockchainDeploymentError(
                "Blockchain configuration error: ELECTION_AUTHORITY_ADDRESS is not a valid Ethereum address."
            )
        if configured_auth_addr.lower() != derived_auth_address.lower():
            raise BlockchainDeploymentError(
                "Blockchain configuration error: ELECTION_AUTHORITY_ADDRESS does not match derived authority key address."
            )

    raw_deployer_key = cfg.get(
        'BLOCKCHAIN_DEPLOYER_PRIVATE_KEY',
        getattr(settings, 'BLOCKCHAIN_DEPLOYER_PRIVATE_KEY', None),
    )
    deployer_address = None
    if raw_deployer_key and str(raw_deployer_key).strip():
        clean_dep = str(raw_deployer_key).strip()
        if not HEX_PRIVATE_KEY_RE.match(clean_dep):
            raise BlockchainDeploymentError(
                "Blockchain configuration error: BLOCKCHAIN_DEPLOYER_PRIVATE_KEY must be a valid 32-byte hex key."
            )
        norm_dep = clean_dep if clean_dep.startswith(('0x', '0X')) else '0x' + clean_dep
        if prod_mode and norm_dep.lower() in KNOWN_DEV_PRIVATE_KEYS:
            raise BlockchainDeploymentError(
                "Blockchain configuration error: BLOCKCHAIN_DEPLOYER_PRIVATE_KEY cannot use a public development key in production."
            )
        try:
            deployer_address = Account.from_key(norm_dep).address
        except Exception:
            raise BlockchainDeploymentError(
                "Blockchain configuration error: BLOCKCHAIN_DEPLOYER_PRIVATE_KEY is not a valid secp256k1 key."
            )
        if deployer_address.lower() == derived_auth_address.lower():
            raise BlockchainDeploymentError(
                "Blockchain configuration error: BLOCKCHAIN_DEPLOYER_PRIVATE_KEY and ELECTION_AUTHORITY_PRIVATE_KEY must belong to distinct accounts."
            )

    abi, bytecode, _ = load_contract_artifact()

    return {
        'valid': True,
        'rpc_endpoint': _sanitize_rpc_endpoint_label(rpc_url),
        'chain_id': chain_id,
        'contract_address': Web3.to_checksum_address(contract_addr) if contract_addr else None,
        'authority_address': derived_auth_address,
        'deployer_address': deployer_address,
        'artifact_loaded': bool(abi and bytecode),
    }



def inspect_deployed_contract(contract_address):
    """
    Verify on-chain contract code, bytecode hash, and availability of all EVoting.sol functions
    and state variables (including candidatesLocked, votingWindowLocked, getCandidateIds, and getCandidateCount).
    """
    w3 = get_web3_provider()
    if not w3.is_connected():
        raise BlockchainDeploymentError("Blockchain Node Unavailable: Cannot connect to Ethereum node.")

    if not contract_address or not Web3.is_address(contract_address):
        return {
            'has_code': False,
            'is_compatible': False,
            'contract_address': contract_address,
        }

    checksum_addr = Web3.to_checksum_address(contract_address)
    code = w3.eth.get_code(checksum_addr)
    if not code or code == b'' or code == '0x':
        return {
            'has_code': False,
            'is_compatible': False,
            'contract_address': checksum_addr,
        }

    bytecode_hash = '0x' + Web3.keccak(code).hex()
    abi, _, _ = load_contract_artifact()
    contract = w3.eth.contract(address=checksum_addr, abi=abi)
    abi_fn_names = {item.get('name') for item in abi if item.get('type') == 'function'}

    functions_verified = {}
    state_values = {}
    is_compatible = True

    core_views = [
        'owner',
        'electionOpen',
        'candidatesLocked',
        'votingWindowLocked',
        'votingStartTime',
        'votingEndTime',
        'totalVotes',
    ]

    for fn_name in core_views:
        try:
            val = getattr(contract.functions, fn_name)().call()
            if isinstance(val, bytes):
                val = '0x' + val.hex()
            elif isinstance(val, list):
                val = [int(x) for x in val]
            functions_verified[fn_name] = True
            state_values[fn_name] = val
        except Exception:
            functions_verified[fn_name] = False
            is_compatible = False

    for opt_fn in ('electionAuthority', 'electionId', 'DOMAIN_SEPARATOR', 'BALLOT_PERMIT_TYPEHASH'):
        if opt_fn in abi_fn_names:
            try:
                val = getattr(contract.functions, opt_fn)().call()
                if isinstance(val, bytes):
                    val = '0x' + val.hex()
                functions_verified[opt_fn] = True
                state_values[opt_fn] = val
            except Exception:
                functions_verified[opt_fn] = False
                is_compatible = False
        else:
            functions_verified[opt_fn] = True

    try:
        if 'getCandidateCount' in abi_fn_names:
            cand_count = int(contract.functions.getCandidateCount().call())
        else:
            cand_count = int(contract.functions.candidateCount().call())
        functions_verified['getCandidateCount'] = True
        state_values['getCandidateCount'] = cand_count
    except Exception:
        functions_verified['getCandidateCount'] = False
        is_compatible = False

    try:
        if 'getCandidateIds' in abi_fn_names:
            cand_ids = [int(x) for x in contract.functions.getCandidateIds().call()]
        else:
            cand_ids = []
            max_probe = max(int(state_values.get('getCandidateCount') or 0) + 5, 5)
            for probe_id in range(1, max_probe + 1):
                c_tuple = contract.functions.candidates(probe_id).call()
                if c_tuple and len(c_tuple) >= 5 and bool(c_tuple[4]):
                    cand_ids.append(int(c_tuple[0]))
        functions_verified['getCandidateIds'] = True
        state_values['getCandidateIds'] = cand_ids
    except Exception:
        functions_verified['getCandidateIds'] = False
        is_compatible = False

    try:
        cand_ids = state_values.get('getCandidateIds') or []
        if cand_ids:
            first_cid = int(cand_ids[0])
            state_values['first_candidate_votes'] = contract.functions.getCount(first_cid).call()
            if 1 in cand_ids:
                state_values['candidate_1_votes'] = contract.functions.getCount(1).call()
        else:
            # Verify candidates mapping getter is callable on empty roster
            contract.functions.candidates(1).call()
        functions_verified['getCount'] = True
    except Exception:
        functions_verified['getCount'] = False
        is_compatible = False

    try:
        contract.functions.hasVoted(b'\x00' * 32).call()
        functions_verified['hasVoted'] = True
    except Exception:
        functions_verified['hasVoted'] = False
        is_compatible = False

    if 'isNullifierConsumed' in abi_fn_names:
        try:
            contract.functions.isNullifierConsumed(b'\x00' * 32).call()
            functions_verified['isNullifierConsumed'] = True
        except Exception:
            functions_verified['isNullifierConsumed'] = False
            is_compatible = False
    else:
        functions_verified['isNullifierConsumed'] = True

    return {
        'has_code': True,
        'is_compatible': is_compatible,
        'chain_id': w3.eth.chain_id,
        'contract_address': checksum_addr,
        'deployed_bytecode_hash': bytecode_hash,
        'deployed_bytecode_size': len(code),
        'functions_verified': functions_verified,
        'state': state_values,
    }


def _archive_prior_deployments_and_permits(election):
    """
    Preserve any prior contract deployment in ContractDeployment without overwriting historical records,
    and mark prior IssuedPermit records as historical legacy records bound to their original contract address.
    """
    now = timezone.now()
    previous_address = election.contract_address.strip() if election.contract_address else ''

    if previous_address:
        prior_dep = ContractDeployment.objects.filter(
            election=election,
            contract_address__iexact=previous_address
        ).order_by('-id').first()

        if not prior_dep:
            prior_dep = ContractDeployment.objects.create(
                election=election,
                contract_address=previous_address,
                chain_id=election.chain_id,
                deployment_tx_hash=election.deployment_tx_hash or '',
                deployment_block_number=election.deployment_block_number,
                deployed_bytecode_hash=election.deployed_bytecode_hash or '',
                authority_address=election.authority_address or '',
                is_active_deployment=False,
                is_historical_legacy=True,
                superseded_at=now,
            )

        if not election.legacy_contract_address:
            election.legacy_contract_address = previous_address
        elif election.legacy_contract_address.lower() != previous_address.lower():
            election.legacy_contract_address = previous_address

        IssuedPermit.objects.filter(
            election_ref=election,
            is_historical_legacy=False
        ).update(
            is_historical_legacy=True,
            contract_address=previous_address,
            deployment_ref=prior_dep,
        )

    ContractDeployment.objects.filter(
        election=election,
        is_active_deployment=True
    ).update(
        is_active_deployment=False,
        is_historical_legacy=True,
        superseded_at=now,
    )


def initialize_legacy_election_2026_on_chain(election, contract_instance, w3, deployer, deployer_key=None):
    """
    Explicit legacy initialization path for Legacy Election 2026:
    Ensures the 3 legacy candidates exist in the database, populates them onto the
    deployed Election 2026 smart contract, locks the roster, and opens the election.
    """
    legacy_defaults = [
        (1, 'Rahul Gandhi', 'Congress', 'Candidate for Indian National Congress'),
        (2, 'Narendar Modi', 'BJP', 'Candidate for Bharatiya Janata Party'),
        (3, 'Akhilesh Yadav', 'Samajwadi', 'Candidate for Samajwadi Party'),
    ]
    for cid, name, symbol, desc in legacy_defaults:
        Candidate.objects.get_or_create(
            election=election,
            candidate_id_num=cid,
            defaults={
                'name': name,
                'symbol': symbol,
                'description': desc,
                'display_order': cid,
                'is_active': True,
            },
        )

    active_cands = election.candidates.filter(is_active=True).order_by('display_order', 'candidate_id_num')
    for cand in active_cands:
        onchain_cand = contract_instance.functions.candidates(cand.candidate_id_num).call()
        if not onchain_cand[4]:
            _, rec = _execute_deployer_tx(
                w3,
                contract_instance.functions.addCandidate(cand.candidate_id_num, cand.name, cand.symbol),
                deployer=deployer,
                deployer_key=deployer_key,
                timeout=60,
            )
            if not rec or rec.status != 1:
                raise BlockchainDeploymentError(
                    f"Legacy initialization failed while adding candidate #{cand.candidate_id_num}."
                )
        cand.is_synced_on_chain = True
        cand.save(update_fields=['is_synced_on_chain'])

    if not contract_instance.functions.candidatesLocked().call():
        _, lock_rec = _execute_deployer_tx(
            w3,
            contract_instance.functions.lockCandidates(),
            deployer=deployer,
            deployer_key=deployer_key,
            timeout=60,
        )
        if not lock_rec or lock_rec.status != 1:
            raise BlockchainDeploymentError("Legacy initialization failed while locking candidate roster.")

    abi_fn_names = {item.get('name') for item in contract_instance.abi if item.get('type') == 'function'}
    if 'setElectionOpen' in abi_fn_names:
        _, open_rec = _execute_deployer_tx(
            w3,
            contract_instance.functions.setElectionOpen(True),
            deployer=deployer,
            deployer_key=deployer_key,
            timeout=60,
        )
    else:
        if not contract_instance.functions.votingWindowLocked().call():
            now_ts = int(timezone.now().timestamp())
            start_ts = int(election.start_datetime.timestamp()) if election.start_datetime else max(1, now_ts - 60)
            end_ts = int(election.end_datetime.timestamp()) if election.end_datetime else (now_ts + 86400)
            try:
                latest_blk = w3.eth.get_block('latest')
                if latest_blk and 'timestamp' in latest_blk:
                    start_ts = min(start_ts, int(latest_blk['timestamp']))
            except Exception:
                pass
            _execute_deployer_tx(
                w3,
                contract_instance.functions.setVotingWindow(start_ts, end_ts),
                deployer=deployer,
                deployer_key=deployer_key,
                timeout=60,
            )
            _execute_deployer_tx(
                w3,
                contract_instance.functions.lockVotingWindow(),
                deployer=deployer,
                deployer_key=deployer_key,
                timeout=60,
            )
        _, open_rec = _execute_deployer_tx(
            w3,
            contract_instance.functions.openElection(),
            deployer=deployer,
            deployer_key=deployer_key,
            timeout=60,
        )
    if not open_rec or open_rec.status != 1:
        raise BlockchainDeploymentError("Legacy initialization failed while opening Election 2026.")


def deploy_election_contract(election_db_id, actor_user=None, force_redeploy=False, lock_roster=False):
    """
    Explicitly deploys an EVoting smart contract for the specified election.
    - Standard elections (DRAFT / SCHEDULED) initialize with an empty on-chain candidate roster
      and candidatesLocked = False (DRAFT -> CONTRACT DEPLOYED -> SCHEDULED).
    - Does NOT prematurely lock the candidate roster on deployment unless explicitly requested
      via lock_roster=True or during the Legacy Election 2026 ACTIVE bootstrap path.
    - Preserves all historical deployments in ContractDeployment without overwriting prior records.
    """
    w3 = get_web3_provider()
    if not w3.is_connected():
        rpc_label = _sanitize_rpc_endpoint_label(getattr(settings, 'WEB3_RPC_URL', 'http://127.0.0.1:8545'))
        raise BlockchainDeploymentError(
            f"Blockchain Node Unavailable: Cannot connect to Ethereum node at {rpc_label}"
        )

    try:
        election = Election.objects.get(pk=election_db_id)
    except Election.DoesNotExist:
        raise BlockchainDeploymentError(f"Election ID {election_db_id} not found in database.")

    if election.status in ('CLOSED', 'FINALIZED'):
        raise ElectionLifecycleError(
            f"Cannot deploy or replace smart contract after election is '{election.status}'."
        )
    if election.status == 'ACTIVE' and election.election_id != getattr(settings, 'ELECTION_ID', 2026):
        raise ElectionLifecycleError("Cannot redeploy smart contract while election is ACTIVE.")

    if (
        not force_redeploy
        and election.deployment_status == 'DEPLOYED'
        and election.contract_address
        and election.deployment_tx_hash
    ):
        inspection = inspect_deployed_contract(election.contract_address)
        if inspection.get('has_code') and inspection.get('is_compatible'):
            logger.info(f"Election '{election.title}' is already deployed and verified at {election.contract_address}")
            return election.contract_address

    previous_address = election.contract_address.strip() if election.contract_address else ''
    with transaction.atomic():
        _archive_prior_deployments_and_permits(election)
        election.deployment_status = 'PENDING_DEPLOYMENT'
        election.save(update_fields=['deployment_status', 'legacy_contract_address', 'updated_at'])

    try:
        abi, bytecode, _ = load_contract_artifact()
        deployer, deployer_key = _resolve_deployer_account_and_key(w3)

        authority = election.authority_address or getattr(
            settings, 'ELECTION_AUTHORITY_ADDRESS', '0xEe1BbC1BAf695c990ecb43e6Fd43d47060c12D58'
        )
        priv_key = getattr(settings, 'ELECTION_AUTHORITY_PRIVATE_KEY', None)
        if priv_key and not election.authority_address:
            from eth_account import Account
            authority = Account.from_key(priv_key).address

        # Deploy Contract Instance (initializes with 0 candidates, candidatesLocked=False, electionOpen=False)
        ContractFactory = w3.eth.contract(abi=abi, bytecode=bytecode)
        ctor_abi = next((item for item in abi if item.get('type') == 'constructor'), None)
        ctor_inputs = (ctor_abi.get('inputs') or []) if ctor_abi else []
        if len(ctor_inputs) >= 2:
            ctor_call = ContractFactory.constructor(authority, election.election_id)
        else:
            ctor_call = ContractFactory.constructor()
        tx_hash, receipt = _execute_deployer_tx(
            w3,
            ctor_call,
            deployer=deployer,
            deployer_key=deployer_key,
            timeout=60,
        )
        tx_hash_hex = tx_hash.hex() if isinstance(tx_hash, bytes) else str(tx_hash)
        if not tx_hash_hex.startswith('0x'):
            tx_hash_hex = '0x' + tx_hash_hex

        if not receipt or receipt.status != 1:
            raise BlockchainDeploymentError("Smart contract deployment transaction reverted on-chain.")

        contract_addr = receipt.contractAddress
        contract_instance = w3.eth.contract(address=contract_addr, abi=abi)

        # Configure start/end time window if already specified on the Election record
        start_ts = int(election.start_datetime.timestamp()) if election.start_datetime else 0
        end_ts = int(election.end_datetime.timestamp()) if election.end_datetime else 0
        if start_ts > 0 or end_ts > 0:
            _, w_rec = _execute_deployer_tx(
                w3,
                contract_instance.functions.setVotingWindow(start_ts, end_ts),
                deployer=deployer,
                deployer_key=deployer_key,
                timeout=60,
            )
            if not w_rec or w_rec.status != 1:
                raise BlockchainDeploymentError("Failed to configure initial voting window on deployed contract.")

        is_legacy_bootstrap = (
            election.election_id == getattr(settings, 'ELECTION_ID', 2026)
            and election.status == 'ACTIVE'
        )

        if is_legacy_bootstrap:
            initialize_legacy_election_2026_on_chain(
                election, contract_instance, w3, deployer, deployer_key=deployer_key
            )
            candidates_locked = True
            window_locked = True
        else:
            # Standard multi-election deployment:
            # Reset candidate sync flags for this fresh contract deployment and keep roster unlocked
            Candidate.objects.filter(election=election).update(is_synced_on_chain=False)
            if lock_roster:
                active_cands = list(
                    election.candidates.filter(is_active=True).order_by('display_order', 'candidate_id_num')
                )
                if not active_cands:
                    raise ElectionLifecycleError("Cannot lock an empty candidate roster during deployment.")
                for cand in active_cands:
                    _, c_rec = _execute_deployer_tx(
                        w3,
                        contract_instance.functions.addCandidate(
                            cand.candidate_id_num, cand.name, cand.symbol
                        ),
                        deployer=deployer,
                        deployer_key=deployer_key,
                        timeout=60,
                    )
                    if not c_rec or c_rec.status != 1:
                        raise BlockchainDeploymentError(
                            f"Failed to register candidate #{cand.candidate_id_num} on-chain."
                        )
                    cand.is_synced_on_chain = True
                    cand.save(update_fields=['is_synced_on_chain'])
                _, l_rec = _execute_deployer_tx(
                    w3,
                    contract_instance.functions.lockCandidates(),
                    deployer=deployer,
                    deployer_key=deployer_key,
                    timeout=60,
                )
                if not l_rec or l_rec.status != 1:
                    raise BlockchainDeploymentError("Failed to lock candidate roster on-chain.")
                candidates_locked = True
            else:
                candidates_locked = False
            window_locked = False

        deployed_code = w3.eth.get_code(contract_addr)
        bytecode_hash = '0x' + Web3.keccak(deployed_code).hex()
        current_chain_id = w3.eth.chain_id

        with transaction.atomic():
            deployment_record = ContractDeployment.objects.create(
                election=election,
                contract_address=contract_addr,
                chain_id=current_chain_id,
                deployment_tx_hash=tx_hash_hex,
                deployment_block_number=receipt.blockNumber,
                deployed_bytecode_hash=bytecode_hash,
                authority_address=authority,
                is_active_deployment=True,
                is_historical_legacy=False,
            )

            election.contract_address = contract_addr
            election.authority_address = authority
            election.chain_id = current_chain_id
            election.deployment_tx_hash = tx_hash_hex
            election.deployment_block_number = receipt.blockNumber
            election.deployed_bytecode_hash = bytecode_hash
            election.deployment_status = 'DEPLOYED'
            election.candidates_locked_on_chain = candidates_locked
            election.voting_window_locked_on_chain = window_locked
            election.results_verified = False
            if election.status == 'DRAFT':
                election.status = 'SCHEDULED'
            election.save()

            if previous_address and previous_address.lower() != contract_addr.lower():
                VoterEligibility.objects.filter(election=election).update(has_voted=False, voted_at=None)
                if election.election_id == getattr(settings, 'ELECTION_ID', 2026):
                    from .models import Voter
                    Voter.objects.all().update(has_voted=False, voted_at=None)

            AdminAuditLog.objects.create(
                actor=actor_user,
                action='ELECTION_CONTRACT_DEPLOYED',
                target_model='Election',
                target_id=str(election.pk),
                details=json.dumps({
                    'deployment_id': deployment_record.pk,
                    'contract_address': contract_addr,
                    'legacy_contract_address': election.legacy_contract_address,
                    'tx_hash': tx_hash_hex,
                    'block_number': receipt.blockNumber,
                    'bytecode_hash': bytecode_hash,
                    'chain_id': current_chain_id,
                    'candidates_locked': candidates_locked,
                })
            )

        return contract_addr

    except ElectionLifecycleError:
        election.deployment_status = 'DEPLOYMENT_FAILED'
        election.save(update_fields=['deployment_status', 'updated_at'])
        raise
    except Exception as e:
        election.deployment_status = 'DEPLOYMENT_FAILED'
        election.save(update_fields=['deployment_status', 'updated_at'])
        logger.error(f"Blockchain deployment failed for election {election_db_id}: {e}")
        raise BlockchainDeploymentError(f"Deployment failed: {str(e)}")


# ==========================================
# MODULE 4: CANDIDATE MANAGEMENT SERVICES
# ==========================================

def _assert_candidate_roster_mutable(election):
    """
    Verify server-side and on-chain that the election's candidate roster is not locked
    and that the election has not entered ACTIVE, CLOSED, or FINALIZED states.
    """
    if election.status in ('ACTIVE', 'CLOSED', 'FINALIZED'):
        raise ElectionLifecycleError(
            f"Candidate roster cannot be modified when election is in '{election.status}' state."
        )
    if election.candidates_locked_on_chain:
        raise ElectionLifecycleError("Candidate roster is locked and cannot be modified.")

    if election.deployment_status == 'DEPLOYED' and election.contract_address:
        w3 = get_web3_provider()
        if w3.is_connected():
            try:
                abi, _, _ = load_contract_artifact()
                contract = w3.eth.contract(
                    address=Web3.to_checksum_address(election.contract_address),
                    abi=abi
                )
                if contract.functions.candidatesLocked().call():
                    election.candidates_locked_on_chain = True
                    election.save(update_fields=['candidates_locked_on_chain', 'updated_at'])
                    raise ElectionLifecycleError("Candidate roster is locked on-chain and cannot be modified.")
            except ElectionLifecycleError:
                raise
            except Exception:
                pass


def verify_election_candidate_parity(election, w3=None, contract=None):
    """
    Verify exact database vs. on-chain candidate parity for an election:
    1. At least one active candidate exists in the database.
    2. Every active DB candidate has is_synced_on_chain == True.
    3. On-chain getCandidateIds() has no missing IDs, no unexpected/extra IDs, and no duplicate IDs.
    4. Every candidate's on-chain (name, symbol) matches its database record.
    """
    if election.deployment_status != 'DEPLOYED' or not election.contract_address:
        raise ElectionLifecycleError("Cannot verify candidate parity before smart contract deployment.")

    active_candidates = list(
        election.candidates.filter(is_active=True).order_by('display_order', 'candidate_id_num')
    )
    if not active_candidates:
        raise ElectionLifecycleError("Election must have at least one active candidate.")

    unsynced = [c.candidate_id_num for c in active_candidates if not c.is_synced_on_chain]
    if unsynced:
        raise ElectionLifecycleError(
            f"Active candidates {unsynced} are not marked as synchronized on-chain."
        )

    w3 = w3 or get_web3_provider()
    if not w3.is_connected():
        raise BlockchainDeploymentError("Blockchain Node Unavailable: Cannot verify on-chain candidate parity.")

    if contract is None:
        abi, _, _ = load_contract_artifact()
        contract = w3.eth.contract(address=Web3.to_checksum_address(election.contract_address), abi=abi)

    abi_fn_names = {item.get('name') for item in getattr(contract, 'abi', []) if item.get('type') == 'function'}
    try:
        if 'getCandidateIds' in abi_fn_names or hasattr(contract.functions, 'getCandidateIds'):
            raw_onchain_ids = contract.functions.getCandidateIds().call()
            onchain_ids = [int(x) for x in raw_onchain_ids]
        else:
            onchain_count = int(contract.functions.candidateCount().call())
            max_db_id = max((int(c.candidate_id_num) for c in active_candidates), default=0)
            probe_ids = sorted(set(range(1, max(onchain_count + 5, max_db_id + 3))) | {int(c.candidate_id_num) for c in active_candidates})
            onchain_ids = []
            for pid in probe_ids:
                c_data = contract.functions.candidates(pid).call()
                if c_data and len(c_data) >= 5 and bool(c_data[4]):
                    onchain_ids.append(int(c_data[0]))
    except Exception as e:
        raise BlockchainDeploymentError(f"Failed to read on-chain candidateIds: {str(e)}")

    if len(onchain_ids) != len(set(onchain_ids)):
        raise ElectionLifecycleError("Duplicate candidate IDs detected on-chain.")

    db_ids = {int(c.candidate_id_num) for c in active_candidates}
    onchain_id_set = set(onchain_ids)

    missing_on_chain = sorted(db_ids - onchain_id_set)
    if missing_on_chain:
        raise ElectionLifecycleError(
            f"Candidate parity check failed: Active DB candidate IDs {missing_on_chain} are missing on-chain."
        )

    unexpected_on_chain = sorted(onchain_id_set - db_ids)
    if unexpected_on_chain:
        raise ElectionLifecycleError(
            f"Candidate parity check failed: Unexpected candidate IDs {unexpected_on_chain} exist on-chain "
            f"but are inactive or missing in database."
        )

    for cand in active_candidates:
        c_data = contract.functions.candidates(cand.candidate_id_num).call()
        if not c_data[4]:
            raise ElectionLifecycleError(
                f"Candidate #{cand.candidate_id_num} ('{cand.name}') does not exist on-chain."
            )
        if c_data[1] != cand.name or c_data[2] != cand.symbol:
            raise ElectionLifecycleError(
                f"Candidate #{cand.candidate_id_num} mismatch: DB has ('{cand.name}', '{cand.symbol}') "
                f"but contract has ('{c_data[1]}', '{c_data[2]}')."
            )

    return {
        'parity_verified': True,
        'candidate_ids': sorted(db_ids),
        'count': len(db_ids),
    }


def add_election_candidate(
    election_db_id,
    candidate_id_num,
    name,
    symbol,
    description='',
    display_order=None,
    is_active=True,
    sync_on_chain=True,
    actor_user=None,
):
    """
    Create a new candidate for an election prior to roster lock.
    - Uses row-level locking on Election inside transaction.atomic() so concurrent additions cannot race.
    - Creates the DB record with is_synced_on_chain=False first.
    - If the contract is deployed and sync_on_chain=True, submits addCandidate on-chain, waits for a
      successful transaction receipt (status == 1), and only then sets is_synced_on_chain=True.
    - Failed on-chain transactions never mark candidates as synchronized.
    """
    try:
        cid = int(candidate_id_num)
    except (TypeError, ValueError):
        raise ElectionLifecycleError("Candidate ID must be a valid integer.")
    if cid <= 0:
        raise ElectionLifecycleError("Candidate ID must be a positive integer.")

    clean_name = str(name or '').strip()
    clean_symbol = str(symbol or '').strip()
    clean_desc = str(description or '').strip()

    if not clean_name:
        raise ElectionLifecycleError("Candidate name cannot be empty.")
    if len(clean_name) > 150:
        raise ElectionLifecycleError("Candidate name cannot exceed 150 characters.")
    if not clean_symbol:
        raise ElectionLifecycleError("Candidate symbol cannot be empty.")
    if len(clean_symbol) > 100:
        raise ElectionLifecycleError("Candidate symbol cannot exceed 100 characters.")

    with transaction.atomic():
        election = Election.objects.select_for_update().get(pk=election_db_id)
        _assert_candidate_roster_mutable(election)

        if Candidate.objects.filter(election=election, candidate_id_num=cid).exists():
            raise ElectionLifecycleError(f"Candidate ID #{cid} already exists in this election.")

        if Candidate.objects.filter(election=election, name__iexact=clean_name).exists():
            raise ElectionLifecycleError(f"Candidate '{clean_name}' is already registered in this election.")

        if display_order is None:
            max_order = (
                Candidate.objects.filter(election=election)
                .order_by('-display_order')
                .values_list('display_order', flat=True)
                .first()
            )
            order_val = (max_order or 0) + 1
        else:
            try:
                order_val = int(display_order)
            except (TypeError, ValueError):
                raise ElectionLifecycleError("Display order must be an integer.")

        candidate = Candidate.objects.create(
            election=election,
            candidate_id_num=cid,
            name=clean_name,
            symbol=clean_symbol,
            description=clean_desc,
            display_order=order_val,
            is_active=bool(is_active),
            is_synced_on_chain=False,
        )

        AdminAuditLog.objects.create(
            actor=actor_user,
            action='CANDIDATE_ADDED',
            target_model='Election',
            target_id=str(election.pk),
            details=json.dumps({
                'candidate_id_num': cid,
                'name': clean_name,
                'symbol': clean_symbol,
                'display_order': order_val,
                'is_active': candidate.is_active,
                'is_synced_on_chain': False,
            })
        )

    if bool(is_active) and sync_on_chain and election.deployment_status == 'DEPLOYED' and election.contract_address:
        w3 = get_web3_provider()
        if not w3.is_connected():
            raise BlockchainDeploymentError("Blockchain Node Unavailable: Cannot sync new candidate on-chain.")
        abi, _, _ = load_contract_artifact()
        contract = w3.eth.contract(address=Web3.to_checksum_address(election.contract_address), abi=abi)
        onchain_cand = contract.functions.candidates(cid).call()
        if onchain_cand[4]:  # exists == True
            if onchain_cand[1] != clean_name or onchain_cand[2] != clean_symbol:
                raise ElectionLifecycleError(
                    f"Candidate ID #{cid} is already occupied on-chain by '{onchain_cand[1]} ({onchain_cand[2]})'."
                )
        else:
            deployer, deployer_key = _resolve_deployer_account_and_key(w3)
            try:
                _, receipt = _execute_deployer_tx(
                    w3,
                    contract.functions.addCandidate(cid, clean_name, clean_symbol),
                    deployer=deployer,
                    deployer_key=deployer_key,
                    timeout=60,
                )
            except Exception as e:
                raise BlockchainDeploymentError(f"On-chain addCandidate transaction failed: {str(e)}")
            if not receipt or receipt.status != 1:
                raise BlockchainDeploymentError("On-chain addCandidate transaction reverted (status != 1).")

        candidate.is_synced_on_chain = True
        candidate.save(update_fields=['is_synced_on_chain'])

    return candidate


def update_election_candidate(
    election_db_id,
    candidate_id_num,
    name=None,
    symbol=None,
    description=None,
    display_order=None,
    is_active=None,
    actor_user=None,
):
    """
    Update an existing candidate prior to roster lock.
    Enforces on-chain immutability: once a candidate is synchronized on-chain (or exists on the deployed
    contract), its (name, symbol) or active status cannot silently change without redeploying the contract.
    """
    with transaction.atomic():
        election = Election.objects.select_for_update().get(pk=election_db_id)
        _assert_candidate_roster_mutable(election)

        candidate = (
            Candidate.objects.select_for_update()
            .filter(election=election, candidate_id_num=candidate_id_num)
            .first()
        )
        if not candidate:
            raise ElectionLifecycleError(f"Candidate #{candidate_id_num} not found in this election.")

        new_name = str(name).strip() if name is not None else candidate.name
        new_symbol = str(symbol).strip() if symbol is not None else candidate.symbol
        new_desc = str(description).strip() if description is not None else candidate.description
        new_order = int(display_order) if display_order is not None else candidate.display_order
        new_active = bool(is_active) if is_active is not None else candidate.is_active

        if not new_name:
            raise ElectionLifecycleError("Candidate name cannot be empty.")
        if not new_symbol:
            raise ElectionLifecycleError("Candidate symbol cannot be empty.")

        if (
            Candidate.objects.filter(election=election, name__iexact=new_name)
            .exclude(pk=candidate.pk)
            .exists()
        ):
            raise ElectionLifecycleError(f"Another candidate with name '{new_name}' already exists in this election.")

        # Enforce immutability if candidate has already been committed on-chain
        onchain_committed = candidate.is_synced_on_chain
        onchain_name = candidate.name
        onchain_symbol = candidate.symbol

        if election.deployment_status == 'DEPLOYED' and election.contract_address:
            w3 = get_web3_provider()
            if w3.is_connected():
                abi, _, _ = load_contract_artifact()
                contract = w3.eth.contract(address=Web3.to_checksum_address(election.contract_address), abi=abi)
                onchain_cand = contract.functions.candidates(candidate.candidate_id_num).call()
                if onchain_cand[4]:
                    onchain_committed = True
                    onchain_name = onchain_cand[1]
                    onchain_symbol = onchain_cand[2]

        if onchain_committed:
            if new_name != onchain_name or new_symbol != onchain_symbol:
                raise ElectionLifecycleError(
                    "Cannot modify name or symbol of a candidate already committed on the smart contract. "
                    "Force-redeploy the contract in SCHEDULED state before locking if identity changes are needed."
                )
            if not new_active:
                raise ElectionLifecycleError(
                    "Cannot deactivate a candidate that has already been synchronized to the smart contract."
                )

        candidate.name = new_name
        candidate.symbol = new_symbol
        candidate.description = new_desc
        candidate.display_order = new_order
        candidate.is_active = new_active
        candidate.save()

        audit_action = 'CANDIDATE_DEACTIVATED' if (is_active is False) else 'CANDIDATE_UPDATED'
        AdminAuditLog.objects.create(
            actor=actor_user,
            action=audit_action,
            target_model='Election',
            target_id=str(election.pk),
            details=json.dumps({
                'candidate_id_num': candidate.candidate_id_num,
                'name': candidate.name,
                'symbol': candidate.symbol,
                'display_order': candidate.display_order,
                'is_active': candidate.is_active,
                'is_synced_on_chain': candidate.is_synced_on_chain,
            })
        )

    return candidate


def deactivate_election_candidate(election_db_id, candidate_id_num, actor_user=None):
    """Deactivate an unsynchronized candidate prior to roster lock."""
    return update_election_candidate(
        election_db_id=election_db_id,
        candidate_id_num=candidate_id_num,
        is_active=False,
        actor_user=actor_user,
    )


def sync_and_lock_candidates(election_db_id, lock_on_chain=True, actor_user=None):
    """
    Synchronize all active database candidates to the deployed smart contract, verify exact
    DB/on-chain candidate parity, and optionally permanently lock the candidate roster on-chain.
    """
    pre_el = Election.objects.get(pk=election_db_id)
    _assert_candidate_roster_mutable(pre_el)
    if pre_el.deployment_status != 'DEPLOYED' or not pre_el.contract_address:
        raise ElectionLifecycleError("Cannot sync or lock candidates on-chain before contract deployment.")
    if not pre_el.candidates.filter(is_active=True).exists():
        raise ElectionLifecycleError("Cannot sync or lock an empty candidate roster. Add at least one active candidate.")

    w3 = get_web3_provider()
    if not w3.is_connected():
        raise BlockchainDeploymentError("Blockchain Node Unavailable: Cannot sync or lock candidates on-chain.")

    # Verify live chain ID and contract bytecode outside the inner atomic block so
    # CHAIN_RESET_REDEPLOY_REQUIRED is committed if the node was restarted.
    verify_live_election_contract_on_chain(pre_el, w3=w3)

    with transaction.atomic():
        election = Election.objects.select_for_update().get(pk=election_db_id)
        _assert_candidate_roster_mutable(election)

        if election.deployment_status != 'DEPLOYED' or not election.contract_address:
            raise ElectionLifecycleError("Cannot sync or lock candidates on-chain before contract deployment.")

        active_candidates = list(
            election.candidates.filter(is_active=True).order_by('display_order', 'candidate_id_num')
        )
        if not active_candidates:
            raise ElectionLifecycleError("Cannot sync or lock an empty candidate roster. Add at least one active candidate.")

        abi, _, _ = load_contract_artifact()
        contract = w3.eth.contract(address=Web3.to_checksum_address(election.contract_address), abi=abi)
        deployer, deployer_key = _resolve_deployer_account_and_key(w3)

        synced_ids = []
        for cand in active_candidates:
            onchain_cand = contract.functions.candidates(cand.candidate_id_num).call()
            if not onchain_cand[4]:
                try:
                    _, receipt = _execute_deployer_tx(
                        w3,
                        contract.functions.addCandidate(
                            cand.candidate_id_num, cand.name, cand.symbol
                        ),
                        deployer=deployer,
                        deployer_key=deployer_key,
                        timeout=60,
                    )
                except Exception as e:
                    raise BlockchainDeploymentError(
                        f"Failed to register candidate #{cand.candidate_id_num} on-chain: {str(e)}"
                    )
                if not receipt or receipt.status != 1:
                    raise BlockchainDeploymentError(
                        f"On-chain addCandidate transaction for #{cand.candidate_id_num} reverted."
                    )
            else:
                if onchain_cand[1] != cand.name or onchain_cand[2] != cand.symbol:
                    raise ElectionLifecycleError(
                        f"On-chain candidate #{cand.candidate_id_num} ('{onchain_cand[1]}', '{onchain_cand[2]}') "
                        f"does not match DB ('{cand.name}', '{cand.symbol}')."
                    )
            cand.is_synced_on_chain = True
            cand.save(update_fields=['is_synced_on_chain'])
            synced_ids.append(cand.candidate_id_num)

        # Verify strict DB/on-chain parity (no missing or unexpected candidate IDs on-chain)
        verify_election_candidate_parity(election, w3=w3, contract=contract)

        if lock_on_chain:
            if contract.functions.candidatesLocked().call():
                raise ElectionLifecycleError("Candidate roster is already locked on-chain.")
            _, lock_receipt = _execute_deployer_tx(
                w3,
                contract.functions.lockCandidates(),
                deployer=deployer,
                deployer_key=deployer_key,
                timeout=60,
            )
            if not lock_receipt or lock_receipt.status != 1:
                raise BlockchainDeploymentError("On-chain lockCandidates transaction reverted.")

        is_locked = bool(contract.functions.candidatesLocked().call())
        election.candidates_locked_on_chain = is_locked
        election.save(update_fields=['candidates_locked_on_chain', 'updated_at'])

        AdminAuditLog.objects.create(
            actor=actor_user,
            action='CANDIDATES_SYNCED_AND_LOCKED' if is_locked else 'CANDIDATES_SYNCED',
            target_model='Election',
            target_id=str(election.pk),
            details=json.dumps({
                'synced_candidate_ids': synced_ids,
                'candidates_locked_on_chain': is_locked,
            })
        )

    return election


def get_election_candidates_status(election_db_id):
    """
    Return the election's candidate roster along with on-chain synchronization, parity, and lock status.
    """
    election = Election.objects.get(pk=election_db_id)
    w3 = get_web3_provider()
    contract = None
    onchain_locked = election.candidates_locked_on_chain
    onchain_ids = []

    if election.deployment_status == 'DEPLOYED' and election.contract_address and w3.is_connected():
        try:
            abi, _, _ = load_contract_artifact()
            contract = w3.eth.contract(address=Web3.to_checksum_address(election.contract_address), abi=abi)
            onchain_locked = bool(contract.functions.candidatesLocked().call())
            abi_fn_names = {item.get('name') for item in abi if item.get('type') == 'function'}
            if 'getCandidateIds' in abi_fn_names:
                onchain_ids = [int(x) for x in contract.functions.getCandidateIds().call()]
            else:
                onchain_count = int(contract.functions.candidateCount().call())
                for pid in range(1, max(onchain_count + 5, 10)):
                    c_data = contract.functions.candidates(pid).call()
                    if c_data and len(c_data) >= 5 and bool(c_data[4]):
                        onchain_ids.append(int(c_data[0]))
        except Exception:
            contract = None

    roster = []
    for cand in election.candidates.all().order_by('display_order', 'candidate_id_num'):
        onchain_exists = False
        onchain_matches = False
        if contract:
            try:
                c_data = contract.functions.candidates(cand.candidate_id_num).call()
                onchain_exists = bool(c_data[4])
                onchain_matches = onchain_exists and (c_data[1] == cand.name and c_data[2] == cand.symbol)
            except Exception:
                pass

        roster.append({
            'id': cand.pk,
            'candidate_id': cand.candidate_id_num,
            'name': cand.name,
            'symbol': cand.symbol,
            'description': cand.description,
            'display_order': cand.display_order,
            'is_active': cand.is_active,
            'is_synced_on_chain': bool(cand.is_synced_on_chain and onchain_matches) if contract else cand.is_synced_on_chain,
            'onchain_exists': onchain_exists,
            'onchain_matches': onchain_matches,
        })

    return {
        'election_id': election.election_id,
        'status': election.status,
        'deployment_status': election.deployment_status,
        'contract_address': election.contract_address,
        'candidates_locked_on_chain': onchain_locked,
        'onchain_candidate_ids': onchain_ids,
        'roster_mutable': (not onchain_locked) and (election.status in ('DRAFT', 'SCHEDULED')),
        'candidates': roster,
    }


# ==========================================
# MODULE 3: LIFECYCLE & RECONCILIATION
# ==========================================

def validate_immediate_duration(duration_val):
    """
    Validate that duration is an integer strictly between 1 and 24 hours.
    Rejects zero, negative, fractional, boolean, missing, and values > 24.
    """
    if duration_val is None:
        raise ElectionLifecycleError("Voting duration (1-24 hours) is required for Immediate elections.")
    if isinstance(duration_val, bool):
        raise ElectionLifecycleError("Voting duration must be an integer between 1 and 24 hours.")
    try:
        if isinstance(duration_val, float):
            if not duration_val.is_integer():
                raise ElectionLifecycleError("Voting duration must be a whole integer between 1 and 24 hours.")
            ival = int(duration_val)
        elif isinstance(duration_val, int):
            ival = duration_val
        elif isinstance(duration_val, str):
            clean_str = duration_val.strip()
            if not clean_str.isdigit():
                raise ElectionLifecycleError("Voting duration must be an integer between 1 and 24 hours.")
            ival = int(clean_str)
        else:
            raise ElectionLifecycleError("Voting duration must be an integer between 1 and 24 hours.")
    except (ValueError, TypeError):
        raise ElectionLifecycleError("Voting duration must be an integer between 1 and 24 hours.")

    if ival < 1 or ival > 24:
        raise ElectionLifecycleError("Voting duration must be strictly between 1 and 24 hours.")
    return ival


def configure_voting_window(
    election_db_id,
    start_datetime=None,
    end_datetime=None,
    actor_user=None,
    commencement_mode=None,
    immediate_duration_hours=None,
):
    """
    Configure or update the voting window and commencement mode before election activation.
    Reverts if the election has already been activated or if votingWindowLocked is True.
    """
    election = Election.objects.get(pk=election_db_id)

    if election.voting_window_locked_on_chain or election.status in ('ACTIVE', 'CLOSED', 'FINALIZED'):
        raise ElectionLifecycleError("Voting window is locked and cannot be modified after election activation.")

    target_mode = commencement_mode.upper() if commencement_mode else election.commencement_mode
    if target_mode not in ('SCHEDULED', 'IMMEDIATE'):
        raise ElectionLifecycleError("Invalid commencement mode specified.")

    if target_mode == 'SCHEDULED':
        if not start_datetime or not end_datetime:
            raise ElectionLifecycleError("Scheduled election requires both start and end datetimes.")
        if end_datetime <= start_datetime:
            raise ElectionLifecycleError("End time must be after start time.")
        target_start = start_datetime
        target_end = end_datetime
        target_duration = None
    else:
        # IMMEDIATE mode: Actual start and end timestamps are calculated upon activation.
        target_start = None
        target_end = None
        if immediate_duration_hours is not None:
            target_duration = validate_immediate_duration(immediate_duration_hours)
        else:
            target_duration = election.immediate_duration_hours

    start_ts = int(target_start.timestamp()) if target_start else 0
    end_ts = int(target_end.timestamp()) if target_end else 0

    if election.deployment_status == 'DEPLOYED' and election.contract_address:
        w3 = get_web3_provider()
        if not w3.is_connected():
            raise BlockchainDeploymentError("Blockchain Node Unavailable: Cannot update voting window on-chain.")
        abi, _, _ = load_contract_artifact()
        contract = w3.eth.contract(address=Web3.to_checksum_address(election.contract_address), abi=abi)
        if contract.functions.votingWindowLocked().call():
            election.voting_window_locked_on_chain = True
            election.save(update_fields=['voting_window_locked_on_chain'])
            raise ElectionLifecycleError("On-chain voting window is already locked.")

        deployer, deployer_key = _resolve_deployer_account_and_key(w3)
        _, rec = _execute_deployer_tx(
            w3,
            contract.functions.setVotingWindow(start_ts, end_ts),
            deployer=deployer,
            deployer_key=deployer_key,
            timeout=60,
        )
        if not rec or rec.status != 1:
            raise BlockchainDeploymentError("Failed to update voting window on-chain.")

    election.commencement_mode = target_mode
    election.immediate_duration_hours = target_duration
    election.start_datetime = target_start
    election.end_datetime = target_end
    election.save(update_fields=[
        'commencement_mode',
        'immediate_duration_hours',
        'start_datetime',
        'end_datetime',
        'updated_at',
    ])

    AdminAuditLog.objects.create(
        actor=actor_user,
        action='VOTING_WINDOW_CONFIGURED',
        target_model='Election',
        target_id=str(election.pk),
        details=json.dumps({
            'commencement_mode': target_mode,
            'immediate_duration_hours': target_duration,
            'start_ts': start_ts,
            'end_ts': end_ts,
        })
    )
    return election


def activate_election(election_db_id, actor_user=None):
    """
    Transition election from SCHEDULED -> ACTIVE following the strict sequence:
    DRAFT -> CONTRACT DEPLOYED -> SCHEDULED -> CANDIDATE SYNCHRONIZATION -> CANDIDATE LOCK -> ACTIVE.
    - Rejects activation without contract deployment.
    - Rejects activation if the candidate roster is not locked (both in DB and on-chain).
    - Rejects activation if any active candidate is unsynchronized or fails exact DB/on-chain parity.
    - Rejects premature activation for Scheduled elections before their configured commencement time.
    - Validates duration (1-24 hours) and calculates start and end timestamps at activation time for Immediate elections.
    - Verifies and permanently locks the voting window on-chain with non-zero start and end timestamps.
    """
    election = Election.objects.get(pk=election_db_id)
    if election.status in ('CLOSED', 'FINALIZED'):
        raise ElectionLifecycleError(
            f"Cannot reopen an election that has already been '{election.status}'."
        )
    if election.status == 'ACTIVE':
        raise ElectionLifecycleError("Election is already ACTIVE. Repeated activation is not permitted.")
    if election.deployment_status != 'DEPLOYED' or not election.contract_address:
        raise ElectionLifecycleError("Cannot activate an election whose smart contract is not deployed.")
    if election.status != 'SCHEDULED':
        raise ElectionLifecycleError(f"Cannot activate election in '{election.status}' state. Must be 'SCHEDULED'.")

    if not election.candidates.filter(is_active=True).exists():
        raise ElectionLifecycleError("Cannot activate an election with no active candidates.")

    if not election.candidates_locked_on_chain:
        raise ElectionLifecycleError(
            "Cannot activate election: Candidate roster must be synchronized and locked before activation."
        )

    now = timezone.now()
    if election.commencement_mode == 'SCHEDULED':
        if not election.start_datetime or not election.end_datetime:
            raise ElectionLifecycleError("Cannot activate scheduled election: Incomplete schedule configuration.")
        if election.end_datetime <= election.start_datetime:
            raise ElectionLifecycleError("Cannot activate election: Invalid voting window (end time must be after start time).")
        if now < election.start_datetime:
            raise ElectionLifecycleError(
                f"Cannot activate scheduled election before its configured commencement time ({election.start_datetime.isoformat()})."
            )
        if now >= election.end_datetime:
            raise ElectionLifecycleError("Cannot activate scheduled election after its configured end time.")
        expected_start_ts = int(election.start_datetime.timestamp())
        expected_end_ts = int(election.end_datetime.timestamp())
        actual_activation_start = election.start_datetime
        actual_activation_end = election.end_datetime
    else:
        # IMMEDIATE mode: Duration (1-24h) is strictly validated, start timestamp is the moment of activation,
        # and end timestamp is calculated as start + duration.
        duration_hours = validate_immediate_duration(election.immediate_duration_hours)
        actual_activation_start = now
        actual_activation_end = now + timedelta(hours=duration_hours)
        expected_start_ts = int(actual_activation_start.timestamp())
        expected_end_ts = int(actual_activation_end.timestamp())

    w3 = get_web3_provider()
    if not w3.is_connected():
        raise BlockchainDeploymentError("Blockchain Node Unavailable: Cannot activate election on-chain.")

    verify_live_election_contract_on_chain(election, w3=w3)

    inspection = inspect_deployed_contract(election.contract_address)
    if not inspection.get('has_code') or not inspection.get('is_compatible'):
        raise ElectionLifecycleError("Cannot activate election: Deployed contract is missing or incompatible on-chain.")

    abi, _, _ = load_contract_artifact()
    contract = w3.eth.contract(address=Web3.to_checksum_address(election.contract_address), abi=abi)
    deployer, deployer_key = _resolve_deployer_account_and_key(w3)

    # 1. Verify candidate roster is locked on-chain
    if not contract.functions.candidatesLocked().call():
        raise ElectionLifecycleError(
            "Cannot activate election: Candidate roster is not locked on the smart contract."
        )

    # 2. Verify exact DB/on-chain candidate parity (no missing, unexpected, or mismatched candidates)
    parity = verify_election_candidate_parity(election, w3=w3, contract=contract)

    # 3. Configure voting window on-chain if not yet locked, then open election (which locks votingWindowLocked)
    abi_fn_names = {item.get('name') for item in abi if item.get('type') == 'function'}
    if not contract.functions.votingWindowLocked().call():
        if expected_start_ts > 0 or expected_end_ts > 0:
            _, w_rec = _execute_deployer_tx(
                w3,
                contract.functions.setVotingWindow(expected_start_ts, expected_end_ts),
                deployer=deployer,
                deployer_key=deployer_key,
                timeout=60,
            )
            if not w_rec or w_rec.status != 1:
                raise BlockchainDeploymentError("Failed to synchronize voting window on-chain prior to activation.")
        if 'setElectionOpen' not in abi_fn_names:
            _, lw_rec = _execute_deployer_tx(
                w3,
                contract.functions.lockVotingWindow(),
                deployer=deployer,
                deployer_key=deployer_key,
                timeout=60,
            )
            if not lw_rec or lw_rec.status != 1:
                raise BlockchainDeploymentError("Failed to lock voting window on-chain prior to activation.")

    if 'setElectionOpen' in abi_fn_names:
        tx, receipt = _execute_deployer_tx(
            w3,
            contract.functions.setElectionOpen(True),
            deployer=deployer,
            deployer_key=deployer_key,
            timeout=60,
        )
    else:
        try:
            from .simple_voting import _sync_hardhat_block_timestamp
            _sync_hardhat_block_timestamp(w3)
        except Exception:
            pass
        tx, receipt = _execute_deployer_tx(
            w3,
            contract.functions.openElection(),
            deployer=deployer,
            deployer_key=deployer_key,
            timeout=60,
        )
    if not receipt or receipt.status != 1:
        raise BlockchainDeploymentError("On-chain election activation transaction reverted.")

    # 4. Verify post-activation on-chain invariants (electionOpen, candidatesLocked, votingWindowLocked, window timestamps)
    onchain_open = bool(contract.functions.electionOpen().call())
    onchain_cand_locked = bool(contract.functions.candidatesLocked().call())
    onchain_win_locked = bool(contract.functions.votingWindowLocked().call())
    onchain_start = int(contract.functions.votingStartTime().call())
    onchain_end = int(contract.functions.votingEndTime().call())

    if not (onchain_open and onchain_cand_locked and onchain_win_locked):
        raise ElectionLifecycleError("On-chain activation verification failed: lock flags not set.")
    if (expected_start_ts > 0 or expected_end_ts > 0) and (
        onchain_start != expected_start_ts or onchain_end != expected_end_ts
    ):
        raise ElectionLifecycleError("On-chain voting window timestamps do not match configured election window.")

    with transaction.atomic():
        election.status = 'ACTIVE'
        election.candidates_locked_on_chain = True
        election.voting_window_locked_on_chain = True
        election.start_datetime = actual_activation_start
        election.end_datetime = actual_activation_end
        election.save(update_fields=[
            'status',
            'candidates_locked_on_chain',
            'voting_window_locked_on_chain',
            'start_datetime',
            'end_datetime',
            'updated_at',
        ])

        AdminAuditLog.objects.create(
            actor=actor_user,
            action='ELECTION_ACTIVATED',
            target_model='Election',
            target_id=str(election.pk),
            details=json.dumps({
                'status': 'ACTIVE',
                'commencement_mode': election.commencement_mode,
                'immediate_duration_hours': election.immediate_duration_hours,
                'start_datetime': election.start_datetime.isoformat() if election.start_datetime else None,
                'end_datetime': election.end_datetime.isoformat() if election.end_datetime else None,
                'candidates_locked': True,
                'voting_window_locked': True,
                'parity_verified': True,
                'tx_hash': tx.hex() if isinstance(tx, bytes) else str(tx),
                'contract_address': election.contract_address,
                'voting_start_ts': onchain_start,
                'voting_end_ts': onchain_end,
            })
        )
    return election


def close_election(election_db_id, actor_user=None):
    """
    Transition election from ACTIVE -> CLOSED.
    Calls setElectionOpen(False) on-chain. Voting window remains permanently locked.
    """
    election = Election.objects.get(pk=election_db_id)
    if election.status != 'ACTIVE':
        raise ElectionLifecycleError(f"Cannot close election in '{election.status}' state. Must be 'ACTIVE'.")

    if election.deployment_status == 'DEPLOYED' and election.contract_address:
        w3 = get_web3_provider()
        if not w3.is_connected():
            raise BlockchainDeploymentError("Blockchain Node Unavailable: Cannot close election on-chain.")
        verify_live_election_contract_on_chain(election, w3=w3)
        abi, _, _ = load_contract_artifact()
        contract = w3.eth.contract(address=Web3.to_checksum_address(election.contract_address), abi=abi)
        deployer, deployer_key = _resolve_deployer_account_and_key(w3)
        abi_fn_names = {item.get('name') for item in abi if item.get('type') == 'function'}
        close_fn = (
            contract.functions.setElectionOpen(False)
            if 'setElectionOpen' in abi_fn_names
            else contract.functions.closeElection()
        )
        _, receipt = _execute_deployer_tx(
            w3,
            close_fn,
            deployer=deployer,
            deployer_key=deployer_key,
            timeout=60,
        )
        if receipt.status != 1:
            raise BlockchainDeploymentError("On-chain election close transaction reverted.")

    with transaction.atomic():
        election.status = 'CLOSED'
        election.save(update_fields=['status', 'updated_at'])

        AdminAuditLog.objects.create(
            actor=actor_user,
            action='ELECTION_CLOSED',
            target_model='Election',
            target_id=str(election.pk),
            details=json.dumps({'status': 'CLOSED'})
        )
    return election


LIFECYCLE_TRANSITION_LOCK_TIMEOUT_SECONDS = 60


def check_election_readiness_for_activation(election, now=None):
    """
    Inspect whether a SCHEDULED election has satisfied all readiness requirements
    for automatic activation:
    - Commencement mode is SCHEDULED.
    - Status is SCHEDULED.
    - Start datetime has arrived (now >= start_datetime) and election has not expired (now < end_datetime).
    - Dedicated smart contract is deployed with valid address.
    - Candidate roster has active candidates and is locked on-chain.
    """
    if now is None:
        now = timezone.now()

    if election.status != 'SCHEDULED':
        return False, f"Election status is '{election.status}', must be 'SCHEDULED'."

    if election.commencement_mode != 'SCHEDULED':
        return False, f"Commencement mode is '{election.commencement_mode}', not 'SCHEDULED'."

    if not election.start_datetime or not election.end_datetime:
        return False, "Election schedule is incomplete (missing start or end datetime)."

    if election.end_datetime <= election.start_datetime:
        return False, "Invalid voting window: end time must be after start time."

    if now < election.start_datetime:
        return False, f"Start time ({election.start_datetime.isoformat()}) has not yet arrived."

    if now >= election.end_datetime:
        return False, f"Configured end time ({election.end_datetime.isoformat()}) has already passed."

    if election.deployment_status != 'DEPLOYED' or not election.contract_address:
        return False, "Ballot contract is not deployed."

    if not election.candidates.filter(is_active=True).exists():
        return False, "Candidate roster has no active candidates."

    if not election.candidates_locked_on_chain:
        return False, "Candidate roster is not locked on-chain."

    return True, "Ready for automatic activation."


def get_election_lifecycle_operational_status(election, now=None):
    """
    Determine the fine-grained operational status of an election for administrative observability.
    Distinguishes:
    - Scheduled awaiting commencement
    - Ready for automatic activation
    - Activation attempted but unsuccessful
    - Active voting
    - Awaiting automatic closure
    - Closing attempted but unsuccessful / retrying
    - Closed / Finalized
    """
    if now is None:
        now = timezone.now()

    status = election.status
    has_err = bool(getattr(election, 'auto_transition_last_error', ''))
    last_act = getattr(election, 'auto_transition_last_action', '')

    if status == 'DRAFT':
        return {
            'code': 'DRAFT',
            'label': 'Draft (Not Ready)',
            'badge_class': 'badge-draft',
            'is_ready_for_activation': False,
            'is_overdue_for_closing': False,
        }

    if status == 'SCHEDULED':
        if not election.start_datetime:
            return {
                'code': 'SCHEDULED_PENDING_CONFIG',
                'label': 'Schedule Pending',
                'badge_class': 'badge-scheduled',
                'is_ready_for_activation': False,
                'is_overdue_for_closing': False,
            }
        if now < election.start_datetime:
            return {
                'code': 'SCHEDULED_AWAITING_COMMENCEMENT',
                'label': 'Scheduled (Awaiting Commencement)',
                'badge_class': 'badge-scheduled',
                'is_ready_for_activation': False,
                'is_overdue_for_closing': False,
            }
        # now >= start_datetime
        if has_err and last_act == 'ACTIVATION':
            return {
                'code': 'ACTIVATION_ATTEMPTED_FAILED',
                'label': 'Activation Attempted (Action Required)',
                'badge_class': 'badge-closed',
                'is_ready_for_activation': False,
                'is_overdue_for_closing': False,
                'error': election.auto_transition_last_error,
            }
        is_ready, reason = check_election_readiness_for_activation(election, now=now)
        if is_ready:
            return {
                'code': 'READY_FOR_AUTO_ACTIVATION',
                'label': 'Ready for Automatic Activation',
                'badge_class': 'badge-active',
                'is_ready_for_activation': True,
                'is_overdue_for_closing': False,
            }
        else:
            return {
                'code': 'ACTIVATION_READINESS_UNMET',
                'label': f'Activation Unmet: {reason}',
                'badge_class': 'badge-warning',
                'is_ready_for_activation': False,
                'is_overdue_for_closing': False,
            }

    if status == 'ACTIVE':
        if election.end_datetime and now >= election.end_datetime:
            if has_err and last_act == 'CLOSING':
                return {
                    'code': 'CLOSING_ATTEMPTED_FAILED',
                    'label': 'Closing Attempted (Retrying)',
                    'badge_class': 'badge-warning',
                    'is_ready_for_activation': False,
                    'is_overdue_for_closing': True,
                    'error': election.auto_transition_last_error,
                }
            return {
                'code': 'AWAITING_AUTO_CLOSURE',
                'label': 'Awaiting Automatic Closure',
                'badge_class': 'badge-scheduled',
                'is_ready_for_activation': False,
                'is_overdue_for_closing': True,
            }
        return {
            'code': 'ACTIVE_VOTING',
            'label': 'Active Voting',
            'badge_class': 'badge-active',
            'is_ready_for_activation': False,
            'is_overdue_for_closing': False,
        }

    if status == 'CLOSED':
        return {
            'code': 'CLOSED',
            'label': 'Voting Closed',
            'badge_class': 'badge-closed',
            'is_ready_for_activation': False,
            'is_overdue_for_closing': False,
        }

    if status == 'FINALIZED':
        return {
            'code': 'FINALIZED',
            'label': 'Finalized',
            'badge_class': 'badge-finalized',
            'is_ready_for_activation': False,
            'is_overdue_for_closing': False,
        }

    return {
        'code': status,
        'label': status.title(),
        'badge_class': 'badge-draft',
        'is_ready_for_activation': False,
        'is_overdue_for_closing': False,
    }


def execute_automatic_lifecycle_transitions(now=None, dry_run=False, actor_user=None):
    """
    Automatic lifecycle engine:
    1. Scheduled Elections: activates SCHEDULED elections whose start_datetime <= now,
       verifying readiness and preserving configured start/end datetimes.
    2. Active Elections: closes ACTIVE elections (Scheduled and Immediate) whose end_datetime <= now,
       invoking on-chain setElectionOpen(False) and confirming receipt.
    Concurrency & Idempotency Safeguards:
    - select_for_update() row-level locking avoids races.
    - In-progress timeout lock prevents duplicate transactions across concurrent workers.
    - Blockchain state reconciliation detects if an unconfirmed/previous attempt already opened/closed on-chain.
    """
    if now is None:
        now = timezone.now()

    summary = {
        'activated': [],
        'closed': [],
        'skipped': [],
        'errors': [],
        'evaluated_at': now.isoformat(),
        'dry_run': dry_run,
    }

    # -------------------------------------------------------------
    # PART 1: Scheduled Elections Automatic Activation
    # -------------------------------------------------------------
    due_for_activation_ids = list(
        Election.objects.filter(
            commencement_mode='SCHEDULED',
            status='SCHEDULED',
            start_datetime__isnull=False,
            start_datetime__lte=now,
        ).values_list('pk', flat=True)
    )

    for el_id in due_for_activation_ids:
        try:
            with transaction.atomic():
                el = Election.objects.select_for_update().get(pk=el_id)
                if el.status != 'SCHEDULED':
                    continue

                if el.auto_transition_in_progress and el.auto_transition_last_attempt_at:
                    elapsed = (now - el.auto_transition_last_attempt_at).total_seconds()
                    if elapsed < LIFECYCLE_TRANSITION_LOCK_TIMEOUT_SECONDS:
                        summary['skipped'].append({
                            'election_id': el.election_id,
                            'action': 'ACTIVATION',
                            'reason': 'Transition lock active by another process.',
                        })
                        continue

                el.auto_transition_in_progress = True
                el.auto_transition_last_attempt_at = now
                el.auto_transition_last_action = 'ACTIVATION'
                el.save(update_fields=[
                    'auto_transition_in_progress',
                    'auto_transition_last_attempt_at',
                    'auto_transition_last_action',
                ])

            if dry_run:
                is_ready, reason = check_election_readiness_for_activation(el, now=now)
                with transaction.atomic():
                    el = Election.objects.select_for_update().get(pk=el.pk)
                    el.auto_transition_in_progress = False
                    el.save(update_fields=['auto_transition_in_progress'])
                summary['activated'].append({
                    'election_id': el.election_id,
                    'dry_run': True,
                    'is_ready': is_ready,
                    'reason': reason,
                })
                continue

            # Check readiness
            is_ready, reason = check_election_readiness_for_activation(el, now=now)
            if not is_ready:
                with transaction.atomic():
                    el = Election.objects.select_for_update().get(pk=el.pk)
                    el.auto_transition_in_progress = False
                    el.auto_transition_last_error = reason
                    el.save(update_fields=['auto_transition_in_progress', 'auto_transition_last_error'])
                    AdminAuditLog.objects.create(
                        actor=actor_user,
                        action='AUTO_ACTIVATION_SKIPPED',
                        target_model='Election',
                        target_id=str(el.pk),
                        details=json.dumps({
                            'election_id': el.election_id,
                            'reason': reason,
                        })
                    )
                summary['skipped'].append({
                    'election_id': el.election_id,
                    'action': 'ACTIVATION',
                    'reason': reason,
                })
                continue

            # Safe on-chain state reconciliation check:
            reconciled = False
            try:
                w3 = get_web3_provider()
                if w3.is_connected() and el.contract_address:
                    abi, _, _ = load_contract_artifact()
                    contract = w3.eth.contract(address=Web3.to_checksum_address(el.contract_address), abi=abi)
                    onchain_open = bool(contract.functions.electionOpen().call())
                    onchain_win_locked = bool(contract.functions.votingWindowLocked().call())
                    onchain_cand_locked = bool(contract.functions.candidatesLocked().call())
                    onchain_start = int(contract.functions.votingStartTime().call())
                    onchain_end = int(contract.functions.votingEndTime().call())

                    expected_start_ts = int(el.start_datetime.timestamp()) if el.start_datetime else 0
                    expected_end_ts = int(el.end_datetime.timestamp()) if el.end_datetime else 0

                    start_matches = (expected_start_ts == 0) or (onchain_start == expected_start_ts)
                    end_matches = (expected_end_ts == 0) or (onchain_end == expected_end_ts)

                    if onchain_open and onchain_win_locked and onchain_cand_locked and start_matches and end_matches:
                        # Full voting window state matches expected on-chain invariants! Reconcile DB safely
                        with transaction.atomic():
                            el = Election.objects.select_for_update().get(pk=el.pk)
                            el.status = 'ACTIVE'
                            el.candidates_locked_on_chain = True
                            el.voting_window_locked_on_chain = True
                            el.auto_transition_in_progress = False
                            el.auto_transition_last_error = ''
                            el.save(update_fields=[
                                'status',
                                'candidates_locked_on_chain',
                                'voting_window_locked_on_chain',
                                'auto_transition_in_progress',
                                'auto_transition_last_error',
                            ])
                            AdminAuditLog.objects.create(
                                actor=actor_user,
                                action='AUTO_ACTIVATION_RECONCILED',
                                target_model='Election',
                                target_id=str(el.pk),
                                details=json.dumps({
                                    'election_id': el.election_id,
                                    'status': 'ACTIVE',
                                    'message': 'Complete on-chain state verified (electionOpen, windowLocked, candidateLocked, timestamps); reconciled database status to ACTIVE.',
                                    'voting_start_ts': onchain_start,
                                    'voting_end_ts': onchain_end,
                                })
                            )
                        reconciled = True
                        summary['activated'].append({
                            'election_id': el.election_id,
                            'status': 'ACTIVE',
                            'reconciled': True,
                        })
            except Exception:
                pass

            if reconciled:
                continue

            # Execute activation
            try:
                activated = activate_election(el.pk, actor_user=actor_user)
                with transaction.atomic():
                    el = Election.objects.select_for_update().get(pk=el.pk)
                    el.auto_transition_in_progress = False
                    el.auto_transition_last_error = ''
                    el.save(update_fields=['auto_transition_in_progress', 'auto_transition_last_error'])
                    AdminAuditLog.objects.create(
                        actor=actor_user,
                        action='AUTO_ACTIVATION_SUCCESS',
                        target_model='Election',
                        target_id=str(el.pk),
                        details=json.dumps({
                            'election_id': el.election_id,
                            'status': 'ACTIVE',
                            'commencement_mode': 'SCHEDULED',
                            'start_datetime': el.start_datetime.isoformat() if el.start_datetime else None,
                            'end_datetime': el.end_datetime.isoformat() if el.end_datetime else None,
                        })
                    )
                summary['activated'].append({
                    'election_id': el.election_id,
                    'status': 'ACTIVE',
                    'start_datetime': el.start_datetime.isoformat(),
                    'end_datetime': el.end_datetime.isoformat(),
                })
            except Exception as e:
                with transaction.atomic():
                    el = Election.objects.select_for_update().get(pk=el.pk)
                    el.auto_transition_in_progress = False
                    el.auto_transition_last_error = str(e)
                    el.save(update_fields=['auto_transition_in_progress', 'auto_transition_last_error'])
                    AdminAuditLog.objects.create(
                        actor=actor_user,
                        action='AUTO_ACTIVATION_FAILED',
                        target_model='Election',
                        target_id=str(el.pk),
                        details=json.dumps({
                            'election_id': el.election_id,
                            'error': str(e),
                        })
                    )
                summary['errors'].append({
                    'election_id': el.election_id,
                    'action': 'ACTIVATION',
                    'error': str(e),
                })
        except Exception as outer_e:
            summary['errors'].append({
                'election_id': el_id,
                'action': 'ACTIVATION',
                'error': str(outer_e),
            })

    # -------------------------------------------------------------
    # PART 2: Automatic Election Closing (Scheduled and Immediate)
    # -------------------------------------------------------------
    due_for_closing_ids = list(
        Election.objects.filter(
            status='ACTIVE',
            end_datetime__isnull=False,
            end_datetime__lte=now,
        ).values_list('pk', flat=True)
    )

    for el_id in due_for_closing_ids:
        try:
            with transaction.atomic():
                el = Election.objects.select_for_update().get(pk=el_id)
                if el.status != 'ACTIVE':
                    continue

                if el.auto_transition_in_progress and el.auto_transition_last_attempt_at:
                    elapsed = (now - el.auto_transition_last_attempt_at).total_seconds()
                    if elapsed < LIFECYCLE_TRANSITION_LOCK_TIMEOUT_SECONDS:
                        summary['skipped'].append({
                            'election_id': el.election_id,
                            'action': 'CLOSING',
                            'reason': 'Transition lock active by another process.',
                        })
                        continue

                el.auto_transition_in_progress = True
                el.auto_transition_last_attempt_at = now
                el.auto_transition_last_action = 'CLOSING'
                el.save(update_fields=[
                    'auto_transition_in_progress',
                    'auto_transition_last_attempt_at',
                    'auto_transition_last_action',
                ])

            if dry_run:
                with transaction.atomic():
                    el = Election.objects.select_for_update().get(pk=el.pk)
                    el.auto_transition_in_progress = False
                    el.save(update_fields=['auto_transition_in_progress'])
                summary['closed'].append({
                    'election_id': el.election_id,
                    'dry_run': True,
                    'status': 'CLOSED',
                })
                continue

            # Safe on-chain reconciliation check:
            reconciled = False
            try:
                w3 = get_web3_provider()
                if w3.is_connected() and el.contract_address:
                    abi, _, _ = load_contract_artifact()
                    contract = w3.eth.contract(address=Web3.to_checksum_address(el.contract_address), abi=abi)
                    onchain_open = bool(contract.functions.electionOpen().call())
                    onchain_win_locked = bool(contract.functions.votingWindowLocked().call())
                    onchain_cand_locked = bool(contract.functions.candidatesLocked().call())

                    if not onchain_open and onchain_win_locked and onchain_cand_locked:
                        # Already closed and locked on-chain! Reconcile DB safely
                        with transaction.atomic():
                            el = Election.objects.select_for_update().get(pk=el.pk)
                            el.status = 'CLOSED'
                            el.auto_transition_in_progress = False
                            el.auto_transition_last_error = ''
                            el.save(update_fields=[
                                'status',
                                'auto_transition_in_progress',
                                'auto_transition_last_error',
                            ])
                            AdminAuditLog.objects.create(
                                actor=actor_user,
                                action='AUTO_CLOSING_RECONCILED',
                                target_model='Election',
                                target_id=str(el.pk),
                                details=json.dumps({
                                    'election_id': el.election_id,
                                    'status': 'CLOSED',
                                    'message': 'Complete on-chain state verified (electionOpen == False, windowLocked, candidateLocked); reconciled database status to CLOSED.',
                                })
                            )
                        reconciled = True
                        summary['closed'].append({
                            'election_id': el.election_id,
                            'status': 'CLOSED',
                            'reconciled': True,
                        })
            except Exception:
                pass

            if reconciled:
                continue

            # Execute closing
            try:
                closed = close_election(el.pk, actor_user=actor_user)
                with transaction.atomic():
                    el = Election.objects.select_for_update().get(pk=el.pk)
                    el.auto_transition_in_progress = False
                    el.auto_transition_last_error = ''
                    el.save(update_fields=['auto_transition_in_progress', 'auto_transition_last_error'])
                    AdminAuditLog.objects.create(
                        actor=actor_user,
                        action='AUTO_CLOSING_SUCCESS',
                        target_model='Election',
                        target_id=str(el.pk),
                        details=json.dumps({
                            'election_id': el.election_id,
                            'status': 'CLOSED',
                            'closed_at': now.isoformat(),
                        })
                    )
                summary['closed'].append({
                    'election_id': el.election_id,
                    'status': 'CLOSED',
                })
            except Exception as e:
                with transaction.atomic():
                    el = Election.objects.select_for_update().get(pk=el.pk)
                    el.auto_transition_in_progress = False
                    el.auto_transition_last_error = str(e)
                    el.save(update_fields=['auto_transition_in_progress', 'auto_transition_last_error'])
                    AdminAuditLog.objects.create(
                        actor=actor_user,
                        action='AUTO_CLOSING_FAILED',
                        target_model='Election',
                        target_id=str(el.pk),
                        details=json.dumps({
                            'election_id': el.election_id,
                            'error': str(e),
                        })
                    )
                summary['errors'].append({
                    'election_id': el.election_id,
                    'action': 'CLOSING',
                    'error': str(e),
                })
        except Exception as outer_e:
            summary['errors'].append({
                'election_id': el_id,
                'action': 'CLOSING',
                'error': str(outer_e),
            })

    return summary


def _verify_permits_against_contract_receipts(w3, contract, target_address, expected_election_id, permits_iterable):
    """
    Internal helper to verify a set of IssuedPermit records against actual on-chain
    transaction receipts and VoteCast event logs on `target_address`.
    - Distinguishes unconsumed permits from claimed consumed permits.
    - Verifies receipt.status == 1 and receipt.to == target_address.
    - Decodes VoteCast events emitted by target_address and verifies electionId, candidateId, and voterNullifier.
    - Prevents duplicate tx_hash, duplicate (tx_hash, logIndex), and duplicate voter_nullifier counting.
    """
    checksum_target = Web3.to_checksum_address(target_address)
    target_lower = checksum_target.lower()

    seen_tx_hashes = set()
    seen_nullifiers = set()
    seen_event_keys = set()

    verified_total = 0
    verified_by_candidate = {}
    discrepancies = []

    for permit in permits_iterable:
        cid = int(permit.candidate_id)
        verified_by_candidate.setdefault(cid, 0)

        # Verify permit's recorded contract_address matches target_address
        if permit.contract_address and permit.contract_address.strip().lower() != target_lower:
            discrepancies.append(
                f"Permit #{permit.pk} contract_address ({permit.contract_address}) does not match {checksum_target}."
            )
            continue

        tx_hash = (permit.tx_hash or '').strip()
        if not tx_hash:
            discrepancies.append(f"Permit #{permit.pk} is marked consumed but has no tx_hash.")
            continue

        tx_hash_lower = tx_hash.lower()
        if tx_hash_lower in seen_tx_hashes:
            discrepancies.append(f"Duplicate transaction hash {tx_hash} detected on permit #{permit.pk}.")
            continue

        nullifier_lower = (permit.voter_nullifier or '').strip().lower()
        if not nullifier_lower.startswith('0x') and nullifier_lower:
            nullifier_lower = '0x' + nullifier_lower
        if nullifier_lower in seen_nullifiers:
            discrepancies.append(f"Duplicate voter_nullifier {nullifier_lower} detected on permit #{permit.pk}.")
            continue

        try:
            receipt = w3.eth.get_transaction_receipt(tx_hash)
        except Exception as e:
            discrepancies.append(f"Permit #{permit.pk} tx_hash {tx_hash} receipt lookup failed: {str(e)}")
            continue

        if not receipt or receipt.get('status') != 1:
            discrepancies.append(f"Permit #{permit.pk} transaction {tx_hash} reverted or failed (status != 1).")
            continue

        receipt_to = (receipt.get('to') or '').lower()
        if receipt_to != target_lower:
            discrepancies.append(
                f"Permit #{permit.pk} transaction {tx_hash} was sent to {receipt.get('to')} instead of {checksum_target}."
            )
            continue

        try:
            events = contract.events.VoteCast().process_receipt(receipt)
        except Exception as e:
            discrepancies.append(f"Failed to decode VoteCast events for tx {tx_hash}: {str(e)}")
            continue

        matching_events = []
        for ev in events:
            if (ev.get('address') or '').lower() != target_lower:
                continue
            ev_nullifier = '0x' + ev['args']['voterNullifier'].hex().lower()
            ev_cid = int(ev['args']['candidateId'])
            ev_el_id = int(ev['args']['electionId'])
            if ev_nullifier == nullifier_lower and ev_cid == cid and ev_el_id == int(expected_election_id):
                matching_events.append(ev)

        if len(matching_events) != 1:
            discrepancies.append(
                f"Permit #{permit.pk} tx {tx_hash} expected 1 matching VoteCast event on {checksum_target}, found {len(matching_events)}."
            )
            continue

        ev = matching_events[0]
        event_key = (tx_hash_lower, ev.get('logIndex'))
        if event_key in seen_event_keys:
            discrepancies.append(f"Duplicate VoteCast event log {event_key} detected.")
            continue

        # Also verify on-chain hasVoted state for this nullifier
        try:
            nullifier_bytes = Web3.to_bytes(hexstr=nullifier_lower)
            if not contract.functions.hasVoted(nullifier_bytes).call():
                discrepancies.append(f"Permit #{permit.pk} nullifier {nullifier_lower} is not marked hasVoted on-chain.")
                continue
        except Exception as e:
            discrepancies.append(f"Permit #{permit.pk} on-chain hasVoted check failed: {str(e)}")
            continue

        seen_tx_hashes.add(tx_hash_lower)
        seen_nullifiers.add(nullifier_lower)
        seen_event_keys.add(event_key)
        verified_total += 1
        verified_by_candidate[cid] = verified_by_candidate.get(cid, 0) + 1

    return {
        'verified_total': verified_total,
        'verified_by_candidate': verified_by_candidate,
        'discrepancies': discrepancies,
    }


def verify_historical_deployment_results(election):
    """
    Inspect all historical deployments and historical permits for an election:
    - Distinguishes issued permits (unconsumed) from claimed consumed permits and receipt-verified cast votes.
    - Verifies historical votes against actual transaction receipts and VoteCast events on each historical contract.
    - Keeps historical contract tallies strictly separate from the active replacement contract.
    """
    w3 = get_web3_provider()
    node_connected = w3.is_connected()
    abi = None
    if node_connected:
        try:
            abi, _, _ = load_contract_artifact()
        except Exception:
            abi = None

    historical_deployments_qs = ContractDeployment.objects.filter(
        election=election,
        is_historical_legacy=True
    ).order_by('deployed_at', 'id')

    historical_permits_qs = IssuedPermit.objects.filter(
        election_ref=election,
        is_historical_legacy=True
    )

    total_issued = historical_permits_qs.count()
    unconsumed_count = historical_permits_qs.filter(is_consumed_on_chain=False).count()
    claimed_consumed_qs = historical_permits_qs.filter(is_consumed_on_chain=True)
    claimed_consumed_count = claimed_consumed_qs.count()

    deployment_reports = []
    total_verified_historical_votes = 0

    # Collect distinct historical contract addresses from both ContractDeployment and historical permits
    seen_addrs = set()
    deployment_entries = []
    for dep in historical_deployments_qs:
        addr_low = dep.contract_address.lower()
        seen_addrs.add(addr_low)
        deployment_entries.append({
            'deployment_id': dep.pk,
            'contract_address': dep.contract_address,
            'chain_id': dep.chain_id,
            'deployment_tx_hash': dep.deployment_tx_hash,
            'deployment_block_number': dep.deployment_block_number,
            'deployed_bytecode_hash': dep.deployed_bytecode_hash,
            'superseded_at': dep.superseded_at.isoformat() if dep.superseded_at else None,
        })

    if election.legacy_contract_address and election.legacy_contract_address.lower() not in seen_addrs:
        seen_addrs.add(election.legacy_contract_address.lower())
        deployment_entries.append({
            'deployment_id': None,
            'contract_address': election.legacy_contract_address,
            'chain_id': election.chain_id,
            'deployment_tx_hash': '',
            'deployment_block_number': None,
            'deployed_bytecode_hash': '',
            'superseded_at': None,
        })

    for entry in deployment_entries:
        hist_addr = entry['contract_address']
        addr_permits = historical_permits_qs.filter(contract_address__iexact=hist_addr)
        addr_issued = addr_permits.count()
        addr_unconsumed = addr_permits.filter(is_consumed_on_chain=False).count()
        addr_claimed_consumed = list(addr_permits.filter(is_consumed_on_chain=True))

        verified_votes = 0
        onchain_total = None
        verified_by_cand = {}
        discrepancies = []

        if node_connected and abi and Web3.is_address(hist_addr):
            checksum_hist = Web3.to_checksum_address(hist_addr)
            code = w3.eth.get_code(checksum_hist)
            if code and code != b'' and code != '0x':
                hist_contract = w3.eth.contract(address=checksum_hist, abi=abi)
                try:
                    onchain_total = hist_contract.functions.totalVotes().call()
                except Exception:
                    onchain_total = None

                if addr_claimed_consumed:
                    v_res = _verify_permits_against_contract_receipts(
                        w3=w3,
                        contract=hist_contract,
                        target_address=checksum_hist,
                        expected_election_id=election.election_id,
                        permits_iterable=addr_claimed_consumed,
                    )
                    verified_votes = v_res['verified_total']
                    verified_by_cand = v_res['verified_by_candidate']
                    discrepancies = v_res['discrepancies']
                else:
                    discrepancies = []
            else:
                if addr_claimed_consumed:
                    discrepancies.append(f"Historical contract {hist_addr} has no bytecode on current node.")

        total_verified_historical_votes += verified_votes
        deployment_reports.append({
            **entry,
            'permits_issued': addr_issued,
            'unconsumed_permits': addr_unconsumed,
            'claimed_consumed_permits': len(addr_claimed_consumed),
            'verified_cast_votes': verified_votes,
            'onchain_total_votes': onchain_total,
            'verified_candidate_votes': verified_by_cand,
            'discrepancies': discrepancies,
        })

    return {
        'historical_deployments_count': len(deployment_reports),
        'historical_permits_issued': total_issued,
        'historical_unconsumed_permits': unconsumed_count,
        'historical_claimed_consumed_permits': claimed_consumed_count,
        'historical_verified_cast_votes': total_verified_historical_votes,
        'deployments': deployment_reports,
    }


def reconcile_election_results(election_db_id, actor_user=None):
    """
    Reconcile database vote records against on-chain smart contract tallies, receipts, and VoteCast events.
    - Verifies contract address, chain ID, deployed bytecode, and on-chain electionId.
    - Verifies every consumed DB permit via actual transaction receipt (status == 1) and decoded VoteCast event.
    - Checks electionId, candidateId, and voterNullifier consistency.
    - Prevents duplicate transaction/event/nullifier counting.
    - Compares verified DB votes against on-chain totalVotes(), on-chain VoteCast log count, and candidate getCount().
    - Never sets results_verified = True from database totals alone.
    """
    election = Election.objects.get(pk=election_db_id)
    if election.deployment_status != 'DEPLOYED' or not election.contract_address:
        raise ElectionLifecycleError("Cannot reconcile an election without a deployed contract.")

    w3 = get_web3_provider()
    if not w3.is_connected():
        raise BlockchainDeploymentError("Blockchain Node Unavailable: Cannot verify on-chain vote tallies.")

    checksum_addr = Web3.to_checksum_address(election.contract_address)
    code = w3.eth.get_code(checksum_addr)
    if not code or code == b'' or code == '0x':
        raise BlockchainDeploymentError(f"No contract bytecode found at {checksum_addr}.")

    discrepancies = []

    # 1. Verify Chain ID and Bytecode Hash
    live_chain_id = w3.eth.chain_id
    if int(live_chain_id) != int(election.chain_id):
        discrepancies.append(f"Chain ID mismatch: DB expects {election.chain_id}, connected node is {live_chain_id}.")

    live_bytecode_hash = '0x' + Web3.keccak(code).hex()
    if election.deployed_bytecode_hash and election.deployed_bytecode_hash.lower() != live_bytecode_hash.lower():
        discrepancies.append(
            f"Bytecode hash mismatch at {checksum_addr}: expected {election.deployed_bytecode_hash}, found {live_bytecode_hash}."
        )

    abi, _, _ = load_contract_artifact()
    contract = w3.eth.contract(address=checksum_addr, abi=abi)

    # 2. Verify on-chain electionId
    onchain_election_id = contract.functions.electionId().call()
    if int(onchain_election_id) != int(election.election_id):
        discrepancies.append(
            f"On-chain electionId ({onchain_election_id}) does not match DB election_id ({election.election_id})."
        )

    onchain_total = contract.functions.totalVotes().call()

    # 3. Separate active permits (consumed vs unconsumed) from historical legacy permits
    active_permits_all = IssuedPermit.objects.filter(
        election_ref=election,
        is_historical_legacy=False
    )
    active_unconsumed_count = active_permits_all.filter(is_consumed_on_chain=False).count()
    active_claimed_consumed = list(active_permits_all.filter(is_consumed_on_chain=True).order_by('id'))
    db_claimed_consumed_count = len(active_claimed_consumed)

    # 4. Verify each claimed consumed permit against its on-chain transaction receipt and VoteCast event
    receipt_verification = _verify_permits_against_contract_receipts(
        w3=w3,
        contract=contract,
        target_address=checksum_addr,
        expected_election_id=election.election_id,
        permits_iterable=active_claimed_consumed,
    )
    verified_db_total = receipt_verification['verified_total']
    verified_by_cand = receipt_verification['verified_by_candidate']
    discrepancies.extend(receipt_verification['discrepancies'])

    # 5. Inspect all on-chain VoteCast events emitted by this contract to detect unindexed or duplicate events
    try:
        all_onchain_logs = contract.events.VoteCast().get_logs(from_block=0, to_block='latest')
        distinct_onchain_events = set()
        onchain_event_by_cand = {}
        for ev in all_onchain_logs:
            if (ev.get('address') or '').lower() != checksum_addr.lower():
                continue
            ev_key = (ev['transactionHash'].hex().lower(), ev.get('logIndex'))
            if ev_key not in distinct_onchain_events:
                distinct_onchain_events.add(ev_key)
                cid = int(ev['args']['candidateId'])
                onchain_event_by_cand[cid] = onchain_event_by_cand.get(cid, 0) + 1
        onchain_events_count = len(distinct_onchain_events)
    except Exception as e:
        onchain_events_count = -1
        onchain_event_by_cand = {}
        discrepancies.append(f"Failed to query on-chain VoteCast event logs: {str(e)}")

    if onchain_events_count != onchain_total:
        discrepancies.append(
            f"On-chain VoteCast event count ({onchain_events_count}) does not match on-chain totalVotes ({onchain_total})."
        )

    # 6. Compare candidate-wise tallies (On-chain getCount vs Verified DB votes vs Claimed DB votes)
    candidate_reconciliation = []
    sum_candidate_onchain = 0
    candidates_match = True

    for cand in election.candidates.filter(is_active=True).order_by('display_order', 'candidate_id_num'):
        cid = cand.candidate_id_num
        onchain_cand_votes = contract.functions.getCount(cid).call()
        db_claimed_cand_votes = sum(1 for p in active_claimed_consumed if int(p.candidate_id) == cid)
        db_verified_cand_votes = verified_by_cand.get(cid, 0)
        sum_candidate_onchain += onchain_cand_votes

        cand_matched = (
            onchain_cand_votes == db_verified_cand_votes
            and db_verified_cand_votes == db_claimed_cand_votes
        )
        if not cand_matched:
            candidates_match = False
            discrepancies.append(
                f"Candidate #{cid} ({cand.name}) mismatch: on-chain={onchain_cand_votes}, "
                f"verified_db={db_verified_cand_votes}, claimed_db={db_claimed_cand_votes}."
            )

        candidate_reconciliation.append({
            'candidate_id': cid,
            'name': cand.name,
            'symbol': cand.symbol,
            'onchain_votes': onchain_cand_votes,
            'db_confirmed_votes': db_verified_cand_votes,
            'db_claimed_votes': db_claimed_cand_votes,
            'matched': cand_matched,
        })

    # 7. Historical deployment & permit verification (kept strictly separate)
    historical_summary = verify_historical_deployment_results(election)

    is_verified = (
        len(discrepancies) == 0
        and verified_db_total == db_claimed_consumed_count
        and onchain_total == verified_db_total
        and onchain_events_count == onchain_total
        and onchain_total == sum_candidate_onchain
        and candidates_match
    )

    with transaction.atomic():
        election.results_verified = is_verified
        election.reconciled_at = timezone.now()
        election.save(update_fields=['results_verified', 'reconciled_at', 'updated_at'])

        AdminAuditLog.objects.create(
            actor=actor_user,
            action='ELECTION_RECONCILED',
            target_model='Election',
            target_id=str(election.pk),
            details=json.dumps({
                'results_verified': is_verified,
                'onchain_total': onchain_total,
                'db_verified_votes': verified_db_total,
                'db_claimed_consumed': db_claimed_consumed_count,
                'active_unconsumed_permits': active_unconsumed_count,
                'historical_legacy_count': historical_summary['historical_permits_issued'],
                'discrepancies': discrepancies,
            })
        )

    return {
        'election_id': election.election_id,
        'chain_id': live_chain_id,
        'contract_address': election.contract_address,
        'legacy_contract_address': election.legacy_contract_address,
        'results_verified': is_verified,
        'onchain_total_votes': onchain_total,
        'onchain_votecast_events': onchain_events_count,
        'db_confirmed_votes': verified_db_total,
        'db_claimed_consumed_votes': db_claimed_consumed_count,
        'active_unconsumed_permits_count': active_unconsumed_count,
        'historical_legacy_permits_count': historical_summary['historical_permits_issued'],
        'historical_archive': historical_summary,
        'candidates': candidate_reconciliation,
        'discrepancies': discrepancies,
        'reconciled_at': election.reconciled_at.isoformat(),
    }


def authorize_result_publication(election_db_id, publish=True, policy=None, actor_user=None):
    """
    Authorize or revoke result publication for a closed election, or update publication policy.
    """
    election = Election.objects.get(pk=election_db_id)
    if publish and election.status in ('DRAFT', 'SCHEDULED', 'ACTIVE'):
        raise ElectionLifecycleError("Candidate-wise results cannot be published while election is active or pre-active.")

    if policy in dict(Election.RESULT_PUBLICATION_CHOICES):
        election.result_publication_policy = policy

    election.results_published = bool(publish)
    election.save(update_fields=['results_published', 'result_publication_policy', 'updated_at'])

    AdminAuditLog.objects.create(
        actor=actor_user,
        action='RESULT_PUBLICATION_UPDATED',
        target_model='Election',
        target_id=str(election.pk),
        details=json.dumps({
            'results_published': election.results_published,
            'policy': election.result_publication_policy,
        })
    )
    return election


def finalize_election(election_db_id, actor_user=None):
    """
    Transition election from CLOSED -> FINALIZED.
    Rejects finalization unless the election is CLOSED and has already passed reconciliation
    (results_verified == True) AND passes live reconciliation at finalization time.
    """
    election = Election.objects.get(pk=election_db_id)
    if election.status != 'CLOSED':
        raise ElectionLifecycleError(f"Cannot finalize election in '{election.status}' state. Must be 'CLOSED' first.")

    if not election.results_verified:
        raise ElectionLifecycleError(
            "Cannot finalize election before successful reconciliation (results_verified is False)."
        )

    reconciliation = reconcile_election_results(election.pk, actor_user=actor_user)
    if not reconciliation['results_verified']:
        raise ElectionLifecycleError(
            "Cannot finalize election: Database and blockchain vote counts failed reconciliation."
        )

    with transaction.atomic():
        election.status = 'FINALIZED'
        election.results_verified = True
        election.results_published = True
        election.finalized_at = timezone.now()
        election.save(update_fields=['status', 'results_verified', 'results_published', 'finalized_at', 'updated_at'])

        AdminAuditLog.objects.create(
            actor=actor_user,
            action='ELECTION_FINALIZED',
            target_model='Election',
            target_id=str(election.pk),
            details=json.dumps({
                'status': 'FINALIZED',
                'finalized_at': election.finalized_at.isoformat(),
                'onchain_total_votes': reconciliation['onchain_total_votes'],
            })
        )
    return election


def get_public_election_summary(election):
    """Return the public election summary with server-time-driven lifecycle state."""
    now = timezone.now()
    effective_status = compute_election_lifecycle_status(election, now=now)
    if election.pk and election.status != effective_status and election.status not in ('DRAFT', 'FINALIZED'):
        election.status = effective_status
        election.save(update_fields=['status', 'updated_at'])

    end_dt = election.end_datetime
    if end_dt and timezone.is_naive(end_dt):
        end_dt = timezone.make_aware(end_dt, timezone.get_current_timezone())
    has_ended_by_time = bool(end_dt is None or now >= end_dt)

    eligible_count = VoterEligibility.objects.filter(election=election, is_eligible=True).count()
    receipts = BallotReceipt.objects.filter(election=election)
    confirmed_count = receipts.count()
    results_visible = bool(
        has_ended_by_time and (
            (effective_status == 'FINALIZED' and election.results_verified)
            or (effective_status == 'CLOSED' and (
                election.results_published
                or election.result_publication_policy == 'PROVISIONAL_AFTER_CLOSE'
            ))
        )
    )
    if not results_visible:
        classification = 'HIDDEN'
    elif effective_status == 'FINALIZED':
        classification = 'OFFICIAL'
    else:
        classification = 'VERIFIED' if election.results_verified else 'PROVISIONAL'

    from .simple_voting import get_candidate_vote_count, SimpleVotingError
    candidate_list = []
    for cand in election.candidates.filter(is_active=True).order_by('display_order', 'candidate_id_num'):
        entry = {
            'candidate_id': cand.candidate_id_num, 'name': cand.name,
            'symbol': cand.symbol, 'description': cand.description,
            'symbol_image_url': cand.symbol_image.url if cand.symbol_image else '',
        }
        if results_visible:
            try:
                entry['votes'] = get_candidate_vote_count(election, cand.candidate_id_num)
            except Exception:
                entry['votes'] = None
        candidate_list.append(entry)

    participation_rate = round((confirmed_count / eligible_count) * 100, 2) if eligible_count else 0.0
    deployments_history = list(
        ContractDeployment.objects.filter(election=election).order_by('-deployed_at', '-id').values(
            'id', 'contract_address', 'chain_id', 'deployment_tx_hash', 'deployment_block_number',
            'deployed_bytecode_hash', 'is_active_deployment', 'is_historical_legacy', 'deployed_at', 'superseded_at'
        )
    )
    for item in deployments_history:
        for key in ('deployed_at', 'superseded_at'):
            if item.get(key): item[key] = item[key].isoformat()

    return {
        'election_id': election.election_id, 'title': election.title,
        'description': election.description, 'election_type': election.election_type,
        'commencement_mode': election.commencement_mode,
        'immediate_duration_hours': election.immediate_duration_hours,
        'status': effective_status,
        'operational_status': get_election_lifecycle_operational_status(election, now=now),
        'start_datetime': election.start_datetime.isoformat() if election.start_datetime else None,
        'end_datetime': election.end_datetime.isoformat() if election.end_datetime else None,
        'turnout': {
            'eligible_voters': eligible_count, 'confirmed_votes_cast': confirmed_count,
            'unconsumed_permits_issued': 0, 'participation_rate_percent': participation_rate,
        },
        'candidates': [
            {
                'candidate_id': item['candidate_id'],
                'name': item['name'],
                'symbol': item['symbol'],
                'description': item['description'],
                'symbol_image_url': item['symbol_image_url'],
            }
            for item in candidate_list
        ],
        'results': {
            'visible': results_visible, 'classification': classification,
            'verified': election.results_verified, 'published': election.results_published,
            'reconciled_at': election.reconciled_at.isoformat() if election.reconciled_at else None,
            'finalized_at': election.finalized_at.isoformat() if election.finalized_at else None,
            'candidates': candidate_list if results_visible else [],
            'message': (
                'Official finalized election results.' if classification == 'OFFICIAL'
                else 'Verified election results.' if classification == 'VERIFIED'
                else 'Provisional election results.' if classification == 'PROVISIONAL'
                else 'Live candidate-wise results are hidden during active voting.'
            ),
        },
        'blockchain_audit': {
            'deployment_status': election.deployment_status, 'chain_id': election.chain_id,
            'active_contract_address': election.contract_address,
            'deployment_tx_hash': election.deployment_tx_hash,
            'deployment_block_number': election.deployment_block_number,
            'deployed_bytecode_hash': election.deployed_bytecode_hash,
            'candidates_locked_on_chain': election.candidates_locked_on_chain,
            'voting_window_locked_on_chain': election.voting_window_locked_on_chain,
            'deployments_history': deployments_history,
            'historical_legacy_archive': {
                'legacy_contract_address': election.legacy_contract_address,
                'historical_permit_records_count': 0, 'historical_consumed_votes_count': 0,
                'historical_unconsumed_permits_count': 0, 'note': '',
            },
        },
    }


# ==========================================
# MODULE 5: VOTER REGISTRATION & ELIGIBILITY
# ==========================================

def mask_aadhar(aadhar):
    """Mask 12-digit Aadhaar number, revealing only the final 4 digits for privacy protection."""
    clean = str(aadhar or '').strip()
    if len(clean) >= 4:
        return ('X' * (len(clean) - 4)) + clean[-4:]
    return 'XXXXXXXXXXXX'


def validate_aadhar_format(aadhar):
    """
    Validate 12-digit Aadhaar number:
    - Must be exactly 12 numeric characters.
    - Rejects strings with non-digit characters.
    - Rejects trivially invalid sequences (e.g., all identical repeating digits like '000000000000').
    """
    clean = str(aadhar or '').strip()
    if not clean:
        raise VoterValidationError("Aadhaar number cannot be empty.")
    if len(clean) != 12 or not clean.isdigit():
        raise VoterValidationError("Aadhaar number must consist of exactly 12 numeric digits.")
    if len(set(clean)) <= 1:
        raise VoterValidationError("Aadhaar number cannot consist of 12 repeating identical digits.")
    return clean


def validate_wallet_format(wallet):
    """
    Validate Ethereum wallet address format:
    - Returns None if empty or None.
    - Validates 42-character hex format starting with '0x'.
    - Returns standardized EIP-55 checksum address.
    """
    if wallet is None:
        return None
    clean = str(wallet).strip()
    if not clean:
        return None
    if not clean.startswith('0x') or len(clean) != 42 or not Web3.is_address(clean):
        raise VoterValidationError(f"Invalid Ethereum wallet address format: '{clean}'.")
    return Web3.to_checksum_address(clean)


def register_voter(name, aadhar_number, bound_wallet=None, is_synthetic=False, actor_user=None):
    """
    Register a new voter identity in the primary electoral roll:
    - Validates name and 12-digit Aadhaar format.
    - Rejects duplicate Aadhaar numbers (preserves existing records).
    - Enforces 1-to-1 wallet-to-voter Sybil binding if wallet is provided.
    - Distinguishes synthetic test identities via is_synthetic flag.
    - Masks Aadhaar in all audit log records.
    """
    clean_name = str(name or '').strip()
    if not clean_name:
        raise VoterValidationError("Voter name cannot be empty.")
    if len(clean_name) > 100:
        raise VoterValidationError("Voter name cannot exceed 100 characters.")

    clean_aadhar = validate_aadhar_format(aadhar_number)
    clean_wallet = validate_wallet_format(bound_wallet)

    with transaction.atomic():
        if Voter.objects.filter(aadhar_number=clean_aadhar).exists():
            raise VoterValidationError(f"Voter with Aadhaar {mask_aadhar(clean_aadhar)} is already registered.")

        if clean_wallet:
            existing_wallet = Voter.objects.filter(bound_wallet__iexact=clean_wallet).first()
            if existing_wallet:
                raise VoterValidationError("Wallet address is already bound to another registered voter.")

        voter = Voter.objects.create(
            name=clean_name,
            aadhar_number=clean_aadhar,
            bound_wallet=clean_wallet,
            is_synthetic=bool(is_synthetic),
            has_voted=False,
        )

        AdminAuditLog.objects.create(
            actor=actor_user,
            action='VOTER_REGISTERED',
            target_model='Voter',
            target_id=str(voter.pk),
            details=json.dumps({
                'voter_id': voter.pk,
                'name': clean_name,
                'aadhar_masked': mask_aadhar(clean_aadhar),
                'bound_wallet': clean_wallet,
                'is_synthetic': bool(is_synthetic),
            })
        )

    return voter


def validate_voter_id_format(voter_id):
    """
    Validate a global Voter ID:
    - Enforces ^\\d{12}$ (exactly 12 numeric digits).
    - Rejects alphabetic characters, special characters, internal spaces, and lengths != 12.
    - Preserves leading zeros as a 12-character string.
    """
    clean = str(voter_id or '').strip()
    if not clean:
        raise VoterValidationError("Missing Voter ID.")
    if not re.fullmatch(r'^\d{12}$', clean):
        raise VoterValidationError("Invalid Voter ID (must be exactly 12 numeric digits).")
    return clean


def validate_phone_format(phone):
    """
    Validate a voter phone number:
    - Must be present.
    - Supports optional '+91' prefix, spaces, or hyphens.
    - Normalized phone number must be a valid 10-digit numeric phone number not starting with 0
      and not consisting of 10 identical repeating digits.
    """
    raw = str(phone or '').strip()
    if not raw:
        raise VoterValidationError("Invalid phone number.")
    cleaned = re.sub(r'[\s\-()]', '', raw)
    if cleaned.startswith('+91') and len(cleaned) == 13:
        cleaned = cleaned[3:]
    if len(cleaned) != 10 or not cleaned.isdigit() or cleaned[0] == '0' or len(set(cleaned)) <= 1:
        raise VoterValidationError("Invalid phone number.")
    return cleaned


def _is_voter_header_row(parts):
    """Return True if the 3-column row represents an optional header row (VoterID, Name, Phone)."""
    if len(parts) != 3:
        return False
    col0 = re.sub(r'[^a-z0-9]', '', parts[0].lower())
    col1 = re.sub(r'[^a-z0-9]', '', parts[1].lower())
    col2 = re.sub(r'[^a-z0-9]', '', parts[2].lower())
    return (
        col0 in ('voterid', 'id', 'aadhar', 'aadhaar', 'aadharnumber', 'voter')
        and col1 in ('name', 'votername', 'fullname')
        and col2 in ('phone', 'phonenumber', 'mobile', 'mobilenumber', 'contact')
    )


def register_voters_from_multiline_text(raw_text, actor_user=None):
    """
    Parse and validate multiline voter records in the format:
        VoterID, Name, Phone
    - Supports an optional header row.
    - Validates each record individually in Django so invalid records do not block valid records.
    - Registers valid voters only in the central Voter table (does NOT create VoterEligibility records).
    - Handles database uniqueness constraints and concurrent submissions safely via per-record atomic transactions.
    """
    text = str(raw_text or '')
    lines = text.splitlines()

    non_empty_lines = [(idx + 1, line.strip()) for idx, line in enumerate(lines) if line.strip()]
    if not non_empty_lines:
        return {
            'registered_count': 0,
            'rejected_count': 1,
            'registered_voters': [],
            'rejected_records': [
                {
                    'line_number': 1,
                    'raw_line': '',
                    'voter_id': '',
                    'reason': 'Invalid input format.',
                }
            ],
        }

    registered_voters = []
    rejected_records = []
    seen_voter_ids = set()
    data_rows_processed = 0

    for row_idx, (line_num, line) in enumerate(non_empty_lines):
        parts = [p.strip() for p in line.split(',')]

        if row_idx == 0 and _is_voter_header_row(parts):
            continue

        data_rows_processed += 1

        if len(parts) != 3:
            rejected_records.append({
                'line_number': line_num,
                'raw_line': line,
                'voter_id': parts[0] if parts else '',
                'reason': 'Invalid input format.',
            })
            continue

        raw_voter_id, raw_name, raw_phone = parts[0], parts[1], parts[2]

        try:
            clean_voter_id = validate_voter_id_format(raw_voter_id)
        except VoterValidationError as exc:
            rejected_records.append({
                'line_number': line_num,
                'raw_line': line,
                'voter_id': raw_voter_id,
                'reason': str(exc),
            })
            continue

        norm_id = clean_voter_id.upper()
        if norm_id in seen_voter_ids:
            rejected_records.append({
                'line_number': line_num,
                'raw_line': line,
                'voter_id': clean_voter_id,
                'reason': 'Duplicate Voter ID in this submission.',
            })
            continue
        seen_voter_ids.add(norm_id)

        if not raw_name:
            rejected_records.append({
                'line_number': line_num,
                'raw_line': line,
                'voter_id': clean_voter_id,
                'reason': 'Missing voter name.',
            })
            continue

        if len(raw_name) > 100:
            rejected_records.append({
                'line_number': line_num,
                'raw_line': line,
                'voter_id': clean_voter_id,
                'reason': 'Voter name cannot exceed 100 characters.',
            })
            continue

        try:
            clean_phone = validate_phone_format(raw_phone)
        except VoterValidationError as exc:
            rejected_records.append({
                'line_number': line_num,
                'raw_line': line,
                'voter_id': clean_voter_id,
                'reason': str(exc),
            })
            continue

        if Voter.objects.filter(aadhar_number__iexact=clean_voter_id).exists():
            rejected_records.append({
                'line_number': line_num,
                'raw_line': line,
                'voter_id': clean_voter_id,
                'reason': 'Voter ID already exists.',
            })
            continue

        try:
            with transaction.atomic():
                if Voter.objects.select_for_update().filter(aadhar_number__iexact=clean_voter_id).exists():
                    rejected_records.append({
                        'line_number': line_num,
                        'raw_line': line,
                        'voter_id': clean_voter_id,
                        'reason': 'Voter ID already exists.',
                    })
                    continue

                voter = Voter.objects.create(
                    aadhar_number=clean_voter_id,
                    name=raw_name,
                    phone=clean_phone,
                    status='ACTIVE',
                    has_voted=False,
                    is_synthetic=False,
                )

                if actor_user and getattr(actor_user, 'is_authenticated', False):
                    AdminAuditLog.objects.create(
                        actor=actor_user,
                        action='VOTER_REGISTERED',
                        target_model='Voter',
                        target_id=str(voter.pk),
                        details=json.dumps({
                            'voter_id': voter.aadhar_number,
                            'name': voter.name,
                            'phone': voter.phone,
                        }),
                    )

                registered_voters.append(voter)
        except IntegrityError:
            rejected_records.append({
                'line_number': line_num,
                'raw_line': line,
                'voter_id': clean_voter_id,
                'reason': 'Voter ID already exists.',
            })

    if data_rows_processed == 0:
        rejected_records.append({
            'line_number': 1,
            'raw_line': non_empty_lines[0][1],
            'voter_id': '',
            'reason': 'Invalid input format.',
        })

    return {
        'registered_count': len(registered_voters),
        'rejected_count': len(rejected_records),
        'registered_voters': registered_voters,
        'rejected_records': rejected_records,
    }


def validate_official_id_format(official_id):
    """
    Validate an Official ID:
    - Enforces ^[A-Za-z0-9]{5}$ (exactly 5 alphanumeric characters).
    - Rejects special characters, spaces, and lengths != 5.
    """
    clean = str(official_id or '').strip()
    if not clean:
        raise VoterValidationError("Missing Official ID.")
    if not re.fullmatch(r'^[A-Za-z0-9]{5}$', clean):
        raise VoterValidationError("Invalid Official ID (must be exactly 5 alphanumeric characters).")
    return clean


def _is_official_header_row(parts):
    """Return True if the 3-column row represents an optional header row (OfficialID, Name, Password)."""
    if len(parts) != 3:
        return False
    col0 = re.sub(r'[^a-z0-9]', '', parts[0].lower())
    col1 = re.sub(r'[^a-z0-9]', '', parts[1].lower())
    col2 = re.sub(r'[^a-z0-9]', '', parts[2].lower())
    return (
        col0 in ('officialid', 'id', 'username', 'staffid', 'adminid')
        and col1 in ('name', 'officialname', 'fullname', 'staffname')
        and col2 in ('password', 'pass', 'pwd')
    )


def register_officials_from_multiline_text(raw_text, actor_user=None):
    """
    Parse and validate multiline election official records in the format:
        OfficialID, Name, Password
    - Validates each record independently in Django so invalid lines do not block valid registrations.
    - Official ID must be exactly 5 alphanumeric characters and unique across User accounts.
    - Creates regular staff/admin User accounts (is_staff=True, is_superuser=False) assigned to
      the 'Election Administrator' group using Django's create_user() password hashing.
    - Never stores or logs plaintext passwords.
    """
    from django.contrib.auth.models import Group, User

    text = str(raw_text or '')
    lines = text.splitlines()

    non_empty_lines = [(idx + 1, line.strip()) for idx, line in enumerate(lines) if line.strip()]
    if not non_empty_lines:
        return {
            'registered_count': 0,
            'rejected_count': 1,
            'registered_officials': [],
            'rejected_records': [
                {
                    'line_number': 1,
                    'official_id': '',
                    'reason': 'Invalid input format.',
                }
            ],
        }

    registered_officials = []
    rejected_records = []
    seen_official_ids = set()
    data_rows_processed = 0

    for row_idx, (line_num, line) in enumerate(non_empty_lines):
        parts = [p.strip() for p in line.split(',')]

        if row_idx == 0 and _is_official_header_row(parts):
            continue

        data_rows_processed += 1

        if len(parts) != 3:
            rejected_records.append({
                'line_number': line_num,
                'official_id': parts[0] if parts else '',
                'reason': 'Invalid input format.',
            })
            continue

        raw_official_id, raw_name, raw_password = parts[0], parts[1], parts[2]

        try:
            clean_official_id = validate_official_id_format(raw_official_id)
        except VoterValidationError as exc:
            rejected_records.append({
                'line_number': line_num,
                'official_id': raw_official_id,
                'reason': str(exc),
            })
            continue

        norm_id = clean_official_id.upper()
        if norm_id in seen_official_ids:
            rejected_records.append({
                'line_number': line_num,
                'official_id': clean_official_id,
                'reason': 'Duplicate Official ID in this submission.',
            })
            continue
        seen_official_ids.add(norm_id)

        if not raw_name:
            rejected_records.append({
                'line_number': line_num,
                'official_id': clean_official_id,
                'reason': 'Missing official name.',
            })
            continue

        if len(raw_name) > 150:
            rejected_records.append({
                'line_number': line_num,
                'official_id': clean_official_id,
                'reason': 'Official name cannot exceed 150 characters.',
            })
            continue

        if not raw_password:
            rejected_records.append({
                'line_number': line_num,
                'official_id': clean_official_id,
                'reason': 'Missing password.',
            })
            continue

        if User.objects.filter(username__iexact=clean_official_id).exists():
            rejected_records.append({
                'line_number': line_num,
                'official_id': clean_official_id,
                'reason': 'Official ID already exists.',
            })
            continue

        try:
            with transaction.atomic():
                if User.objects.select_for_update().filter(username__iexact=clean_official_id).exists():
                    rejected_records.append({
                        'line_number': line_num,
                        'official_id': clean_official_id,
                        'reason': 'Official ID already exists.',
                    })
                    continue

                admin_group, _ = Group.objects.get_or_create(name='Election Administrator')
                user_obj = User.objects.create_user(
                    username=clean_official_id,
                    password=raw_password,
                    first_name=raw_name,
                    is_staff=True,
                    is_superuser=False,
                    is_active=True,
                )
                user_obj.groups.add(admin_group)

                if actor_user and getattr(actor_user, 'is_authenticated', False):
                    AdminAuditLog.objects.create(
                        actor=actor_user,
                        action='OFFICIAL_ACCOUNT_CREATED',
                        target_model='User',
                        target_id=str(user_obj.pk),
                        details=json.dumps({
                            'official_id': user_obj.username,
                            'name': user_obj.first_name,
                            'role': 'Election Administrator',
                        }),
                    )

                registered_officials.append(user_obj)
        except IntegrityError:
            rejected_records.append({
                'line_number': line_num,
                'official_id': clean_official_id,
                'reason': 'Official ID already exists.',
            })

    if data_rows_processed == 0:
        rejected_records.append({
            'line_number': 1,
            'official_id': '',
            'reason': 'Invalid input format.',
        })

    return {
        'registered_count': len(registered_officials),
        'rejected_count': len(rejected_records),
        'registered_officials': registered_officials,
        'rejected_records': rejected_records,
    }


def update_voter_record(voter_id, name=None, actor_user=None):
    """Update non-identity fields (e.g. name) of an existing voter record."""
    with transaction.atomic():
        voter = Voter.objects.select_for_update().filter(pk=voter_id).first()
        if not voter:
            raise VoterValidationError(f"Voter ID {voter_id} not found.")

        if name is not None:
            clean_name = str(name).strip()
            if not clean_name:
                raise VoterValidationError("Voter name cannot be empty.")
            voter.name = clean_name

        voter.save(update_fields=['name', 'updated_at'])

        AdminAuditLog.objects.create(
            actor=actor_user,
            action='VOTER_UPDATED',
            target_model='Voter',
            target_id=str(voter.pk),
            details=json.dumps({
                'name': voter.name,
                'aadhar_masked': mask_aadhar(voter.aadhar_number),
            })
        )
    return voter


def bind_or_update_voter_wallet(voter_id, new_wallet, force=False, actor_user=None):
    """
    Bind or reassign a voter's Ethereum wallet:
    - Enforces 1-to-1 wallet-to-voter Sybil binding (rejects wallets bound to other voters).
    - If voter already has a bound wallet and has cast ballots or holds active permits,
      requires administrative authorization (force=True or superuser) to reassign.
    - Audits every wallet binding or change with target and actor tracking.
    """
    clean_wallet = validate_wallet_format(new_wallet)

    with transaction.atomic():
        voter = Voter.objects.select_for_update().filter(pk=voter_id).first()
        if not voter:
            raise VoterValidationError(f"Voter ID {voter_id} not found.")

        old_wallet = voter.bound_wallet
        if clean_wallet and old_wallet and old_wallet.lower() == clean_wallet.lower():
            return voter

        if clean_wallet:
            existing_holder = (
                Voter.objects.filter(bound_wallet__iexact=clean_wallet)
                .exclude(pk=voter.pk)
                .first()
            )
            if existing_holder:
                raise VoterValidationError("Wallet address is already bound to another registered voter.")

        # If voter already has a bound wallet and has cast confirmed votes in any election
        has_voted_anywhere = voter.has_voted or VoterEligibility.objects.filter(voter=voter, has_voted=True).exists()
        has_active_permits = IssuedPermit.objects.filter(voter=voter, is_consumed_on_chain=False, is_historical_legacy=False).exists()

        if old_wallet and (has_voted_anywhere or has_active_permits):
            is_authorized = force or (actor_user and getattr(actor_user, 'is_superuser', False))
            if not is_authorized:
                raise VoterValidationError(
                    "Cannot reassign wallet for a voter who holds active permits or confirmed cast votes "
                    "without administrative authorization (force=True)."
                )

        voter.bound_wallet = clean_wallet
        voter.save(update_fields=['bound_wallet', 'updated_at'])

        action_name = 'VOTER_WALLET_REASSIGNED' if old_wallet else 'VOTER_WALLET_BOUND'
        AdminAuditLog.objects.create(
            actor=actor_user,
            action=action_name,
            target_model='Voter',
            target_id=str(voter.pk),
            details=json.dumps({
                'voter_id': voter.pk,
                'aadhar_masked': mask_aadhar(voter.aadhar_number),
                'old_wallet': old_wallet,
                'new_wallet': clean_wallet,
                'forced': bool(force),
            })
        )

    return voter


def assign_voter_eligibility(election_db_id, voter_id, is_eligible=True, actor_user=None):
    """
    Assign or update voter eligibility for a specific election using VoterEligibility as the authoritative record:
    - Supports multiple elections per voter.
    - Prevents duplicate voter-election assignments via unique_together constraint.
    - Rejects modifications if the election is CLOSED or FINALIZED.
    - Prevents revoking eligibility if the voter has already cast a confirmed ballot in this election.
    - Preserves independent has_voted and voted_at timestamps per election.
    """
    with transaction.atomic():
        try:
            election = Election.objects.select_for_update().get(pk=election_db_id)
        except Election.DoesNotExist:
            raise VoterEligibilityError(f"Election ID {election_db_id} not found.")

        try:
            voter = Voter.objects.select_for_update().get(pk=voter_id)
        except Voter.DoesNotExist:
            raise VoterEligibilityError(f"Voter ID {voter_id} not found.")

        if is_eligible and voter.status != 'ACTIVE':
            raise VoterEligibilityError(
                f"Cannot grant election eligibility: Voter account is currently '{voter.status}'."
            )

        if election.status in ('CLOSED', 'FINALIZED'):
            raise VoterEligibilityError(
                f"Cannot assign or modify voter eligibility: Election is already '{election.status}'."
            )

        eligibility = VoterEligibility.objects.select_for_update().filter(voter=voter, election=election).first()

        if eligibility:
            if eligibility.has_voted and not is_eligible:
                raise VoterEligibilityError(
                    "Cannot revoke eligibility for a voter who has already cast a confirmed ballot in this election."
                )
            created = False
            eligibility.is_eligible = bool(is_eligible)
            eligibility.assigned_by = actor_user
            eligibility.save(update_fields=['is_eligible', 'assigned_by'])
        else:
            created = True
            eligibility = VoterEligibility.objects.create(
                voter=voter,
                election=election,
                is_eligible=bool(is_eligible),
                has_voted=False,
                voted_at=None,
                assigned_by=actor_user,
            )

        audit_action = 'VOTER_ELIGIBILITY_ASSIGNED' if created else (
            'VOTER_ELIGIBILITY_GRANTED' if is_eligible else 'VOTER_ELIGIBILITY_REVOKED'
        )
        AdminAuditLog.objects.create(
            actor=actor_user,
            action=audit_action,
            target_model='VoterEligibility',
            target_id=str(eligibility.pk),
            details=json.dumps({
                'election_id': election.election_id,
                'voter_id': voter.pk,
                'is_eligible': eligibility.is_eligible,
                'created': created,
            })
        )

    return eligibility


def revoke_voter_eligibility(election_db_id, voter_id, actor_user=None):
    """Revoke voter eligibility for a specific election."""
    return assign_voter_eligibility(
        election_db_id=election_db_id,
        voter_id=voter_id,
        is_eligible=False,
        actor_user=actor_user,
    )


def import_synthetic_voters_from_csv(
    csv_content_or_file,
    default_election_id=None,
    assign_eligibility=True,
    dry_run=True,
    actor_user=None,
):
    """
    Import synthetic voter records from CSV with a safe validation and preview stage:
    - Parses CSV with headers: name, aadhar_number/aadhaar, optional wallet_address/bound_wallet.
    - Validates name length, 12-digit Aadhaar format, and wallet format.
    - Detects:
      - valid_new: valid new synthetic records.
      - valid_existing: existing voter records to be assigned eligibility without modifying identity.
      - duplicates_in_file: repeated Aadhaar or wallet inside the CSV itself.
      - conflicts: wallet already bound to a different voter in the database.
      - invalid: malformed Aadhaar, empty name, or invalid wallet format.
    - Safe & idempotent:
      - dry_run=True: returns complete preview metrics without writing to DB.
      - dry_run=False: writes inside transaction.atomic(); rolls back completely on any unexpected error.
      - Never silently overwrites existing voter identities or bound wallets.
      - Marks newly imported records with is_synthetic=True.
    """
    if hasattr(csv_content_or_file, 'read'):
        raw_text = csv_content_or_file.read()
        if isinstance(raw_text, bytes):
            raw_text = raw_text.decode('utf-8', errors='replace')
    else:
        raw_text = str(csv_content_or_file or '')

    if not raw_text.strip():
        raise VoterValidationError("CSV content is empty.")

    f = io.StringIO(raw_text.strip())
    reader = csv.reader(f)
    try:
        header_row = next(reader)
    except StopIteration:
        raise VoterValidationError("CSV file is empty or missing headers.")

    # Normalize header mapping
    header_map = {}
    for idx, col in enumerate(header_row):
        norm = re.sub(r'[^a-z0-9]', '', col.lower())
        header_map[norm] = idx

    name_idx = None
    for k in ('name', 'fullname', 'votername'):
        if k in header_map:
            name_idx = header_map[k]
            break

    aadhar_idx = None
    for k in ('aadharnumber', 'aadhar', 'aadhaar', 'aadhaarnumber', 'uid'):
        if k in header_map:
            aadhar_idx = header_map[k]
            break

    wallet_idx = None
    for k in ('walletaddress', 'wallet', 'boundwallet', 'ethaddress'):
        if k in header_map:
            wallet_idx = header_map[k]
            break

    if name_idx is None or aadhar_idx is None:
        raise VoterValidationError(
            "CSV must contain at least 'name' and 'aadhar_number' (or 'aadhaar') columns."
        )

    target_election = None
    if default_election_id:
        target_election = (
            Election.objects.filter(election_id=default_election_id).first()
            or Election.objects.filter(pk=default_election_id).first()
        )
        if not target_election:
            raise VoterValidationError(f"Target election ID {default_election_id} not found.")

    seen_aadhars_in_csv = set()
    seen_wallets_in_csv = set()

    parsed_rows = []
    valid_new_rows = []
    valid_existing_rows = []
    duplicate_rows = []
    conflict_rows = []
    invalid_rows = []

    row_num = 1
    for raw_row in reader:
        row_num += 1
        if not any(x.strip() for x in raw_row):
            continue

        raw_name = raw_row[name_idx].strip() if name_idx < len(raw_row) else ''
        raw_aadhar = raw_row[aadhar_idx].strip() if aadhar_idx < len(raw_row) else ''
        raw_wallet = raw_row[wallet_idx].strip() if (wallet_idx is not None and wallet_idx < len(raw_row)) else ''

        row_meta = {
            'row_num': row_num,
            'name': raw_name,
            'raw_aadhar': raw_aadhar,
            'aadhar_masked': mask_aadhar(raw_aadhar),
            'wallet': raw_wallet or None,
            'status': None,
            'reason': None,
        }

        # 1. Validation checks
        if not raw_name:
            row_meta['status'] = 'INVALID'
            row_meta['reason'] = 'Missing or empty name.'
            invalid_rows.append(row_meta)
            parsed_rows.append(row_meta)
            continue

        try:
            clean_aadhar = validate_aadhar_format(raw_aadhar)
        except VoterValidationError as e:
            row_meta['status'] = 'INVALID'
            row_meta['reason'] = str(e)
            invalid_rows.append(row_meta)
            parsed_rows.append(row_meta)
            continue

        clean_wallet = None
        if raw_wallet:
            try:
                clean_wallet = validate_wallet_format(raw_wallet)
            except VoterValidationError as e:
                row_meta['status'] = 'INVALID'
                row_meta['reason'] = str(e)
                invalid_rows.append(row_meta)
                parsed_rows.append(row_meta)
                continue

        row_meta['clean_aadhar'] = clean_aadhar
        row_meta['clean_wallet'] = clean_wallet

        # 2. Check duplicate within CSV file itself
        if clean_aadhar in seen_aadhars_in_csv:
            row_meta['status'] = 'DUPLICATE_IN_FILE'
            row_meta['reason'] = f"Aadhaar {row_meta['aadhar_masked']} occurs multiple times in import file."
            duplicate_rows.append(row_meta)
            parsed_rows.append(row_meta)
            continue
        seen_aadhars_in_csv.add(clean_aadhar)

        if clean_wallet:
            if clean_wallet.lower() in seen_wallets_in_csv:
                row_meta['status'] = 'DUPLICATE_IN_FILE'
                row_meta['reason'] = f"Wallet {clean_wallet} occurs multiple times in import file."
                duplicate_rows.append(row_meta)
                parsed_rows.append(row_meta)
                continue
            seen_wallets_in_csv.add(clean_wallet.lower())

        # 3. Check existing database records
        existing_voter = Voter.objects.filter(aadhar_number=clean_aadhar).first()
        if existing_voter:
            # Check wallet conflict
            if clean_wallet and existing_voter.bound_wallet and existing_voter.bound_wallet.lower() != clean_wallet.lower():
                row_meta['status'] = 'CONFLICT'
                row_meta['reason'] = (
                    f"Aadhaar {row_meta['aadhar_masked']} already exists in database with a different wallet "
                    f"({existing_voter.bound_wallet}). Overwrites are blocked."
                )
                conflict_rows.append(row_meta)
                parsed_rows.append(row_meta)
                continue
            row_meta['status'] = 'VALID_EXISTING'
            row_meta['voter_id'] = existing_voter.pk
            row_meta['reason'] = 'Existing voter record; eligibility will be assigned.'
            valid_existing_rows.append(row_meta)
            parsed_rows.append(row_meta)
            continue

        # Check if new voter's wallet is already bound to someone else
        if clean_wallet:
            other_holder = Voter.objects.filter(bound_wallet__iexact=clean_wallet).first()
            if other_holder:
                row_meta['status'] = 'CONFLICT'
                row_meta['reason'] = f"Wallet {clean_wallet} is already bound to another registered voter."
                conflict_rows.append(row_meta)
                parsed_rows.append(row_meta)
                continue

        row_meta['status'] = 'VALID_NEW'
        row_meta['reason'] = 'Valid new synthetic voter.'
        valid_new_rows.append(row_meta)
        parsed_rows.append(row_meta)

    preview_summary = {
        'total_rows_processed': len(parsed_rows),
        'valid_new_count': len(valid_new_rows),
        'valid_existing_count': len(valid_existing_rows),
        'duplicate_in_file_count': len(duplicate_rows),
        'conflict_count': len(conflict_rows),
        'invalid_count': len(invalid_rows),
        'dry_run': bool(dry_run),
        'preview_rows': [
            {
                'row_num': r['row_num'],
                'name': r['name'],
                'aadhar_masked': r['aadhar_masked'],
                'wallet': r['wallet'],
                'status': r['status'],
                'reason': r['reason'],
            }
            for r in parsed_rows[:50]
        ],
    }

    if dry_run:
        return preview_summary

    # Commit mode: Safe transactional execution
    created_voters = []
    eligibilities_assigned = 0

    with transaction.atomic():
        for r in valid_new_rows:
            v = Voter.objects.create(
                name=r['name'],
                aadhar_number=r['clean_aadhar'],
                bound_wallet=r['clean_wallet'],
                is_synthetic=True,
                has_voted=False,
            )
            created_voters.append(v)
            r['voter_id'] = v.pk

            if target_election and assign_eligibility:
                VoterEligibility.objects.get_or_create(
                    voter=v,
                    election=target_election,
                    defaults={'is_eligible': True, 'assigned_by': actor_user},
                )
                eligibilities_assigned += 1

        for r in valid_existing_rows:
            if target_election and assign_eligibility:
                v = Voter.objects.get(pk=r['voter_id'])
                _, el_created = VoterEligibility.objects.get_or_create(
                    voter=v,
                    election=target_election,
                    defaults={'is_eligible': True, 'assigned_by': actor_user},
                )
                if el_created:
                    eligibilities_assigned += 1

        AdminAuditLog.objects.create(
            actor=actor_user,
            action='SYNTHETIC_VOTERS_IMPORTED',
            target_model='Election' if target_election else 'Voter',
            target_id=str(target_election.pk) if target_election else '',
            details=json.dumps({
                'valid_new_imported': len(created_voters),
                'valid_existing_processed': len(valid_existing_rows),
                'eligibilities_assigned': eligibilities_assigned,
                'election_id': target_election.election_id if target_election else None,
                'conflicts_skipped': len(conflict_rows),
                'duplicates_skipped': len(duplicate_rows),
                'invalid_skipped': len(invalid_rows),
            })
        )

    preview_summary['committed'] = True
    preview_summary['created_voter_ids'] = [v.pk for v in created_voters]
    preview_summary['eligibilities_assigned'] = eligibilities_assigned
    return preview_summary


def get_election_voters_summary(election_db_id):
    """
    Retrieve election voter eligibility roster for administrative review:
    - Never exposes unmasked Aadhaar numbers.
    - Reports eligibility status, has_voted status, and wallet binding.
    """
    election = Election.objects.get(pk=election_db_id)
    eligibilities = (
        VoterEligibility.objects.filter(election=election)
        .select_related('voter', 'assigned_by')
        .order_by('voter__id')
    )

    roster = []
    for el in eligibilities:
        roster.append({
            'voter_id': el.voter.pk,
            'name': el.voter.name,
            'aadhar_masked': mask_aadhar(el.voter.aadhar_number),
            'bound_wallet': el.voter.bound_wallet,
            'is_eligible': el.is_eligible,
            'has_voted': el.has_voted,
            'voted_at': el.voted_at.isoformat() if el.voted_at else None,
            'assigned_at': el.assigned_at.isoformat(),
            'assigned_by': el.assigned_by.username if el.assigned_by else None,
            'is_synthetic': el.voter.is_synthetic,
        })

    return {
        'election_id': election.election_id,
        'title': election.title,
        'status': election.status,
        'total_voters': len(roster),
        'eligible_voters': sum(1 for r in roster if r['is_eligible']),
        'confirmed_voted': sum(1 for r in roster if r['has_voted']),
        'voters': roster,
    }


# ==========================================
# MODULE 8 PHASE 7: DEPLOYMENT READINESS SERVICES
# ==========================================

DVS_CANONICAL_RBAC_GROUPS = (
    'Super Admin',
    'Election Administrator',
    'Election Worker',
    'Auditor',
)


def ensure_dvs_rbac_groups():
    """
    Ensure all four canonical DVS RBAC groups exist in the database.
    Returns dict mapping group name -> Group instance.
    """
    from django.contrib.auth.models import Group
    groups = {}
    for group_name in DVS_CANONICAL_RBAC_GROUPS:
        grp, _ = Group.objects.get_or_create(name=group_name)
        groups[group_name] = grp
    return groups


def initialize_system_superuser(env=None, strict=False):
    """
    Idempotently initialize the initial Django Superuser and assign the DVS 'Super Admin'
    application role group using environment configuration:
    - DJANGO_SUPERUSER_USERNAME
    - DJANGO_SUPERUSER_EMAIL
    - DJANGO_SUPERUSER_PASSWORD
    Requirements enforced:
    - Creates the account ONLY if the configured username does not already exist.
    - NEVER overwrites an existing account's password.
    - Assigns the account to the DVS 'Super Admin' Group (does not rely solely on is_superuser).
    - Never logs, returns, or exposes the password.
    """
    from django.contrib.auth.models import User

    if env is None:
        env = os.environ

    username = str(env.get('DJANGO_SUPERUSER_USERNAME', '') or '').strip()
    email = str(env.get('DJANGO_SUPERUSER_EMAIL', '') or '').strip()
    password = str(env.get('DJANGO_SUPERUSER_PASSWORD', '') or '').strip()

    missing_or_placeholder = (
        not username
        or not password
        or 'replace-with' in username.lower()
        or 'replace-with' in password.lower()
    )

    if missing_or_placeholder:
        msg = (
            "Superuser initialization skipped: DJANGO_SUPERUSER_USERNAME and "
            "DJANGO_SUPERUSER_PASSWORD must be set to non-placeholder values."
        )
        if strict:
            raise ElectionLifecycleError(msg)
        return {
            'status': 'SKIPPED_MISSING_CONFIG',
            'created': False,
            'password_modified': False,
            'message': msg,
        }

    if not email or 'replace-with' in email.lower():
        email = f"{username.lower()}@dvs.local"

    with transaction.atomic():
        groups = ensure_dvs_rbac_groups()
        super_admin_group = groups['Super Admin']

        existing_user = User.objects.select_for_update().filter(username=username).first()
        if existing_user:
            if not existing_user.is_superuser:
                raise ElectionLifecycleError(
                    f"Security conflict: Account '{username}' already exists as a non-superuser. "
                    f"Refusing to silently elevate privileges."
                )

            # Never overwrite an existing superuser account's password
            updated_fields = []
            if not existing_user.is_staff:
                existing_user.is_staff = True
                updated_fields.append('is_staff')
            if not existing_user.is_active:
                existing_user.is_active = True
                updated_fields.append('is_active')
            if updated_fields:
                existing_user.save(update_fields=updated_fields)

            if not existing_user.groups.filter(name='Super Admin').exists():
                existing_user.groups.add(super_admin_group)

            return {
                'status': 'ALREADY_EXISTS',
                'created': False,
                'password_modified': False,
                'username': existing_user.username,
                'email': existing_user.email,
                'super_admin_group_assigned': existing_user.groups.filter(name='Super Admin').exists(),
                'message': f"Superuser '{existing_user.username}' already exists; existing password preserved.",
            }

        if len(password) < 8:
            msg = "Superuser initialization failed: DJANGO_SUPERUSER_PASSWORD must be at least 8 characters."
            if strict:
                raise ElectionLifecycleError(msg)
            return {
                'status': 'INVALID_CONFIG',
                'created': False,
                'password_modified': False,
                'message': msg,
            }

        user = User.objects.create_superuser(
            username=username,
            email=email,
            password=password,
        )
        user.groups.add(super_admin_group)

        AdminAuditLog.objects.create(
            actor=user,
            action='SUPERUSER_INITIALIZED',
            target_model='User',
            target_id=str(user.pk),
            details=json.dumps({
                'username': user.username,
                'email': user.email,
                'is_superuser': True,
                'dvs_group': 'Super Admin',
            }),
        )

        return {
            'status': 'CREATED',
            'created': True,
            'password_modified': True,
            'username': user.username,
            'email': user.email,
            'super_admin_group_assigned': True,
            'message': f"Initialized superuser '{user.username}' with DVS 'Super Admin' group.",
        }


def get_application_health_status(check_blockchain=True):
    """
    Lightweight operational health check for Render and Cloud Run readiness/liveness probes.
    Verifies:
    1. Django application availability.
    2. Database connectivity (`SELECT 1`).
    3. Essential configuration & smart-contract artifact validity.
    4. Blockchain JSON-RPC reachability, Chain ID 31337, and active deployed contract bytecode on-chain.
    Strictly excludes all private keys, database passwords, secret keys, and RPC auth tokens.
    """
    from django.db import connection

    db_healthy = False
    db_vendor = 'unknown'
    try:
        db_vendor = connection.vendor
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            row = cursor.fetchone()
            db_healthy = bool(row and row[0] == 1)
    except Exception:
        db_healthy = False

    config_healthy = False
    try:
        secret_ok = bool(getattr(settings, 'SECRET_KEY', None))
        bc_cfg = validate_blockchain_configuration(is_production=getattr(settings, 'IS_PRODUCTION', False))
        config_healthy = bool(secret_ok and bc_cfg.get('valid') and bc_cfg.get('artifact_loaded'))
    except Exception:
        config_healthy = False

    configured_chain_id = int(getattr(settings, 'CHAIN_ID', 31337) or 31337)
    blockchain_reachable = False
    blockchain_status = 'unchecked'
    live_chain_id = None
    chain_id_valid = None
    active_contract_addr = None
    contract_deployed = False
    contract_bytecode_size = 0

    if check_blockchain:
        try:
            w3 = get_web3_provider(timeout=1)
            blockchain_reachable = bool(w3.is_connected())
            blockchain_status = 'connected' if blockchain_reachable else 'unavailable'
            if blockchain_reachable:
                raw_cid = getattr(w3.eth, 'chain_id', None)
                if isinstance(raw_cid, int):
                    live_chain_id = int(raw_cid)
                    chain_id_valid = (live_chain_id == configured_chain_id)

                candidate_addrs = []
                try:
                    latest_el = (
                        Election.objects.filter(deployment_status='DEPLOYED')
                        .exclude(contract_address='')
                        .order_by('-updated_at', '-id')
                        .first()
                    )
                    if latest_el and Web3.is_address(latest_el.contract_address):
                        candidate_addrs.append(Web3.to_checksum_address(latest_el.contract_address))
                except Exception:
                    pass

                try:
                    from .hardhat_demo import load_demo_deployment_metadata
                    meta = load_demo_deployment_metadata()
                    if meta and meta.get('contract_address') and Web3.is_address(meta['contract_address']):
                        addr_meta = Web3.to_checksum_address(meta['contract_address'])
                        if addr_meta not in candidate_addrs:
                            candidate_addrs.append(addr_meta)
                except Exception:
                    pass

                cfg_addr = str(getattr(settings, 'CONTRACT_ADDRESS', '') or '').strip()
                if cfg_addr and Web3.is_address(cfg_addr):
                    addr_cfg = Web3.to_checksum_address(cfg_addr)
                    if addr_cfg not in candidate_addrs:
                        candidate_addrs.append(addr_cfg)

                for cand_addr in candidate_addrs:
                    try:
                        code = w3.eth.get_code(cand_addr)
                        if isinstance(code, (bytes, bytearray)) and len(code) > 0:
                            active_contract_addr = cand_addr
                            contract_deployed = True
                            contract_bytecode_size = len(code)
                            break
                    except Exception:
                        continue
                if not active_contract_addr and candidate_addrs:
                    active_contract_addr = candidate_addrs[0]
        except Exception:
            blockchain_reachable = False
            blockchain_status = 'unavailable'

    app_healthy = bool(db_healthy and config_healthy)

    return {
        'status': 'ok' if app_healthy else 'error',
        'http_status': 200 if app_healthy else 503,
        'application': 'available',
        'environment': getattr(settings, 'DJANGO_ENV', 'development'),
        'database': {
            'status': 'ok' if db_healthy else 'error',
            'engine': db_vendor,
        },
        'configuration': {
            'status': 'ok' if config_healthy else 'error',
        },
        'blockchain': {
            'status': blockchain_status,
            'reachable': blockchain_reachable,
            'configured_chain_id': configured_chain_id,
            'live_chain_id': live_chain_id,
            'chain_id_valid': chain_id_valid,
            'contract_address': active_contract_addr,
            'contract_deployed': contract_deployed,
            'contract_bytecode_size': contract_bytecode_size,
        },
    }


# ==========================================
# TASK 8: CREATE ELECTIONS WIZARD & AUTOMATIC LIFECYCLE SERVICES
# ==========================================

WIZARD_ELECTION_TYPE_CHOICES = [
    ('ELECTION', 'Election'),
    ('POLL', 'Poll'),
    ('REFERENDUM', 'Referendum'),
]


def _ensure_aware_datetime(dt):
    """Ensure a datetime object is timezone-aware in the configured Django current timezone."""
    if dt is None:
        return None
    if timezone.is_naive(dt):
        return timezone.make_aware(dt, timezone.get_current_timezone())
    return dt


def compute_election_lifecycle_status(election, now=None):
    """
    Determine an election's lifecycle status automatically from the server's current time:
    1. Before start_datetime (now < start_datetime): 'SCHEDULED' (voting unavailable, not publicly visible).
    2. At or after start_datetime and before end_datetime (start_datetime <= now < end_datetime): 'ACTIVE'.
    3. At or after end_datetime (now >= end_datetime): 'CLOSED' (completed).
    Preserves 'DRAFT' and 'FINALIZED' states, and respects manually closed elections.
    """
    if not election:
        return 'DRAFT'
    raw_status = str(getattr(election, 'status', 'DRAFT') or 'DRAFT').upper()
    if raw_status in ('DRAFT', 'FINALIZED'):
        return raw_status

    now_dt = _ensure_aware_datetime(now or timezone.now())
    start_dt = _ensure_aware_datetime(getattr(election, 'start_datetime', None))
    end_dt = _ensure_aware_datetime(getattr(election, 'end_datetime', None))

    if start_dt and end_dt:
        if now_dt < start_dt:
            return 'SCHEDULED'
        if now_dt >= end_dt:
            return 'CLOSED'
        return 'ACTIVE'

    return raw_status


def is_election_voting_open(election, now=None):
    """
    Authoritative backend check for whether voting is currently open for an election:
    - False if election is None, DRAFT, CLOSED, or FINALIZED.
    - False if start_datetime or end_datetime is missing.
    - False before start_datetime (now < start_datetime).
    - True at or after start_datetime and before end_datetime (start_datetime <= now < end_datetime).
    - False at or after end_datetime (now >= end_datetime).
    - If an on-chain smart contract is deployed/attached, also checks on-chain lock flags.
    """
    if not election:
        return False
    now_dt = _ensure_aware_datetime(now or timezone.now())
    start_dt = _ensure_aware_datetime(getattr(election, 'start_datetime', None))
    end_dt = _ensure_aware_datetime(getattr(election, 'end_datetime', None))
    if not start_dt or not end_dt:
        return False

    if compute_election_lifecycle_status(election, now=now_dt) != 'ACTIVE':
        return False

    if not (start_dt <= now_dt < end_dt):
        return False

    if getattr(election, 'contract_address', ''):
        if not (getattr(election, 'candidates_locked_on_chain', False) and getattr(election, 'voting_window_locked_on_chain', False)):
            return False

    return True


def is_election_publicly_visible(election, now=None):
    """
    Determine whether an election should be visible on public pages and public APIs:
    - DRAFT elections are never publicly visible.
    - Elections whose start_datetime is in the future (now < start_datetime) must remain
      unavailable and not visible until their start_datetime arrives.
    - Active (start_datetime <= now < end_datetime) and Completed (now >= end_datetime or CLOSED/FINALIZED)
      elections are publicly visible.
    """
    if not election:
        return False
    raw_status = str(getattr(election, 'status', 'DRAFT') or 'DRAFT').upper()
    if raw_status == 'DRAFT':
        return False

    now_dt = _ensure_aware_datetime(now or timezone.now())
    start_dt = _ensure_aware_datetime(getattr(election, 'start_datetime', None))
    if start_dt and now_dt < start_dt:
        return False

    effective_status = compute_election_lifecycle_status(election, now=now_dt)
    return effective_status in ('ACTIVE', 'CLOSED', 'FINALIZED')


def sync_election_lifecycle_state(election=None, now=None):
    """
    Synchronize persisted Election.status with the server's current time so that:
    - Elections before start_datetime are in 'SCHEDULED'.
    - Elections with start_datetime <= now < end_datetime transition to 'ACTIVE' automatically.
    - Elections with now >= end_datetime transition to 'CLOSED' automatically even if no admin visits.
    """
    now_dt = _ensure_aware_datetime(now or timezone.now())
    if election is not None:
        elections = [election] if getattr(election, 'pk', None) else []
    else:
        elections = list(
            Election.objects.exclude(status__in=['DRAFT', 'FINALIZED']).filter(
                start_datetime__isnull=False,
                end_datetime__isnull=False,
            )
        )

    for el in elections:
        if el.status in ('DRAFT', 'FINALIZED'):
            continue
        target_status = compute_election_lifecycle_status(el, now=now_dt)
        if el.status != target_status:
            el.status = target_status
            el.save(update_fields=['status', 'updated_at'])


def validate_wizard_election_details(title, description, election_type, start_datetime_raw, end_datetime_raw):
    """
    Validate Step 1 (Election Details) of the Create Elections Wizard:
    - All fields are required.
    - Election type must be one of the three supported choices: Election, Poll, Referendum.
      Rejects Immediate, Scheduled, Draft, or any unsupported value.
    - Start and end datetimes must be valid and end_datetime > start_datetime.
    """
    from django.utils.dateparse import parse_datetime

    clean_title = str(title or '').strip()
    if not clean_title:
        raise ElectionLifecycleError("Election name is required.")
    if len(clean_title) > 200:
        raise ElectionLifecycleError("Election name cannot exceed 200 characters.")

    clean_description = str(description or '').strip()
    if not clean_description:
        raise ElectionLifecycleError("Election description is required.")

    raw_type = str(election_type or '').strip()
    upper_type = raw_type.upper()
    if upper_type in ('IMMEDIATE', 'SCHEDULED', 'DRAFT'):
        raise ElectionLifecycleError("Invalid election type. Choose Election, Poll, or Referendum.")

    type_map = dict(WIZARD_ELECTION_TYPE_CHOICES)
    if upper_type not in type_map:
        raise ElectionLifecycleError("Select a valid election type (Election, Poll, or Referendum).")

    raw_start = str(start_datetime_raw or '').strip()
    raw_end = str(end_datetime_raw or '').strip()
    if not raw_start:
        raise ElectionLifecycleError("Voting start date and time is required.")
    if not raw_end:
        raise ElectionLifecycleError("Voting end date and time is required.")

    start_dt = parse_datetime(raw_start)
    end_dt = parse_datetime(raw_end)
    if not start_dt or not end_dt:
        raise ElectionLifecycleError("Enter valid voting start and end dates and times.")

    start_dt = _ensure_aware_datetime(start_dt)
    end_dt = _ensure_aware_datetime(end_dt)

    if end_dt <= start_dt:
        raise ElectionLifecycleError("Voting end date and time must be later than voting start date and time.")

    return {
        'title': clean_title,
        'description': clean_description,
        'election_type': upper_type,
        'election_type_label': type_map[upper_type],
        'start_datetime_iso': start_dt.isoformat(),
        'end_datetime_iso': end_dt.isoformat(),
        'start_datetime_input': raw_start,
        'end_datetime_input': raw_end,
    }


def validate_and_store_wizard_candidate_image(uploaded_file):
    """
    Validate an uploaded party symbol image and store it once using Django's default_storage:
    - Validates file presence, size <= 5 MB, and image integrity (PNG, JPEG, WEBP).
    - Stores under candidate_symbols/%Y/%m/<unique_name> and returns (relative_path, url).
    """
    import secrets
    from PIL import Image
    from django.core.files.storage import FileSystemStorage
    storage = FileSystemStorage(location=settings.MEDIA_ROOT, base_url=settings.MEDIA_URL)

    if not uploaded_file:
        raise ElectionLifecycleError("Party symbol image is required for each candidate.")

    if getattr(uploaded_file, 'size', 0) <= 0:
        raise ElectionLifecycleError("Uploaded party symbol image file is empty.")

    if uploaded_file.size > 5 * 1024 * 1024:
        raise ElectionLifecycleError("Party symbol image must be 5 MB or smaller.")

    allowed_content_types = ('image/png', 'image/jpeg', 'image/jpg', 'image/webp')
    content_type = getattr(uploaded_file, 'content_type', '') or ''
    if content_type and content_type.lower() not in allowed_content_types:
        raise ElectionLifecycleError("Party symbol image must be a PNG, JPG, or WEBP file.")

    try:
        uploaded_file.seek(0)
        probe = Image.open(uploaded_file)
        img_format = (probe.format or '').upper()
        probe.verify()
        uploaded_file.seek(0)
    except Exception as exc:
        raise ElectionLifecycleError("The uploaded party symbol is not a valid image file.") from exc

    if img_format not in ('PNG', 'JPEG', 'WEBP'):
        raise ElectionLifecycleError("Party symbol image must be PNG, JPG, or WEBP format.")

    ext_map = {'PNG': '.png', 'JPEG': '.jpg', 'WEBP': '.webp'}
    ext = ext_map.get(img_format, '.png')
    now = timezone.now()
    rel_dir = f"candidate_symbols/{now:%Y/%m}"
    filename = f"{rel_dir}/symbol_{secrets.token_hex(8)}{ext}"
    saved_name = storage.save(filename, uploaded_file)
    return saved_name, storage.url(saved_name)


def validate_and_include_wizard_voters(raw_text, existing_included_ids=None):
    """
    Validate Step 3 (Include Voters) multiline Voter ID input:
    - Accepts only existing registered 12-digit numeric Voter IDs.
    - Rejects non-12-digit IDs, unknown IDs, duplicate IDs within the submission,
      and voters already included in this election.
    - Does NOT create new global Voter records.
    """
    existing_ids = list(existing_included_ids or [])
    existing_set = set(existing_ids)

    text = str(raw_text or '')
    lines = text.splitlines()
    non_empty_lines = [(idx + 1, line.strip()) for idx, line in enumerate(lines) if line.strip()]

    if not non_empty_lines:
        return {
            'included_count': 0,
            'rejected_count': 1,
            'newly_included_voters': [],
            'rejected_records': [
                {
                    'line_number': 1,
                    'voter_id': '',
                    'reason': 'Enter at least one 12-digit Voter ID.',
                }
            ],
            'updated_included_ids': existing_ids,
        }

    newly_included_voters = []
    rejected_records = []
    seen_in_submission = set()
    data_rows_processed = 0

    for row_idx, (line_num, line) in enumerate(non_empty_lines):
        norm_header = re.sub(r'[^a-z0-9]', '', line.lower())
        if row_idx == 0 and norm_header in ('voterid', 'voterids', 'id', 'aadhar', 'aadhaar', 'aadharnumber'):
            continue

        data_rows_processed += 1

        if not re.fullmatch(r'^\d{12}$', line):
            rejected_records.append({
                'line_number': line_num,
                'voter_id': line,
                'reason': 'Invalid Voter ID (must be 12 numeric digits).',
            })
            continue

        if line in seen_in_submission:
            rejected_records.append({
                'line_number': line_num,
                'voter_id': line,
                'reason': 'Duplicate Voter ID in this submission.',
            })
            continue
        seen_in_submission.add(line)

        if line in existing_set:
            rejected_records.append({
                'line_number': line_num,
                'voter_id': line,
                'reason': 'Voter is already included in this election.',
            })
            continue

        voter = Voter.objects.filter(aadhar_number=line, status='ACTIVE').first()
        if not voter:
            rejected_records.append({
                'line_number': line_num,
                'voter_id': line,
                'reason': 'Voter ID does not exist in the registered voter database.',
            })
            continue

        existing_ids.append(voter.aadhar_number)
        existing_set.add(voter.aadhar_number)
        newly_included_voters.append({
            'voter_id': voter.aadhar_number,
            'name': voter.name,
            'phone': voter.phone,
        })

    if data_rows_processed == 0:
        rejected_records.append({
            'line_number': 1,
            'voter_id': '',
            'reason': 'Enter at least one 12-digit Voter ID.',
        })

    return {
        'included_count': len(newly_included_voters),
        'rejected_count': len(rejected_records),
        'newly_included_voters': newly_included_voters,
        'rejected_records': rejected_records,
        'updated_included_ids': existing_ids,
    }


def get_included_voters_details(included_voter_ids):
    """Retrieve ordered Voter records (Voter ID, Name, Phone) from the central Voter table."""
    ids = list(included_voter_ids or [])
    if not ids:
        return []
    voter_map = {
        v.aadhar_number: v
        for v in Voter.objects.filter(aadhar_number__in=ids, status='ACTIVE')
    }
    result = []
    for vid in ids:
        v = voter_map.get(vid)
        if v:
            result.append({
                'id': v.pk,
                'voter_id': v.aadhar_number,
                'name': v.name,
                'phone': v.phone,
            })
    return result


def create_election_from_wizard_state(wizard_state, actor_user):
    """
    Validate the complete 4-step wizard state and atomically create:
    1. Election with status automatically determined from server's current time against [start_datetime, end_datetime).
    2. Candidate records with their single stored symbol_image reference.
    3. Election-specific VoterEligibility records.
    """
    from django.core.files.storage import FileSystemStorage
    from django.db import models
    from django.utils.dateparse import parse_datetime
    storage = FileSystemStorage(location=settings.MEDIA_ROOT, base_url=settings.MEDIA_URL)

    if not isinstance(wizard_state, dict):
        raise ElectionLifecycleError("Election wizard session data is missing or invalid.")

    details = wizard_state.get('details') or {}
    validated_details = validate_wizard_election_details(
        title=details.get('title'),
        description=details.get('description'),
        election_type=details.get('election_type'),
        start_datetime_raw=details.get('start_datetime_input') or details.get('start_datetime_iso'),
        end_datetime_raw=details.get('end_datetime_input') or details.get('end_datetime_iso'),
    )

    candidates_data = wizard_state.get('candidates') or []
    if not candidates_data:
        raise ElectionLifecycleError("At least one candidate is required to create an election.")

    validated_candidates = []
    for idx, cand in enumerate(candidates_data, start=1):
        c_name = str(cand.get('name') or '').strip()
        c_party = str(cand.get('party') or '').strip()
        c_img_name = str(cand.get('symbol_image_name') or '').strip()
        if not c_name:
            raise ElectionLifecycleError(f"Candidate #{idx} is missing a candidate name.")
        if len(c_name) > 150:
            raise ElectionLifecycleError(f"Candidate #{idx} name cannot exceed 150 characters.")
        if not c_party:
            raise ElectionLifecycleError(f"Candidate #{idx} is missing a party name.")
        if len(c_party) > 100:
            raise ElectionLifecycleError(f"Candidate #{idx} party name cannot exceed 100 characters.")
        if not c_img_name or not storage.exists(c_img_name):
            raise ElectionLifecycleError(f"Candidate #{idx} is missing a valid party symbol image.")
        validated_candidates.append({
            'candidate_id_num': idx,
            'name': c_name,
            'party': c_party,
            'symbol_image_name': c_img_name,
        })

    included_ids = list(wizard_state.get('included_voter_ids') or [])
    if not included_ids:
        raise ElectionLifecycleError("At least one registered voter must be included to create an election.")

    seen_vids = set()
    voters_to_include = []
    for vid in included_ids:
        clean_vid = str(vid or '').strip()
        if not re.fullmatch(r'^\d{12}$', clean_vid):
            raise ElectionLifecycleError(f"Included Voter ID '{clean_vid}' is not a valid 12-digit Voter ID.")
        if clean_vid in seen_vids:
            raise ElectionLifecycleError(f"Duplicate Voter ID '{clean_vid}' found in included voters.")
        seen_vids.add(clean_vid)
        voter_obj = Voter.objects.filter(aadhar_number=clean_vid, status='ACTIVE').first()
        if not voter_obj:
            raise ElectionLifecycleError(f"Voter ID '{clean_vid}' does not exist in the active voter database.")
        voters_to_include.append(voter_obj)

    start_dt = _ensure_aware_datetime(parse_datetime(validated_details['start_datetime_iso']))
    end_dt = _ensure_aware_datetime(parse_datetime(validated_details['end_datetime_iso']))
    now_dt = timezone.now()

    if now_dt < start_dt:
        initial_status = 'SCHEDULED'
    elif now_dt < end_dt:
        initial_status = 'ACTIVE'
    else:
        initial_status = 'CLOSED'

    with transaction.atomic():
        max_id = Election.objects.select_for_update().aggregate(m=models.Max('election_id'))['m'] or 2025
        election_id_num = int(max_id) + 1

        election = Election.objects.create(
            election_id=election_id_num,
            title=validated_details['title'],
            description=validated_details['description'],
            election_type=validated_details['election_type'],
            commencement_mode='SCHEDULED',
            start_datetime=start_dt,
            end_datetime=end_dt,
            status=initial_status,
            deployment_status='NOT_DEPLOYED',
            result_publication_policy='PROVISIONAL_AFTER_CLOSE',
            created_by=actor_user if (actor_user and getattr(actor_user, 'is_authenticated', False)) else None,
        )

        for cand_item in validated_candidates:
            Candidate.objects.create(
                election=election,
                candidate_id_num=cand_item['candidate_id_num'],
                name=cand_item['name'],
                symbol=cand_item['party'],
                symbol_image=cand_item['symbol_image_name'],
                display_order=cand_item['candidate_id_num'],
                is_active=True,
                is_synced_on_chain=False,
            )

        for voter_obj in voters_to_include:
            VoterEligibility.objects.update_or_create(
                election=election,
                voter=voter_obj,
                defaults={
                    'is_eligible': True,
                    'assigned_by': actor_user if (actor_user and getattr(actor_user, 'is_authenticated', False)) else None,
                },
            )

        if actor_user and getattr(actor_user, 'is_authenticated', False):
            AdminAuditLog.objects.create(
                actor=actor_user,
                action='ELECTION_CREATED',
                target_model='Election',
                target_id=str(election.pk),
                details=json.dumps({
                    'election_id': election.election_id,
                    'title': election.title,
                    'election_type': election.election_type,
                    'status': election.status,
                    'candidates_count': len(validated_candidates),
                    'eligible_voters_count': len(voters_to_include),
                }),
            )

    # Automatically deploy and initialize EVoting contract on local Hardhat node if reachable
    try:
        w3 = get_web3_provider(timeout=2)
        if w3.is_connected() and isinstance(getattr(w3.eth, 'chain_id', None), int) and int(w3.eth.chain_id) == 31337:
            from .simple_voting import _sync_hardhat_block_timestamp
            _sync_hardhat_block_timestamp(w3)
            abi, bytecode, _ = load_contract_artifact()
            deployer, deployer_key = _resolve_deployer_account_and_key(w3)
            ctor_abi = next((item for item in abi if item.get('type') == 'constructor'), None)
            ctor_inputs = (ctor_abi.get('inputs') or []) if ctor_abi else []
            ContractFactory = w3.eth.contract(abi=abi, bytecode=bytecode)
            authority = getattr(settings, 'ELECTION_AUTHORITY_ADDRESS', deployer)
            ctor_call = (
                ContractFactory.constructor(authority, election.election_id)
                if len(ctor_inputs) >= 2
                else ContractFactory.constructor()
            )
            tx_hash, receipt = _execute_deployer_tx(w3, ctor_call, deployer=deployer, deployer_key=deployer_key, timeout=60)
            if receipt and receipt.status == 1 and receipt.contractAddress:
                contract_addr = Web3.to_checksum_address(receipt.contractAddress)
                contract_instance = w3.eth.contract(address=contract_addr, abi=abi)
                for cand in election.candidates.filter(is_active=True).order_by('display_order', 'candidate_id_num'):
                    _, c_rec = _execute_deployer_tx(
                        w3,
                        contract_instance.functions.addCandidate(cand.candidate_id_num, cand.name, cand.symbol),
                        deployer=deployer,
                        deployer_key=deployer_key,
                        timeout=60,
                    )
                    if c_rec and c_rec.status == 1:
                        cand.is_synced_on_chain = True
                        cand.save(update_fields=['is_synced_on_chain'])

                start_ts = int(start_dt.timestamp())
                end_ts = int(end_dt.timestamp())
                if initial_status == 'ACTIVE':
                    try:
                        latest_blk = w3.eth.get_block('latest')
                        if latest_blk and 'timestamp' in latest_blk:
                            start_ts = min(start_ts, int(latest_blk['timestamp']))
                    except Exception:
                        pass
                _execute_deployer_tx(
                    w3,
                    contract_instance.functions.setVotingWindow(start_ts, end_ts),
                    deployer=deployer,
                    deployer_key=deployer_key,
                    timeout=60,
                )
                abi_fn_names = {item.get('name') for item in abi if item.get('type') == 'function'}
                if 'lockVotingWindow' in abi_fn_names:
                    _execute_deployer_tx(
                        w3,
                        contract_instance.functions.lockVotingWindow(),
                        deployer=deployer,
                        deployer_key=deployer_key,
                        timeout=60,
                    )
                _execute_deployer_tx(
                    w3,
                    contract_instance.functions.lockCandidates(),
                    deployer=deployer,
                    deployer_key=deployer_key,
                    timeout=60,
                )
                if initial_status == 'ACTIVE':
                    _sync_hardhat_block_timestamp(w3)
                    open_fn = (
                        contract_instance.functions.setElectionOpen(True)
                        if 'setElectionOpen' in abi_fn_names
                        else contract_instance.functions.openElection()
                    )
                    _execute_deployer_tx(
                        w3,
                        open_fn,
                        deployer=deployer,
                        deployer_key=deployer_key,
                        timeout=60,
                    )

                deployed_code = w3.eth.get_code(contract_addr)
                bytecode_hash = '0x' + Web3.keccak(deployed_code).hex()
                tx_hash_hex = tx_hash.hex() if isinstance(tx_hash, bytes) else str(tx_hash)
                if not tx_hash_hex.startswith('0x'):
                    tx_hash_hex = '0x' + tx_hash_hex

                with transaction.atomic():
                    ContractDeployment.objects.create(
                        election=election,
                        contract_address=contract_addr,
                        chain_id=31337,
                        deployment_tx_hash=tx_hash_hex,
                        deployment_block_number=receipt.blockNumber,
                        deployed_bytecode_hash=bytecode_hash,
                        authority_address=authority,
                        is_active_deployment=True,
                        is_historical_legacy=False,
                    )
                    election.contract_address = contract_addr
                    election.authority_address = authority
                    election.chain_id = 31337
                    election.deployment_tx_hash = tx_hash_hex
                    election.deployment_block_number = receipt.blockNumber
                    election.deployed_bytecode_hash = bytecode_hash
                    election.deployment_status = 'DEPLOYED'
                    election.candidates_locked_on_chain = True
                    election.voting_window_locked_on_chain = True
                    election.save(update_fields=[
                        'contract_address', 'authority_address', 'chain_id',
                        'deployment_tx_hash', 'deployment_block_number', 'deployed_bytecode_hash',
                        'deployment_status', 'candidates_locked_on_chain', 'voting_window_locked_on_chain',
                        'updated_at',
                    ])
    except Exception as exc:
        logger.warning(f"Optional automatic contract deployment during wizard election creation skipped: {exc}")

    return election



