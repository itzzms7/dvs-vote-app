from functools import wraps
from django.contrib import messages
from django.shortcuts import redirect
from django.http import HttpResponseForbidden, JsonResponse
from .models import Election, ElectionAdminAssignment


def get_user_portal_role(user):
    """
    Determine the primary portal role for an authenticated staff user:
    - 'SUPER_ADMIN'
    - 'ELECTION_ADMIN'
    - 'ELECTION_WORKER'
    - 'AUDITOR'
    - None (unauthenticated or no administrative/worker/auditor role)
    """
    if not user or not user.is_authenticated:
        return None

    if user.is_superuser or user.groups.filter(name='Super Admin').exists():
        return 'SUPER_ADMIN'

    user_groups = set(user.groups.values_list('name', flat=True))
    assignment_roles = set(
        ElectionAdminAssignment.objects.filter(user=user).values_list('role', flat=True)
    )

    if 'Election Administrator' in user_groups or 'ELECTION_ADMIN' in assignment_roles:
        return 'ELECTION_ADMIN'
    if 'Election Worker' in user_groups or 'ELECTION_WORKER' in assignment_roles:
        return 'ELECTION_WORKER'
    if 'Auditor' in user_groups or 'AUDITOR' in assignment_roles:
        return 'AUDITOR'
    if user.is_staff:
        return 'ELECTION_ADMIN'

    return None


def get_user_election_role(user, election):
    """
    Determine a user's effective role for a specific Election instance:
    - 'SUPER_ADMIN'
    - 'ELECTION_ADMIN'
    - 'ELECTION_WORKER'
    - 'AUDITOR'
    - None
    Note: Election Workers and Election Administrators NEVER gain access to an
    election merely by belonging to a Django group; they must hold an explicit
    ElectionAdminAssignment for that election.
    """
    if not user or not user.is_authenticated or not election:
        return None

    if user.is_superuser or user.groups.filter(name='Super Admin').exists():
        return 'SUPER_ADMIN'

    assignment = ElectionAdminAssignment.objects.filter(election=election, user=user).first()
    if assignment:
        return assignment.role

    if user.groups.filter(name='Auditor').exists():
        return 'AUDITOR'

    return None


def has_election_permission(user, election, action='read'):
    """
    Check if a user has permission ('read', 'worker_write', or 'write') on a specific Election object.
    - Super Admins have global permission across all actions.
    - Election Administrators have 'read', 'worker_write', and 'write' on assigned elections.
    - Election Workers have 'read' and 'worker_write' (voter registration & identity staging only)
      strictly on assigned elections; they NEVER have 'write' permission.
    - Auditors have strictly 'read' permission on assigned elections (or global read-only if in Auditor group).
    """
    effective_role = get_user_election_role(user, election)
    if not effective_role:
        return False

    if effective_role == 'SUPER_ADMIN':
        return True

    if action == 'read':
        return effective_role in ('ELECTION_ADMIN', 'ELECTION_WORKER', 'AUDITOR')
    elif action == 'worker_write':
        return effective_role in ('ELECTION_ADMIN', 'ELECTION_WORKER')
    elif action == 'write':
        return effective_role == 'ELECTION_ADMIN'

    return False


def role_required(allowed_roles=None):
    """
    Decorator to enforce system-wide Role-Based Access Control (RBAC).
    Checks if user is authenticated and belongs to allowed_roles or is superuser.
    Enforces read-only method restriction if the user only holds the Auditor role.
    """
    if allowed_roles is None:
        allowed_roles = []

    def decorator(view_func):
        @wraps(view_func)
        def _wrapped_view(request, *args, **kwargs):
            is_api = request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.path.startswith('/api/')
            if not request.user.is_authenticated:
                if is_api:
                    return JsonResponse({'error': 'Authentication Required: Please log in as administrator.'}, status=401)
                if hasattr(request, '_messages'):
                    messages.error(request, 'Please log in to access the administrator dashboard.')
                return redirect('Admin')

            if request.user.is_superuser:
                return view_func(request, *args, **kwargs)

            user_groups = set(request.user.groups.values_list('name', flat=True))
            if any(role in user_groups for role in allowed_roles):
                is_write_role = (
                    'Super Admin' in user_groups
                    or 'Election Administrator' in user_groups
                    or 'Election Worker' in user_groups
                )
                if not is_write_role and 'Auditor' in user_groups and request.method not in ('GET', 'HEAD', 'OPTIONS'):
                    if is_api:
                        return JsonResponse({'error': 'Permission Denied: Auditor role is strictly read-only.'}, status=403)
                    return HttpResponseForbidden('<h1>403 Forbidden</h1><p>Auditor role is strictly read-only.</p>')
                return view_func(request, *args, **kwargs)

            if is_api:
                return JsonResponse({'error': 'Permission Denied: Insufficient administrative privileges.'}, status=403)

            return HttpResponseForbidden('<h1>403 Forbidden</h1><p>You do not have administrative permission to access this page.</p>')

        return _wrapped_view
    return decorator


def election_permission_required(action='read'):
    """
    Decorator to enforce election-level permissions on views accepting election_id or pk.
    - When action='read' and HTTP method is non-safe (POST, PUT, PATCH, DELETE), upgrades required action to 'write'.
    - When action='worker_write', permits Super Admin, assigned Election Admin, and assigned Election Worker.
    - When action='write', permits only Super Admin and assigned Election Admin.
    """
    def decorator(view_func):
        @wraps(view_func)
        def _wrapped_view(request, *args, **kwargs):
            is_api = request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.path.startswith('/api/')
            if not request.user.is_authenticated:
                if is_api:
                    return JsonResponse({'error': 'Authentication Required: Please log in.'}, status=401)
                return redirect('Admin')

            election_id = kwargs.get('election_id') or kwargs.get('pk') or request.GET.get('election_id') or request.POST.get('election_id')
            if not election_id and request.content_type == 'application/json':
                try:
                    import json
                    body = json.loads(request.body.decode('utf-8'))
                    election_id = body.get('election_id')
                except Exception:
                    pass
            if not election_id:
                election_id = 2026

            election = Election.objects.filter(election_id=election_id).first() or Election.objects.filter(pk=election_id).first()
            if not election:
                if is_api:
                    return JsonResponse({'error': 'Election Not Found'}, status=404)
                return HttpResponseForbidden('<h1>404 Not Found</h1><p>The requested election does not exist.</p>')

            if request.method not in ('GET', 'HEAD', 'OPTIONS') and action == 'read':
                effective_action = 'write'
            else:
                effective_action = action

            if not has_election_permission(request.user, election, action=effective_action):
                if is_api:
                    return JsonResponse({'error': f'Permission Denied: Lacks {effective_action} privileges on this election.'}, status=403)
                return HttpResponseForbidden('<h1>403 Forbidden</h1><p>You are not authorized to perform this action on this election.</p>')

            request.election = election
            request.election_role = get_user_election_role(request.user, election)
            return view_func(request, *args, **kwargs)

        return _wrapped_view
    return decorator
